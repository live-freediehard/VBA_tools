/******************************************************************************
**
**      Revision History
**
**      $Log:   O:/GTS/server/src/qs/batch/inc/qs_bautobkoff.hv_  $
 * 
 *    Rev 1.0   Jul 19 1996 17:57:42   rajuk
 * Checked in from initial workfile by PVCS Version Manager Project Assistant.
**
*******************************************************************************/
/******************************************************************************
*
*M      System:         Global Trade System
*M
*M      File Name:      qs_bautobkoff.h
*M      Description:    Class definition for queue AUTO BOOKOFF
*M      Type:           C++ include file
*M
*M      Process:        Nil
*M      Input:          Nil
*M      Output:         Nil
*M      Return:         Nil
*
*H      Modification Date:
*H      Modified By:
*H      Changes:
*H
*H      Creation Date:  Thu Oct 20 09:32:12 1994
*H      Written By:     C. S. Wong
*H      Process:        Nil
*H      Input:          Nil
*H      Output:         Nil
*H      Return:         Nil
*
******************************************************************************/

#ifndef _QS_BAUTOBKOF_H
#define _QS_BAUTOBKOF_H

#include "trace.h"

#ifndef _QS_BASE_DEF
#include "qs_base.h"
#endif
 
#define _SQL_AUTOBKOF_SEL       "exec GTDPEND1..USP_BAUTOBKOFF_SEL "
#define _SQL_AUTOBKOF_BAT       "exec GTDPEND1..USP_BAUTOBKOFF "

class QS_BAUTOBKOFF: public QS {
        CString         pQsp;
        CString         proc_unit;
        CString         proc_dt;
public:
         QS_BAUTOBKOFF() {};
        ~QS_BAUTOBKOFF();
        void SetUp();
//      virtual QS_BOOL      Run();             // The interface for queue 
                                                // server manager to run the 
                                                // Queue Server
        virtual QS_RETCODE   ProcCurEntry();    // Process the current entry of
        virtual void    PrintOn();      
};

#endif
