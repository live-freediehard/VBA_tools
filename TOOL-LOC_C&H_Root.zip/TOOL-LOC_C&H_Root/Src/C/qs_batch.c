/******************************************************************************
**
**      Revision History
**
**      $Log:   O:\GTS\SERVER\src\qs\batch\src\qs_batch.cv_  $
 *
 *    Rev 1.10   Jan 13 1998 16:56:06   Behp
 * 113EY6G
 * Fix extra control M
 *
 *    Rev 1.9   Jan 05 1998 18:14:32   Behp
 * 1051MRG
 * Unified Version
 *
 *    Rev 1.8   Sep 16 1997 18:49:32   kwand
 * Bug Item #: 916172C
 * Add Queue Server QS_BILLG_Q
 *
 *    Rev 1.7   Aug 20 1997 12:42:10   kwand
 * Bug Item #: 818D187
 * Support new error handling options
 *
 *    Rev 1.6   16 Jul 1997 10:23:16   hsih
 * 711YZY6
 * o generate weekends into the holiday table base on local currency
 *
 *    Rev 1.5   04 Mar 1997 11:13:06   maaa
 * BUG# 205NDZA
 * First version
 *
 *
 *    Rev 1.4   11 Feb 1997 17:11:56   huac
 * For billing tracking end of day
 *
 *    Rev 1.3   Feb 01 1997 16:22:42   kwand
 * Bug Tracking No.: 113CTJA
 *
 *    Rev 1.2   Jan 22 1997 12:42:18   kwand
 * Bug Tracking No.: C11EJN6
 * Accept -t as an option command line argument for tracer processing.
 *
 *    Rev 1.1   Oct 03 1996 13:23:20   kwand
 * Bug Tracking No.: A039E55
 * Move online report queue server from 'batch' to 'online' module
 *
 *    Rev 1.0   Jul 19 1996 17:57:58   rajuk
 * Checked in from initial workfile by PVCS Version Manager Project Assistant.
**
*******************************************************************************/

#include        "trace.h"
#include        "qs_btracer.h"
#include        "qs_bhousekeep.h"
#include        "qs_bfeeamort.h"
#include        "qs_bfeecapt.h"
#include        "qs_btickler.h"
#include        "qs_bautobkoff.h"
#include		"qs_bautomtr.h"
#include		"qs_bautosetl.h"
#include        "qs_bautoext_rej.h"
#include        "qs_bautoext_rls.h"
#include        "qs_bautoext_gen.h"
#include        "qs_bautoliab.h"
#include        "qs_bautoaval.h"
#include	"qs_bprexprn.h"
#include        "qs_bbilling_chrg.h"
#include        "qs_bbilling_amort.h"
#include		"qs_bbilling_recv.h"
#include        "qs_bbilling_ap.h"
#include        "qs_bautorein.h"
#include        "qs_batch_errs.h"
#include        "qs_bbillg_fee.h"
#include        "qs_bbillg_adj.h"
#include        "qs_bbillg_ae.h"
#include        "qs_bbillg_trck.h"
#include        "qs_weekend.h"
#include        "qs_bbillg_q.h"
#include        "qs_bautoclosstal.h"
#include        "qs_bswitch_acct.h"
#include        "qs_bautowof.h"
#include "qs_bautochrg.h"
#include      "qs_blcbac_eval.h"
#include		"qs_btracer_gen.h"
#include "qs_bfxreval.h"
#include "qs_binq_reload_q.h"
#include "qs_bautosdip.h"
#include "qs_bpdn_takedown.h"
#include "qs_predebit_not.h"

#ifdef GTS_NY
#include        "qs_bprooftape_upd.h"
#include		"qs_brebate_upd.h"
#else
#include        "qs_bloanbal_upd.h"
#endif

//Ray testing
#include "qs_bauto_wp_gen_ny_alps.h"

void
usage(char* pgm_nm, char* mod_nm)
{
        cout << "Usage: " << pgm_nm << " <name> -u<proc_unit>" << endl
                << "\t[-S<server>] [-U<user>] [-P<passwd>]"
                << " [-d<proc_dt>] [-e<error handling mode>]";

        if ( ! strcmp(mod_nm, "tracer") )
                cout << " [-t<tracer_dt>]";
#ifdef GTS_NY
	cout << endl << "Where" << endl << "   <name>"
		<< "\ttracer, feeamort, feecapt, tickler, autobkoff, automtr, autosetl, autowof, autochrg, sdip, autoext_rej, autoext_rls, autoext_gen" << endl
		<< "\t\tautoclosstal, autoliab, autoaval, billing_chrg, billing_amort, billing_recv, pdn_takedown, prexprn, autorein, housekeep, billgfee" << endl
		<< "\t\tbillgadj, billgae, billgtrck, billgq, weekend, prooftape, rebate, switch, lcbac, inqreload" << endl
		<< "   <proc_unit>\tName of processing unit" << endl
		<< "Optional" << endl
		<< "   <server>\tName of database server" << endl
		<< "   <user>\tName of database login" << endl
		<< "   <passwd>\tPassword of database login" << endl
		<< "   <proc_dt>\tProcessing date" << endl
		<< "   <error handling mode>" << endl
		<< "\t\t0 - Handles all errors" << endl
		<< "\t\t1 - Ignore application errors (default)" << endl
		<< "\t\t2 - Ignore system errors" << endl;
#else
        cout << endl << "Where" << endl << "   <name>"
                << "\ttracer, feeamort, feecapt, tickler, autobkoff, autowof, autochrg, sdip, autoext_rej, autoext_rls, autoext_gen" << endl
                << "\t\tautoclosstal, autoliab, autoaval, billing_chrg, billing_amort, billing_recv, pdn_takedown, prexprn,  autorein, housekeep, billgfee" << endl
                << "\t\tbillgadj, billgae, billgtrck, billgq, weekend, loanbalupd, lcbac, inqreload" << endl
                << "   <proc_unit>\tName of processing unit" << endl
                << "Optional" << endl
                << "   <server>\tName of database server" << endl
                << "   <user>\tName of database login" << endl
                << "   <passwd>\tPassword of database login" << endl
                << "   <proc_dt>\tProcessing date" << endl
                << "   <error handling mode>" << endl
                << "\t\t0 - Handles all errors" << endl
                << "\t\t1 - Ignore application errors (default)" << endl
                << "\t\t2 - Ignore system errors" << endl;
#endif
        exit(1);
}

main(int argc, char ** argv)
{
        QS_BOOL ok;

        QSB__errinit();

        if (argc == 1)
        {
                usage(argv[0]," ");
                return 1;
        }
        if (!strcmp(argv[1], "housekeep")) {
                cout << "Processing HOUSEKEEP ..." << endl;
                QS_BHSEKEEP     housekeep;

                if ( ! housekeep.Init(argc-1, &(argv[1])) )
                        usage(argv[0], argv[1]);
                housekeep.SetUp();
                housekeep.PrintOn();
                ok = housekeep.Run();
        }
        else if (!strcmp(argv[1], "tracer")) {
                cout << "Processing TRACER ..." << endl;
/*
                QS_BTRACER      tracer;
#ifdef GTS_NY
                                if ( ! tracer.Init(argc-1, &(argv[1])) )
                                        usage(argv[0], argv[1]);
                tracer.PrintOn();
                ok = tracer.Run();
#elif defined GTS_ASIA
                                if ( ! tracer.Init(argc-1, &(argv[1]), "S:U:P:u:d:t:") )
                                        usage(argv[0], argv[1]);
                tracer.PrintOn();
                ok = tracer.Run();
#else
                                if ( ! tracer.Init(argc-1, &(argv[1]), "S:U:P:u:d:t:") )
                                        usage(argv[0], argv[1]);
                                tracer.SetUp();
                tracer.PrintOn();
                ok = tracer.Run();
#endif
*/
                QS_BTRACER_GEN t;
                if (!t.Init(argc-1, &(argv[1]), "S:U:P:u:d:t:") )
                  usage(argv[0], argv[1]);
                t.SetUp();
                t.PrintOn();
                ok = t.Run();
        }
        else if (!strcmp(argv[1], "feeamort")) {
                cout << "Processing FEE AMORTIZATION ..." << endl;
                QS_BFEEAMORT    feeamort;

                if ( ! feeamort.Init(argc-1, &(argv[1])) )
                        usage(argv[0], argv[1]);
                feeamort.SetUp();
                feeamort.PrintOn();
                ok = feeamort.Run();
        }
        else if (!strcmp(argv[1], "feecapt")) {
                cout << "Processing FEE CAPTURE ..." << endl;
                QS_BFEECAPT     feecapt;

                if ( ! feecapt.Init(argc-1, &(argv[1])) )
                        usage(argv[0], argv[1]);
                feecapt.SetUp();
                feecapt.PrintOn();
                ok = feecapt.Run();
        }
        else if (!strcmp(argv[1], "tickler")) {
                cout << "Processing TICKLER GENERATION ..." << endl;
                QS_BTICKLER tickler;

                if ( ! tickler.Init(argc-1, &(argv[1])) )
                        usage(argv[0], argv[1]);
                tickler.SetUp();
                tickler.PrintOn();
                ok = tickler.Run();
        }
        else if (!strcmp(argv[1], "autobkoff")) {
                cout << "Processing AUTO BOOKOFF..." << endl;
                QS_BAUTOBKOFF autobkoff;

                if ( ! autobkoff.Init(argc-1, &(argv[1])) )
                        usage(argv[0], argv[1]);
                autobkoff.SetUp();
                autobkoff.PrintOn();
                ok = autobkoff.Run();
        }
        else if (!strcmp(argv[1], "automtr")) {
        	    cout << "Processing AUTO MATURITY..." << endl;
                QS_BAUTOMTR automtr;

                if ( ! automtr.Init(argc-1, &(argv[1])) )
                        usage(argv[0], argv[1]);
                automtr.SetUp();
                automtr.PrintOn();
                ok = automtr.Run();
		}        
		else if (!strcmp(argv[1], "autosetl")) {
        	    cout << "Processing AUTO SETTLMENT..." << endl;
                QS_BAUTOSETL autosetl;

                if ( ! autosetl.Init(argc-1, &(argv[1])) )
                        usage(argv[0], argv[1]);
                autosetl.SetUp();
                autosetl.PrintOn();
                ok = autosetl.Run();
		}  
		else if (!strcmp(argv[1], "autowof")) {
			cout << "Processing AUTO WRITEOFF... " << endl;
			QS_BAUTOWOF autowof;

			if ( ! autowof.Init(argc-1, &(argv[1])) )
				usage(argv[0], argv[1]);
			autowof.SetUp();
			autowof.PrintOn();
			ok = autowof.Run();
		}
    	else if (!strcmp(argv[1], "autochrg")) {
			cout << "Processing AUTO CHARGE... " << endl;
			QS_BAUTOCHRG autochrg;

			if ( ! autochrg.Init(argc-1, &(argv[1])) )
				usage(argv[0], argv[1]);
			autochrg.SetUp();
			autochrg.PrintOn();
			ok = autochrg.Run();
	    }
        else if (!strcmp(argv[1], "sdip")) {
                cout << "Processing DIRECT INTEREST PAYMENT ..." << endl;
                QS_BAUTOSDIP sdip;

                if ( ! sdip.Init(argc-1, &(argv[1])) )
                        usage(argv[0], argv[1]);
                sdip.SetUp();
                sdip.PrintOn();
                ok = sdip.Run();
        }		
        else if (!strcmp(argv[1], "autoext_rej")) {
                cout << "Processing AUTO EXTENSION REJECTION ..." << endl;
                QS_BAUTOEXT_REJ autoext_rej;

                if ( ! autoext_rej.Init(argc-1, &(argv[1])) )
                        usage(argv[0], argv[1]);
                autoext_rej.SetUp();
                autoext_rej.PrintOn();
                ok = autoext_rej.Run();
        }
        else if (!strcmp(argv[1], "autoext_rls")) {
                cout << "Processing AUTO EXTENSION RELEASE..." << endl;
                QS_BAUTOEXT_RLS autoext_rls;

                if ( ! autoext_rls.Init(argc-1, &(argv[1])) )
                        usage(argv[0], argv[1]);
                autoext_rls.SetUp();
                autoext_rls.PrintOn();
                ok = autoext_rls.Run();
        }
        else if (!strcmp(argv[1], "autoext_gen")) {
                cout << "Processing  AUTO EXTENSION GENERATION..." << endl;
                QS_BAUTOEXT_GEN autoext_gen;

                if ( ! autoext_gen.Init(argc-1, &(argv[1])) )
                        usage(argv[0], argv[1]);
                autoext_gen.SetUp();
                autoext_gen.PrintOn();
                ok = autoext_gen.Run();
        }
        else if (!strcmp(argv[1], "autoclosstal")) {
                cout << "Processing AUTO CLOSEOUT ..." << endl;
                QS_BAUTOCLOS autoclos;

                if ( ! autoclos.Init(argc-1, &(argv[1])) )
                        usage(argv[0], argv[1]);
                autoclos.SetUp();
                autoclos.PrintOn();
                ok = autoclos.Run();
        }
        else if (!strcmp(argv[1], "autoliab")) {
                cout << "Processing AUTO LIABILITY ..." << endl;
                QS_BAUTOLIAB autoliab;

                if ( ! autoliab.Init(argc-1, &(argv[1])) )
                        usage(argv[0], argv[1]);
                autoliab.SetUp();
                autoliab.PrintOn();
                ok = autoliab.Run();
        }
        else if (!strcmp(argv[1], "autoaval")) {
                cout << "Processing AUTO INCREASE/DECREASE ..." << endl;
                QS_BAUTOAVAL autoaval;

                if ( ! autoaval.Init(argc-1, &(argv[1])) )
                        usage(argv[0], argv[1]);
                autoaval.SetUp();
                autoaval.PrintOn();
                ok = autoaval.Run();
        }
        else if (!strcmp(argv[1], "pdn_takedown")) {
                cout << "Processing PRE DEBIT NOTICE ..." << endl;
                QS_BPDN_TAKEDOWN pdn_takedown;

                if ( ! pdn_takedown.Init(argc-1, &(argv[1])) )
                        usage(argv[0], argv[1]);
                pdn_takedown.SetUp();
                pdn_takedown.PrintOn();
                ok = pdn_takedown.Run();
        }        
        else if (!strcmp(argv[1], "prexprn")) {
                cout << "Processing PRE EXPIRY NOTICE ..." << endl;
                QS_BPREXPRN prexprn;

                if ( ! prexprn.Init(argc-1, &(argv[1])) )
                        usage(argv[0], argv[1]);
                prexprn.SetUp();
                prexprn.PrintOn();
                ok = prexprn.Run();
        }
        else if (!strcmp(argv[1], "billing_chrg")) {
                cout << "Processing BILLING_CHRG ..." << endl;
                QS_BBILLING_CHRG billing_chrg;

                if ( ! billing_chrg.Init(argc-1, &(argv[1]),"S:U:P:u:d:e:t:") )
                        usage(argv[0], argv[1]);
                billing_chrg.SetUp();
                billing_chrg.PrintOn();
                ok = billing_chrg.Run();
        }
        else if (!strcmp(argv[1], "billing_amort")) {
                cout << "Processing BILLING_AMORT ..." << endl;
                QS_BBILLING_AMORT billing_amort;

                if ( ! billing_amort.Init(argc-1, &(argv[1])) )
                        usage(argv[0], argv[1]);
                billing_amort.SetUp();
                billing_amort.PrintOn();
                ok = billing_amort.Run();
        }
		else if (!strcmp(argv[1], "billing_recv")) {
                cout << "Processing BILLING_RECV ..." << endl;
                QS_BBILLING_RECV billing_recv;

                if ( ! billing_recv.Init(argc-1, &(argv[1])) )
                        usage(argv[0], argv[1]);
                billing_recv.SetUp();
                billing_recv.PrintOn();
                ok = billing_recv.Run();
		}
        else if (!strcmp(argv[1], "billing_ap")) {
                cout << "Processing BILLING_AP ..." << endl;
                QS_BBILLING_AP billing_ap;

                if ( ! billing_ap.Init(argc-1, &(argv[1])) )
                        usage(argv[0], argv[1]);
                billing_ap.SetUp();
                billing_ap.PrintOn();
                ok = billing_ap.Run();
        }
        else if (!strcmp(argv[1], "autorein")) {
                cout << "Processing AUTO REINSTATE ..." << endl;
                QS_BAUTOREIN autorein;

                if ( ! autorein.Init(argc-1, &(argv[1])) )
                        usage(argv[0], argv[1]);
                autorein.SetUp();
                autorein.PrintOn();
                ok = autorein.Run();
        }
        else if (!strcmp(argv[1], "billgfee")) {
                cout << "Processing BILLING FEE GENERATION ..." << endl;
                QS_BBILLG_FEE billgfee;

                if ( ! billgfee.Init(argc-1, &(argv[1])) )
                        usage(argv[0], argv[1]);
                billgfee.SetUp();
                billgfee.PrintOn();
                ok = billgfee.Run();
        }
        else if (!strcmp(argv[1], "billgadj")) {
                cout << "Processing BILLING CHARGE ADJUSTMENT ..." << endl;
                QS_BBILLG_ADJ billgadj;

                if ( ! billgadj.Init(argc-1, &(argv[1])) )
                        usage(argv[0], argv[1]);
                billgadj.SetUp();
                billgadj.PrintOn();
                ok = billgadj.Run();
        }
        else if (!strcmp(argv[1], "billgae")) {
                cout << "Processing BILLING AE GENERATION ..." << endl;
                QS_BBILLG_AE billgae;

                if ( ! billgae.Init(argc-1, &(argv[1])) )
                        usage(argv[0], argv[1]);
                billgae.SetUp();
                billgae.PrintOn();
                ok = billgae.Run();
        }
        else if (!strcmp(argv[1], "billgtrck")) {
                cout << "Processing BILLING TRACKING GENERATION ..." << endl;
                QS_BBILLG_TRCK billgtrck;

                if ( ! billgtrck.Init(argc-1, &(argv[1])) )
                        usage(argv[0], argv[1]);
                billgtrck.SetUp();
                billgtrck.PrintOn();
                ok = billgtrck.Run();
        }
        else if (!strcmp(argv[1], "billgq")) {
                cout << "Processing BILLING QUEUE ..." << endl;
                QS_BBILLG_Q billgq;

                if ( ! billgq.Init(argc-1, &(argv[1])) )
                        usage(argv[0], argv[1]);
                billgq.SetUp();
                billgq.PrintOn();
                ok = billgq.Run();
        }
		else if (!strcmp(argv[1], "switch")) {
                cout << "Processing Switch Account ..." << endl;
                QS_BSWITCH_ACCT switch_acct;

                if ( ! switch_acct.Init(argc-1, &(argv[1])) )
                        usage(argv[0], argv[1]);
				switch_acct.SetUp();
                switch_acct.PrintOn();
                ok = switch_acct.Run();
        }
        else if (!strcmp(argv[1], "weekend")) {
                cout << "Processing WEEKEND GENERATION ..." << endl;
                QS_WEEKEND weekend;

                if ( ! weekend.Init(argc-1, &(argv[1])) )
                        usage(argv[0], argv[1]);
                weekend.SetUp();
                weekend.PrintOn();
                ok = weekend.Run();
        }

#ifdef GTS_NY
        else if (!strcmp(argv[1], "prooftape")) {
                cout << "Processing PROOF TAPE UPDATING ..." << endl;
                QS_PROOFTAPE_UPD prooftape;

                if ( ! prooftape.Init(argc-1, &(argv[1])) )
                        usage(argv[0], argv[1]);
                prooftape.PrintOn();
                ok = prooftape.Run();
        }
        else if (!strcmp(argv[1], "rebate")) {
                cout << "Processing TP_REBATE Table UPDATING ..." << endl;
                QS_REBATE_UPD rebate;

                if ( ! rebate.Init(argc-1, &(argv[1])) )
                        usage(argv[0], argv[1]);
                rebate.PrintOn();
                ok = rebate.Run();
        }
#else
        else if (!strcmp(argv[1], "loanbalupd")) {
                cout << "Processing LOAN BALANCE UPDATE ..." << endl;
                QS_BLOANBAL bloanbal;

                if ( ! bloanbal.Init(argc-1, &(argv[1])) )
                        usage(argv[0], argv[1]);
                bloanbal.SetUp();
                bloanbal.PrintOn();
                ok = bloanbal.Run();
        }
#endif
        else if (!strcmp(argv[1], "lcbac")) {
                cout << "Processing LC BAC Evaluation ..." << endl;
                QS_BLCBAC_EVAL blcbac;

                if ( ! blcbac.Init(argc-1, &(argv[1])) )
                        usage(argv[0], argv[1]);
                blcbac.SetUp();
                blcbac.PrintOn();
                ok = blcbac.Run();
        }
	else if (!strcmp(argv[1], "fxreval")) {
         cout << "Processing FXREVAL ..." << endl;
         QS_BFXREVAL fx;
         if (!fx.Init(argc-1, &(argv[1]), "S:U:P:u:d:t:") )
           usage(argv[0], argv[1]);
         fx.SetUp();
         fx.PrintOn();
         ok = fx.Run();
	}
	else if (!strcmp(argv[1], "pda")) {
         cout << "Processing PDA ..." << endl;
         QS_BPRE_DEBIT_NOTICE pda;
         if (!pda.Init(argc-1, &(argv[1]), "S:U:P:u:d:t:") )
           usage(argv[0], argv[1]);
         pda.SetUp();
         pda.PrintOn();
         ok = pda.Run();
	}
        else if (!strcmp(argv[1], "inqreload")) {
                cout << "Processing INQUIRY RELOAD ..." << endl;
                QS_BINQ_RELOAD_Q     inqreload;

                if ( ! inqreload.Init(argc-1, &(argv[1])) )
                        usage(argv[0], argv[1]);
                inqreload.SetUp();
                inqreload.PrintOn();
                ok = inqreload.Run();
        }
        else
                usage(argv[0], argv[1]);

        // Pat changed for NT
        return (ok ? 0 : 1);
        exit(ok ? 0 : 1);
}
