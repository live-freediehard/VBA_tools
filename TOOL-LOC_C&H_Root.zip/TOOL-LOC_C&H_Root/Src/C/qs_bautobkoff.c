/******************************************************************************
**
**      Revision History
**
**      $Log:   O:\GTS\SERVER\src\qs\batch\src\qs_bautobkoff.cv_  $
 * 
 *    Rev 1.6   Jan 26 1998 10:55:50   kwand
 * Bug Item #: 11472RE
 * Retrofit the changes made to the branches on Jan 14 & 15, 1998:
 * Two new return status added besides QS_SUCCEED and QS_FAIL:
 * - QS_FAIL_IGNAPPERRS
 * - QS_FAIL_IGNSYSERRS
 * If either of the two status is returned,  ProcCurEntry() will rollback the transaction,
 * ignore the error, and continue processing the next row.  Eventually,  ProcMainQ()
 * will return ok since the error (application or system) is set to be ignored.
 * 
 * 
 *    Rev 1.5   Jan 13 1998 16:56:12   Behp
 * 113EY6G
 * Fix extra control M
 * 
 *    Rev 1.4   Jan 05 1998 18:14:54   Behp
 * 1051MRG
 * Unified Version
 * 
 *    Rev 1.3   Aug 20 1997 12:42:28   kwand
 * Bug Item #: 818D187
 * Support new error handling options
 * 
 *    Rev 1.2   Aug 19 1997 10:42:18   gaminis
 * Bug Id # 818D187
 * 
 *    Rev 1.1   Aug 20 1996 10:42:56   kwand
 * Replace version 1.0 (6/96 HK production) with 8/96 HK production version
 * 
 *    Rev 1.0   Jul 19 1996 17:58:14   rajuk
 * Checked in from initial workfile by PVCS Version Manager Project Assistant.
**
*******************************************************************************/
/******************************************************************************
*
*M      System:         Global Trade System
*M
*M      File Name:      qs_bautobkoff.C
*M      Description:    Process auto bookoff
*M      Type:           C++ source
*M
*M      Process:        Nil
*M      Input:          Nil
*M      Output:         Nil
*M      Return:         Nil
*
*H      Delta:          960094
*H      Date:           July 1996
*H      By:             Edward
*H      Changes:        Handle period basis 'Y', 'M', 'W' and 'D'
*H
*H      Creation Date:  Thu Oct 20 09:32:12 1994
*H      Written By:     C. S. Wong
*H      Process:        Nil
*H      Input:          Nil
*H      Output:         Nil
*H      Return:         Nil
*
******************************************************************************/
#include        "errors.h"
#include        "qs_bautobkoff.h"
#include        "qs_batch_errs.h"
#include 	"qs_bauto_wp_gen_ny_alps.h"

QS_BAUTOBKOFF::~QS_BAUTOBKOFF()
{
        pUSPResult = NULL;
}
/*
QS_BOOL QS_BAUTOBKOFF::Run()
{
        cout << "Call the member function Run()" << endl;
        return (QS_TRUE);
}
*/

void
QS_BAUTOBKOFF::SetUp()
{
        this->pQSelect = _SQL_AUTOBKOF_SEL;
        this->pQSelect += "'" + sProcUnit + "'" + ",'" + sProcDt + "'";
        pQsp = _SQL_AUTOBKOF_BAT;
        proc_unit = sProcUnit;
        proc_dt = sProcDt; 
}

QS_RETCODE
QS_BAUTOBKOFF::ProcCurEntry()
{
	CString Sql;
	CString PROC_UNIT, PROD_CAT, PROD_TYP, TRAN_REF_NBR, TRAN_SEQ_NBR, EXT_REF_NBR;
	
	
	GT_Value* pVal = (pCurEntry->GetCol("PROC_UNIT"))->GetValue();
	pVal->GetValue(PROC_UNIT);
	
	pVal = (pCurEntry->GetCol("PROD_CAT"))->GetValue();
	pVal->GetValue(PROD_CAT);
	
	pVal = (pCurEntry->GetCol("PROD_TYP"))->GetValue();
	pVal->GetValue(PROD_TYP);
	
	pVal = (pCurEntry->GetCol("TRAN_REF_NBR"))->GetValue();
	pVal->GetValue(TRAN_REF_NBR);
	
	pVal = (pCurEntry->GetCol("TRAN_SEQ_NBR"))->GetValue();
	pVal->GetValue(TRAN_SEQ_NBR);
	
	pVal = (pCurEntry->GetCol("EXT_REF_NBR"))->GetValue();
	pVal->GetValue(EXT_REF_NBR);
	
	
	CurTime = CurTime.GetCurrentTime();
	
	
	cout << endl;
	cout << endl;
	cout << endl;
	cout << CurTime.Format("%m/%d %T ") + sServer + " : " << endl;
	cout << "[**********************************************]" << endl;
	cout << "[**  START TO AUTOBOOKOFF THE FOLLOWING TXN  **]" << endl;
	cout << "[**********************************************]" << endl
	<< "-------------------------------------------------------------------"
	<< endl
	<< "pu= [" << PROC_UNIT << "]"
	<< "Txn: " << "cat=["<< PROD_CAT << "] "
	<< "typ=[" << PROD_TYP << "] "
	<< "ref=[" << TRAN_REF_NBR << "] "
	<< "seq=[" << TRAN_SEQ_NBR << "]" << endl <<endl;


	
	
	
	/* ----------------------------------------- */
	/* Run the 1st part of USP_BAUTOBKOFF_MAIN   */
	/* ----------------------------------------- */
	QS_SMALLINT     status;
	QS_SMALLINT	wp_status;
	QS_SMALLINT	intTranSeq;	
	CString		strTranSeq;
	CString		strItemOS;
	CString		strLiabBal;
	CString		strChrgAmt;
	CString		strPaymtResult;
	CString		strGracePeriod;
	CString		strGraceBasis;
	CString		strExpDate;
	CString		strWODate;
	CString		strPlcExp;
	char		strStatus[10];
	char		strWPStatus[10];
	char		strFieldName[5][20];
	CString 		strMain2Return;

	status = 0;
	strTranSeq = "0";
	strItemOS = "";
	strLiabBal = "0";
	strChrgAmt = "0";
	strPaymtResult = "0";
	strGraceBasis = "";
	strGracePeriod = "0";
	strExpDate = "";
	strWODate = "";
	strPlcExp = "";
	


	Sql =   "exec GTDPEND1..USP_BAUTOBKOFF_MAIN1 #PROC_UNIT, "		
			"#TRAN_REF_NBR, #TRAN_SEQ_NBR, #PROD_TYP, #PROD_CAT, "	
			"#BATCH_DT, #BOOKOFF_DT";
	
	
	SetSql(Sql);
	SetSqlParamFromQEntry();
	GetSql(Sql);

	cout << "[USP_BAUTOBKOFF_MAIN1 --- SQL]" << endl;
	cout << Sql << endl;
	
	ExecSql();
	GetResult(&pUSPResult);
	GetRetStatus(status);
	
	
	cout << "[USP_BAUTOBKOFF_MAIN1 --- RETURN]" << endl;
	cout << status <<endl;
	
	
	cout << "[USP_BAUTOBKOFF_MAIN1 --- TEMP RESULT]" << endl;
	
	
	
	
	if (status >= 0)
	{
		Sql =	"select * from GTDPEND1..WK_AUTOBKOF "
				"WHERE PROC_UNIT=#PROC_UNIT AND TRAN_REF_NBR=#TRAN_REF_NBR "
				"AND TRAN_SEQ_NBR=#TRAN_SEQ_NBR";
	
		SetSql(Sql);
		SetSqlParamFromQEntry();
		GetSql(Sql);
		ExecSql();
		GetResult(&pUSPResult);
	
		if (pUSPResult->GetRowCount() > 0)
		{	
			GetColStr(pUSPResult, "NEW_TRAN_SEQ_NBR", strTranSeq);	
			GetColStr(pUSPResult, "ITEM_OS", strItemOS);	
			GetColStr(pUSPResult, "LC_LIAB_BAL", strLiabBal);	
			GetColStr(pUSPResult, "WO_CHRG_AMT", strChrgAmt);	
			GetColStr(pUSPResult, "PAYMT_RESULT", strPaymtResult);	
			GetColStr(pUSPResult, "GRACE_BASIS", strGraceBasis);	
			GetColStr(pUSPResult, "GRACE_PRD", strGracePeriod);	
			GetColStr(pUSPResult, "LC_EXP_DT", strExpDate);	
			GetColStr(pUSPResult, "LC_WO_DT", strWODate);	
			GetColStr(pUSPResult, "PLC_EXP", strPlcExp);	
			
			cout << "New TRAN_SEQ_NBR	=" << strTranSeq << endl;
			cout << "    ITEM_OS		=" << strItemOS << endl;
			cout << "    LC_LIAB_BAL	=" << strLiabBal << endl;
			cout << "    WO_CHRG_AMT	=" << strChrgAmt << endl;
			cout << "    PAYMT_RESULT	=" << strPaymtResult << endl;
			/*
			cout << "    GRACE_BASIS	=" << strGraceBasis << endl;
			cout << "    GRACE_PRD		=" << strGracePeriod << endl;
			cout << "    LC_EXP_DT		=" << strExpDate << endl;
			cout << "    LC_WO_DT		=" << strWODate << endl;
			cout << "    PLC_EXP		=" << strPlcExp << endl;
			*/
		}
		else
		{
			status = 10400;
		}	
	}
	else
	{
		status = 10000;
	}	
	
	
	
	
	/* ------------------------------------------ */
	/* Call function to generated WP              */
	/* Only do if Charge & Payment generated succ */
	/* ------------------------------------------ */
	sprintf(strWPStatus, "0");
	if (status == 0 && atoi(strPaymtResult) == 0)
	{
		cout << endl << "========================" << endl;
		cout << "[CALLING auto_wp_gen...]" << endl;
		QS_AUTO_WP_GEN	auto_wp_gen;
		wp_status = auto_wp_gen.Run1(*pDBConnection,PROC_UNIT,TRAN_REF_NBR,atoi(strTranSeq));
		sprintf(strWPStatus, "%d", wp_status);
		cout << "[AFTER generating WP, wp_status=" << wp_status<< "]" << endl;
	}




	/* ----------------------------------------------------- */
	/* Continue to run the 2nd part of USP_BAUTOBKOFF_MAIN   */
	/* ----------------------------------------------------- */

	/***************************************************************/
	/* Continue no matter whether the WP generation is succ or not */
	/***************************************************************/
	if (status == 0)
	{
		Sql =	"exec GTDPEND1..USP_BAUTOBKOFF_MAIN2 #PROC_UNIT, " 
				"#TRAN_REF_NBR, " + strTranSeq + ", #PROD_TYP, #PROD_CAT, " + status;
		
		SetSql(Sql);
		SetSqlParamFromQEntry();
		GetSql(Sql);
		
		cout << "[USP_BAUTOBKOFF_MAIN2 --- SQL]" << endl;
		cout << Sql << endl;
		
		ExecSql();
		GetResult(&pUSPResult);
		GetRetStatus(status);
		    	
	    cout << "[USP_BAUTOBKOFF_MAIN2 --- RETURN]" << endl;
		cout << status <<endl;
	}	   
	
	
	
    
	if (status != 0)
	{	
		cout << "[*****ROLLBACK TRAN*****]" << endl;
		RollBackTran();
		strMain2Return = "N";
	}
	else
	{
		Sql =	"delete from GTDPEND1..WK_AUTOBKOF "
			"WHERE PROC_UNIT=#PROC_UNIT AND TRAN_REF_NBR=#TRAN_REF_NBR "
			"AND TRAN_SEQ_NBR=#TRAN_SEQ_NBR";
	
		SetSql(Sql);
		SetSqlParamFromQEntry();
		GetSql(Sql);
		ExecSql();

		cout << "[*****COMMIT TRAN*****]" << endl;
		CommitTran();
		strMain2Return="Y";
	}

	

	BeginTran();
	Sql =   "exec GTDPEND1..USP_BAUTOBKOFF '" + PROC_UNIT + "','"
			+ TRAN_REF_NBR + "'," + strTranSeq + "," + status + + "," + strPaymtResult + "," + strWPStatus + ",'" + strItemOS + "', " 
			+ strLiabBal + ", " + strChrgAmt + ",'" + strMain2Return + "'";
	cout << "[GTDPEND1..USP_BAUTOBKOFF --- SQL]" << endl;
	cout << Sql << endl;
	
	SetSql(Sql);
	SetSqlParamFromQEntry();
	GetSql(Sql);
	ExecSql();
	GetResult(&pUSPResult);
	GetRetStatus(status);
	cout << "[AFTER GTDPEND1..USP_BAUTOBKOFF --- RETURN]" << endl;
	cout << status <<endl;

	
	/********************************
		If there is anything not
		expected in the GTDPEND1..USP_BAUTOSETL,
		we log in the GTDTRAN1..OP_AUD_TRAIL
	**********************************/
	if (status != 0)
	{
		cout << "[!!!!!!!!!!!!!!!!!!!!!!!!!!!!!]" << endl;
		cout << "[SYSTEM ERROR --- PLS REFER TO GTDTRAN1..OP_AUD_TRAIL FOR DETAIL]" << endl;
		seterror(QSB__FAILBKOF, WARNING, STR2CHR(PROD_CAT),
		STR2CHR(PROD_TYP), STR2CHR(EXT_REF_NBR),
		STR2CHR(TRAN_SEQ_NBR));
	
		if ( GetErrHdlTyp() == IGNAPPERRS )
		{
			cout << "----- RollBackTran ---" << endl;
			RollBackTran();
			LogAppErr(proc_unit, "Auto-Bookoff", status, TRAN_REF_NBR);
			return QS_FAIL_IGNAPPERRS;
		}
		else
		{
			cout << "----- ThrowQSException ---" << endl;
			ThrowQSException(QS_USP_FAIL);
			return QS_FAIL;
		}
	}
	else
	{
		return QS_SUCCEED;
	}

	
	
}

void QS_BAUTOBKOFF::PrintOn()
{
        cout << "pQsp:  [" << pQsp << "]" << endl;
        cout << "pQSelect:      [" << this->pQSelect << "]" << endl;
        cout << "PROC_UNIT:     [" << proc_unit << "]" << endl;
        cout << "PROC_DT:       [" << proc_dt << "]" << endl;
}



