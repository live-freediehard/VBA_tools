
USE GTDPEND1
GO

SETUSER  'dbo'
GO	
	
PRINT 'STORED PROCEDURE : dbo.USP_BAUTOBKOFF_MAIN1'

GO
	
if exists (select * from dbo.sysobjects where id = Object_id('dbo.USP_BAUTOBKOFF_MAIN1') and (type = 'P' or type = 'RF'))
begin
	drop proc dbo.USP_BAUTOBKOFF_MAIN1
end
	
GO


CREATE PROC USP_BAUTOBKOFF_MAIN1 
	@_pu            char(3), 
	@_tran_ref      char(16), 
	@_tran_seq      gtt_seq, 
	@_prod_typ      char(6), 
	@_prod_cat      char(3), 
	@_batch_dt	gtt_dt,
	@_bookoff_dt	gtt_dt

/*
@_pu            char(3), 
@_tran_ref      char(16), 
@_tran_seq      gtt_seq, 
@_prod_typ      char(6), 
@_prod_cat      char(3), 
@_plc_exp       char(1), 
@_basis_our     char(1), 
@_basis_their   char(1), 
@_basis_other   char(1), 
@_gp_our        smallint, 
@_gp_their      smallint, 
@_gp_other	smallint, 
@_warn_basis	char(1), 
@_warn_prd	tinyint, 
@_lc_exp_dt	gtt_dt, 
@_nxt_dt	gtt_dt, 
@_this_dt	gtt_dt,
@_batch_dt	gtt_dt,
@_bookoff_dt	gtt_dt
*/
as 
/****************************************************************************** 
* 
*M      System:         Global Trade System 
*M 
*M      File Name:      USP_BAUTOBKOFF_MAIN1.sql 
*M      Description:     
*M      Type:           Server Stored Procedure 
*M      Process:        Reject Records - 
*M                      1. categories not in ('ILC', 'ELC', 'NLC', 'XLC', 'TLC') 
*M                      2. extend   
*M                      Get Upper and Lower Bound - 
*M                      1. get upper 
*M                      2. lower = upper - 2 business days 
*M                      Get Other Details for those close or equal to bookoff day - 
*M                      1. check pending amendment 
*M                      2. check o/s payment 
*M                      3. check o/s acct. receivable 
*M                      4. check o/s acct. payable 
*M                      5. check pending charges 
*M                      6. write to report for those 
*M                         - close to bookoff day 
*M                         - pending amendment exists 
*M                         - outstanding payment exists 
*M                      Book-off Transaction - 
*M                      1. new 
*M                      2. confirm		(=> Moved to USP_BAUTOBKOFF_MAIN2) 
*M                      3. release		(=> Moved to USP_BAUTOBKOFF_MAIN2) 
*M                      4. clo			(=> Moved to USP_BAUTOBKOFF_MAIN2) 
*M      Input:           
*M      Output:          
*M      Return:          
* 
*H      Delta:          960094 
*H      Date:           July 1996 
*H      By:             Edward 
*H      Changes:        Handle period basis 'Y', 'M', 'W' as well as 'D' 
*H 
*H      Modification Date: Mar 17, 1997, Steve Su - Added a new field ARAP_STATUS to TP_AR_AP_BAL 
*H      Modified By: 
*H      Changes: 
*H 
*H      Modification Date: Jun 29, 1995 - changa - fix select by dates 
*H      Modified By: 
*H      Changes: 
*H 
*H      Creation Date:  Mar 13 1995 
*H      Written By:     Gary Liu 
*H      Process:         
*H      Input:           
*H      Output:          
*H      Return:          
* 
******************************************************************************/ 
/****************************************************************************** 
** 
**      Revision History 
** 
**      $Log:   O:\GTS\database\sql\batch\usp_bautobkoff_main1.svl  $ 
* 
*   Rev 1.8   Apr 06 1998 16:19:24   kwand 
*Bug #: 3235C9D_1 
* 
*   Rev 1.7   23 Mar 1998 15:28:02   paradind 
*3235C9D - AutoBookoff not picking up transactions due to outstanding payment transactions (which have been settled and are not outstanding) 
*Problems: 
*1) If a transaction has FADV that has not been settled or accepted in the same transactions, there will be an item in LC_CCY where the TRAN_AMT_TYPE is 'FADV',  
*causing the logic to fail even if the bill is settled. 
*2) Standalone transactions currently have a blank TRAN_AMT_TYP, causing the logic to fail although the standalone should not impact the liability. 
*3) This logic does not check to if any payment transactions have been confirmed and pending release, which it should 
*Resolution: 
*The logic was changed to: 
*1. Check if the last transaction for a bill is either "ACDS", "ACPT", "DPAY", "SETL" and not a standalone 
*2. Check for confirmed transactions 
* 
* 
*   Rev 1.6   Aug 15 1997 12:48:20   kwand 
*Bug Item #: 815LP28 
*Create new PT_Q entries with all approval status reset 
* 
*   Rev 1.5   Aug 08 1997 17:16:00   kwand 
*Bug Item #: 808Z6KA 
*Check if transaction evergreen 
* 
*   Rev 1.4   15 May 1997 23:43:30   yaggier 
*411YL7C - Auto Extension. 
* 
*   Rev 1.3   17 Mar 1997 10:36:22   sus 
*227CG69 : UK ARAP - Modify four existing tables (SYBUK) 
* 
*   Rev 1.2   02 Oct 1996 12:31:06   rajuk 
*HK0996 
*Modified Stored Procs 
* 
*   Rev 1.1   Jul 24 1996 10:32:26   kwand 
*Insert file header right after the "CREATE PROC" statement 
* 
*   Rev 1.0   23 Jul 1996 10:40:58   rajuk 
*Checked in from initial workfile by PVCS Version Manager Project Assistant. 
** 
*******************************************************************************/ 
	declare @grace_prd      int, 
		@grace_basis    char(1), 
--		@EXPRN_DT       gtt_dt, 
		@status         int, 
		@new_tran_seq   gtt_seq, 
		@ERROR_CD       int, 
		@count          int, 
		@cust_name      char(35), 
		@amendment      char(1), 
		@payment        char(1), 
		@acctrec_os     char(1), 
		@acctpay_os     char(1), 
		@pending_chrg   char(1), 
		@item_os        char(20), 
		@bookoff_ready  char(1), 
		@new_item_nbr	char(4), 
		@pt_ref_nbr	gtt_ptref, 
		@result			int,
		@PAYMT_REF_NBR  char(16),
		@AUTO_WO_IND	char(1),
		@AUTO_EXT_IND	char(1),
		@INOPR_IND	char(1),
		@AUTOBKOF_ZERO_LIAB_TXN	char(1)
	
	select  @status = 0, 
		@ERROR_CD = 10106, 
		@result = 0
	
	select  @grace_prd = -1, 
		@grace_basis = ' ', 
		--@EXPRN_DT=@_lc_exp_dt, 
		@new_tran_seq = 0, 
		@count = 0 
	
	select  @cust_name	= '', 
		@amendment	= ' ', 
		@payment	= ' ', 
		@acctrec_os	= ' ', 
		@acctpay_os	= ' ', 
		@pending_chrg	= ' ', 
		@item_os	= '', 
		@bookoff_ready	= 'N',
		@AUTO_EXT_IND	= 'N',
		@INOPR_IND	= 'N'
			
 
 
	/* Variables for getting liability balace */ 
	declare @LC_LIAB_BAL    	gtt_amt, 
		@LC_FACE_AMT    	gtt_amt, 
		@ABT_PCT_PLUS   	gtt_rtpct, 
		@ADV_OS_AMT     	gtt_amt, 
		@ACPT_OS_AMT    	gtt_amt, 
		@TOT_ACPT_OS_AMT  	gtt_amt, 
		@WO_CHRG_AMT		gtt_amt 


	select 	@LC_LIAB_BAL		= 0, 
		@LC_FACE_AMT		= 0, 
		@ADV_OS_AMT		= 0, 
		@ACPT_OS_AMT		= 0, 
		@TOT_ACPT_OS_AMT	= 0, 
		@WO_CHRG_AMT		= 0 



	/*
	============================================================== 
	Make sure the Product Category passed in can be handled by 
	this stored procedure. 
	============================================================== 
	*/ 
	if (@_prod_cat NOT IN ('ELC','ILC','STG','NLC','XLC'))
	begin
		PRINT "PROD_CAT NOT SUPPORTTED TO BE BOOKOFF --- %1!", @_tran_ref
		select	@status = @ERROR_CD
	end
	
	
	
	
	/*  
	============================================================== 
	LOGIC TO DETERMINE THE LC_EXPRN_DT.
	IMPLEMENT LATER FOR AUTO_EXT
	
	Get the grace period and basis to be used to calculate the 
	expiry date (@EXPRN_DT) from LC_AUTO_EXT
	============================================================== 
	*/ 
	
	/*
	if	(@status = 0)
	begin
		select  @_lc_exp_dt	= FINAL_EXPRN_DT, 
			@grace_prd	= EXT_PRD, 
			@grace_basis	= PRD_BASIS 
		from    GTDMAST1..LC_AUTO_EXT 
		where   PROC_UNIT	= @_pu 
		and     TRAN_REF_NBR	= @_tran_ref 
		
		select @count = @@rowcount 
		if (@count > 1) 
		begin 
			PRINT "MORE THAN 1 ENTRY IN LC_AUTO_EXT --- %1!", @_tran_ref
			select	@status = @ERROR_CD
		end 
		
		else if (@count = 0) 
		begin 
			/*  
			============================================================= 
			If no information is available in LC_AUTO_EXT then get the  
			grace period and basis to be used to calculate the expiry  
			date (@EXPRN_DT) from the parameters passed to this procedure 
			=============================================================  
			*/ 
			
			if ( @_plc_exp = 'O' ) 
				select  @grace_basis	= @_basis_our,  
					@grace_prd	= @_gp_our 
			else if ( @_plc_exp = 'N' ) 
				select  @grace_basis	= @_basis_their,  
					@grace_prd	= @_gp_their 
			else if ( @_plc_exp = 'X' ) 
				select  @grace_basis	= @_basis_other,  
					@grace_prd	= @_gp_other 
			else  
			begin
				PRINT "UNKNOWN PLACE OF EXPIRY"
				select @status = @ERROR_CD
			end
		end 
		else
		begin 
			select @AUTO_EXT_IND = 'Y'
			/*************************************************
				IF THERE IS ONE ENTRY IN LC_AUTO_EXT
				AND THE FINAL_EXPRN_DT IS '', 
				Indicates an evergreen transaction. 
				No book-off should be carried out
			**************************************************/ 
			if ( @_lc_exp_dt = '' ) 
			begin 
				PRINT "EVERGREEN LC SHOULD NOT BE BOOKOFF"
				select @status = @ERROR_CD
			end 
		end 
	end		
	*/
	
	
		
		
		
		
		
	/*  
	============================================================== 
	Get the final expiry date with the grace period included
	============================================================== 
	*/ 
	/*
	if (@status = 0) 
	begin
		exec @status = USP_CGET_NEXT_XDATE	@_pu,
											@_lc_exp_dt,  
											@grace_prd,	--if 0, becomes 1 automatically pu_config 'AUTOBKOF_GRACE_PERIOD' is set and <> 0
											@grace_basis,  
											'N',  
											@EXPRN_DT output,  
											0       -- 0 means holiday is okay 
		if (@status != 0) 
		begin 
			PRINT "Sorry, cannot determine final expiry date!"
		end  			
	end
	*/
	/*  
	============================================================== 
	If no warning period is specified, default to 2 days 
	============================================================== 
	*/ 
	/*
	if (@status = 0) 
	begin
	
	if (@_warn_prd = 0)  
	select  @_warn_basis = 'D',  
			@_warn_prd = 2 				
	end  
	*/
        
        
	/*  
	============================================================== 
	Calculate the last warning date (@end_warn_dt) to determine if  
	the LC should be processed for auto bookoff or should be  
	included on the auto bookoff report.  LCs which have an  
	expiry date > @end_warn_dt will be ignored - they are no  
	longer in the warning period. 
	
	Note: The warning period is > @_this_dt  
	and <= @_this_dt + (warn_prd) * business day 
	============================================================== 
	*/ 
	/*
	if (@status = 0) 
	begin
		declare @end_warn_dt    gtt_dt 
		exec @status = GTDPEND1..USP_CGET_NEXT_XDATE	@_pu,  
														@_this_dt,  
														@_warn_prd, --if 0, becomes 1 automatically pu_config 'AUTOBKOF_GRACE_PERIOD' is set and <> 0
														@_warn_basis,  
														'N', 
														@end_warn_dt output,  
														1
		if (@status != 0) 
		begin 
			PRINT "Sorry, cannot determine warning period!" 
		end  						
	end 
	*/
   
    
    
	/*  
	============================================================== 
	Only LCs that fall within the warning period will be processed. 
	If a LC exceeds the warning period, then it should have been 
	included on several previous reports and will now be ignored. 

	Additional Case: Non-expired LCs which has no outstanding liability 
	will be processed.
	============================================================== 
	*/ 
	if (@status = 0) 
	begin
		/* check whether autobkoff non-expired LCs with zero liability */
		select 	@AUTOBKOF_ZERO_LIAB_TXN = Isnull (CONFIG_VAL, '')
		from 	GTDMAST1..PU_CONFIG
		where	PROC_UNIT 	= @_pu
		and	CONFIG_NM	='AUTOBKOF_ZERO_LIAB_TXN'

		if (@_bookoff_dt > @_batch_dt and @AUTOBKOF_ZERO_LIAB_TXN <> 'Y')
		begin
			PRINT "TXN FALL INTO WARNING PERIOD" 
			select @status = 10401							 
		end
		else
		begin
			if (@_prod_cat IN ('ELC','ILC','NLC','XLC'))
			begin
				exec @status = USP_CCHK_LCBKOF	@_pu, @_tran_ref, @_tran_seq, @item_os output
				if (@status > 0) 
				begin 
					PRINT "TXN FAIL USP_CCHK_LCBKOF %1!, %2!, %3!, %4!, %5!", @_pu, @_tran_ref, @_tran_seq, @status, @item_os
					end 
				else  
				begin 
					PRINT "TXN PASS USP_CCHK_LCBKOF %1!, %2!, %3!", @_pu, @_tran_ref, @_tran_seq
				end 
			end
			else if (@_prod_cat IN ('STG'))
			begin
				exec @status = USP_CCHK_SGBKOF	@_pu, @_tran_ref, @_tran_seq, @item_os output
				if (@status > 0) 
				begin 
					PRINT "TXN FAIL USP_CCHK_SGBKOF %1!, %2!, %3!, %4!, %5!", @_pu, @_tran_ref, @_tran_seq, @status, @item_os
					end 
				else  
				begin 
					PRINT "TXN PASS USP_CCHK_SGBKOF %1!, %2!, %3!", @_pu, @_tran_ref, @_tran_seq
				end 
			end
		end
	end
			
	
	
	
	
	
	
	begin tran TRAN_BAUTOBKOFF_MAIN1 
	save tran BAUTOBKOFF_MAIN1 
	/*  
	============================================================== 
		*************** start bookoff processing ************* 
		If all requirements to start the bookoff process have been 
		met, then start the bookoff processing 
	============================================================== 
	*/ 
	if (@status = 0) 
	begin
		if (@_prod_cat = 'ELC') 
		begin
			exec @status = GTDPEND1..USP_PELCBKOF_NEW	@_pu, 
									@_prod_typ, @_tran_ref, @_tran_seq 
		end
		
		if (@_prod_cat = 'ILC') 
		begin
			exec @status = GTDPEND1..USP_PILCBKOF_NEW	@_pu, 
									@_prod_typ, @_tran_ref, @_tran_seq 
		end

		if (@_prod_cat = 'STG') 
		begin
			exec @status = GTDPEND1..USP_PSTGBKOF_NEW	@_pu, 
									@_prod_typ, @_tran_ref, @_tran_seq 
		end
		
		if (@_prod_cat = 'NLC') 
		begin
			exec @status = GTDPEND1..USP_PNLCBKOF_NEW	@_pu, 
									@_prod_typ, @_tran_ref, @_tran_seq 
		end
		
		if (@_prod_cat = 'XLC') 
		begin
			exec @status = GTDPEND1..USP_PXLCBKOF_NEW	@_pu, 
									@_prod_typ, @_tran_ref, @_tran_seq 
		end
		/*  
		============================================================== 
		Determine the TRAN_SEQ_NBR of the new Bookoff Transaction 
		============================================================== 
		*/ 
		if (@status = 0) 
		begin 
			select  @new_tran_seq = max(TRAN_SEQ_NBR) 
			from    GTDPEND1..TP_TRAN_HDR 
			where   PROC_UNIT       = @_pu 
			and     TRAN_REF_NBR    = @_tran_ref 
			and	TRAN_TYP	in ('BKOF', 'PIBO')

			exec @status = USP_CADD_PT_Q	@_pu, @_tran_ref, @_tran_seq, @new_tran_seq,'BKOF','Y','SBKF',''
			if ( @status <> 0 ) 
			begin 
				rollback tran BAUTOBKOFF_MAIN1
				PRINT "USP_CADD_PT_Q failed (status = %1!)...", @status
			end
		end
		else
		begin
			rollback tran BAUTOBKOFF_MAIN1
		end
	
	
	
		if (@status = 0)
		begin
			exec @status = USP_CGET_NEWPRN1 @_pu, @PAYMT_REF_NBR out
			
			if (@status = 0)
			begin
				update	GTDPEND1..LC_CCY
				set	PAYMT_REF_NBR = @PAYMT_REF_NBR
				where	PROC_UNIT	= @_pu
				and     TRAN_REF_NBR	= @_tran_ref 
				and     TRAN_SEQ_NBR	= @new_tran_seq
				PRINT "************ PAYMT_REF_NBR = %1!****************", @PAYMT_REF_NBR
			end
			else
			begin
				PRINT "************ Fail getting PAYMT_REF_NBR ****************"
				rollback tran BAUTOBKOFF_MAIN1
			end
		end 							

		/* 
		===================================================== 
		Generate Charge and Payment for this BKOF transaction
		===================================================== 
		*/  
		if (@status = 0)
		begin
			save tran SAVE_BEFORE_GEN_PAYMENT 
			
			PRINT "Before USP_CGEN_PAYMT, status = %1!, result = %2!, tran_ref = %3!, new_tran_seq = %4!", @status, @result, @_tran_ref, @new_tran_seq 
			exec @status = USP_CGEN_PAYMT @_pu, @_tran_ref, @new_tran_seq, 'B', @result output 
	
			/* 
			=================================================================================
			If Charge and Payment generation failed, rollback things done in USP_CGEN_PAYMT,
			then continue to do the Bookoff.
			=================================================================================
			*/  
			if (@status != 0) 		
			begin
				select @result = @status
				--select @status = 0
				rollback tran SAVE_BEFORE_GEN_PAYMENT	
			end 
			else if (@result != 0)
			begin
				rollback tran SAVE_BEFORE_GEN_PAYMENT		
			end 
		end

	        if (@status = 0)
	        begin
	        	PRINT 'INSERT TP_PDN_DTL'
	        	exec @status = USP_CADD_PDN @_pu, @_tran_ref, @new_tran_seq, @_bookoff_dt
	        	if (@status !=0)
	        	begin
	        		PRINT 'INSERT TP_PDN_DTL FAIL'
				rollback tran SAVE_BEFORE_GEN_PAYMENT		
	        	end	
	        end 
		
	end
		
	/*  
	============================================================== 
	Get Charge Amount 
	============================================================== 
	*/ 					
	select 	@WO_CHRG_AMT = sum(CHRG_AMT)
	from	GTDPEND1..TP_CHRG
	where	PROC_UNIT	= @_pu
	and     TRAN_REF_NBR	=@_tran_ref 
	and     TRAN_SEQ_NBR	= @new_tran_seq
	
	
	
	select	@LC_LIAB_BAL = sum(TOT_LC_LIAB_OS_AMT)
	from	GTDMAST1..LC_LIAB_BAL 
	where	PROC_UNIT	= @_pu
	and	TRAN_REF_NBR	= @_tran_ref
        

	if ( @LC_LIAB_BAL = NULL ) 
		select  @LC_LIAB_BAL = 0 	                
		

	/* Bug Item#7162
	   =============
		Change the receivable takedown logic during BKOF for BOTH NLC and XLC as follows:
		1) Do not take down any RMIT, DFP or DFPB
		2) In the BKOF report, show exception if there is outstanding DFP and/or DFPB.
	*/
	if (@_prod_typ = 'NLC' or @_prod_typ = 'XLC')
	begin
	if exists(select 1 
				from GTDMAST1..TP_AR_AP_BAL taab,
				     GTDTRAN1..TP_PAYMT tpp,
				     GTDMAST1..PAYMT_MTHD pm
				where taab.PROC_UNIT = @_pu
				and   taab.TRAN_REF_NBR = @_tran_ref
				and   taab.PROC_UNIT = tpp.PROC_UNIT
				and   taab.PAYMT_REF_NBR = tpp.PAYMT_REF_NBR 
				and   taab.PAYMT_SEQ_NBR = tpp.PAYMT_SEQ_NBR 
				and   taab.PAYMT_SUB_SEQ_NBR = tpp.PAYMT_SUB_SEQ_NBR 
				and   tpp.PROC_UNIT = pm.PROC_UNIT
				and   tpp.PAYMT_MTHD = pm.PAYMT_MTHD
				and   pm.WHEN_TO_TAKE in ('D','C'))
        select @result = 12222
	end
	
	delete 
	from	GTDPEND1..WK_AUTOBKOF
	where	PROC_UNIT = @_pu
	and	TRAN_REF_NBR = @_tran_ref
	and	TRAN_SEQ_NBR = @_tran_seq
				
	insert into GTDPEND1..WK_AUTOBKOF
	(	
		STATUS,
		PROC_UNIT,
		TRAN_REF_NBR,
		TRAN_SEQ_NBR,
		NEW_TRAN_SEQ_NBR,
		ITEM_OS,
		LC_LIAB_BAL,
		GRACE_BASIS,
		GRACE_PRD,
		LC_EXP_DT,
		LC_WO_DT,
		PLC_EXP,
		WO_CHRG_AMT,
		PAYMT_RESULT			
	)		
	values
	(
		@status,
		@_pu,
		@_tran_ref,
		@_tran_seq,
		@new_tran_seq,
		@item_os,
		@LC_LIAB_BAL,
		@grace_basis,		/*useless now*/
		@grace_prd,		/*useless now*/
		--@_lc_exp_dt,		/*useless now*/
		'',
		@_bookoff_dt,		/*useless now*/
		--@_plc_exp,		/*useless now*/
		'',
		@WO_CHRG_AMT,
		isnull(@result, 0)		
	)
	


	/* insert entries which send pdn by swift but no swift address */
	/* and can send by telex */



	   
	   
	commit tran TRAN_BAUTOBKOFF_MAIN1
	return @status 	
           
           
/* ### DEFNCOPY: END OF DEFINITION */ 
           
/* ### DEFNCOPY: END OF DEFINITION */ 
           
           
           
go

PRINT 'CREATING PRIVILEGE : ' 
	
GO  

grant exec on dbo.USP_BAUTOBKOFF_MAIN1 to oprgrp, gtsuser 


GO

sp_procxmode 'USP_BAUTOBKOFF_MAIN1', 'anymode'

GO
