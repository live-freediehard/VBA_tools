
USE GTDPEND1
GO

SETUSER  'dbo'
GO	
	
PRINT 'STORED PROCEDURE : dbo.USP_BAUTOBKOFF_SEL'

GO
	
if exists (select * from dbo.sysobjects where id = Object_id('dbo.USP_BAUTOBKOFF_SEL') and (type = 'P' or type = 'RF'))
begin
	drop proc dbo.USP_BAUTOBKOFF_SEL
end
	
GO

	
CREATE PROC USP_BAUTOBKOFF_SEL
	@PROC_UNIT      char(3),
	@PROC_DT        gtt_dt,
	@PROC_DT_2		gtt_dt=NULL
as
/******************************************************************************
*
*M      System:         Global Trade System
*M
*M      File Name:      USP_BAUTOBKOFF_SEL.sql
*M      Description:    Auto Bookoff - Form the processing queue
*M      Type:           Server Stored Procedure
*M
*M      Process:        Form the processing queue
*M                      1. Select the PROC_DT
*M                      2. Clean up warning messages
*M                      3. Select from LC_DTL, TP_MST_HDR, PROD_TYP
*M                         where  LC_STATUS = 'I'
*M      Input:          PROC_UNIT, PROD_DT
*M      Output:         Set of queue entries
*M      Return:         Nil
*
*H      Delta:          960094
*H      Date:           July 1996
*H      By:             Edward
*H      Changes:        Handle period basis 'Y', 'M', 'W' as well as 'D'
*H
*H      Creation Date:  Oct 01 1994
*H      Written By:     C. S. Wong
*H      Process:        Form the processing queue
*H                      1. Select from LC_DTL, TP_MST_HDR, PROD_TYP
*H                         where  LC_STATUS not in ('B', 'C')
*H                      2. Calculate the LOWER_BOUND, UPPER_BOUND
*H      Input:          PROC_UNIT, PROD_DT
*H      Output:         Set of queue entries
*H      Return:         Nil
*
******************************************************************************/
/******************************************************************************
**
**      Revision History
**
**      $Log:   O:/GTS/database/sql/batch/usp_bautobkoff_sel.svl  $
*
*   Rev 1.3   Aug 19 1997 10:51:22   gaminis
*Bug Id # 818D187
*
*   Rev 1.2   02 Oct 1996 12:31:06   rajuk
*HK0996
*Modified Stored Procs
*
*   Rev 1.1   Jul 24 1996 10:32:32   kwand
*Insert file header right after the "create proc" statement
*
*   Rev 1.0   23 Jul 1996 10:40:58   rajuk
*Checked in from initial workfile by PVCS Version Manager Project Assistant.
**
*******************************************************************************/

	declare @THIS_PROC_DT	gtt_dt,
		@LST_PROC_DT    gtt_dt          ,
		@NXT_PROC_DT    gtt_dt,
		@BATCH_RUN_DT	gtt_dt,
		@GMT_DT		gtt_dttm,
		@NUM_OF_DYS	integer,
		@AUTOBKOF_ZERO_LIAB_TXN	char(1)
	

	
	
	
	/********************************************************
		HOPE THIS COMMENT CAN HELP A BIT.....
		IF @PROC_DT_2 IS NULL, THEN THIS SP IS 
		CALL BY AUTOSYS, AND IS SUPPOSED TO BE 
		CALLED AFTER FLIP-DAY, SUCH THAT,
		GTDMAST1..PROC_UNIT.NXT_PROC_DT WILL EQUAL
		TO WHAT USER ENTER IN THE "NEXT_PROC_DT" IN FRONT-END.
		
		IF @PROC_DT_2 IS NOT NULL, THEN THIS MEANS USER WANT
		TO SPECIFY A DATE, AND FOR THIS CASE, @PROC_DT IS DUMMY.
	************************************************************/
	if (@PROC_DT_2 is not null)
	begin
		select	@PROC_DT = @PROC_DT_2
	end
	

	/*************************
		Default 15 days
	**************************/
	select 	@NUM_OF_DYS = Isnull (convert(int, CONFIG_VAL), 15) 
	from 	GTDMAST1..PU_CONFIG
	where	PROC_UNIT 	= @PROC_UNIT 
	and	CONFIG_NM	='ALPS_BATCH_RPT_TBL_CLR_DYS'
	
	delete  GTDPEND1..RPT_AUTOBKOF
	where   PROC_UNIT 	= @PROC_UNIT
	and	datediff(dd, GMT_DT, getdate()) > @NUM_OF_DYS
	
	delete  GTDPEND1..RPT_AUTOBKOF
	where   PROC_UNIT 	= @PROC_UNIT
	and	MESSAGE_ID	!= 10409
	
	
	
	/**************************************************
		CLEAN UP ANY ENTRY WHICH IS NOT
		SUPPOSED TO BE HERE, MAY BE CAUSED BY
		BUG, ACT OF GOD.....
		JUST ANOTHER SAFE GUARD
	*************************************************/
	delete  GTDPEND1..RPT_AUTOBKOF
	where   PROC_UNIT 	= @PROC_UNIT
	and	AUD_ID		= -1
	



	select	@BATCH_RUN_DT	= @PROC_DT
	select	@GMT_DT		= getdate()
	


	
	/*********************************************
		If it is call from autosys, then the THIS_PROC_DT
		should has been flipped.
		e.g.	@PROC_DT		= 2003-01-19 THEN 
				@THIS_PROC_DT	= 2003-01-20
	*********************************************/
	select  @THIS_PROC_DT = THIS_PROC_DT,
		@LST_PROC_DT  = LST_PROC_DT,
		@NXT_PROC_DT  = NXT_PROC_DT
	from    GTDMAST1..PROC_UNIT
	where   PROC_UNIT = @PROC_UNIT



	/********************************************
		ELC --- EXPORT LC
		ILC --- IMPORT LC
		NLC/XLC - STANDBY LC
	********************************************/
	/* 
	For better performance , set forceplan on
	*/
	set forceplan on
	INSERT	GTDPEND1..RPT_AUTOBKOF
	select  ld.PROC_UNIT    ,
		ld.TRAN_REF_NBR ,
		ld.TRAN_SEQ_NBR ,
		tmh.EXT_REF_NBR,
		tmh.PROD_CAT,
		tmh.PROD_TYP,
		-1,		--MESSAGE_ID
		'',		--CUST_NAME
		'',		--ITEM_OS
		0,		--TOT_LC_LIAB_OS_AMT
		CASE	WHEN ld.PLC_OF_EXPRY = 'O'
				THEN pt.AUTO_BKOFF_GRACE_BASIS_OUR
			WHEN ld.PLC_OF_EXPRY = 'N'
				THEN pt.AUTO_BKOFF_GRACE_BASIS_THEIR
			WHEN ld.PLC_OF_EXPRY = 'X'
				THEN pt.AUTO_BKOFF_GRACE_BASIS_OTHER
			ELSE	pt.AUTO_BKOFF_GRACE_BASIS_OUR
		END,		--GRACE_PRD_BASIS
		CASE	WHEN ld.PLC_OF_EXPRY = 'O'
				THEN pt.AUTO_BKOFF_GRACE_PRD_OUR
			WHEN ld.PLC_OF_EXPRY = 'N'
				THEN pt.AUTO_BKOFF_GRACE_PRD_THEIR
			WHEN ld.PLC_OF_EXPRY = 'X'
				THEN pt.AUTO_BKOFF_GRACE_PRD_OTHER
			ELSE	pt.AUTO_BKOFF_GRACE_PRD_OUR
		END,		--GRACE_PRD
		
		
		lsc.AUTO_WO_IND,
		CASE	WHEN @PROC_DT	>=	CASE	WHEN ld.PLC_OF_EXPRY = 'O' and pt.AUTO_BKOFF_GRACE_BASIS_OUR = 'D'
								THEN dateadd(dd, pt.AUTO_BKOFF_GRACE_PRD_OUR, ld.LC_EXPRN_DT)
							WHEN ld.PLC_OF_EXPRY = 'N' and pt.AUTO_BKOFF_GRACE_BASIS_THEIR = 'D'
								THEN dateadd(dd, pt.AUTO_BKOFF_GRACE_PRD_THEIR, ld.LC_EXPRN_DT)
							WHEN ld.PLC_OF_EXPRY = 'X' and pt.AUTO_BKOFF_GRACE_BASIS_OTHER = 'D'
								THEN dateadd(dd, pt.AUTO_BKOFF_GRACE_PRD_OTHER, ld.LC_EXPRN_DT)
							else ld.LC_EXPRN_DT /*code later*/
						end
			THEN	'N'
			ELSE	'Y'
		END,		--IS_PRE_WARNING


		'',		--CUST_ID
		ld.LC_EXPRN_DT,
		CASE	WHEN ld.PLC_OF_EXPRY = 'O' and pt.AUTO_BKOFF_GRACE_BASIS_OUR = 'D'
			THEN dateadd(dd, pt.AUTO_BKOFF_GRACE_PRD_OUR, ld.LC_EXPRN_DT)
			WHEN ld.PLC_OF_EXPRY = 'N' and pt.AUTO_BKOFF_GRACE_BASIS_THEIR = 'D'
			THEN dateadd(dd, pt.AUTO_BKOFF_GRACE_PRD_THEIR, ld.LC_EXPRN_DT)
			WHEN ld.PLC_OF_EXPRY = 'X' and pt.AUTO_BKOFF_GRACE_BASIS_OTHER = 'D'
			THEN dateadd(dd, pt.AUTO_BKOFF_GRACE_PRD_OTHER, ld.LC_EXPRN_DT)
			else ld.LC_EXPRN_DT /*code later*/
		end,		--LC_WO_DT
		ld.PLC_OF_EXPRY,
		0,		--WO_CHRG_AMT
		'',		--MESSAGE
		-1,		--SUB_MSG_ID
		'',		--SUB_MESSAGE
		@BATCH_RUN_DT,
		@THIS_PROC_DT,
		@GMT_DT,
		-1,
		'N' -- BKOF_IND
	from		GTDMAST1..LC_DTL        ld,
			GTDMAST1..TP_MST_HDR    tmh,
			GTDMAST1..PROD_TYP	pt,
			GTDMAST1..LC_SYS_CNTRL	lsc

	where	ld.PROC_UNIT			= @PROC_UNIT
	and	ld.LC_STATUS			= 'I'
	and	ld.PROC_UNIT			= tmh.PROC_UNIT 
	and	ld.TRAN_REF_NBR			= tmh.TRAN_REF_NBR
	and	tmh.PROC_UNIT			= pt.PROC_UNIT
	and	tmh.PROD_TYP			= pt.PROD_TYP
	
	and	lsc.PROC_UNIT			= tmh.PROC_UNIT
	and	lsc.TRAN_REF_NBR		= tmh.TRAN_REF_NBR

	and	pt.PRE_BKOFF_WARN_PRD_BASIS	='D'
	and     dateadd ( dd, - pt.PRE_BKOFF_WARN_PRD, CASE	WHEN ld.PLC_OF_EXPRY = 'O' and pt.AUTO_BKOFF_GRACE_BASIS_OUR = 'D'
									THEN dateadd(dd, pt.AUTO_BKOFF_GRACE_PRD_OUR, ld.LC_EXPRN_DT)
								WHEN ld.PLC_OF_EXPRY = 'N' and pt.AUTO_BKOFF_GRACE_BASIS_THEIR = 'D'
									THEN dateadd(dd, pt.AUTO_BKOFF_GRACE_PRD_THEIR, ld.LC_EXPRN_DT)
								WHEN ld.PLC_OF_EXPRY = 'X' and pt.AUTO_BKOFF_GRACE_BASIS_OTHER = 'D'
									THEN dateadd(dd, pt.AUTO_BKOFF_GRACE_PRD_OTHER, ld.LC_EXPRN_DT)
								else	ld.LC_EXPRN_DT /*code later*/
							end) <= @PROC_DT
	and	tmh.PROD_CAT			in ('ELC','ILC','NLC','XLC')
	union all
	select	sg.PROC_UNIT,
		sg.TRAN_REF_NBR,
		sg.TRAN_SEQ_NBR,
		tmh.EXT_REF_NBR,
		tmh.PROD_CAT,
		tmh.PROD_TYP,
		-1,		--MESSAGE_ID
		'',		--CUST_NAME
		'',		--ITEM_OS
		0,		--TOT_LC_LIAB_OS_AMT
		'',		--GRACE_PRD_BASIS
		0,		--GRACE_PRD
		'Y',		--AUTO_WO_IND
		'N',		--IS_PRE_WARNING
		'',		--CUST_ID
		sg.EXPRN_DT,	--LC_EXPRN_DT
		sg.EXPRN_DT,	--LC_WO_DT
		'',		--PLC_OF_EXPRY
		0,		--WO_CHRG_AMT
		'',		--MESSAGE
		-1,		--SUB_MSG_ID
		'',		--SUB_MESSAGE
		@BATCH_RUN_DT,
		@THIS_PROC_DT,
		@GMT_DT,
		-1,
		'N'
	from		GTDMAST1..SG_DTL        sg,
			GTDMAST1..TP_MST_HDR    tmh

	where	sg.PROC_UNIT			= @PROC_UNIT
	and	sg.LC_STATUS			= 'I'
	and	sg.PROC_UNIT			= tmh.PROC_UNIT 
	and	sg.TRAN_REF_NBR			= tmh.TRAN_REF_NBR
	and     sg.EXPRN_DT			<= @PROC_DT
	and	tmh.PROD_CAT			in ('STG')


	print 'No. of selected LC = %1!',@@rowcount

	/***************************************************************
		To select the LC which has no outstanding liability 
		and not expired yet (excluded in the above selection)
		'ELC','ILC','NLC','XLC'
	****************************************************************/

	select 	@AUTOBKOF_ZERO_LIAB_TXN = Isnull(CONFIG_VAL, '')
	from 	GTDMAST1..PU_CONFIG
	where	PROC_UNIT 	= @PROC_UNIT 
	and	CONFIG_NM	='AUTOBKOF_ZERO_LIAB_TXN'

	if(@AUTOBKOF_ZERO_LIAB_TXN = 'Y')
	begin
		INSERT	GTDPEND1..RPT_AUTOBKOF
		select  ld.PROC_UNIT    ,
			ld.TRAN_REF_NBR ,
			ld.TRAN_SEQ_NBR ,
			tmh.EXT_REF_NBR,
			tmh.PROD_CAT,
			tmh.PROD_TYP,
			-1,		--MESSAGE_ID
			'',		--CUST_NAME
			'',		--ITEM_OS
			0,		--TOT_LC_LIAB_OS_AMT
			CASE	WHEN ld.PLC_OF_EXPRY = 'O'
					THEN pt.AUTO_BKOFF_GRACE_BASIS_OUR
				WHEN ld.PLC_OF_EXPRY = 'N'
					THEN pt.AUTO_BKOFF_GRACE_BASIS_THEIR
				WHEN ld.PLC_OF_EXPRY = 'X'
					THEN pt.AUTO_BKOFF_GRACE_BASIS_OTHER
				ELSE	pt.AUTO_BKOFF_GRACE_BASIS_OUR
			END,		--GRACE_PRD_BASIS
			CASE	WHEN ld.PLC_OF_EXPRY = 'O'
					THEN pt.AUTO_BKOFF_GRACE_PRD_OUR
				WHEN ld.PLC_OF_EXPRY = 'N'
					THEN pt.AUTO_BKOFF_GRACE_PRD_THEIR
				WHEN ld.PLC_OF_EXPRY = 'X'
					THEN pt.AUTO_BKOFF_GRACE_PRD_OTHER
				ELSE	pt.AUTO_BKOFF_GRACE_PRD_OUR
			END,		--GRACE_PRD
			
			
			lsc.AUTO_WO_IND,
			CASE	WHEN @PROC_DT	>=	CASE	WHEN ld.PLC_OF_EXPRY = 'O' and pt.AUTO_BKOFF_GRACE_BASIS_OUR = 'D'
									THEN dateadd(dd, pt.AUTO_BKOFF_GRACE_PRD_OUR, ld.LC_EXPRN_DT)
								WHEN ld.PLC_OF_EXPRY = 'N' and pt.AUTO_BKOFF_GRACE_BASIS_THEIR = 'D'
									THEN dateadd(dd, pt.AUTO_BKOFF_GRACE_PRD_THEIR, ld.LC_EXPRN_DT)
								WHEN ld.PLC_OF_EXPRY = 'X' and pt.AUTO_BKOFF_GRACE_BASIS_OTHER = 'D'
									THEN dateadd(dd, pt.AUTO_BKOFF_GRACE_PRD_OTHER, ld.LC_EXPRN_DT)
								else ld.LC_EXPRN_DT /*code later*/
							end
				THEN	'N'
				ELSE	'Y'
			END,		--IS_PRE_WARNING


			'',		--CUST_ID
			ld.LC_EXPRN_DT,
			CASE	WHEN ld.PLC_OF_EXPRY = 'O' and pt.AUTO_BKOFF_GRACE_BASIS_OUR = 'D'
				THEN dateadd(dd, pt.AUTO_BKOFF_GRACE_PRD_OUR, ld.LC_EXPRN_DT)
				WHEN ld.PLC_OF_EXPRY = 'N' and pt.AUTO_BKOFF_GRACE_BASIS_THEIR = 'D'
				THEN dateadd(dd, pt.AUTO_BKOFF_GRACE_PRD_THEIR, ld.LC_EXPRN_DT)
				WHEN ld.PLC_OF_EXPRY = 'X' and pt.AUTO_BKOFF_GRACE_BASIS_OTHER = 'D'
				THEN dateadd(dd, pt.AUTO_BKOFF_GRACE_PRD_OTHER, ld.LC_EXPRN_DT)
				else ld.LC_EXPRN_DT /*code later*/
			end,		--LC_WO_DT
			ld.PLC_OF_EXPRY,
			0,		--WO_CHRG_AMT
			'',		--MESSAGE
			-1,		--SUB_MSG_ID
			'',		--SUB_MESSAGE
			@BATCH_RUN_DT,
			@THIS_PROC_DT,
			@GMT_DT,
			-1,
			'N' -- BKOF_IND
		from		GTDMAST1..LC_DTL        ld,
				GTDMAST1..TP_MST_HDR    tmh,
				GTDMAST1..PROD_TYP	pt,
				GTDMAST1..LC_SYS_CNTRL	lsc,
				GTDMAST1..LC_LIAB_BAL   llb

		where	ld.PROC_UNIT			= @PROC_UNIT
		and	ld.LC_STATUS			= 'I'
		and	ld.PROC_UNIT			= tmh.PROC_UNIT 
		and	ld.TRAN_REF_NBR			= tmh.TRAN_REF_NBR
		and	tmh.PROC_UNIT			= pt.PROC_UNIT
		and	tmh.PROD_TYP			= pt.PROD_TYP
		and	lsc.PROC_UNIT			= tmh.PROC_UNIT
		and	lsc.TRAN_REF_NBR		= tmh.TRAN_REF_NBR
		and	pt.PRE_BKOFF_WARN_PRD_BASIS	='D'
		and     dateadd ( dd, - pt.PRE_BKOFF_WARN_PRD, CASE	WHEN ld.PLC_OF_EXPRY = 'O' and pt.AUTO_BKOFF_GRACE_BASIS_OUR = 'D'
										THEN dateadd(dd, pt.AUTO_BKOFF_GRACE_PRD_OUR, ld.LC_EXPRN_DT)
									WHEN ld.PLC_OF_EXPRY = 'N' and pt.AUTO_BKOFF_GRACE_BASIS_THEIR = 'D'
										THEN dateadd(dd, pt.AUTO_BKOFF_GRACE_PRD_THEIR, ld.LC_EXPRN_DT)
									WHEN ld.PLC_OF_EXPRY = 'X' and pt.AUTO_BKOFF_GRACE_BASIS_OTHER = 'D'
										THEN dateadd(dd, pt.AUTO_BKOFF_GRACE_PRD_OTHER, ld.LC_EXPRN_DT)
									else	ld.LC_EXPRN_DT /*code later*/
								end) > @PROC_DT
		and	tmh.PROD_CAT			in ('ELC','ILC','NLC','XLC')
		and	llb.PROC_UNIT			= tmh.PROC_UNIT
		and	llb.TRAN_REF_NBR		= tmh.TRAN_REF_NBR
		and	llb.LC_LIAB_OS_AMT		= 0

		print 'No. of selected LC (Not expired and No O/S liab) = %1!',@@rowcount
	end

	set forceplan off
	select	PROC_UNIT,
		TRAN_REF_NBR,
		TRAN_SEQ_NBR,
		EXT_REF_NBR,
		PROD_TYP,
		PROD_CAT,
		BATCH_DT	= BATCH_RUN_DT,
		BOOKOFF_DT	= LC_WO_DT
	FROM	GTDPEND1..RPT_AUTOBKOF
	WHERE	PROC_UNIT	= @PROC_UNIT
	AND	AUD_ID		= -1
	AND	GMT_DT		= @GMT_DT



/*
	select  ld.PROC_UNIT    ,
			ld.TRAN_REF_NBR ,
			ld.TRAN_SEQ_NBR ,
			ld.PLC_OF_EXPRY ,
			EXPRN_DT=ld.LC_EXPRN_DT ,
			pt.AUTO_BKOFF_GRACE_BASIS_OUR,
			pt.AUTO_BKOFF_GRACE_BASIS_THEIR,
			pt.AUTO_BKOFF_GRACE_BASIS_OTHER,
			pt.AUTO_BKOFF_GRACE_PRD_OUR,
			pt.AUTO_BKOFF_GRACE_PRD_THEIR,
			pt.AUTO_BKOFF_GRACE_PRD_OTHER,
			pt.PRE_BKOFF_WARN_PRD_BASIS,
			pt.PRE_BKOFF_WARN_PRD,
			NXT_PROC_DT		= @NXT_PROC_DT,
			THIS_PROC_DT	= @THIS_PROC_DT,
			pt.PROD_TYP, 
			pt.PROD_CAT,
			tmh.EXT_REF_NBR, 
			lsc.AUTO_WO_IND
	from    GTDMAST1..LC_DTL        ld,
			GTDMAST1..TP_MST_HDR    tmh,
			GTDMAST1..PROD_TYP      pt,
			GTDMAST1..LC_SYS_CNTRL  lsc      
	where   ld.PROC_UNIT			= @PROC_UNIT 
	and     ld.LC_STATUS			= 'I'
	and     ld.PROC_UNIT			= tmh.PROC_UNIT 
	and     ld.TRAN_REF_NBR			= tmh.TRAN_REF_NBR
	and     tmh.PROC_UNIT			= pt.PROC_UNIT
	and     tmh.PROD_TYP			= pt.PROD_TYP
	
	and     ld.PROC_UNIT            = lsc.PROC_UNIT 
	and     ld.TRAN_REF_NBR         = lsc.TRAN_REF_NBR                
    
	and     upper(pt.PRE_BKOFF_WARN_PRD_BASIS)  ='D'
	and     dateadd ( dd, - pt.PRE_BKOFF_WARN_PRD, ld.LC_EXPRN_DT) <= @PROC_DT
	and		tmh.PROD_CAT			= 'ELC'
        
        
    
    
    
        union

        select  ld.PROC_UNIT    ,
                ld.TRAN_REF_NBR ,
                ld.TRAN_SEQ_NBR ,
                ld.PLC_OF_EXPRY ,
                EXPRN_DT=ld.LC_EXPRN_DT  ,
                pt.AUTO_BKOFF_GRACE_BASIS_OUR,
                pt.AUTO_BKOFF_GRACE_BASIS_THEIR,
                pt.AUTO_BKOFF_GRACE_BASIS_OTHER,
                pt.AUTO_BKOFF_GRACE_PRD_OUR,
                pt.AUTO_BKOFF_GRACE_PRD_THEIR,
                pt.AUTO_BKOFF_GRACE_PRD_OTHER,
                pt.PRE_BKOFF_WARN_PRD_BASIS,
                pt.PRE_BKOFF_WARN_PRD,
                NXT_PROC_DT = @NXT_PROC_DT,
                THIS_PROC_DT = @THIS_PROC_DT,
                pt.PROD_TYP,
                pt.PROD_CAT,
                tmh.EXT_REF_NBR,
                lsc.AUTO_WO_IND
        from    GTDMAST1..LC_DTL        ld,
                GTDMAST1..TP_MST_HDR    tmh,
                GTDMAST1..PROD_TYP      pt,
                GTDMAST1..LC_SYS_CNTRL  lsc                                
        where   ld.PROC_UNIT            = @PROC_UNIT
        and     ld.LC_STATUS            = 'I'
        and     ld.PROC_UNIT            = tmh.PROC_UNIT
        and     ld.TRAN_REF_NBR         = tmh.TRAN_REF_NBR
        and     ld.PROC_UNIT            = lsc.PROC_UNIT 
        and     ld.TRAN_REF_NBR         = lsc.TRAN_REF_NBR                
        and     tmh.PROC_UNIT           = pt.PROC_UNIT
        and     tmh.PROD_TYP            = pt.PROD_TYP
        and     upper(pt.PRE_BKOFF_WARN_PRD_BASIS)  ='W'
        and     dateadd ( wk,
                          pt.PRE_BKOFF_WARN_PRD * -1,
                          ld.LC_EXPRN_DT) <= @PROC_DT
        and		tmh.PROD_CAT			= 'ELC'
       

        union

        select  ld.PROC_UNIT    ,
                ld.TRAN_REF_NBR ,
                ld.TRAN_SEQ_NBR ,
                ld.PLC_OF_EXPRY ,
                EXPRN_DT=ld.LC_EXPRN_DT  ,
                pt.AUTO_BKOFF_GRACE_BASIS_OUR,
                pt.AUTO_BKOFF_GRACE_BASIS_THEIR,
                pt.AUTO_BKOFF_GRACE_BASIS_OTHER,
                pt.AUTO_BKOFF_GRACE_PRD_OUR,
                pt.AUTO_BKOFF_GRACE_PRD_THEIR,
                pt.AUTO_BKOFF_GRACE_PRD_OTHER,
                pt.PRE_BKOFF_WARN_PRD_BASIS,
                pt.PRE_BKOFF_WARN_PRD,
                NXT_PROC_DT = @NXT_PROC_DT,
                THIS_PROC_DT = @THIS_PROC_DT,
                pt.PROD_TYP,
                pt.PROD_CAT,
                tmh.EXT_REF_NBR,
                lsc.AUTO_WO_IND                
        from    GTDMAST1..LC_DTL        ld,
                GTDMAST1..TP_MST_HDR    tmh,
                GTDMAST1..PROD_TYP      pt,
                GTDMAST1..LC_SYS_CNTRL  lsc
                                         
        where   ld.PROC_UNIT            = @PROC_UNIT
        and     ld.LC_STATUS            = 'I'
        and     ld.PROC_UNIT            = tmh.PROC_UNIT
        and     ld.TRAN_REF_NBR         = tmh.TRAN_REF_NBR
        and     ld.PROC_UNIT            = lsc.PROC_UNIT 
        and     ld.TRAN_REF_NBR         = lsc.TRAN_REF_NBR                
        and     tmh.PROC_UNIT           = pt.PROC_UNIT
        and     tmh.PROD_TYP            = pt.PROD_TYP
        and     upper(pt.PRE_BKOFF_WARN_PRD_BASIS)  ='M'
        and     dateadd ( mm,
                          pt.PRE_BKOFF_WARN_PRD * -1,
                          ld.LC_EXPRN_DT) <= @PROC_DT    
		and		tmh.PROD_CAT			= 'ELC'
       
        union

        select  ld.PROC_UNIT    ,
                ld.TRAN_REF_NBR ,
                ld.TRAN_SEQ_NBR ,
                ld.PLC_OF_EXPRY ,
                EXPRN_DT=ld.LC_EXPRN_DT  ,
                pt.AUTO_BKOFF_GRACE_BASIS_OUR,
                pt.AUTO_BKOFF_GRACE_BASIS_THEIR,
                pt.AUTO_BKOFF_GRACE_BASIS_OTHER,
                pt.AUTO_BKOFF_GRACE_PRD_OUR,
                pt.AUTO_BKOFF_GRACE_PRD_THEIR,
                pt.AUTO_BKOFF_GRACE_PRD_OTHER,
                pt.PRE_BKOFF_WARN_PRD_BASIS,
                pt.PRE_BKOFF_WARN_PRD,
                NXT_PROC_DT		= @NXT_PROC_DT,
                THIS_PROC_DT	= @THIS_PROC_DT,
                pt.PROD_TYP,
                pt.PROD_CAT,
                tmh.EXT_REF_NBR,
                lsc.AUTO_WO_IND                
        from    GTDMAST1..LC_DTL        ld,
                GTDMAST1..TP_MST_HDR    tmh,
                GTDMAST1..PROD_TYP      pt,
                GTDMAST1..LC_SYS_CNTRL  lsc
                                         
        where   ld.PROC_UNIT            = @PROC_UNIT
        and     ld.LC_STATUS            = 'I'
        and     ld.PROC_UNIT            = tmh.PROC_UNIT
        and     ld.TRAN_REF_NBR         = tmh.TRAN_REF_NBR
        and     ld.PROC_UNIT            = lsc.PROC_UNIT 
        and     ld.TRAN_REF_NBR         = lsc.TRAN_REF_NBR                
        and     tmh.PROC_UNIT           = pt.PROC_UNIT
        and     tmh.PROD_TYP            = pt.PROD_TYP
        and     upper(pt.PRE_BKOFF_WARN_PRD_BASIS)  ='Q'
        and     dateadd ( qq,
                          pt.PRE_BKOFF_WARN_PRD * -1,
                          ld.LC_EXPRN_DT) <= @PROC_DT    
		and		tmh.PROD_CAT			= 'ELC'
       union

        select  ld.PROC_UNIT    ,
                ld.TRAN_REF_NBR ,
                ld.TRAN_SEQ_NBR ,
                ld.PLC_OF_EXPRY ,
                EXPRN_DT=ld.LC_EXPRN_DT  ,
                pt.AUTO_BKOFF_GRACE_BASIS_OUR,
                pt.AUTO_BKOFF_GRACE_BASIS_THEIR,
                pt.AUTO_BKOFF_GRACE_BASIS_OTHER,
                pt.AUTO_BKOFF_GRACE_PRD_OUR,
                pt.AUTO_BKOFF_GRACE_PRD_THEIR,
                pt.AUTO_BKOFF_GRACE_PRD_OTHER,
                pt.PRE_BKOFF_WARN_PRD_BASIS,
                pt.PRE_BKOFF_WARN_PRD,
                NXT_PROC_DT = @NXT_PROC_DT,
                THIS_PROC_DT = @THIS_PROC_DT,
                pt.PROD_TYP,
                pt.PROD_CAT,
                tmh.EXT_REF_NBR,
                lsc.AUTO_WO_IND                
        from    GTDMAST1..LC_DTL        ld,
                GTDMAST1..TP_MST_HDR    tmh,
                GTDMAST1..PROD_TYP      pt,
                GTDMAST1..LC_SYS_CNTRL  lsc
                                         
        where   ld.PROC_UNIT            = @PROC_UNIT
        and     ld.LC_STATUS            = 'I'
        and     ld.PROC_UNIT            = tmh.PROC_UNIT
        and     ld.TRAN_REF_NBR         = tmh.TRAN_REF_NBR
        and     ld.PROC_UNIT            = lsc.PROC_UNIT 
        and     ld.TRAN_REF_NBR         = lsc.TRAN_REF_NBR                
        and     tmh.PROC_UNIT           = pt.PROC_UNIT
        and     tmh.PROD_TYP            = pt.PROD_TYP
        and     upper(pt.PRE_BKOFF_WARN_PRD_BASIS)  ='Y'
        and     dateadd ( yy,
                          pt.PRE_BKOFF_WARN_PRD * -1,
                          ld.LC_EXPRN_DT) <= @PROC_DT    
		and		tmh.PROD_CAT			= 'ELC'

*/
/********************************************
        LI - Letter Indemity 
********************************************/
/*
        union

        select  sd.PROC_UNIT    ,
                sd.TRAN_REF_NBR ,
                sd.TRAN_SEQ_NBR ,
                PLC_OF_EXPRY='O', --ld.PLC_OF_EXPRY     , 
                EXPRN_DT=bsl.PROC_DT    ,
                pt.AUTO_BKOFF_GRACE_BASIS_OUR,
                pt.AUTO_BKOFF_GRACE_BASIS_THEIR,
                pt.AUTO_BKOFF_GRACE_BASIS_OTHER,
                pt.AUTO_BKOFF_GRACE_PRD_OUR,
                pt.AUTO_BKOFF_GRACE_PRD_THEIR,
                pt.AUTO_BKOFF_GRACE_PRD_OTHER,
                pt.PRE_BKOFF_WARN_PRD_BASIS,
                pt.PRE_BKOFF_WARN_PRD,
                NXT_PROC_DT = @NXT_PROC_DT,
                THIS_PROC_DT = @THIS_PROC_DT,
                pt.PROD_TYP, 
                pt.PROD_CAT,
                tmh.EXT_REF_NBR,
                lsc.AUTO_WO_IND                
        from    GTDMAST1..SG_DTL        sd,
                GTDMAST1..BILL_SG_LNK   bsl,
                GTDMAST1..BILL_DTL      bd,
                GTDMAST1..TP_MST_HDR    tmh,
                GTDMAST1..PROD_TYP      pt,
                GTDMAST1..LC_SYS_CNTRL  lsc
                
        where   sd.PROC_UNIT            = @PROC_UNIT 
        and     sd.LC_STATUS            = 'I'
        and     sd.PROC_UNIT            = tmh.PROC_UNIT 
        and     sd.TRAN_REF_NBR         = tmh.TRAN_REF_NBR
        and     sd.PROC_UNIT            = lsc.PROC_UNIT 
        and     sd.TRAN_REF_NBR         = lsc.TRAN_REF_NBR                
        and     bsl.PROC_UNIT           = sd.PROC_UNIT
        and     bsl.SG_TRAN_NBR         = sd.TRAN_REF_NBR
        and     bd.PROC_UNIT            = bsl.PROC_UNIT
        and     bd.TRAN_REF_NBR         = bsl.TRAN_REF_NBR
        and     bd.BILL_STATUS          = 'S'
        and     tmh.PROC_UNIT           = pt.PROC_UNIT
        and     tmh.PROD_TYP            = pt.PROD_TYP
        and     upper(pt.PRE_BKOFF_WARN_PRD_BASIS)  ='D'
        --and		lsc.AUTO_WO_IND = 'Y'        
        and     dateadd ( dd,
                          -7 - pt.PRE_BKOFF_WARN_PRD,
                          bsl.PROC_DT) <= @PROC_DT

        union

        select  sd.PROC_UNIT    ,
                sd.TRAN_REF_NBR ,
                sd.TRAN_SEQ_NBR ,
                PLC_OF_EXPRY='O', --ld.PLC_OF_EXPRY     ,
                EXPRN_DT=bsl.PROC_DT    ,
                pt.AUTO_BKOFF_GRACE_BASIS_OUR,
                pt.AUTO_BKOFF_GRACE_BASIS_THEIR,
                pt.AUTO_BKOFF_GRACE_BASIS_OTHER,
                pt.AUTO_BKOFF_GRACE_PRD_OUR,
                pt.AUTO_BKOFF_GRACE_PRD_THEIR,
                pt.AUTO_BKOFF_GRACE_PRD_OTHER,
                pt.PRE_BKOFF_WARN_PRD_BASIS,
                pt.PRE_BKOFF_WARN_PRD,
                NXT_PROC_DT = @NXT_PROC_DT,
                THIS_PROC_DT = @THIS_PROC_DT,
                pt.PROD_TYP, 
                pt.PROD_CAT,
                tmh.EXT_REF_NBR,
                lsc.AUTO_WO_IND                
        from    GTDMAST1..SG_DTL        sd,
                GTDMAST1..BILL_SG_LNK   bsl,
                GTDMAST1..BILL_DTL      bd,
                GTDMAST1..TP_MST_HDR    tmh,
                GTDMAST1..PROD_TYP      pt,
                GTDMAST1..LC_SYS_CNTRL  lsc
                                
        where   sd.PROC_UNIT            = @PROC_UNIT 
        and     sd.LC_STATUS            = 'I'
        and     sd.PROC_UNIT            = tmh.PROC_UNIT 
        and     sd.TRAN_REF_NBR         = tmh.TRAN_REF_NBR
        and     sd.PROC_UNIT            = lsc.PROC_UNIT 
        and     sd.TRAN_REF_NBR         = lsc.TRAN_REF_NBR                
        and     bsl.PROC_UNIT           = sd.PROC_UNIT
        and     bsl.SG_TRAN_NBR         = sd.TRAN_REF_NBR
        and     bd.PROC_UNIT            = bsl.PROC_UNIT
        and     bd.TRAN_REF_NBR         = bsl.TRAN_REF_NBR
        and     bd.BILL_STATUS          = 'S'
        and     tmh.PROC_UNIT           = pt.PROC_UNIT
        and     tmh.PROD_TYP            = pt.PROD_TYP
        and     upper(pt.PRE_BKOFF_WARN_PRD_BASIS)  ='W'
        --and		lsc.AUTO_WO_IND = 'Y'        
        and     dateadd ( wk,
                          pt.PRE_BKOFF_WARN_PRD * -1,
                          bsl.PROC_DT) <= @PROC_DT

        union

        select  sd.PROC_UNIT    ,
                sd.TRAN_REF_NBR ,
                sd.TRAN_SEQ_NBR ,
                PLC_OF_EXPRY='O', --ld.PLC_OF_EXPRY     ,
                EXPRN_DT=bsl.PROC_DT    ,
                pt.AUTO_BKOFF_GRACE_BASIS_OUR,
                pt.AUTO_BKOFF_GRACE_BASIS_THEIR,
                pt.AUTO_BKOFF_GRACE_BASIS_OTHER,
                pt.AUTO_BKOFF_GRACE_PRD_OUR,
                pt.AUTO_BKOFF_GRACE_PRD_THEIR,
                pt.AUTO_BKOFF_GRACE_PRD_OTHER,
                pt.PRE_BKOFF_WARN_PRD_BASIS,
                pt.PRE_BKOFF_WARN_PRD,
                NXT_PROC_DT = @NXT_PROC_DT,
                THIS_PROC_DT = @THIS_PROC_DT,
                pt.PROD_TYP, 
                pt.PROD_CAT,
                tmh.EXT_REF_NBR,
                lsc.AUTO_WO_IND                 
        from    GTDMAST1..SG_DTL        sd,
                GTDMAST1..BILL_SG_LNK   bsl,
                GTDMAST1..BILL_DTL      bd,
                GTDMAST1..TP_MST_HDR    tmh,
                GTDMAST1..PROD_TYP      pt,
                GTDMAST1..LC_SYS_CNTRL  lsc
                                
        where   sd.PROC_UNIT            = @PROC_UNIT 
        and     sd.LC_STATUS            = 'I'
        and     sd.PROC_UNIT            = tmh.PROC_UNIT 
        and     sd.TRAN_REF_NBR         = tmh.TRAN_REF_NBR
        and     sd.PROC_UNIT            = lsc.PROC_UNIT 
        and     sd.TRAN_REF_NBR         = lsc.TRAN_REF_NBR                
        and     bsl.PROC_UNIT           = sd.PROC_UNIT
        and     bsl.SG_TRAN_NBR         = sd.TRAN_REF_NBR
        and     bd.PROC_UNIT            = bsl.PROC_UNIT
        and     bd.TRAN_REF_NBR         = bsl.TRAN_REF_NBR
        and     bd.BILL_STATUS          = 'S'
        and     tmh.PROC_UNIT           = pt.PROC_UNIT
        and     tmh.PROD_TYP            = pt.PROD_TYP
        and     upper(pt.PRE_BKOFF_WARN_PRD_BASIS)  ='M'
        --and		lsc.AUTO_WO_IND = 'Y'        
        and     dateadd ( mm,
                          pt.PRE_BKOFF_WARN_PRD * -1,
                          bsl.PROC_DT) <= @PROC_DT

        union

        select  sd.PROC_UNIT    ,
                sd.TRAN_REF_NBR ,
                sd.TRAN_SEQ_NBR ,
                PLC_OF_EXPRY='O', --ld.PLC_OF_EXPRY     ,
                EXPRN_DT=bsl.PROC_DT    ,
                pt.AUTO_BKOFF_GRACE_BASIS_OUR,
                pt.AUTO_BKOFF_GRACE_BASIS_THEIR,
                pt.AUTO_BKOFF_GRACE_BASIS_OTHER,
                pt.AUTO_BKOFF_GRACE_PRD_OUR,
                pt.AUTO_BKOFF_GRACE_PRD_THEIR,
                pt.AUTO_BKOFF_GRACE_PRD_OTHER,
                pt.PRE_BKOFF_WARN_PRD_BASIS,
                pt.PRE_BKOFF_WARN_PRD,
                NXT_PROC_DT = @NXT_PROC_DT,
                THIS_PROC_DT = @THIS_PROC_DT,
                pt.PROD_TYP, 
                pt.PROD_CAT,
                tmh.EXT_REF_NBR,
                lsc.AUTO_WO_IND                 
        from    GTDMAST1..SG_DTL        sd,
                GTDMAST1..BILL_SG_LNK   bsl,
                GTDMAST1..BILL_DTL      bd,
                GTDMAST1..TP_MST_HDR    tmh,
                GTDMAST1..PROD_TYP      pt,
                GTDMAST1..LC_SYS_CNTRL  lsc
                                
        where   sd.PROC_UNIT            = @PROC_UNIT 
        and     sd.LC_STATUS            = 'I'
        and     sd.PROC_UNIT            = tmh.PROC_UNIT 
        and     sd.TRAN_REF_NBR         = tmh.TRAN_REF_NBR
        and     sd.PROC_UNIT            = lsc.PROC_UNIT 
        and     sd.TRAN_REF_NBR         = lsc.TRAN_REF_NBR                
        and     bsl.PROC_UNIT           = sd.PROC_UNIT
        and     bsl.SG_TRAN_NBR         = sd.TRAN_REF_NBR
        and     bd.PROC_UNIT            = bsl.PROC_UNIT
        and     bd.TRAN_REF_NBR         = bsl.TRAN_REF_NBR
        and     bd.BILL_STATUS          = 'S'
        and     tmh.PROC_UNIT           = pt.PROC_UNIT
        and     tmh.PROD_TYP            = pt.PROD_TYP
        and     upper(pt.PRE_BKOFF_WARN_PRD_BASIS)  ='Q'
        --and		lsc.AUTO_WO_IND = 'Y'        
        and     dateadd ( qq,
                          pt.PRE_BKOFF_WARN_PRD * -1,
                          bsl.PROC_DT) <= @PROC_DT

        union

        select  sd.PROC_UNIT    ,
                sd.TRAN_REF_NBR ,
                sd.TRAN_SEQ_NBR ,
                PLC_OF_EXPRY='O', --ld.PLC_OF_EXPRY     ,
                EXPRN_DT=bsl.PROC_DT    ,
                pt.AUTO_BKOFF_GRACE_BASIS_OUR,
                pt.AUTO_BKOFF_GRACE_BASIS_THEIR,
                pt.AUTO_BKOFF_GRACE_BASIS_OTHER,
                pt.AUTO_BKOFF_GRACE_PRD_OUR,
                pt.AUTO_BKOFF_GRACE_PRD_THEIR,
                pt.AUTO_BKOFF_GRACE_PRD_OTHER,
                pt.PRE_BKOFF_WARN_PRD_BASIS,
                pt.PRE_BKOFF_WARN_PRD,
                NXT_PROC_DT = @NXT_PROC_DT,
                THIS_PROC_DT = @THIS_PROC_DT,
                pt.PROD_TYP, 
                pt.PROD_CAT,
                tmh.EXT_REF_NBR,
                lsc.AUTO_WO_IND
        from    GTDMAST1..SG_DTL        sd,
                GTDMAST1..BILL_SG_LNK   bsl,
                GTDMAST1..BILL_DTL      bd,
                GTDMAST1..TP_MST_HDR    tmh,
                GTDMAST1..PROD_TYP      pt,
                GTDMAST1..LC_SYS_CNTRL  lsc
                                
        where   sd.PROC_UNIT            = @PROC_UNIT 
        and     sd.LC_STATUS            = 'I'
        and     sd.PROC_UNIT            = tmh.PROC_UNIT 
        and     sd.TRAN_REF_NBR         = tmh.TRAN_REF_NBR
        and     sd.PROC_UNIT            = lsc.PROC_UNIT 
        and     sd.TRAN_REF_NBR         = lsc.TRAN_REF_NBR                
        and     bsl.PROC_UNIT           = sd.PROC_UNIT
        and     bsl.SG_TRAN_NBR         = sd.TRAN_REF_NBR
        and     bd.PROC_UNIT            = bsl.PROC_UNIT
        and     bd.TRAN_REF_NBR         = bsl.TRAN_REF_NBR
        and     bd.BILL_STATUS          = 'S'
        and     tmh.PROC_UNIT           = pt.PROC_UNIT
        and     tmh.PROD_TYP            = pt.PROD_TYP
        and     upper(pt.PRE_BKOFF_WARN_PRD_BASIS)  ='Y'
        --and		lsc.AUTO_WO_IND = 'Y'        
        and     dateadd ( yy,
                          pt.PRE_BKOFF_WARN_PRD * -1,
                          bsl.PROC_DT) <= @PROC_DT

*/
/************************************************************
        EB/PIBO - Payment Indemity 
        Note: 
                Don't care about BILL_STATUS
                Instead, look at CSGN_STATUS
                But usually, BILL_STATUS='S' when
                an SAPI is created...
*************************************************************/
/*
        union

        select  bd.PROC_UNIT    ,
                bd.TRAN_REF_NBR ,
                bd.TRAN_SEQ_NBR ,
                PLC_OF_EXPRY='O', --ld.PLC_OF_EXPRY     , 
                EXPRN_DT=tth.PROC_DT    ,
                pt.AUTO_BKOFF_GRACE_BASIS_OUR,
                pt.AUTO_BKOFF_GRACE_BASIS_THEIR,
                pt.AUTO_BKOFF_GRACE_BASIS_OTHER,
                pt.AUTO_BKOFF_GRACE_PRD_OUR,
                pt.AUTO_BKOFF_GRACE_PRD_THEIR,
                pt.AUTO_BKOFF_GRACE_PRD_OTHER,
                pt.PRE_BKOFF_WARN_PRD_BASIS,
                pt.PRE_BKOFF_WARN_PRD,
                NXT_PROC_DT = @NXT_PROC_DT,
                THIS_PROC_DT = @THIS_PROC_DT,
                pt.PROD_TYP, 
                pt.PROD_CAT,
                tmh.EXT_REF_NBR,
                lsc.AUTO_WO_IND
                
        from    GTDMAST1..BILL_DTL      bd,
                GTDMAST1..TP_MST_HDR    tmh,
                GTDMAST1..PROD_TYP      pt,
                GTDTRAN1..TP_TRAN_HDR   tth,
                GTDMAST1..LC_SYS_CNTRL  lsc
                                
        where   bd.PROC_UNIT            = @PROC_UNIT
        and     bd.CSGN_STATUS          = 'Y' 
        and     bd.PROC_UNIT            = tmh.PROC_UNIT 
        and     bd.TRAN_REF_NBR         = tmh.TRAN_REF_NBR
        and     bd.PROC_UNIT            = lsc.PROC_UNIT 
        and     bd.TRAN_REF_NBR         = lsc.TRAN_REF_NBR                
        and     tmh.PROC_UNIT           = pt.PROC_UNIT
        and     tmh.PROD_TYP            = pt.PROD_TYP
        and     tth.PROC_UNIT           = tmh.PROC_UNIT
        and     tth.TRAN_REF_NBR        = tmh.TRAN_REF_NBR
        and     tth.TRAN_TYP            = 'SAPI'
        and     tth.GMT_DT      = (select max(GMT_DT)
                                from    GTDTRAN1..TP_TRAN_HDR
                                where   PROC_UNIT = tth.PROC_UNIT
                                and     TRAN_REF_NBR = tth.TRAN_REF_NBR
                                and     TRAN_TYP = 'SAPI')
        and     upper(pt.PRE_BKOFF_WARN_PRD_BASIS)  ='D'
        --and		lsc.AUTO_WO_IND = 'Y'        
        and     dateadd ( dd,
                          -7 - pt.PRE_BKOFF_WARN_PRD,
                          tth.PROC_DT) <= @PROC_DT

        union

        select  bd.PROC_UNIT    ,
                bd.TRAN_REF_NBR ,
                bd.TRAN_SEQ_NBR ,
                PLC_OF_EXPRY='O', --ld.PLC_OF_EXPRY     , 
                EXPRN_DT=tth.PROC_DT    ,
                pt.AUTO_BKOFF_GRACE_BASIS_OUR,
                pt.AUTO_BKOFF_GRACE_BASIS_THEIR,
                pt.AUTO_BKOFF_GRACE_BASIS_OTHER,
                pt.AUTO_BKOFF_GRACE_PRD_OUR,
                pt.AUTO_BKOFF_GRACE_PRD_THEIR,
                pt.AUTO_BKOFF_GRACE_PRD_OTHER,
                pt.PRE_BKOFF_WARN_PRD_BASIS,
                pt.PRE_BKOFF_WARN_PRD,
                NXT_PROC_DT = @NXT_PROC_DT,
                THIS_PROC_DT = @THIS_PROC_DT,
                pt.PROD_TYP, 
                pt.PROD_CAT,
                tmh.EXT_REF_NBR,
                lsc.AUTO_WO_IND
                                
        from    GTDMAST1..BILL_DTL      bd,
                GTDMAST1..TP_MST_HDR    tmh,
                GTDMAST1..PROD_TYP      pt,
                GTDTRAN1..TP_TRAN_HDR   tth,
                GTDMAST1..LC_SYS_CNTRL  lsc                
        where   bd.PROC_UNIT            = @PROC_UNIT
        and     bd.CSGN_STATUS          = 'Y' 
        and     bd.PROC_UNIT            = tmh.PROC_UNIT 
        and     bd.TRAN_REF_NBR         = tmh.TRAN_REF_NBR
        and     bd.PROC_UNIT            = lsc.PROC_UNIT 
        and     bd.TRAN_REF_NBR         = lsc.TRAN_REF_NBR                
        and     tmh.PROC_UNIT           = pt.PROC_UNIT
        and     tmh.PROD_TYP            = pt.PROD_TYP
        and     tth.PROC_UNIT           = tmh.PROC_UNIT
        and     tth.TRAN_REF_NBR        = tmh.TRAN_REF_NBR
        and     tth.TRAN_TYP            = 'SAPI'
        and     tth.GMT_DT      = (select max(GMT_DT)
                                from    GTDTRAN1..TP_TRAN_HDR
                                where   PROC_UNIT = tth.PROC_UNIT
                                and     TRAN_REF_NBR = tth.TRAN_REF_NBR
                                and     TRAN_TYP = 'SAPI')
        and     upper(pt.PRE_BKOFF_WARN_PRD_BASIS)  ='W'
        --and		lsc.AUTO_WO_IND = 'Y'        
        and     dateadd ( wk,
                          pt.PRE_BKOFF_WARN_PRD * -1,
                          tth.PROC_DT) <= @PROC_DT

        union

        select  bd.PROC_UNIT    ,
                bd.TRAN_REF_NBR ,
                bd.TRAN_SEQ_NBR ,
                PLC_OF_EXPRY='O', --ld.PLC_OF_EXPRY     , 
                EXPRN_DT=tth.PROC_DT    ,
                pt.AUTO_BKOFF_GRACE_BASIS_OUR,
                pt.AUTO_BKOFF_GRACE_BASIS_THEIR,
                pt.AUTO_BKOFF_GRACE_BASIS_OTHER,
                pt.AUTO_BKOFF_GRACE_PRD_OUR,
                pt.AUTO_BKOFF_GRACE_PRD_THEIR,
                pt.AUTO_BKOFF_GRACE_PRD_OTHER,
                pt.PRE_BKOFF_WARN_PRD_BASIS,
                pt.PRE_BKOFF_WARN_PRD,
                NXT_PROC_DT = @NXT_PROC_DT,
                THIS_PROC_DT = @THIS_PROC_DT,
                pt.PROD_TYP, 
                pt.PROD_CAT,
                tmh.EXT_REF_NBR,
                lsc.AUTO_WO_IND
                                
        from    GTDMAST1..BILL_DTL      bd,
                GTDMAST1..TP_MST_HDR    tmh,
                GTDMAST1..PROD_TYP      pt,
                GTDTRAN1..TP_TRAN_HDR   tth,
                GTDMAST1..LC_SYS_CNTRL  lsc
                                
        where   bd.PROC_UNIT            = @PROC_UNIT
        and     bd.CSGN_STATUS          = 'Y' 
        and     bd.PROC_UNIT            = tmh.PROC_UNIT 
        and     bd.TRAN_REF_NBR         = tmh.TRAN_REF_NBR
        and     bd.PROC_UNIT            = lsc.PROC_UNIT 
        and     bd.TRAN_REF_NBR         = lsc.TRAN_REF_NBR                
        and     tmh.PROC_UNIT           = pt.PROC_UNIT
        and     tmh.PROD_TYP            = pt.PROD_TYP
        and     tth.PROC_UNIT           = tmh.PROC_UNIT
        and     tth.TRAN_REF_NBR        = tmh.TRAN_REF_NBR
        and     tth.TRAN_TYP            = 'SAPI'
        and     tth.GMT_DT      = (select max(GMT_DT)
                                from    GTDTRAN1..TP_TRAN_HDR
                                where   PROC_UNIT = tth.PROC_UNIT
                                and     TRAN_REF_NBR = tth.TRAN_REF_NBR
                                and     TRAN_TYP = 'SAPI')
        and     upper(pt.PRE_BKOFF_WARN_PRD_BASIS)  ='M'
        --and		lsc.AUTO_WO_IND = 'Y'        
        and     dateadd ( mm,
                          pt.PRE_BKOFF_WARN_PRD * -1,
                          tth.PROC_DT) <= @PROC_DT

        union

        select  bd.PROC_UNIT    ,
                bd.TRAN_REF_NBR ,
                bd.TRAN_SEQ_NBR ,
                PLC_OF_EXPRY='O', --ld.PLC_OF_EXPRY     , 
                EXPRN_DT=tth.PROC_DT    ,
                pt.AUTO_BKOFF_GRACE_BASIS_OUR,
                pt.AUTO_BKOFF_GRACE_BASIS_THEIR,
                pt.AUTO_BKOFF_GRACE_BASIS_OTHER,
                pt.AUTO_BKOFF_GRACE_PRD_OUR,
                pt.AUTO_BKOFF_GRACE_PRD_THEIR,
                pt.AUTO_BKOFF_GRACE_PRD_OTHER,
                pt.PRE_BKOFF_WARN_PRD_BASIS,
                pt.PRE_BKOFF_WARN_PRD,
                NXT_PROC_DT = @NXT_PROC_DT,
                THIS_PROC_DT = @THIS_PROC_DT,
                pt.PROD_TYP, 
                pt.PROD_CAT,
                tmh.EXT_REF_NBR,
                lsc.AUTO_WO_IND
                                
        from    GTDMAST1..BILL_DTL      bd,
                GTDMAST1..TP_MST_HDR    tmh,
                GTDMAST1..PROD_TYP      pt,
                GTDTRAN1..TP_TRAN_HDR   tth,
                GTDMAST1..LC_SYS_CNTRL  lsc
                                
        where   bd.PROC_UNIT            = @PROC_UNIT
        and     bd.CSGN_STATUS          = 'Y' 
        and     bd.PROC_UNIT            = tmh.PROC_UNIT 
        and     bd.TRAN_REF_NBR         = tmh.TRAN_REF_NBR
        and     bd.PROC_UNIT            = lsc.PROC_UNIT 
        and     bd.TRAN_REF_NBR         = lsc.TRAN_REF_NBR                
        and     tmh.PROC_UNIT           = pt.PROC_UNIT
        and     tmh.PROD_TYP            = pt.PROD_TYP
        and     tth.PROC_UNIT           = tmh.PROC_UNIT
        and     tth.TRAN_REF_NBR        = tmh.TRAN_REF_NBR
        and     tth.TRAN_TYP            = 'SAPI'
        and     tth.GMT_DT      = (select max(GMT_DT)
                                from    GTDTRAN1..TP_TRAN_HDR
                                where   PROC_UNIT = tth.PROC_UNIT
                                and     TRAN_REF_NBR = tth.TRAN_REF_NBR
                                and     TRAN_TYP = 'SAPI')
        and     upper(pt.PRE_BKOFF_WARN_PRD_BASIS)  ='Q'
        --and		lsc.AUTO_WO_IND = 'Y'        
        and     dateadd ( qq,
                          pt.PRE_BKOFF_WARN_PRD * -1,
                          tth.PROC_DT) <= @PROC_DT

        union

        select  bd.PROC_UNIT    ,
                bd.TRAN_REF_NBR ,
                bd.TRAN_SEQ_NBR ,
                PLC_OF_EXPRY='O', --ld.PLC_OF_EXPRY     , 
                EXPRN_DT=tth.PROC_DT    ,
                pt.AUTO_BKOFF_GRACE_BASIS_OUR,
                pt.AUTO_BKOFF_GRACE_BASIS_THEIR,
                pt.AUTO_BKOFF_GRACE_BASIS_OTHER,
                pt.AUTO_BKOFF_GRACE_PRD_OUR,
                pt.AUTO_BKOFF_GRACE_PRD_THEIR,
                pt.AUTO_BKOFF_GRACE_PRD_OTHER,
                pt.PRE_BKOFF_WARN_PRD_BASIS,
                pt.PRE_BKOFF_WARN_PRD,
                NXT_PROC_DT = @NXT_PROC_DT,
                THIS_PROC_DT = @THIS_PROC_DT,
                pt.PROD_TYP, 
                pt.PROD_CAT,
                tmh.EXT_REF_NBR,
                lsc.AUTO_WO_IND
                                
        from    GTDMAST1..BILL_DTL      bd,
                GTDMAST1..TP_MST_HDR    tmh,
                GTDMAST1..PROD_TYP      pt,
                GTDTRAN1..TP_TRAN_HDR   tth,
                GTDMAST1..LC_SYS_CNTRL  lsc
                                
        where   bd.PROC_UNIT            = @PROC_UNIT
        and     bd.CSGN_STATUS          = 'Y' 
        and     bd.PROC_UNIT            = tmh.PROC_UNIT 
        and     bd.TRAN_REF_NBR         = tmh.TRAN_REF_NBR
        and     bd.PROC_UNIT            = lsc.PROC_UNIT 
        and     bd.TRAN_REF_NBR         = lsc.TRAN_REF_NBR                
        and     tmh.PROC_UNIT           = pt.PROC_UNIT
        and     tmh.PROD_TYP            = pt.PROD_TYP
        and     tth.PROC_UNIT           = tmh.PROC_UNIT
        and     tth.TRAN_REF_NBR        = tmh.TRAN_REF_NBR
        and     tth.TRAN_TYP            = 'SAPI'
        and     tth.GMT_DT      = (select max(GMT_DT)
                                from    GTDTRAN1..TP_TRAN_HDR
                                where   PROC_UNIT = tth.PROC_UNIT
                                and     TRAN_REF_NBR =  tth.TRAN_REF_NBR
                                and     TRAN_TYP = 'SAPI')
        and     upper(pt.PRE_BKOFF_WARN_PRD_BASIS)  ='Y'
        --and		lsc.AUTO_WO_IND = 'Y'        
        and     dateadd ( yy,
                          pt.PRE_BKOFF_WARN_PRD * -1,
                          tth.PROC_DT) <= @PROC_DT

*/ 
/* ### DEFNCOPY: END OF DEFINITION */
 
/* ### DEFNCOPY: END OF DEFINITION */

go

PRINT 'CREATING PRIVILEGE : ' 
	
GO  

grant exec on dbo.USP_BAUTOBKOFF_SEL to oprgrp, gtsuser 


GO

sp_procxmode 'USP_BAUTOBKOFF_SEL', 'anymode'

GO
