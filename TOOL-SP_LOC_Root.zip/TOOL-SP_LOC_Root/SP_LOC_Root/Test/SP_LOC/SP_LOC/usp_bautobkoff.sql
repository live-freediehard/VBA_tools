
USE GTDPEND1
GO

SETUSER  'dbo'
GO	
	
PRINT 'STORED PROCEDURE : dbo.USP_BAUTOBKOFF'

GO
	
if exists (select * from dbo.sysobjects where id = Object_id('dbo.USP_BAUTOBKOFF') and (type = 'P' or type = 'RF'))
begin
	drop proc dbo.USP_BAUTOBKOFF
end
	
GO


create proc USP_BAUTOBKOFF
	@_pu			char(3),
	@_tran_ref		char(16),
	@_tran_seq		gtt_seq,	
	@_msg_code		int,
	@_paymtresult		int,
	@_wpresult		int,
	@_item_os		char(18),	
	@_liab_amt		gtt_amt,	
	@_wo_chrg_amt		gtt_amt,
	@_bkof_ind		char(1)
as
/******************************************************************************
*
*M      System:         Global Trade System
*M
*M      File Name:      USP_BAUTOBKOFF.sql
*M      Description:    Auto Bookoff -- Control batch
*M      Type:           Server Stored Procedure
*M
*M      Process:        Control batch to switch to different processing
*M      Input:          whcih, PROC_UNIT, TRAN_REF_NBR, TRAN_SEQ_NBR
*M      Output:         Nil
*M      Return:         0       - success
*M                      10106   - failure
*
*H      Modification Date:
*H      Modified By:
*H      Changes:
*H
*H      Creation Date:  Oct 01 1994
*H      Written By:     C. S. Wong
*H      Process:        Control batch to switch to different processing
*H      Input:          whcih, PROC_UNIT, TRAN_REF_NBR, TRAN_SEQ_NBR
*H      Output:         Nil
*H      Return:         0       - success
*H                      10106   - failure
*
******************************************************************************/
/******************************************************************************
**
**      Revision History
**
**      $Log:   O:/GTS/database/sql/batch/usp_bautobkoff.svl  $
*
*   Rev 1.1   Jul 24 1996 10:32:16   kwand
*Insert file header right after the "create proc" statement
*
*   Rev 1.0   23 Jul 1996 10:40:54   rajuk
*Checked in from initial workfile by PVCS Version Manager Project Assistant.
**
*******************************************************************************/

	declare	@status		int,
		@CUST_ID	gtt_custid,
		@CUST_NAME	char(35),
		@MESSAGE	varchar(255),
		@AUTO_WO_IND	char(1)
			
	select	@status		= 0,
		@CUST_ID	= '',
		@CUST_NAME	= ''
			
	
	/*  
	============================================================== 
	CUST_NAME is the name of Booking Liability 
	============================================================== 
	*/ 
	select  @CUST_ID = PTY_ID,
		@CUST_NAME = PTY_NM
	from	GTDMAST1..TP_PTY
	where	PROC_UNIT	= @_pu
	and	TRAN_REF_NBR	= @_tran_ref
	and	PTY_CD		= '7'				
    
	
	
	
	if (@_msg_code = 0)
		select	@_msg_code = 10409

	
	if (@_msg_code = 10409)
	begin
		if (@_paymtresult <> 0)
		begin
			select	@_msg_code = @_paymtresult
			/*
			if (@_paymt_result = 12151 or @_paymt_result = 12152)
				select @status = @_paymt_result
			else
				select @status = 12151
			*/
		end
		else if (@_wpresult <> 0)
		begin				
			select @_msg_code = 12500				
		end 
	end		
	
	
	
	/*  
	============================================================== 
	Two types of message here:
	1. Error message from GT_MESSAGES
	2. Manual Bookoff Reasons from LC_SYS_CNTRL.
	============================================================== 
	*/ 
	select	@AUTO_WO_IND = 'Y'

	select	@AUTO_WO_IND = AUTO_WO_IND
	from	GTDMAST1..LC_SYS_CNTRL
	where   PROC_UNIT = @_pu 
	and     TRAN_REF_NBR = @_tran_ref 
					
	if (@AUTO_WO_IND != 'Y')
	begin
		select	@MESSAGE = MANUAL_WO_REASON
		from	GTDMAST1..LC_SYS_CNTRL
		where	PROC_UNIT = @_pu
		and	TRAN_REF_NBR = @_tran_ref
	end 
	else
	begin
		select	@MESSAGE = MESSAGE
		from	GTDMAST1..GT_MESSAGES
		where	MESSAGE_ID = @_msg_code
	end
	
	/*
	if (@_sub_msg_code != 0)
	begin
		select	@SUB_MESSAGE = MESSAGE
		from	GTDMAST1..GT_MESSAGES
		where	MESSAGE_ID = @_sub_msg_code
	end
	*/


	UPDATE	GTDPEND1..RPT_AUTOBKOF
	SET	TRAN_SEQ_NBR	= @_tran_seq,
		MESSAGE_ID	= @_msg_code,
		CUST_NAME	= @CUST_NAME,
		ITEM_OS		= @_item_os,
		TOT_LC_LIAB_OS_AMT	= @_liab_amt,
		CUST_ID		= @CUST_ID,
		WO_CHRG_AMT	= @_wo_chrg_amt,
		MESSAGE		= @MESSAGE,
		AUD_ID		= 0,
		GMT_DT		= getdate(),
		BKOF_IND 	= @_bkof_ind
	WHERE	PROC_UNIT	= @_pu
	AND	TRAN_REF_NBR	= @_tran_ref


	return 0


go

PRINT 'CREATING PRIVILEGE : ' 
	
GO  

grant exec on dbo.USP_BAUTOBKOFF to oprgrp, gtsuser 


GO

sp_procxmode 'USP_BAUTOBKOFF', 'anymode'

GO
