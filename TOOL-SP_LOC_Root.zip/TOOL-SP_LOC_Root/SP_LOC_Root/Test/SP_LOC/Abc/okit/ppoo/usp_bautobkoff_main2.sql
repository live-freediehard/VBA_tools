
USE GTDPEND1
GO

SETUSER  'dbo'
GO	
	
PRINT 'STORED PROCEDURE : dbo.USP_BAUTOBKOFF_MAIN2'

GO
	
if exists (select * from dbo.sysobjects where id = Object_id('dbo.USP_BAUTOBKOFF_MAIN2') and (type = 'P' or type = 'RF'))
begin
	drop proc dbo.USP_BAUTOBKOFF_MAIN2
end
	
GO


CREATE PROC USP_BAUTOBKOFF_MAIN2 
	@_pu            char(3), 
	@_tran_ref      char(16), 
	@_tran_seq      gtt_seq, 
	@_prod_typ      char(6), 
	@_prod_cat      char(3), 
	@_status		int
as 
/****************************************************************************** 
* 
*M      System:         Global Trade System 
*M 
*M      File Name:      USP_BAUTOBKOFF_MAIN2.sql 
*M      Description:     
*M      Type:           Server Stored Procedure 
*M      Process:         
*M                      Book-off Transaction  
*M                      2. confirm 
*M                      3. release 
*M                      4. clo 
*M      Input:           
*M      Output:          
*M      Return:          
* 
*H      Delta:          960094 
*H      Date:           July 1996 
*H      By:             Edward 
*H      Changes:        Handle period basis 'Y', 'M', 'W' as well as 'D' 
*H 
*H      Modification Date: Mar 17, 1997, Steve Su - Added a new field ARAP_STATUS to TP_AR_AP_BAL 
*H      Modified By: 
*H      Changes: 
*H 
*H      Modification Date: Jun 29, 1995 - changa - fix select by dates 
*H      Modified By: 
*H      Changes: 
*H 
*H      Creation Date:  Mar 13 1995 
*H      Written By:     Gary Liu 
*H      Process:         
*H      Input:           
*H      Output:          
*H      Return:          
* 
******************************************************************************/ 
/****************************************************************************** 
** 
**      Revision History 
** 
**      $Log:   O:\GTS\database\sql\batch\USP_BAUTOBKOFF_MAIN2.svl  $ 
* 
*   Rev 1.8   Apr 06 1998 16:19:24   kwand 
*Bug #: 3235C9D_1 
* 
*   Rev 1.7   23 Mar 1998 15:28:02   paradind 
*3235C9D - AutoBookoff not picking up transactions due to outstanding payment transactions (which have been settled and are not outstanding) 
*Problems: 
*1) If a transaction has FADV that has not been settled or accepted in the same transactions, there will be an item in LC_CCY where the TRAN_AMT_TYPE is 'FADV',  
*causing the logic to fail even if the bill is settled. 
*2) Standalone transactions currently have a blank TRAN_AMT_TYP, causing the logic to fail although the standalone should not impact the liability. 
*3) This logic does not check to if any payment transactions have been confirmed and pending release, which it should 
*Resolution: 
*The logic was changed to: 
*1. Check if the last transaction for a bill is either "ACDS", "ACPT", "DPAY", "SETL" and not a standalone 
*2. Check for confirmed transactions 
* 
* 
*   Rev 1.6   Aug 15 1997 12:48:20   kwand 
*Bug Item #: 815LP28 
*Create new PT_Q entries with all approval status reset 
* 
*   Rev 1.5   Aug 08 1997 17:16:00   kwand 
*Bug Item #: 808Z6KA 
*Check if transaction evergreen 
* 
*   Rev 1.4   15 May 1997 23:43:30   yaggier 
*411YL7C - Auto Extension. 
* 
*   Rev 1.3   17 Mar 1997 10:36:22   sus 
*227CG69 : UK ARAP - Modify four existing tables (SYBUK) 
* 
*   Rev 1.2   02 Oct 1996 12:31:06   rajuk 
*HK0996 
*Modified Stored Procs 
* 
*   Rev 1.1   Jul 24 1996 10:32:26   kwand 
*Insert file header right after the "CREATE PROC" statement 
* 
*   Rev 1.0   23 Jul 1996 10:40:58   rajuk 
*Checked in from initial workfile by PVCS Version Manager Project Assistant. 
** 
*******************************************************************************/ 
        
	declare @grace_prd      int, 
		@grace_basis    char(1), 
		@EXPRN_DT       gtt_dt, 
		@status         int, 
		@new_tran_seq   gtt_seq, 
		@ERROR_CD       int, 
		@count          int, 
		@cust_name      char(35), 
		@amendment      char(1), 
		@payment        char(1), 
		@acctrec_os     char(1), 
		@acctpay_os     char(1), 
		@pending_chrg   char(1), 
		@item_os        char(18), 
		@bookoff_ready  char(1), 
		@new_item_nbr	char(4), 
		@pt_ref_nbr	gtt_ptref,
		@sub_status		int,
		@TRAN_APRVL_QUEUE_ID	numeric(8,0)
			 
	
	
	select  @status = @_status, 
		@sub_status = @_status,
		@ERROR_CD = 10106 
	
	/*  
	============================================================== 
	Make sure the Product Category passed in can be handled by 
	this stored procedure. 
	============================================================== 
	*/ 
	if (@status = 0) 
	begin
		if (@_prod_cat NOT IN ('ELC', 'ILC', 'STG', 'NLC', 'XLC'))
			select @status = @ERROR_CD
	end  
       
       
	
	
	begin tran TRAN_BAUTOBKOFF_MAIN2
	save tran SAVE_BAUTOBKOFF_MAIN2
	
	/*  
	============================================================== 
	Confirm this Bookoff Transaction 
	============================================================== 
	*/ 
	if (@status = 0) 
	begin
		if (@_prod_cat = 'ELC') 
			exec @status = GTDPEND1..USP_PELCBKOF_CNFM	@_pu, @_prod_typ, @_tran_ref, @_tran_seq
		if (@_prod_cat = 'ILC') 
			exec @status = GTDPEND1..USP_PILCBKOF_CNFM	@_pu, @_prod_typ, @_tran_ref, @_tran_seq
		if (@_prod_cat = 'STG') 
			exec @status = GTDPEND1..USP_PSTGBKOF_CNFM	@_pu, @_prod_typ, @_tran_ref, @_tran_seq
		if (@_prod_cat = 'NLC') 
			exec @status = GTDPEND1..USP_PNLCBKOF_CNFM	@_pu, @_prod_typ, @_tran_ref, @_tran_seq
		if (@_prod_cat = 'XLC') 
			exec @status = GTDPEND1..USP_PXLCBKOF_CNFM	@_pu, @_prod_typ, @_tran_ref, @_tran_seq
	end
	else
	begin
		rollback tran SAVE_BAUTOBKOFF_MAIN2
	end
        
  		
	if (@status = 0) 
	begin
		/*****************************************************
			UPDATE THE TRAN_APRVL_Q STATUS AS FRONT-END
		********************************************************/
		SELECT	@TRAN_APRVL_QUEUE_ID = QUEUE_ID
		FROM	GTDPEND1..TRAN_APRVL_Q
		where   PROC_UNIT = @_pu
		and     TRAN_REF_NBR = @_tran_ref
		and     TRAN_SEQ_NBR = @_tran_seq
		
		EXEC @status = USP_CTRA_APRV_REJ @_pu, @TRAN_APRVL_QUEUE_ID, 'A', 'N', 'Y'
		if ( @status != 0 )
		begin
			rollback tran SAVE_BAUTOBKOFF_MAIN2
		end
		
		if (@status = 0)
		begin
			exec @status = USP_QLCRLSREJ_DELENTRY @_pu, @_tran_ref, @_tran_seq
			if ( @status != 0 )
			begin
				rollback tran SAVE_BAUTOBKOFF_MAIN2
			end
		end
	end
	if (@status = 0) 
	begin 
		exec @status = USP_CGEN_TRACER @_pu, @_tran_ref, @_tran_seq
	
		if ( @status != 0 )
		begin
			/* Fail to add an entry to TP_TRACER */
			rollback tran SAVE_BAUTOBKOFF_MAIN2
		end
	end 
			
	if (@status = 0) 
	begin
		if (@_prod_cat = 'ELC') 
			exec @status = GTDPEND1..USP_PELCBKOF_RLS	@_pu, @_prod_typ, 
									@_tran_ref, @_tran_seq
		if (@_prod_cat = 'ILC') 
			exec @status = GTDPEND1..USP_PILCBKOF_RLS	@_pu, @_prod_typ, 
									@_tran_ref, @_tran_seq
		if (@_prod_cat = 'STG') 
			exec @status = GTDPEND1..USP_PSTGBKOF_RLS	@_pu, @_prod_typ, 
									@_tran_ref, @_tran_seq
		if (@_prod_cat = 'NLC') 
			exec @status = GTDPEND1..USP_PNLCBKOF_RLS	@_pu, @_prod_typ, 
									@_tran_ref, @_tran_seq
		if (@_prod_cat = 'XLC') 
			exec @status = GTDPEND1..USP_PXLCBKOF_RLS	@_pu, @_prod_typ, 
									@_tran_ref, @_tran_seq
									
		if ( @status != 0 )
		begin
			rollback tran SAVE_BAUTOBKOFF_MAIN2
		end

	end        
    
    	
	
	if (@status = 0) 
	begin
		if (@_prod_cat = 'ELC') 
			exec @status = GTDPEND1..USP_PELCBKOF_CLO	@_pu, @_prod_typ, @_tran_ref,  
									@_tran_seq
		if (@_prod_cat = 'ILC') 
			exec @status = GTDPEND1..USP_PILCBKOF_CLO	@_pu, @_prod_typ, @_tran_ref,  
									@_tran_seq
		if (@_prod_cat = 'STG') 
			exec @status = GTDPEND1..USP_PSTGBKOF_CLO	@_pu, @_prod_typ, @_tran_ref,  
									@_tran_seq
		if (@_prod_cat = 'NLC') 
			exec @status = GTDPEND1..USP_PNLCBKOF_CLO	@_pu, @_prod_typ, @_tran_ref,  
									@_tran_seq		
		if (@_prod_cat = 'XLC') 
			exec @status = GTDPEND1..USP_PXLCBKOF_CLO	@_pu, @_prod_typ, @_tran_ref,  
									@_tran_seq
									
		if ( @status != 0 )
		begin
			rollback tran SAVE_BAUTOBKOFF_MAIN2
		end
	end 
        
	
	
	/***********************************
		FINALLY WE CAN PREPARE TO INSERT
		INTO REPORT TABLE
	***********************************/
	/*
	select	@sub_status = @status
	if (@status != 0) 
	begin 
		if (@status != 10401)
		begin
			PRINT "Fail to confirm, release, close, or book-off!!!"  				 
			select @status = 10496	
		end
	end  		
	else
	begin 
		PRINT "Txn has been booked off..." 		
		select @status = 10409						 
	end 
	
	
	
	if (@status = 10409)
	begin
		if (@_paymt_result <> 0)
		begin
			if (@_paymt_result = 12151 or @_paymt_result = 12152)
				select @status = @_paymt_result
			else
				select @status = 12151
		end
		else if (@_wp_result <> 0)
		begin				
			select @status = 12500				
		end 
	end		
	else if (@status <> 0)
	begin			
		rollback tran SAVE_BAUTOBKOFF_MAIN2
	end
	
	
	
	exec GTDPEND1..USP_BAUTOBKOFF	@status,	@_pu,
									@_tran_ref,	@_tran_seq,
									@_item_os,	@_liab_amt,
									@_grace_basis,		@_grace_period,
									@_lc_exp_dt,@_bookoff_dt,
									@_plc_exp,	@_wo_chrg_amt,
									@sub_status
		
	
	*/
	commit tran TRAN_BAUTOBKOFF_MAIN2
	
	return @status 

go

PRINT 'CREATING PRIVILEGE : ' 
	
GO  

grant exec on dbo.USP_BAUTOBKOFF_MAIN2 to oprgrp, gtsuser 


GO

sp_procxmode 'USP_BAUTOBKOFF_MAIN2', 'anymode'

GO
