package com.chase.infra.util.sort2;

import com.chase.infra.util.sort.SortCriteria;


public class ReflectionComparable implements Comparable {

		Object obj;
		SortCriteria c;

		public ReflectionComparable(Object _obj, SortCriteria _c) {
			this.obj = _obj;
			this.c = _c;
		}

		public int compareTo(Object o) {
			try {
				ReflectionComparable to = (ReflectionComparable)o;
				Object objc = to.obj;
				int n = c.getSortMethodsNumber();
				for (int i=0; i<n; i++) {
					String method = c.getMethod(i);
					int order = c.getSortOrder(i);
					Object _obj1 = obj.getClass().getMethod(method, null).invoke(obj, null);
					Object _obj2 = objc.getClass().getMethod(method, null).invoke(objc, null);
					int b = (order == 1)? 1 : -1;
					int result = comp(_obj1, _obj2);
					if (result != 0) {
						return result * b;
					}
				}
			} catch (Exception e) {
				System.out.println("ReflectionComparable.compareTo : "+e.toString());
			}
			return 0;
		}

                public Object getObject() {
                  return obj;
                }

		protected int comp(Object obj1, Object obj2) {

			if (obj1 instanceof String) {
				return ((String) obj1).compareTo((String) obj2);
			}
			if (obj1 instanceof Number) {
				Double d1 = new Double(((Number) obj1).doubleValue());
				Double d2 = new Double(((Number) obj2).doubleValue());
				return d1.compareTo(d2);
			}
			if (obj1 instanceof java.util.Date) {
				return ((java.util.Date) obj1).compareTo((java.util.Date) obj2);
			}
			if (obj1 instanceof Boolean) {
				boolean b1 = ((Boolean) obj1).booleanValue();
				boolean b2 = ((Boolean) obj2).booleanValue();
				if (b1 == b2) {
					return 0;
				}
				if (b1) {
					return 1;
				}
				return -1;
			}
			return 0;	//not defined type, so consider it un-comparable (thus equal)
		}
}


