package com.chase.infra.util.sort2;

import java.util.Vector;


public class VectorHeap {

	protected Vector data;

	public VectorHeap() {
		data = new Vector();
	}

	public VectorHeap(Vector v) {
		int i;
		data = new Vector(v.size());

		for (i = 0; i < v.size(); i++) {
			add((Comparable)v.elementAt(i));
		}
	}

	protected static int parentOf(int i) {
		return (i-1)/2;
	}

	protected static int leftChildOf(int i) {
		return 2*i+1;
	}

	protected static int rightChildOf(int i) {
		return 2*(i+1);
	}

	public Comparable peek() {
		return (Comparable)data.elementAt(0);
	}

	public Comparable remove() {
		Comparable minVal = peek();
		data.setElementAt(data.elementAt(data.size()-1),0);
		data.setSize(data.size()-1);

		if (data.size() > 1) pushDownRoot(0);

		return minVal;
	}

	public void add(Comparable value) {
		data.addElement(value);
		percolateUp(data.size()-1);
	}

	public boolean isEmpty() {
		return data.size() == 0;
	}

	protected void percolateUp(int leaf) {
		int parent = parentOf(leaf);
		Comparable value = (Comparable)(data.elementAt(leaf));

		while (leaf > 0 &&
		       (value.compareTo((Comparable)(data.elementAt(parent))) < 0)) {
			data.setElementAt(data.elementAt(parent),leaf);
			leaf = parent;
			parent = parentOf(leaf);
		}

		data.setElementAt(value,leaf);
	}

	protected void pushDownRoot(int root) {
		int heapSize = data.size();
		Comparable value = (Comparable)data.elementAt(root);

		while (root < heapSize) {
			int childpos = leftChildOf(root);

			if (childpos < heapSize) {
				if ((rightChildOf(root) < heapSize) &&
				    (((Comparable)(data.elementAt(childpos+1))).compareTo
				     ((Comparable)(data.elementAt(childpos))) < 0)) {
					childpos++;
				}
                                if (((Comparable)(data.elementAt(childpos))).compareTo
				    (value) < 0) {
					data.setElementAt(data.elementAt(childpos),root);
					root = childpos;
				}
				else {
					data.setElementAt(value,root);
					return;
				}
			} else {
				data.setElementAt(value,root);
				return;
			}
		}
	}

	public int size() {
		return data.size();
	}

	public void clear() {
		data.clear();
	}

	public String toString() {
		return "<VectorHeap: "+data+">";
	}
}
