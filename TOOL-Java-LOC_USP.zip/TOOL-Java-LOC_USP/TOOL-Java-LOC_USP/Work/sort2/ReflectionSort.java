package com.chase.infra.util.sort2;

import java.util.Vector;

import com.chase.infra.util.sort.SortCriteria;


public class ReflectionSort {

  Vector v;
  SortCriteria sc;

  public ReflectionSort(Vector _v, SortCriteria _sc) {
        v = _v;
        sc = _sc;
  }

  public Vector perform() {

          long t1 = System.currentTimeMillis();
          System.out.println("perform sort");


          VectorHeap p = new VectorHeap();


          for (int i=0; i<v.size(); i++) {
            p.add(new ReflectionComparable(v.get(i), sc));
          }

          Vector ret = new Vector();
          while ( ! p.isEmpty() ) {
            ReflectionComparable vcomp = (ReflectionComparable) p.remove();
            ret.add(vcomp.getObject());
          }

          long t2 = System.currentTimeMillis();
          long second = (t2-t1) / 1000;
          System.out.println("costs : "+second+"s"+" of size "+v.size());

          return ret;
  }

}
