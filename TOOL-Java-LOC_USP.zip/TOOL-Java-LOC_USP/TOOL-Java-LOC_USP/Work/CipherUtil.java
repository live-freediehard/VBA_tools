package com.chase.infra.util;
import javax.crypto.spec.*;
import java.security.*;
import javax.crypto.*;

public final class CipherUtil {

	static boolean _providerLoaded = false;
	public static CipherUtil instance= new CipherUtil();
	private synchronized  void loadProvider() throws CipherUtilException{
		if (! _providerLoaded) {
			try {
			    Config cf = new TIEConfig("cipher.ini");
				String url=cf.getProperty("provider_url","org.bouncycastle.jce.provider.BouncyCastleProvider");
				Provider pro= (Provider)Class.forName(url).newInstance();
				Security.addProvider(pro);
				_providerLoaded = true;
				//System.out.println("load the provider");
			} catch (Exception ex) {
				throw new CipherUtilException(ex.getMessage());			
			}
		}
	}
	/**
	*	encrypt an input plain text using private key algorithm (DESede plus Base64) 
	*	@param plainText input plain Text in ascii format
	*	@param key the private key 
	*	@return the cipher text in ascii format
	*	@exception throw when any padding key error, no such provider
	*/
	public  String encrypt(String plainText, String key) throws CipherUtilException {				
		String encrypted = "";
		if (! _providerLoaded) {
			loadProvider();
		}
		try {
			SecureRandom sr = new SecureRandom(key.getBytes());
			KeyGenerator kg = KeyGenerator.getInstance("DESede");
			kg.init(sr);
			SecretKey sk = kg.generateKey();
			
			// create an instance of cipher
			Cipher cipher = Cipher.getInstance("DESede");
			
			// initialize the cipher with the key 
			cipher.init(Cipher.ENCRYPT_MODE, sk);
			
			// encrypt by DES!
			byte[] desEnc = cipher.doFinal(plainText.getBytes());
			
			// encrypt by base64
			encrypted = Base64Util.encode(desEnc);
		} catch (Exception ex) {
			throw new CipherUtilException(ex.getMessage());
		}
		return encrypted;		
	}
	
	/**
	*	decrypt the input cipher ascii text using private key algorithm (Base64 plus DESede)
	*	@param cipherText the input cipher text in ascii format
	*	@param key the private key
	*	@return the plain text in ascii format
	*	@exception throw when any padding key error, no such provider	
	*/
	public  String decrypt(String cipherText, String key) throws CipherUtilException {				
		String decryptedStr = "";
		if (! _providerLoaded) {
			loadProvider();
		}
		try {
			byte[] desEnc = Base64Util.decode(cipherText);
			// create a binary key from the argument key (seed)
			SecureRandom sr = new SecureRandom(key.getBytes());
			KeyGenerator kg = KeyGenerator.getInstance("DESede");
			kg.init(sr);
			SecretKey sk = kg.generateKey();
			
			// do the decryption with that key
			Cipher cipher = Cipher.getInstance("DESede");
			cipher.init(Cipher.DECRYPT_MODE, sk);
			byte[] decrypted = cipher.doFinal(desEnc);		
			decryptedStr =  new String(decrypted);			
		} catch (Exception ex) {
			throw new CipherUtilException (ex.getMessage());
		}		
		return decryptedStr;
	}
	public static void main(String[] args){
		if (args.length < 3) {
			com.chase.infra.util.LogWrapper.instance.logInfo("Usage : CipherUtil <plain_text> <key> <ENCRYPTED | DECRYPTED>");
			return;
		}

		String str = args[0];
		String key = args[1];
		String method = args[2];


		if ("ENCRYPTED".equals(method)) {
			str = CipherUtil.instance.encrypt(str,key);
			System.out.println(str);
		} else {
			str = CipherUtil.instance.decrypt(str,key);
			System.out.println(str);
		}
		
	}
}