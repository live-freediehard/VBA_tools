/*
 * @(#)LogStream.java  1.0 99/04/27
 *
 * Copyright by CHASE MANHATTAN BANK (HONG KONG)
 * All rights reserved.
 *
 */
package com.chase.infra.util.log;
import java.io.*;
import java.util.Properties;
import java.util.Calendar;
/**
 * A <code>NullOutputStream</code> is a dummy out channel
 */
final class NullOutputStream extends OutputStream
{
/**
 *  A <code>NullOutputStream</code> is a dummy out channel
 *  @param a byte to be wirte
 *  @exception IOException  IO Error
 */
     public void write(int b) throws IOException
     {
        return ;
     }
}
/**
 * A <code>LogStream</code> is a class specified for out put management.
 *  This class provide two static PrinterStream object
 *  <code>out</code> is <code>PrinterStream</code> object standard output
 * <code>err</code> is <code>PrinterStream</code> object  error output
 *  These two member variabel is similary to System.out and System.err.
 *  for example
 *  LogStream.out.println("A log Message!");
 *  LogStream.err.println("A err Message!");
 *   ....
 * catch(Exception e)
 * {
 *    e.printStrackTrace(LogStream.err)
 * }
 *
 *  This Static object will be initialized accord a log.ini file
 *  the location of log.ini according to  System.getProperty("LOGPATH")
 *  This this value is not existed in Syste.properties object.
 *  The location of this object will be redirected to the Java_HOME
 *  directory
 *
 *  Config file :- log.ini
 * ============================
 *  #
 *  # This log file config file for  LogStream.java
 *  #
 *  #
 *  #
 *  #logType : NULL -no output,  FILE - output to file, otherwise Std out
 *  logType=FILE
 *  #errlogType : NULL -no output,  FILE - output to file, otherwise Std err
 *  errlogType=FILE
 *  #OutFile : output file prefix
 *  OutFile=C:\\out1
 *  #OutFile : err file name
 *  ErrFile=C:\\out2
 *
 *
 *
 */

final public class LogStream
{
    static private PrintWriter outStream = new PrintWriter(System.out);
    static private PrintWriter errStream = new PrintWriter(System.err);
    static{
        try{
            Properties p =new Properties();
            String logPath =System.getProperty( "LOGPATH"
                              , System.getProperty("java.home","")
                             )+File.separator+"log.ini";
            p.load(new FileInputStream(logPath));
            String logType=p.getProperty("logType");
            String errLogType=p.getProperty("errlogType");
            String outFile=p.getProperty("OutFile");

            if(logType.equalsIgnoreCase("File"))
            {
                Calendar date = Calendar.getInstance();
                StringBuffer str = new StringBuffer();
                str.append(outFile);
                int nYear=date.get(Calendar.YEAR)
                    ,nMonth=date.get(Calendar.MONTH)+1
                    ,nDay=date.get(Calendar.DAY_OF_MONTH)
                    ,nHour=date.get(Calendar.HOUR)
                    ,nMin=date.get(Calendar.MINUTE)
                    ,nSec=date.get(Calendar.SECOND)
                    ;

                str.append(nYear);
                if(nMonth<10) str.append("0");
                str.append(nMonth);
                if(nDay<10)   str.append("0");
                str.append(nDay);
                if(nHour<10)  str.append("0");
                 str.append(nHour);
                if(nMin<10)   str.append("0");
                str.append(nMin);
                if(nSec<10)   str.append("0");
                str.append(nSec);
                OutputStream oStream = new FileOutputStream(new String(str));
                outStream = new PrintWriter(oStream);
            }

            else if(logType.equalsIgnoreCase("NULL"))
            {
                outStream = new PrintWriter(new NullOutputStream());
            }

            if(errLogType.equalsIgnoreCase("File"))
            {
                String errFile=p.getProperty("ErrFile");
                OutputStream oStream = new FileOutputStream(errFile);
                errStream = new PrintWriter(oStream);
            }
            else if(errLogType.equalsIgnoreCase("NULL"))
            {
                errStream = new PrintWriter(new NullOutputStream());
            }
        }
        catch(Exception e)
        {
            outStream=new PrintWriter(System.out);
            errStream=new PrintWriter(System.err);
        }
    }
    /**
    * A printerWriter for normal output Stream
    */
    final static public PrintWriter out=outStream;
    /**
    * A printerWriter for  error Stream
    */
    final static public PrintWriter err=errStream;
}