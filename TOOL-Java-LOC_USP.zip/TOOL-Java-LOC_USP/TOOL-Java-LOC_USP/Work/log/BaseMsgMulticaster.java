/*
 * @(#)BaseMsgMulticaster.java	1.1 1999/04/12
 * 
 * Copyright 1998-1999 by The Chase Manhattan Bank
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of The Chase Manhattan Bank ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Chase.
 */
package com.chase.infra.util.log;

import java.util.Vector;

/**
 * <p>
 * The BaseMsgMulticaster class 
 *
 * @author  Hung
 * @version 1.1, 1999/04/12
 * @see     com.chase.LogService
 * @since   JDK1.1.7
 */
public class BaseMsgMulticaster {
    protected Vector logServiceEventList = new Vector();

    /**
     * Remove one LogService to the LogServiceListener
     *
     * @param	l	LogServiceListener object
     */
    public synchronized void removeLogServiceListener(LogServiceListener l) {
        logServiceEventList.removeElement(l);
    }

    /**
     * Add one LogService to the LogServiceListener
     *
     * @param	l	LogServiceListener object
     */
    public synchronized void addLogServiceListener(LogServiceListener l) {
        logServiceEventList.addElement(l);
    }

    /**
     * Trigger the LogServiceEvent to send messages to print log
     *
     * @param	typeIn	type of the Event
     * @param	msgIn	messages to be sent to logfile
     */
    public synchronized void fireServiceEvent(int typeIn, String msgIn) {
         LogServiceEvent e = new LogServiceEvent(this,typeIn, msgIn);
         for(int i=0; i<logServiceEventList.size(); i++) {
               LogServiceListener listener=(LogServiceListener)logServiceEventList.elementAt(i);
               listener.logMessage(e);
         }
    }
    
    /**
     * Send the messages to print log
     *
     * @param	type	type of the Event
     * @param	str		messages to be sent to logfile
     */
    public void printLog(int type, String str) {
        fireServiceEvent(type, str);
    }
}
