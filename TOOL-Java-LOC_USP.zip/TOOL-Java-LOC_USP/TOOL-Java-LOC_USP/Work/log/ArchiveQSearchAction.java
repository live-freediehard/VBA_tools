package com.chase.apps.workflow.action;

import java.text.DecimalFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;
import java.util.Vector;

import chase.app.tt.util.Util;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import com.chase.apps.twinq.action.BaseAction;
import com.chase.apps.twinq.util.FormatLogMessage;
import com.chase.apps.twinq.util.MiscUtil;
import com.chase.apps.waas.client.AccessManagerAPI;
import com.chase.apps.waas.client.EntitlementServiceAPI;
import com.chase.apps.workflow.client.ArchiveQSearchClient;
import com.chase.apps.workflow.util.WorkflowViewConstants;
import com.chase.infra.util.LogWrapper;

public class ArchiveQSearchAction extends BaseAction{
	//private declarations

    private static Date minFromDate = MiscUtil.getDateFromString("1","1","1900");
    private static Date maxToDate = MiscUtil.getDateFromString("6","6","2079");
    
    private static final String kSessionId = "SESSION_ID";
    private String dateRange = "";

    protected String getViewId(Map params)
    {
    	return WorkflowViewConstants.kArchiveQSearch;
	}

	protected void loadParams(Map params, HttpSession session, HttpServletRequest request)
	{
		super.loadParams(params,session,request);

		loadRequestParam(request, params, "procUnit");
		loadRequestParam(request, params, "intfType");
		loadRequestParam(request, params, "msgType");
		loadRequestParam(request, params, "senderAddr");
		loadRequestParam(request, params, "senderRef");
		loadRequestParam(request, params, "jpmRef");
		loadRequestParam(request, params, "custName");
		loadRequestParam(request, params, "currency");
		loadRequestParam(request, params, "amountFrom");
		loadRequestParam(request, params, "amountTo");
		loadRequestParam(request, params, "location");
		loadRequestParam(request, params, "prodType");
		loadRequestParam(request, params, "recvFromMonth");
		loadRequestParam(request, params, "recvFromDay");		
		loadRequestParam(request, params, "recvFromYear");
		loadRequestParam(request, params, "recvToMonth");
		loadRequestParam(request, params, "recvToDay");		
		loadRequestParam(request, params, "recvToYear");
//		loadRequestParam(request, params, "submitFromMonth");
//		loadRequestParam(request, params, "submitFromDay");
//		loadRequestParam(request, params, "submitFromYear");
//		loadRequestParam(request, params, "submitToMonth");
//		loadRequestParam(request, params, "submitToDay");
//		loadRequestParam(request, params, "submitToYear");		
		loadRequestParam(request, params, "responseFromMonth");
		loadRequestParam(request, params, "responseFromDay");
		loadRequestParam(request, params, "responseFromYear");
		loadRequestParam(request, params, "responseToMonth");
		loadRequestParam(request, params, "responseToDay");
		loadRequestParam(request, params, "responseToYear");
		loadRequestParam(request, params, "ofacStatus");
		loadRequestParam(request, params, "msgRefNo");

	    dateRange = ((String) session.getAttribute("dateRange")).trim();
	}

	protected Object doSearch(Map params, HttpSession session, HttpServletRequest request)
	{
        setClassName( "ArchiveQSearchAction" );
        setMethodName( "doSearch" );
		logDebug("Start");

        // Get cookies
        String sessionId = null;
        Cookie[] cookies = request.getCookies();
        if (cookies != null)
        {
            for (int i=0; i<cookies.length; i++)
            {
                // Get the session ID
				if (cookies[i].getName().compareTo(kSessionId) == 0)
					sessionId = cookies[i].getValue();
			}
		}
		else
		{
			//no cookies, forward to login page?
		}
		
		//*********start DDRB search**********

		//get parameters
		String appDomain = ((String)session.getAttribute("appDomain")).toUpperCase().trim();

		String procUnit = ((String)params.get("procUnit")).toUpperCase().trim();
		if (procUnit != null) {
			appDomain = procUnit;			
			session.setAttribute("appDomain", appDomain);
		}	
		
		String[] puList = new String[1];
		puList[0] = appDomain;
		
		//Check the allowed action
	    AccessManagerAPI am = null;
	    EntitlementServiceAPI es = null;
		
	    try
	    {
			am = new AccessManagerAPI(hostServer, sessionId);
			es = am.getEntitlementServiceAPIInstance();
	
			Vector actionAllow = new Vector();			
			Vector aclGroup = es.getAclGroupsByAppID(WorkflowViewConstants.kIncomingMessageAppId);			
			Vector aclString = es.getAclString(WorkflowViewConstants.kIncomingMessageAppId, aclGroup, "");			
			        
	        for (int i=0; i<aclString.size(); i++)
	        {
	            StringTokenizer stQueue = new StringTokenizer(aclString.get(i).toString(),";");
	            String queueString = stQueue.nextToken();           
	            
	            if (queueString == null)
	                throw new com.chase.apps.waas.stub.InternalException("Invalid first part of ACL String...");
	            if (queueString.equals(""))
	            	logDebug("No queue type defined ...");
	            
	            //Get the matches queue name
	            if (queueString.equals(WorkflowViewConstants.kArchiveQSearch))
	            {
		            String actionString = stQueue.nextToken();
		            
		            if (actionString == null)
		                throw new com.chase.apps.waas.stub.InternalException("Invalid second part of ACL String...");
		            if (actionString.equals(""))
		            	logDebug("No action string defined ...");
		                        
		            StringTokenizer stAction= new StringTokenizer(actionString,",");                      
					while (stAction.hasMoreTokens())
					{						
						String action = stAction.nextToken();
						actionAllow.add(action);													
					}
					java.util.Collections.sort(actionAllow);
					logDebug("Action Allowed :" + actionAllow.toString() );
	            }            
	        }
	        
	        session.setAttribute("actionAllow",actionAllow);	        
		
	    }catch(Exception ex)
	    {	
	    	session.removeAttribute("actionAllow");
	    	logDebug(ex.getMessage());	    	
	    }
		
		String intfType 		= ((String) params.get("intfType")).toUpperCase().trim();
		String msgType 			= ((String) params.get("msgType")).toUpperCase().trim();	
		String senderAddr 		= ((String) params.get("senderAddr")).toUpperCase().trim();
		String senderRef 		= ((String) params.get("senderRef")).toUpperCase().trim();
		String jpmRef 			= ((String) params.get("jpmRef")).toUpperCase().trim();
		String custName 		= ((String) params.get("custName")).toUpperCase().trim();
		String currency 		= ((String) params.get("currency")).toUpperCase().trim();		
		String amountFrom 		= ((String) params.get("amountFrom")).trim();
		String amountTo 		= ((String) params.get("amountTo")).trim();					
		String location 		= ((String) params.get("location")).toUpperCase().trim();
		String prodType 		= ((String) params.get("prodType")).toUpperCase().trim();
		//String asOfDate 		= (String) params.get("recvFromMonth") + "/" + params.get("recvFromDay") + "/" + params.get("recvFromYear") + " 23:59:59";
		String recvFromMonth 	= ((String) params.get("recvFromMonth")).toUpperCase().trim();
		String recvFromDay 		= ((String) params.get("recvFromDay")).toUpperCase().trim();
		String recvFromYear 	= ((String) params.get("recvFromYear")).toUpperCase().trim();		
		String recvToMonth 		= ((String) params.get("recvToMonth")).toUpperCase().trim();
		String recvToDay 		= ((String) params.get("recvToDay")).toUpperCase().trim();
		String recvToYear 		= ((String) params.get("recvToYear")).toUpperCase().trim();
		String submitFromMonth 	= "";	//((String) params.get("submitFromMonth")).toUpperCase().trim();
		String submitFromDay 	= "";	//((String) params.get("submitFromDay")).toUpperCase().trim();
		String submitFromYear 	= "";	//((String) params.get("submitFromYear")).toUpperCase().trim();		
		String submitToMonth 	= "";	//((String) params.get("submitToMonth")).toUpperCase().trim();
		String submitToDay 		= "";	//((String) params.get("submitToDay")).toUpperCase().trim();
		String submitToYear 	= "";	//((String) params.get("submitToYear")).toUpperCase().trim();		
		String responseFromMonth = ((String) params.get("responseFromMonth")).toUpperCase().trim();
		String responseFromDay 	= ((String) params.get("responseFromDay")).toUpperCase().trim();
		String responseFromYear = ((String) params.get("responseFromYear")).toUpperCase().trim();		
		String responseToMonth 	= ((String) params.get("responseToMonth")).toUpperCase().trim();
		String responseToDay 	= ((String) params.get("responseToDay")).toUpperCase().trim();
		String responseToYear 	= ((String) params.get("responseToYear")).toUpperCase().trim();
		String ofacStatus 		= ((String) params.get("ofacStatus")).toUpperCase().trim();
		String msgRefNo 		= ((String) params.get("msgRefNo")).toUpperCase().trim();
		
		String recvFromDate = "";
		if ((recvFromMonth.length() > 0) || (recvFromDay.length() > 0) || (recvFromYear.length() > 0))
		{
			recvFromDate = recvFromMonth + "/" + recvFromDay + "/" + recvFromYear;
		}
		
		String recvToDate = "";
		if ((recvToMonth.length() > 0) || (recvToDay.length() > 0) || (recvToYear.length() > 0))
		{
			recvToDate = recvToMonth + "/" + recvToDay + "/" + recvToYear;
		}			
		
		String submitFromDate = "";
		if ((submitFromMonth.length() > 0) || (submitFromDay.length() > 0) || (submitFromYear.length() > 0))
		{
			submitFromDate = submitFromMonth + "/" + submitFromDay + "/" + submitFromYear;
		}
		
		String submitToDate = "";
		if ((submitToMonth.length() > 0) || (submitToDay.length() > 0) || (submitToYear.length() > 0))
		{
			submitToDate = submitToMonth + "/" + submitToDay + "/" + submitToYear;
		}	
		
		String responseFromDate = "";
		if ((responseFromMonth.length() > 0) || (responseFromDay.length() > 0) || (responseFromYear.length() > 0))
		{
			responseFromDate = responseFromMonth + "/" + responseFromDay + "/" + responseFromYear;
		}
		
		String responseToDate = "";
		if ((responseToMonth.length() > 0) || (responseToDay.length() > 0) || (responseToYear.length() > 0))
		{
			responseToDate = responseToMonth + "/" + responseToDay + "/" + responseToYear;
		}			
		
		//If user enters a comma, have to get rid of it for the sp to work correctly
		if (amountFrom.indexOf(",") > -1)
		{
			try
			{
				DecimalFormat df = new DecimalFormat();
				Double d = new Double(df.parse(amountFrom).doubleValue());
				amountFrom = String.valueOf(d);
			}
			catch (java.text.ParseException pe)
			{
				logDebug("Error in converting amountFrom from decimal format!!!");
			}
		}
		
		//If user enters a comma, have to get rid of it for the sp to work correctly
		if (amountTo.indexOf(",") > -1)
		{
			try
			{
				DecimalFormat df = new DecimalFormat();
				Double d = new Double(df.parse(amountTo).doubleValue());
				amountTo = String.valueOf(d);
			}
			catch (java.text.ParseException pe)
			{
				logDebug("Error in converting amountTo from decimal format!!!");
			}
		}
		
		/************************************************/
    	//Get the user id 
    	/************************************************/
    	String userId = session.getAttribute("USER_ID").toString();
    	
    	if (userId != null)
    		logDebug("userid: " + userId);
    	else
    		logDebug("userid: No userid found!");			
    	
		//Get the data from Core DB
		String connectionKey = getTwConnectionKey(session);
		logDebug("connectionKey: " + connectionKey);
		
		ArchiveQSearchClient client = new ArchiveQSearchClient(puList, connectionKey, intfType, msgType, senderAddr, senderRef, jpmRef, custName, currency, amountFrom, amountTo, location, prodType, recvFromDate, recvToDate, submitFromDate, submitToDate, responseFromDate, responseToDate, ofacStatus, msgRefNo, userId);
		LogWrapper.instance.logDebug(FormatLogMessage.toString("ArchiveQSearchClient", "ArchiveQSearchClient", "construct"));

		//execute search
        logDebug("execute search");
      	String strArgs = intfType + "," + msgType + "," + senderAddr + "," + senderRef + "," + jpmRef + "," + custName + "," + currency + "," + amountFrom + "," + amountTo + "," + location + "," + prodType + "," + recvFromDate + "," + recvToDate + "," + submitFromDate + "," + submitToDate + "," + responseFromDate + "," + responseToDate + "," + ofacStatus + "," + msgRefNo + "," + userId;
      	
		/************************************************/
		//Get the store proc name for performance tunning 
		/************************************************/
      	
		String actionSp = "";
		actionSp = "GTDPEND1..USP_E_ARCHIVE_Q_SEL";

		
    	logDebug("searchSp: " + actionSp);        				
		logDebug("searchSpParam: " + strArgs);        				
	       
    	List lcs;
    
    	client.execute();

		//get result
		lcs = client.getServiceResponse().getResult();

		//*************************************

		//put search results into session
		session.setAttribute("results",lcs);        		
        	
		//constructing sub header to be shown in header.jsp
		String headLine = "Archive Queue - Summary";
		request.setAttribute("subHeader", headLine);
		
		String searchModule = "/ArchiveQSearch";
		Vector searchCriteria = new Vector();
		Vector searchValue = new Vector();
		
		searchCriteria.add("procUnit");       
		searchCriteria.add("intfType");       
		searchCriteria.add("msgType");        
		searchCriteria.add("senderAddr");     
		searchCriteria.add("senderRef");      
		searchCriteria.add("jpmRef");         
		searchCriteria.add("custName");       
		searchCriteria.add("currency");       
		searchCriteria.add("amountFrom");     
		searchCriteria.add("amountTo");	      
		searchCriteria.add("location");       
		searchCriteria.add("prodType");       
		searchCriteria.add("recvFromMonth");  
		searchCriteria.add("recvFromDay");  	    
		searchCriteria.add("recvFromYear");   
		searchCriteria.add("recvToMonth");    
		searchCriteria.add("recvToDay");      
		searchCriteria.add("recvToYear");     
		searchCriteria.add("responseFromMonth");
		searchCriteria.add("responseFromDay");  
		searchCriteria.add("responseFromYear"); 
		searchCriteria.add("responseToMonth");  
		searchCriteria.add("responseToDay");    
		searchCriteria.add("responseToYear");   
		searchCriteria.add("ofacStatus");		      
		searchCriteria.add("msgRefNo");         
	
		searchValue.add(procUnit);       
		searchValue.add(intfType);       
		searchValue.add(msgType);        
		searchValue.add(senderAddr);     
		searchValue.add(senderRef);      
		searchValue.add(jpmRef);         
		searchValue.add(custName);       
		searchValue.add(currency);       
		searchValue.add(amountFrom);     
		searchValue.add(amountTo);	      
		searchValue.add(location);       
		searchValue.add(prodType);       
		searchValue.add(recvFromMonth);  
		searchValue.add(recvFromDay);  	    
		searchValue.add(recvFromYear);   
		searchValue.add(recvToMonth);    
		searchValue.add(recvToDay);      
		searchValue.add(recvToYear);     
		searchValue.add(responseFromMonth);
		searchValue.add(responseFromDay);  
		searchValue.add(responseFromYear); 
		searchValue.add(responseToMonth);  
		searchValue.add(responseToDay);    
		searchValue.add(responseToYear);   
		searchValue.add(ofacStatus);		      
		searchValue.add(msgRefNo);       

		session.setAttribute("searchModule", searchModule);
		session.setAttribute("searchCriteria", searchCriteria);
		session.setAttribute("searchValue", searchValue);	              		
		
		setUserId(userId);
		setSpName(actionSp);
		setSpArgs(strArgs);
		int ResultCnt = lcs.size();
		setResultCnt(String.valueOf(ResultCnt));

        logDebug("ArchiveQSearchAction End");

		return lcs;
	}


	protected boolean validateParams(Map params, StringBuffer msg)
	{
		LogWrapper.instance.logDebug(FormatLogMessage.toString("ArchiveQSearchAction", "ArchiveQSearchAction", "validateParams"));
		
		String recvFromMonth 	= ((String)params.get("recvFromMonth")).toUpperCase().trim();
		String recvFromDay 		= ((String)params.get("recvFromDay")).toUpperCase().trim();
		String recvFromYear 	= ((String)params.get("recvFromYear")).toUpperCase().trim();
		String recvToMonth 		= ((String)params.get("recvToMonth")).toUpperCase().trim();
		String recvToDay 		= ((String)params.get("recvToDay")).toUpperCase().trim();
		String recvToYear 		= ((String)params.get("recvToYear")).toUpperCase().trim();
		
		String submitFromMonth 	= "";	//((String)params.get("submitFromMonth")).toUpperCase().trim();
		String submitFromDay	= "";	//((String)params.get("submitFromDay")).toUpperCase().trim();
		String submitFromYear 	= "";	//((String)params.get("submitFromYear")).toUpperCase().trim();
		String submitToMonth 	= "";	//((String)params.get("submitToMonth")).toUpperCase().trim();
		String submitToDay 		= "";	//((String)params.get("submitToDay")).toUpperCase().trim();
		String submitToYear 	= "";	//((String)params.get("submitToYear")).toUpperCase().trim();

		String responseFromMonth= ((String)params.get("responseFromMonth")).toUpperCase().trim();
		String responseFromDay 	= ((String)params.get("responseFromDay")).toUpperCase().trim();
		String responseFromYear = ((String)params.get("responseFromYear")).toUpperCase().trim();
		String responseToMonth 	= ((String)params.get("responseToMonth")).toUpperCase().trim();
		String responseToDay 	= ((String)params.get("responseToDay")).toUpperCase().trim();
		String responseToYear 	= ((String)params.get("responseToYear")).toUpperCase().trim();
		
		String amountFrom 		= ((String)params.get("amountFrom")).toUpperCase().trim();
		String amountTo 		= ((String)params.get("amountTo")).toUpperCase().trim();
		
		String senderRef 		= ((String) params.get("senderRef")).toUpperCase().trim();
		String jpmRef 			= ((String) params.get("jpmRef")).toUpperCase().trim();
		String msgRefNo 		= ((String) params.get("msgRefNo")).toUpperCase().trim();
		
		Date recvFromDate		= minFromDate;
		Date recvToDate			= maxToDate;
		
		Calendar cRecvFrom 		= Calendar.getInstance();
		Calendar cRecvTo 		= Calendar.getInstance();
		
		// Validate "Receive From" date if provided
		if ((recvFromMonth.length() > 0) || (recvFromDay.length() > 0) || (recvFromYear.length() > 0))
		{
			String date = recvFromMonth + "/" + recvFromDay + "/" + recvFromYear;

			if (!Util.isDate(date))
			{
				msg.append("'Receive From' date invalid");
				return false;
			}
			else
			{

				Date d = MiscUtil.getDateFromString(recvFromMonth,recvFromDay,recvFromYear);

				if (d.before(minFromDate))
				{
					msg.append("System cannot handle date earlier than Jan 1, 1900");
					return false;
				}
				
				recvFromDate = d;
			}
		}

		// Validate "Receive To" date if provided
		if ((recvToMonth.length() > 0) || (recvToDay.length() > 0) || (recvToYear.length() > 0))
		{
			String date = recvToMonth + "/" + recvToDay + "/" + recvToYear;

			if (!Util.isDate(date))
			{
				msg.append("'Receive To' date invalid");
				return false;
			}
			else
			{
				Date d = MiscUtil.getDateFromString(recvToMonth,recvToDay,recvToYear);

				if (d.after(maxToDate))
				{
					msg.append("System cannot handle date later than June 6, 2079");
					return false;
				}

				recvToDate = d;
			}
		}
		
		// Validate Receive Date
		cRecvFrom.setTime(recvFromDate);
		cRecvTo.setTime(recvToDate);		
		cRecvFrom.add(Calendar.DATE,Integer.parseInt(dateRange)-1);
				
		if (cRecvFrom.before(cRecvTo)
		&& senderRef.equals("") && jpmRef.equals("") && msgRefNo.equals("")) // 29652(WHEM)/29666(EMEA)/29638(AP)
		{						
			msg.append("Receive Date : Maxmium date range for message search is " + dateRange + " calendar days");
			return false;
		}
		
		// Validate "Submit From" date if provided
		if ((submitFromMonth.length() > 0) || (submitFromDay.length() > 0) || (submitFromYear.length() > 0))
		{
			String date = submitFromMonth + "/" + submitFromDay + "/" + submitFromYear;

			if (!Util.isDate(date))
			{
				msg.append("'Submit From' date invalid");
				return false;
			}
			else
			{

				Date d = MiscUtil.getDateFromString(submitFromMonth,submitFromDay,submitFromYear);

				if (d.before(minFromDate))
				{
					msg.append("System cannot handle date earlier than Jan 1, 1900");
					return false;
				}
			}
		}

		// Validate "Submit To" date if provided
		if ((submitToMonth.length() > 0) || (submitToDay.length() > 0) || (submitToYear.length() > 0))
		{
			String date = submitToMonth + "/" + submitToDay + "/" + submitToYear;

			if (!Util.isDate(date))
			{
				msg.append("'Submit To' date invalid");
				return false;
			}
			else
			{
				Date d = MiscUtil.getDateFromString(submitToMonth,submitToDay,submitToYear);

				if (d.after(maxToDate))
				{
					msg.append("System cannot handle date later than June 6, 2079");
					return false;
				}


			}
		}
		
		// Validate "Response From" date if provided
		if ((responseFromMonth.length() > 0) || (responseFromDay.length() > 0) || (responseFromYear.length() > 0))
		{
			String date = responseFromMonth + "/" + responseFromDay + "/" + responseFromYear;

			if (!Util.isDate(date))
			{
				msg.append("'Response From' date invalid");
				return false;
			}
			else
			{

				Date d = MiscUtil.getDateFromString(responseFromMonth,responseFromDay,responseFromYear);

				if (d.before(minFromDate))
				{
					msg.append("System cannot handle date earlier than Jan 1, 1900");
					return false;
				}
			}
		}

		// Validate "Response To" date if provided
		if ((responseToMonth.length() > 0) || (responseToDay.length() > 0) || (responseToYear.length() > 0))
		{
			String date = responseToMonth + "/" + responseToDay + "/" + responseToYear;

			if (!Util.isDate(date))
			{
				msg.append("'Response To' date invalid");
				return false;
			}
			else
			{
				Date d = MiscUtil.getDateFromString(responseToMonth,responseToDay,responseToYear);

				if (d.after(maxToDate))
				{
					msg.append("System cannot handle date later than June 6, 2079");
					return false;
				}


			}
		}
		
		// Validate "From" Amount if provided
		if (amountFrom.length() > 0)
		{
			try
			{
				//Get rid of comma separator if user has entered it
				DecimalFormat df = new DecimalFormat();
				Double d = new Double(df.parse(amountFrom).doubleValue());
				//Double d = new Double(frmAmt);
//				if (d.doubleValue() < 0)
//				{
//				    msg.append("'From' Amount cannot be negative");
//				    return false;
//				}
			}			
			catch (java.text.ParseException pe)
			{
				msg.append("'From' Amount decimal format error");
				return false;
			}
			catch (NumberFormatException nfe)
			{
				msg.append("'From' Amount invalid");
				return false;
			}			
		}

		// Validate "To" Amount if provided
		if (amountTo.length() > 0)
		{
			try
			{
				//Get rid of comma separator if user has entered it
				DecimalFormat df = new DecimalFormat();
				Double d = new Double(df.parse(amountTo).doubleValue());
				//Double d = new Double(toAmt);
//				if (d.doubleValue() < 0)
//				{
//				    msg.append("'To' Amount cannot be negative");
//				    return false;
//				}
			}
			catch (java.text.ParseException pe)
			{
				msg.append("'To' Amount decimal format error");
				return false;
			}
			catch (NumberFormatException nfe)
			{
				msg.append("'To' Amount invalid");
				return false;
			}
		}
		
		return true;
	}
}
