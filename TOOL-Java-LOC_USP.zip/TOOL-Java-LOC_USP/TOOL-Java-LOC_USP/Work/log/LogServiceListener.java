/*
 * @(#)LogServiceListener.java	1.1 1999/04/12
 *
 * Copyright 1998-1999 by The Chase Manhattan Bank
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of The Chase Manhattan Bank ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Chase.
 */
package com.chase.infra.util.log;

import  java.util.EventListener;

/**
 * A class can implement the <code>LogServiceListener</code> interface when it
 * wants to log Message with a LogServiceEvent.
 *
 * @author  Hung
 * @version 1.1, 1999/04/12
 * @see     com.chase.LogService
 * @since   JDK1.1.7
 */
public interface LogServiceListener extends EventListener {
    /**
     * This method is called whenever the LogServiceEvent object needs to log message.
     *
     * @param   e     the LogServiceEvent object.
     */
	public void logMessage(LogServiceEvent e);
}
