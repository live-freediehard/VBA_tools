/*
 * @(#)LogServiceEvent.java	1.1 1999/04/12
 *
 * Copyright 1998-1999 by The Chase Manhattan Bank
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of The Chase Manhattan Bank ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Chase.
 */
package com.chase.infra.util.log;

import java.util.EventObject;

/**
 * <p>
 * The LogServiceEvent class is extended from <code>java.util.EventObject</code>.
 * <p>
 * LogServiceEvent are constructed with a reference to the object, the type and the message.
 *
 * @author  Hung
 * @version 1.1, 1999/04/12
 * @see     com.chase.LogService
 * @since   JDK1.1.7
 */
public final class LogServiceEvent extends EventObject {
    private String msg;
    private int type;
    final static public int NormalEvent=1;
    final static public int ErrorEvent=2;
    final static public int NewLogSegment=3;

    /**
     * Constructs a LogServiceEvent Event.
     *
     * @param    obj		The object on which the Event initially occurred.
     * @param    typeIn		The input object type.
     * @param    msgIn		The input message.
     */
     public LogServiceEvent(Object obj, int typeIn, String msgIn) {
        super(obj);
        type = typeIn;
        msg = msgIn;
    }

    /**
     * Returns a the message of this LogServiceEvent.
     *
     * @return  A a message of this LogServiceEvent.
     */
    public String getMessage() {
        return msg;
    }

    /**
     * Returns the type of this LogServiceEvent.
     *
     * @return  A the type of this LogServiceEvent.
     */
    public int getType() {
        return type;
    }
}
