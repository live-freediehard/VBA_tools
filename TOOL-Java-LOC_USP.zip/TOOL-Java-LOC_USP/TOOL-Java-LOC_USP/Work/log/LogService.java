/*
 * @(#)LogService.java	1.1 1999/04/13
 *
 * Copyright 1998-1999 by The Chase Manhattan Bank
 * All rights reserved.
 *
 * This software is the confidential and proprietary information
 * of The Chase Manhattan Bank ("Confidential Information").  You
 * shall not disclose such Confidential Information and shall use
 * it only in accordance with the terms of the license agreement
 * you entered into with Chase.
 */
package com.chase.infra.util.log;

import java.io.*;
import java.util.Calendar;
import java.text.DateFormat;
import java.util.Date;
import com.chase.infra.util.SysTime;
//import com.chase.util.Util;

/**
 * <p>
 * The LogService class is extended from <code>com.chase.LogService.BaseMsgMulticaster</code>.
 * <p>
 * LogService are constructed with a log file name, or use default filename specified in
 * config.properties
 *
 * @author  Hung
 * @version 1.1, 1999/04/13
 * @see     com.chase.LogService
 * @since   JDK1.1.7
 */
public class LogService extends BaseMsgMulticaster {
    protected String prefix = "log";
    protected String currLog = null;
    protected PrintWriter LogStream = null;

    /**
     * Default Constructor
     *
     */
//    public LogService() {
	//	this.loadDefaultPrefix();
//    	this.init();
 //   }

    /**
     * Constructs a LogService Object.
     *
     * @param    str		log file name to be written.
     */
    public LogService(String str) {
        this.setPrefix(str);
		this.init();
	}

    /**
     * Load the default prefix from config.properties file
     *
     */
//	protected void loadDefaultPrefix() {
	//	String sLogPathFromIni = Util.getPropFromCfgIni("LogService.logpath");
//		StringBuffer sb = new StringBuffer();

	//	// Check log file path
//		if ((sLogPathFromIni == "") || (sLogPathFromIni == null)) {
//			sb.append("c:\\temp\\xtrade");
	//	} else {
//			sb.append(System.getProperties().getProperty("java.home"));
	//		sb.append(File.separator);
//			sb.append("..");
//			sb.append(File.separator);
//			sb.append(sLogPathFromIni);
//		}
//		this.prefix = sb.toString();
//	}

	protected void init() {
        try {
            OpenLogFile();
        }
        catch(IOException e) {
            System.err.println("Log Message class is not initialized. filename=" + currLog);
            e.printStackTrace(System.err);
        }
	}

    /**
     * Open the log file, file name as prefix and yyyymmddhhmmss
     *
     */
    protected boolean OpenLogFile() throws IOException {
        Calendar date = Calendar.getInstance();
        StringBuffer str = new StringBuffer();
        int nYear=date.get(Calendar.YEAR)
            ,nMonth=date.get(Calendar.MONTH)+1
            ,nDay=date.get(Calendar.DAY_OF_MONTH)
            ,nHour=date.get(Calendar.HOUR)
            ,nMin=date.get(Calendar.MINUTE)
            ,nSec=date.get(Calendar.SECOND)
            ;
        str.append(nYear);
        if(nMonth<10) str.append("0");
        str.append(nMonth);
        if(nDay<10)   str.append("0");
        str.append(nDay);
        if(nHour<10)  str.append("0");
        str.append(nHour);
        if(nMin<10)  str.append("0");
        str.append(nMin);
        if(nSec<10)  str.append("0");

        currLog=prefix+str;
        return OpenLog();
    }

    /**
     * Print string to normal log file
     *
     * @param	str		File name as log file prefix, plus date and time as suffix
     */
    public void setPrefix(String str) {
        if (str!=null && !str.equals(""))
            prefix=str;
    }

    /**
     * Print string to normal log file
     *
     * @param	str		String to be written to log file
     */
    public void out(String str) {
    	out(str, false);
    }

    public void out(String str, boolean onScreen) {
    	if (onScreen)
    		System.out.println(str);
    	this.printLog(LogServiceEvent.NormalEvent, str);
    }

    public void error(String errMsg)
    {	String str = SysTime.getDate("yyyy/MM/dd HH:mm:ss") + " <E> : "+errMsg;
    	out(str);
    }

    public void error(String errMsg, boolean onScreen)
    {	String str = SysTime.getDate("yyyy/MM/dd HH:mm:ss") + " <E> : "+errMsg;
    	out(str, onScreen);
    }

    public void error(String errMsg, String sender)
    {	String str = SysTime.getDate("yyyy/MM/dd HH:mm:ss") + " <E> <"+sender+"> : "+errMsg;
    	out(str);
    }

    public void info(String msg)
    {	String str = SysTime.getDate("yyyy/MM/dd HH:mm:ss") + " <I> : "+msg;
    	out(str);
    }

    public void info(String msg, boolean onScreen)
    {	String str = SysTime.getDate("yyyy/MM/dd HH:mm:ss") + " <I> : "+msg;
    	out(str, onScreen);
    }

    public void info(String msg, String sender)
    {	String str = SysTime.getDate("yyyy/MM/dd HH:mm:ss") + " <I> <"+sender+"> : "+msg;
    	out(str);
    }

	public void warn(String warnMsg)
    {	String str = SysTime.getDate("yyyy/MM/dd HH:mm:ss") + " <W> : "+warnMsg;
    	out(str);
    }

	public void warn(String warnMsg, boolean onScreen)
    {	String str = SysTime.getDate("yyyy/MM/dd HH:mm:ss") + " <W> : "+warnMsg;
    	out(str, onScreen);
    }

    public void warn(String warnMsg, String sender)
    {	String str = SysTime.getDate("yyyy/MM/dd HH:mm:ss") + " <W> <"+sender+"> : "+warnMsg;
    	out(str);
    }

    /**
     * Print string to errorlog file
     *
     * @param	errstr		String to be written to errorlog file
     */
    public void errors(String errstr) {
    	this.printLog(LogServiceEvent.ErrorEvent, errstr);
    }

    /**
     * Print string to log file, specified by the type
     *
     * @param	type	Log type
     * @param	str		String to be written to log file
     */
    public void printLog(int type, String str) {
        fireServiceEvent(type, str);
        LogStream.println(str);
        LogStream.flush();
    }

    protected synchronized boolean OpenLog() throws IOException {
        FileOutputStream  outputStream = new FileOutputStream(currLog);
        LogStream = new PrintWriter(outputStream);
        if(LogStream==null)
            throw new IOException("File "+currLog+" Open Error!") ;
        return true;
    }

    /**
     * Export the current log file to a new File
     *
     * @param	exportLogfile		Export file name
     */
    public synchronized  boolean exportLog(String exportLogfile)throws IOException {
        if (currLog==null || LogStream==null)
            return false;
        CopyFile(currLog, exportLogfile);
        return true;
    }

    /**
     * Segment the Log Files.
     * <p>
     * Close the existing log file and open another Log File
     */
    public synchronized void SegmentLogFile() throws IOException {
        LogStream.close();
        LogStream=null;
        OpenLogFile();
        fireServiceEvent(LogServiceEvent.NewLogSegment, "");
    }

    /**
     * Copy the Files
     *
     * @param	inFile		file source
     * @param	outFile		file target
     */
    protected synchronized void CopyFile(String inFile, String outFile) throws IOException {
        try {
            if(LogStream!=null) {
                LogStream.flush();
            }
            FileOutputStream oStream = new FileOutputStream(outFile);
            FileInputStream iStream = new FileInputStream(inFile);
            byte []buffer= new byte[512];
            int byteCnt;
            while((byteCnt=iStream.read(buffer))>0) {
                oStream.write(buffer,0,byteCnt);
            }
            oStream.close();
            iStream.close();
        } catch(IOException e) {
            System.err.println(e.getMessage());
            e.printStackTrace(System.err);
        }
    }

    /**
     * @exception
     */
    protected void finalize() throws Throwable {
        CloseStreamAll();
        super.finalize();
    }

    /**
     * Close the log stream
     *
     */
    protected void CloseStreamAll() {
        LogStream.flush();
        LogStream.close();
        LogStream=null;
    }
}
