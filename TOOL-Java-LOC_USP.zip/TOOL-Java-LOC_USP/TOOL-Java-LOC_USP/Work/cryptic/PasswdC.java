package com.chase.infra.util.cryptic;

import java.security.*;
//import javax.crypto.*;
import java.io.*;
import com.chase.infra.util.*;


final public class PasswdC implements TextDecryptor {
        
        //String masterKey = "38965937604323463";
	String masterKey = "174304839203740120";

        int keyLen = masterKey.length();

        public PasswdC(){
        }
        public PasswdC(String _mkey){
                this.masterKey = _mkey;
        }
        
        public int get_slot (int _keyLen, int _slot){
                return (_slot + 1) % _keyLen;
        }

        //final public String encrypt(String input) throws NoSuchAlgorithmException {
        final public String encrypt(String input) {
                //int seed = (int)(System.CurrentTimeMillis() % 32000);
                StringBuffer sb = new StringBuffer();
                char[] chars = input.toCharArray();
                char[] charsM = masterKey.toCharArray();
                //SecureRandom random = SecureRandom.getInstance("SHA1PRNG");
                //byte[] bytes = new byte[16];
                //random.nextBytes(bytes);
                double d = Math.random()*10000;
                int slot = (int)d;
                slot = get_slot(this.keyLen, slot);
                sb.append((char)input.length());
                sb.append((char)slot);
                for (int i=0; i<input.length(); i++){
                        int c = (int)chars[i] ^ (int)charsM[slot];
                        slot = get_slot(keyLen, slot);
                        sb.append((char)c);
                }
                //then Base64 encode 
                return Base64.encode(sb.toString().getBytes());
        }
        final public String decrypt(String encStr){
                //Base64 decode
                encStr = new String(Base64.decode(encStr));
                char[] chars = encStr.toCharArray();
                char[] charsM = masterKey.toCharArray();
                int len = (int)chars[0];
                int slot = (int)chars[1];
                //System.out.println(len);
                //System.out.println(slot);

                StringBuffer sb = new StringBuffer();
                for (int i=0; i<len; i++){
                        int c = (int)chars[i+2] ^ (int)charsM[slot];
                        slot = get_slot(keyLen, slot);
                        sb.append((char)c);
                }
                return sb.toString();
        }

        public static void main(String[] args){
                String plain = null;
                String encStr = "";
                String decStr = "";
                String fileName = null;
                for (int i=args.length-1; i>0; i--){
                        String tmp = args[i-1];
                        if (tmp.equalsIgnoreCase("-f")){
                                        fileName = args[i];
                        }else if (tmp.equalsIgnoreCase("-p")){
                                        plain = args[i];
                        }
                }
                if (plain==null){
                        System.out.println("USAGE: java classname -p plaintext [-f filename]");
                        System.exit(1);
                }
                PasswdC pc = new PasswdC();
                System.out.println("Plain : "+plain);
                encStr = pc.encrypt(plain);
                System.out.println("Encrypted : "+encStr);
                decStr = pc.decrypt(encStr);
                System.out.println("Decrypted : "+decStr);
                //write to file
                if (fileName != null){
                        System.out.println("Write to file : "+fileName);
                        File file = new File(fileName);
                        if (! file.exists() || ! file.canWrite()){
                                        System.out.println("ERROR: file not exist or not writeable");
                                        System.exit(1);
                        }
                        try {
                                BufferedReader br = new BufferedReader(new FileReader(file));
                                StringBuffer sb = new StringBuffer();
                                String line = null;
                                while ((line=br.readLine())!=null){
                                        if (line.indexOf("ENCPASSWORD")!=-1 || line.indexOf("PASSWORD")!=-1){
                                        }else{
                                                sb.append(line + System.getProperty("line.separator"));
                                        }
                                }
                                //System.getProperties().list(System.out);
                                sb.append("ENCPASSWORD="+encStr+System.getProperty("line.separator"));
                                PrintWriter pw = new PrintWriter(new BufferedWriter(new FileWriter(fileName,false)));
                                pw.print(sb.toString());
                                pw.flush();
                                /*RandomAccessFile raf = new RandomAccessFile(file, "rw");
                                long pointer = 0L;
                                String line = null;
                                while ((line=raf.readline())!=null){
                                        if (line.indexOf("ENCPASSWORD")!=-1){
                                        }
                                }*/
                        }catch(IOException ioe){
                                        System.out.println(ioe);
                        }
                }
        }
}
