package com.chase.infra.util.cryptic; 

import com.chase.infra.util.cryptic.*;

public class PasswordCryptic {
	
	public static void main (String[] args) {

		if (args.length < 2) {
			System.err.println("Usage : PasswordCryptic <Encrypted | Plain text> <ENCRYPTED | PLAIN>");
		}

		String str = args[0];
		String method = args[1];

		PasswdC p = new PasswdC();

		if ("ENCRYPTED".equals(method)) {
			str = p.decrypt(str);
			System.out.println(str);
		} else {
			str = p.encrypt(str);
			System.out.println(str);
		}
	}
}

