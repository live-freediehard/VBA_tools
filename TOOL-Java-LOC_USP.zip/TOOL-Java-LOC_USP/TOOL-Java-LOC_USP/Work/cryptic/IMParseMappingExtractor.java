////////////////////////////////////////////////////////////////////////////////////
// This class is the extractor class for Incoming Message Parsing.
//
// Author: Jack Hui
// Date: 24 August 2004
////////////////////////////////////////////////////////////////////////////////////

package com.chase.apps.gts.mapping.imparse;

import java.util.*;
import java.sql.*;
import java.io.*;
import java.math.* ;

import com.chase.apps.gts.base.data.*;
import com.chase.apps.gts.base.logging.*;
import com.chase.apps.gts.base.mapping.*;
import com.chase.apps.gts.jasper.GTSApplPrntConvertASCII;

import javax.xml.parsers.*;
import javax.xml.transform.*;
import javax.xml.transform.dom.*;
import org.w3c.dom.*;
import org.xml.sax.*;
import org.xml.sax.helpers.DefaultHandler;

import java.text.*;
import java.lang.*;

import com.chase.apps.gts.jasper.GTSApplPrnt;

public class IMParseMappingExtractor extends MappingExtractor {

	//Single connection Object for IMParseMappingExtractor
	IDataConnection  conn = null;
    
	//protected final String _spCreateSchema="exec GTDPEND1..USP_C_GTI_DATAPRE_SCHEMA";
    
    protected final String _sSelectIMBatch="exec GTDPEND1..USP_IMPARSE_BATCH_SEL @BATCH_ID=?, @PROCESSOR_ID=?";
    
    protected final String _sCheckDuplication="exec GTDPEND1..USP_IMPARSE_CHECK_DUP @PROC_UNIT=?, @QUEUE_TYP=?, @QUEUE_ID=?, @MSG_TYP=?, @LNK_REF=?, @LNK_MSG_SEQ=?, @LNK_MSG_TOTAL=?, @SEND_RECV_ADDR=?, @CORRE_ID=?";
    
    protected final String _sCheckGrouping="exec GTDPEND1..USP_IMPARSE_CHECK_GROUPING @PROC_UNIT=?, @QUEUE_TYP=?, @QUEUE_ID=?, @MSG_TYP=?, @LNK_REF=?, @LNK_MSG_SEQ=?, @LNK_MSG_TOTAL=?, @SEND_RECV_ADDR=?, @PROCESSOR_ID=?, @BATCH_ID=?";
    
    //protected final String _sCommitParseSWF="exec GTDPEND1..USP_IMPARSE_COMMIT_PARSE_SWF @PROC_UNIT=?, @QUEUE_TYP=?, @QUEUE_ID=?, @MSG_TYP=?, @LNK_REF=?, @LNK_MSG_SEQ=?, @LNK_MSG_TOTAL=?, @EXT_MSG_REF=?, @REPAIR_IND=?, @DUPLICATE_IND=?, @NEED_GROUPING=?, @GROUP_COMPLETE=?, @PARENT_QUEUE_ID=?";
    protected final String _sCommitParse="exec GTDPEND1..USP_IMPARSE_COMMIT_PARSE @PROC_UNIT=?, @QUEUE_TYP=?, @QUEUE_ID=?, @MSG_TYP=?, @APPL_MSG_REF=?, @LNK_REF=?, @LNK_MSG_SEQ=?, @LNK_MSG_TOTAL=?, @EXT_MSG_REF=?, @REPAIR_IND=?, @DUPLICATE_IND=?, @NEED_GROUPING=?, @GROUP_COMPLETE=?, @PARENT_QUEUE_ID=?, @ROUTE_PROD_TYP=?, @ROUTE_LOCATION_CD=?, @ROUTE_EXT_REF_NBR=?, @CUST_NM=?, @MSG_CCY_CD=?, @MSG_AMT=?, @INPUT_AUD_ID=?";
    
    protected final String _sSelectParentMsg="exec GTDPEND1..USP_IMPARSE_PARENT_MSG_SEL @PROC_UNIT=?, @QUEUE_TYP=?, @PARENT_QUEUE_ID=?";
    protected final String _sSelectMsgContent="exec GTDPEND1..USP_IMPARSE_MSG_CONTENT_SEL @PROC_UNIT=?, @QUEUE_TYP=?, @PARENT_QUEUE_ID=?, @PROCESSOR_ID=?, @BATCH_ID=?";
    //protected final String _sSelectMsgContent="exec GTDPEND1..USP_IMPARSE_PARENT_MSG_SEL @PROC_UNIT=?, @QUEUE_TYP=?, @PARENT_QUEUE_ID=?";
    
    protected final String _sChkNeedOFAC="exec GTDPEND1..USP_IMPARSE_CHK_MSG_OFAC_REQ @PROC_UNIT=?, @QUEUE_TYP=?, @MSG_TYP=?, @OFAC_IND=?";
    protected final String _sCommitParent="exec GTDPEND1..USP_IMPARSE_COMMIT_PARENT @PROC_UNIT=?, @QUEUE_TYP=?, @QUEUE_ID=?, @MSG_TYP=?, @APPL_MSG_REF=?, @ACTION_TYP=?, @OFAC_IND=?, @INPUT_AUD_ID=?, @PROCESSOR_ID=?, @BATCH_ID=?";
    
    protected final String _sCommitSiMsgQ_P2T="exec GTDPEND1..USP_IMPARSE_COMMIT_SIMSGQ_P2T @PROC_UNIT=?, @QUEUE_TYP=?, @PARENT_QUEUE_ID=?, @AUD_ID=?";
    
    protected final String _sSi_Msg_Q_Upd = "exec GTDPEND1..USP_IMPARSE_SIMSGQ_ERR_UPD @PROC_UNIT = ?, @QUEUE_TYP = ?, @QUEUE_ID = ?, @ERRMSG_ID = ?, @ERR_MSG = ?, @INPUT_AUD_ID=?";
    
    protected final String _spGetPuConfig = "exec GTDPEND1..USP_CGET_PU_CONFIG ?, ?, ? ";
    
    protected final String _spMsgRouteResult = "exec GTDPEND1..USP_CGET_MSG_ROUTE_RESULT ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?";
    
    protected final String _sCommitResult = "{? = call GTDPEND1..USP_IMPARSE_COMMIT_RESULT ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?}";
    
    protected final String FIELD_PROC_UNIT="PROC_UNIT";
    protected final String FIELD_OP_TEAM_CD="OP_TEAM_CD";
    protected final String FIELD_PROD_TYP="PROD_TYP";
    protected final String FIELD_PROD_CAT="PROD_CAT";
    protected final String FIELD_EXT_REF_NBR="EXT_REF_NBR";
    protected final String FIELD_TRAN_REF_NBR="TRAN_REF_NBR";
    protected final String FIELD_TRAN_SEQ_NBR="TRAN_SEQ_NBR";
    protected final String FIELD_DUMMY_ID="DUMMY_ID";
    protected final String FIELD_LC_TYP="LC_TYP";
    protected final String FIELD_PROCESSOR_ID="PROCESSOR_ID";
    protected final String FIELD_BATCH_ID="BATCH_ID";
    
    protected final String FIELD_CCY_CD="CCY_CD";
    protected final String FIELD_B1_CUST_ID="B1_CUST_ID";
    protected final String FIELD_B1_APP_ID="B1_APP_ID";
    protected final String FIELD_B1_BENE_ID="B1_BENE_ID";
    protected final String FIELD_VENDOR_ID="VENDOR_ID";
    protected final String FIELD_USER_ID="USER_ID";
    protected final String FIELD_QUEUE_ID="QUEUE_ID";
    protected final String FIELD_MSG_TEXT="MSG_TEXT";
    protected final String FIELD_MSG_CONTENT="MSG_CONTENT";
    protected final String FIELD_MSG_HEADER="MSG_HEADER";
    protected final String FIELD_SEND_RECV_ADDR="SEND_RECV_ADDR";
    protected final String FIELD_APPL_MSG_REF="APPL_MSG_REF";
    protected final String FIELD_CORRE_ID="CORRE_ID";
    protected final String FIELD_LST_MSG_NBR="LST_MSG_NBR";
    protected final String FIELD_RECV_DT="RECV_DT";
    protected final String FIELD_LNK_REF="LNK_REF";
    protected final String FIELD_LNK_MSG_SEQ="LNK_MSG_SEQ";
    protected final String FIELD_LNK_MSG_TOTAL="LNK_MSG_TOTAL";
    protected final String FIELD_EXT_MSG_REF="EXT_MSG_REF";
    protected final String FIELD_REPAIR_IND="REPAIR_IND";
    protected final String FIELD_NEED_GROUPING="NEED_GROUPING";
    protected final String FIELD_GROUP_COMPLETE="GROUP_COMPLETE";
    protected final String FIELD_PARENT_QUEUE_ID="PARENT_QUEUE_ID";
    protected final String FIELD_DUPLICATE_IND="DUPLICATE_IND";
    protected final String FIELD_QUEUE_STATUS="QUEUE_STATUS";
    protected final String FIELD_OFAC_IND="OFAC_IND";
    protected final String FIELD_NEED_TRANSFORM_SYSFMT="NEED_TRANSFORM_SYSFMT";
    protected final String FIELD_TRANSFORM_SYSFMT_SUCCESS="TRANSFORM_SYSFMT_SUCCESS";
    protected final String FIELD_ACTION_TYP="ACTION_TYP";
    protected final String FIELD_REC_EXIST_IND="REC_EXIST_IND";
    protected final String FIELD_APPL_PRNT_PDF="APPL_PRNT_PDF";
    protected final String FIELD_INPUT_AUD_ID="INPUT_AUD_ID";
    protected final String FIELD_COMPLETE_PARENT_PROCESS="COMPLETE_PARENT_PROCESS";
    
    protected final String FIELD_SENDER_REF="SENDER_REF";
    protected final String FIELD_RECV_REF="RECV_REF";
    protected final String FIELD_ISSU_BNK_REF="ISSU_BNK_REF";
    
    protected final String FIELD_NEW_QUEUE_ID="NEW_QUEUE_ID";
    protected final String FIELD_ORIG_REF_NBR="ORIG_REF_NBR";
    protected final String FIELD_GTL_MSG_1="GTL_MSG_1";
    protected final String FIELD_GTL_MSG_2="GTL_MSG_2";
    protected final String FIELD_AUD_ID="AUD_ID";
    protected final String FIELD_CUR_CD="CUR_CD";
    protected final String FIELD_MSG_AMT="MSG_AMT";
    protected final String FIELD_PROC_DT="PROC_DT";
    
    protected final String FIELD_DDA_NBR="DDA_NBR";
    protected final String FIELD_NY_CR_REF="NY_CR_REF";
    protected final String FIELD_VAL_DT="VAL_DT";
    protected final String FIELD_ITEM_OS="ITEM_OS";
    protected final String FIELD_MSG_ID="MSG_ID";
    protected final String FIELD_DR_CR_IND="DR_CR_IND";
    protected final String FIELD_STMT_SEQ_NBR="STMT_SEQ_NBR";
    protected final String FIELD_STMT_LINE="STMT_LINE";
    protected final String FIELD_INFO2_ACCT_ONR="INFO2_ACCT_ONR";
    
    protected final String FIELD_SWIFT_TAG21="SWIFT_TAG21";
    protected final String FIELD_SWIFT_TAG20="SWIFT_TAG20";
    protected final String FIELD_SWIFT_TAG40A="SWIFT_TAG40A";
    protected final String FIELD_SWIFT_TAG40B="SWIFT_TAG40B";
    protected final String FIELD_SWIFT_TAG59="SWIFT_TAG59";
	protected final String FIELD_ROUTE_PROD_TYP="ROUTE_PROD_TYP";
    protected final String FIELD_ROUTE_LOCATION_CD="ROUTE_LOCATION_CD";
    protected final String FIELD_ROUTE_EXT_REF_NBR="ROUTE_EXT_REF_NBR";
    protected final String FIELD_CUST_NM="CUST_NM";
    protected final String FIELD_ISU_BNK_NAME="ISU_BNK_NAME";
    protected final String FIELD_MSG_CCY_CD="MSG_CCY_CD";
    
    //protected final String QUEUE_STATUS_OFAC="O";
    //protected final String QUEUE_STATUS_PARSED="A";
    
    //protected final String FIELD_ERR_TEXT_FMT="ERR_TEXT_FMT";

   
    protected final String _sBatchKeysTblName = "BatchKeys";
    
    //protected final String _spGetDefSchmPty = "exec GTDPEND1..USP_CGET_DEF_FEE_PTY ?,?,?,?,?,?";
    protected final String FIELD_TRAN_TYP = "TRAN_TYP";
    protected final String FIELD_MSG_TYP = "MSG_TYP";
    protected final String FIELD_QUEUE_TYP = "QUEUE_TYP";
 
  
    private final int _ExtractErrCode = 99;
    private final int _VictimErrCode = 100;
    
    //private String tagRef = " "; 
    //private String tranTyp = "";
    //private String logPrefix = "";

    //protected final String _sWarning            = "WARNING";
    
        
    final int DLIHdrLen = 117;
	final int basicHdrLen = 29;
	final int appHdrLen = 51;
	final int CCSbasicHdrLen = 150;
	private static final String CntNonRefNbr = "NONREF";
	
	private static final String QUEUE_TYP_SWIFT = "SWF";
	private static final String QUEUE_TYP_TELEX = "TLX";
	private static final String QUEUE_TYP_GTI = "GTI";
	private static final String  TAGDELI 	  = "\n:";
	private static final String  SWIFTEND 	  = "-}";
    private static final String  TAG20	  = "20";
    private static final String  TAG21	  = "21";
    private static final String  TAG23	  = "23";
    private static final String  lvDefDate = "Jan  1 1900 12:00AM";
    
    private static final String  TAG32A	  = "32A";
    private static final String  TAG32B	  = "32B";
    private static final String  TAG32K	  = "32K";
    private static final String  TAG32C	  = "32C";
    private static final String  TAG32D	  = "32D";
    private static final String  TAG33A	  = "33A";
    private static final String  TAG33B	  = "33B";
    private static final String  TAG33K	  = "33K";
    
	//Copy from qs/ointf/inc/msgdefs.h - Begin
	// For collection only 20050408
	private static final String IDS_TAG_PRIOR_MTY_AMT		="32K";
	private static final String IDS_TAG_AMEND_CURRENCY_AMT		="33A";
	private static final String IDS_TAG_AMEND_CURRENCY_MTY_AMT	="33K";
	private static final String IDS_TAG_AMENDMENTS			="74" ;
	private static final String IDS_MSG_DOC_COLL_ACK		="410";
	private static final String IDS_MSG_DOC_COLL_CACP		="412";
	private static final String IDS_MSG_DOC_COLL_AMNT		="430";
	// End of For collection only 20050408
	
	private static final String IDS_MSG_DOC_COLL_ADVI           ="400";
	private static final String IDS_MSG_DOC_COLL_ISSU           ="40A";
	private static final String IDS_MSG_DOC_COLL_TRACER         ="49T";
	private static final String IDS_MSG_DOC_COLL_ADMIN_MSG      ="499";
	private static final String IDS_MSG_LC_COPY                 ="600";
	private static final String IDS_MSG_PTEMPLATE               ="7XX";
	private static final String IDS_MSG_ADV_ISSUANCE            ="70A";
	private static final String IDS_MSG_ADV_BENE_ISSUANCE       ="70B";
	private static final String IDS_MSG_CANC_REQ                ="70C";
	private static final String IDS_MSG_ADV_EXTENSION           ="70E";
	private static final String IDS_MSG_FEE_ADV                 ="70F";
	private static final String IDS_MSG_ADV_LOAN_MATURITY       ="70M";
	private static final String IDS_MSG_ADV_AMEND_FULL_TEXT     ="77T";
	private static final String IDS_MSG_ADV_AMEND_REJ_CHASE     ="77X";
	private static final String IDS_MSG_DISCREPANCY_RESP        ="79Z";
	private static final String IDS_MSG_ADMIN_MESSAGE           ="799";
	private static final String IDS_MSG_LC_COPY_CHASE_VIEW      ="60A";
	private static final String IDS_MSG_COPY_OF_AMENDMENTS      ="607";
	private static final String IDS_MSG_ADV_LOAN_ROLLOVER       ="70R";
	private static final String IDS_MSG_ADV_PARENT_ACTION       ="70S";
	private static final String IDS_MSG_LC_FULL_TEXT            ="70T";
	private static final String IDS_MSG_ADV_LOAN_CREATION       ="70V";
	private static final String IDS_MSG_ADV_REJECT_OPENING      ="70X";
	private static final String IDS_MSG_CAN_REQ_RESPONSE        ="70Y";
	private static final String IDS_MSG_ADV_GCI_UPDATE          ="70Z";
	private static final String IDS_MSG_LC_OPENING              ="700";
	private static final String IDS_MSG_LC_OPENING_CONT         ="701";
	private static final String IDS_MSG_LC_PADV                 ="705";
	private static final String IDS_MSG_AMEND_APPL              ="707";
	private static final String IDS_MSG_LC_ADV		="710";
	private static final String IDS_MSG_LC_ADV_CONT		="711";
	private static final String IDS_MSG_BTB_ADVI                ="740";
	private static final String IDS_MSG_BTB_AMND                ="747";
	private static final String IDS_MSG_REIMBURSE_CLAIM         ="742";
	private static final String IDS_MSG_ADV_TIME_PAYMENT_DUE    ="75Y";
	private static final String IDS_MSG_ADV_PAYMENT_MADE        ="75Z";
	private static final String IDS_MSG_ADV_DISCREPANCY         ="750";
	private static final String IDS_MSG_ADV_PAYMENT_DUE         ="754";
	private static final String IDS_MSG_ADV_AMEND_APPR          ="77A";
	private static final String IDS_MSG_ADV_AMEND_REJ_BENE      ="77R";
	private static final String IDS_MSG_ADV_AMEND_ACC           ="77S";
	private static final String IDS_MSG_SUBSIDIARY_UPD          ="7PS";
	
	//MT940/950  Auto EC/CANC mapping for SWIFT 940/950 message 
	private static final String IDS_MSG_EC_940_CANC			="940";
	private static final String IDS_MSG_EC_950_CANC			="950";
	//private static final String IDS_TAG_COLLECT_NUMBER		="61E";
	//private static final String IDS_TAG_MSG_CURRENCY		="60C";
	//private static final String IDS_TAG_MSG_AMOUNT		="61A";
	
	private static final String IDS_MSG_LC_GUARANTEE		="760";
	private static final String IDS_MSG_LC_GUARANTEE_AMND		="767";
	
	//added for TOP
	private static final String IDS_MSG_DRAWN_ON			="32U";
	
	private static final String IDS_MSG_ELF_LC_OPENING          ="ELF700";
	private static final String IDS_MSG_ELF_DISCREPANCY_RESP    ="ELF79Z";
	private static final String IDS_MSG_ELF_AMEND_APPL          ="ELF707";
	private static final String IDS_MSG_ELF_ADMIN_MESSAGE       ="ELF799";
	
	// added for SWIFT
	private static final String IDS_MSG_SWF_LC_OPENING          ="SWF700";
	private static final String IDS_MSG_SWF_DISCREPANCY_RESP    ="SWF79Z";
	private static final String IDS_MSG_SWF_AMEND_APPL          ="SWF707";
	private static final String IDS_MSG_SWF_LC_ADV		    ="SWF710";
	private static final String IDS_MSG_SWF_BTB_ADVI            ="SWF740";
	private static final String IDS_MSG_SWF_REIMBURSE_CLAIM     ="SWF742";
	private static final String IDS_MSG_SWF_BTB_AMND            ="SWF747";
	
	
	// 10/97, Jason, EDI from version 1.0 
	private static final String IDS_MSG_EDI_LC_OPENING          ="700";
	private static final String IDS_MSG_EDI_AMEND_APPL          ="707";
	private static final String IDS_MSG_EDI_DISCREPANCY_RESP    ="79Z";
	// *****
	
	private static final String IDS_TAG_2ND_ADVISING_BANK_ADDR  ="57E";
	private static final String IDS_TAG_2ND_ADVISING_BANK_GCI   ="57Y";
	private static final String IDS_TAG_ISSUING_BANK_REF        ="23" ;
	private static final String IDS_TAG_ISSU_DATE               ="31C";
	private static final String IDS_TAG_AVAILABLE_BY_IND        ="41A";
	private static final String IDS_TAG_AVAILABLE_WITH	    ="41D";
	private static final String IDS_TAG_REVOC_IND               ="40R";
	
	private static final String IDS_MSG_ELF_T_ISSUE             ="ELFTIS";
	private static final String IDS_MSG_ELF_M_ISSUE             ="ELFMIS";
	private static final String IDS_MSG_ELF_M_BANK              ="ELFMBK";
	private static final String IDS_MSG_ELF_M_BENE              ="ELFMBE";
	private static final String IDS_ELF_TAG_01                  ="ELF01" ;
	private static final String IDS_ELF_TAG_02                  ="ELF02" ;
	private static final String IDS_ELF_TAG_03                  ="ELF03" ;
	private static final String IDS_ELF_TAG_04                  ="ELF04" ;
	private static final String IDS_ELF_TAG_05                  ="ELF05" ;
	private static final String IDS_ELF_TAG_06                  ="ELF06" ;
	private static final String IDS_ELF_TAG_07                  ="ELF07" ;
	private static final String IDS_ELF_TAG_08                  ="ELF08" ;
	private static final String IDS_ELF_TAG_09                  ="ELF09" ;
	private static final String IDS_ELF_TAG_10                  ="ELF10" ;
	private static final String IDS_ELF_TAG_11                  ="ELF11" ;
	private static final String IDS_ELF_TAG_12                  ="ELF12" ;
	private static final String IDS_ELF_TAG_13                  ="ELF13" ;
	private static final String IDS_ELF_TAG_14                  ="ELF14" ;
	private static final String IDS_ELF_TAG_15                  ="ELF15" ;
	private static final String IDS_ELF_TAG_16                  ="ELF16" ;
	private static final String IDS_ELF_TAG_17                  ="ELF17" ;
	private static final String IDS_ELF_TAG_18                  ="ELF18" ;
	private static final String IDS_ELF_TAG_19                  ="ELF19" ;
	private static final String IDS_ELF_TAG_20                  ="ELF20" ;
	private static final String IDS_ELF_TAG_21                  ="ELF21" ;
	private static final String IDS_ELF_TAG_22                  ="ELF22" ;
	private static final String IDS_ELF_TAG_23                  ="ELF23" ;
	private static final String IDS_ELF_TAG_24                  ="ELF24" ;
	private static final String IDS_ELF_TAG_25                  ="ELF25" ;
	private static final String IDS_ELF_TAG_26                  ="ELF26" ;
	private static final String IDS_ELF_TAG_27                  ="ELF27" ;
	private static final String IDS_ELF_TAG_28                  ="ELF28" ;
	private static final String IDS_ELF_TAG_29                  ="ELF29" ;
	private static final String IDS_ELF_TAG_30                  ="ELF30" ;
	private static final String IDS_ELF_TAG_31                  ="ELF31" ;
	private static final String IDS_ELF_TAG_32                  ="ELF32" ;
	private static final String IDS_ELF_TAG_33                  ="ELF33" ;
	private static final String IDS_ELF_TAG_34                  ="ELF34" ;
	private static final String IDS_ELF_TAG_35                  ="ELF35" ;
	private static final String IDS_ELF_TAG_36                  ="ELF36" ;
	private static final String IDS_ELF_TAG_37                  ="ELF37" ;
	private static final String IDS_ELF_TAG_38                  ="ELF38" ;
	private static final String IDS_ELF_TAG_39                  ="ELF39" ;
	private static final String IDS_ELF_TAG_40                  ="ELF40" ;
	private static final String IDS_ELF_TAG_41                  ="ELF41" ;
	private static final String IDS_ELF_TAG_42                  ="ELF42" ;
	private static final String IDS_ELF_TAG_43                  ="ELF43" ;
	private static final String IDS_ELF_TAG_44                  ="ELF44" ;
	private static final String IDS_ELF_TAG_77F                 ="77F"   ;
	
	// added for EDI
	//private static final String IDS_MSG_EDI_LC_OPENING          ="700";
	//private static final String IDS_MSG_EDI_AMEND_APPL          ="707";
	// private static final String IDS_MSG_EDI_DISCREPANCY_RESP ="001";
	private static final String IDS_MSG_EDI_T_ISSUE             ="002";
	private static final String IDS_MSG_EDI_M_ISSUE             ="003";
	private static final String IDS_MSG_EDI_M_BANK              ="004";
	private static final String IDS_MSG_EDI_M_BENE              ="005";
	
	//20030814
	//added for SWIFT NY MAPPING
	private static final String IDS_TAG_SWF_ADD_AMT_COVERED		="39C";
	private static final String IDS_TAG_SWF_ISSUING_BANK_ADDR   	="52A";
	private static final String IDS_TAG_SWF_NEGOT_BANK_ADDR     	="58A";
	private static final String IDS_TAG_SWF_BENE_BANK_ADDR		="59" ;
	private static final String IDS_TAG_SWF_SHIPMENT_PERIOD		="44D";
	private static final String IDS_TAG_SWF_DRAWEE_BIC		="42A";
	private static final String IDS_TAG_SWF_DRAWEE_ADDR         	="42D";
	private static final String IDS_TAG_SWF_TENOR_DESC		="42C";
	private static final String IDS_TAG_SWF_APPLICANT_BANK_BIC	="51A";
	private static final String IDS_TAG_SWF_APPLICANT_BANK_ADDR 	="51D";
	private static final String IDS_TAG_REIMBURSEMENT_BANK_BIC	="53A";
	private static final String IDS_TAG_DEFER_PAYMENT_DETAIL	="42P";
	private static final String IDS_TAG_SWF_MERCH_DESC          	="45A";
	private static final String IDS_TAG_SWF_DOC_REQ			="46A";
	private static final String IDS_TAG_SWF_ADD_CONDITIONS		="47A";
	private static final String IDS_TAG_SWF_ADVG_BANK_BIC		="57A";
	private static final String IDS_TAG_SWF_ADVG_BANK_ADDR		="57B";
	private static final String IDS_TAG_SWF_REVOCABLE           	="40B";
	private static final String IDS_TAG_SWF_APPLICANT           	="50" ;
	private static final String IDS_TAG_SWF_ORIG_REF_NBR		="21" ;
	
	
	private static final String IDS_TAG_SWF_DDA_ACCT_REF		="25";
	//added for SWIFT NY MAPPING
	//20030814
	
	private static final String IDS_TAG_SWF_DET_GUARANTEE		="77C";
	//20050331 MT760 - Added Tag 40C
	private static final String IDS_TAG_SWF_APPLICABLE_RULES	="40C";
	//Swift2006
	private static final String IDS_TAG_PORT_FROM			="44E";
	private static final String IDS_TAG_PORT_TO			="44F";
	private static final String IDS_TAG_SWF_LC_APPLICABLE_RULES	="40E";
	private static final String IDS_TAG_SWF_BTB_APPLICABLE_RULES	="40F";
	private static final String IDS_TAG_SWF_NON_BANK_ISSUER_ADDR	="50B";
	
	private static final String IDS_TAG_NONE                    =""   ;
	private static final String IDS_TAG_LC_TYPE                 ="00B";
	private static final String IDS_TAG_CANC_DATE               ="00C";
	private static final String IDS_TAG_INPUT_DATE_TIME         ="00D";
	private static final String IDS_TAG_MSG_DATE                ="00M";
	private static final String IDS_TAG_OPENING_LC_IND          ="00T";
	private static final String IDS_TAG_ADVICE_DISCREPANCY      ="01A";
	private static final String IDS_TAG_RESPONSE                ="01Y";
	private static final String IDS_TAG_SECOND_NOTICE           ="01Y";
	private static final String IDS_TAG_DISCR_ACCEPTED          ="01Y";
	private static final String IDS_TAG_BENE_CONSENT_REQD       ="03B";
	private static final String IDS_TAG_CANC_REQ_FLAG           ="03C";
	private static final String IDS_TAG_DEL_FLAG                ="03D";
	private static final String IDS_TAG_INT_ADJ_IND             ="03I";
	private static final String IDS_TAG_RELEASE_FLAG            ="03R";
	private static final String IDS_TAG_LOAN_NO                 ="03Y";
	private static final String IDS_TAG_BILL_REF_NO             ="03Z";
	private static final String IDS_TAG_ADVG_MODE               ="101";
	private static final String IDS_TAG_XFER_DETAILS            ="147";
	private static final String IDS_TAG_NEW_CURRENCY_AND_AMT    ="15C";
	private static final String IDS_TAG_LC_NUMBER               ="20" ;
	private static final String IDS_TAG_AMEND_COUNTER           ="20A";
	private static final String IDS_TAG_LC_LINK                 ="20L";
	private static final String IDS_TAG_CUSTOMER_REF_NO         ="20Z";
	private static final String IDS_TAG_RELATED_NUMBERS         ="20Z";
	private static final String IDS_TAG_ORIG_REF_NBR            ="20Y";
	private static final String IDS_TAG_AMEND_DATE              ="30" ;
	private static final String IDS_TAG_REJECT_DATE             ="30" ;
	private static final String IDS_TAG_ISSUE_DATE              ="31C";
	private static final String IDS_TAG_EXPIRY_INFO             ="31D";
	private static final String IDS_TAG_NEW_EXPIRY_DATE         ="31E";
	private static final String IDS_TAG_EVERGREEN_INFO          ="31F";
	private static final String IDS_TAG_REVOLVER_INFO           ="31R";
	private static final String IDS_TAG_ENTER_DATE              ="31W";
	private static final String IDS_TAG_ADV_DATE                ="31X";
	private static final String IDS_TAG_LOAN_DATE               ="31Y";
	private static final String IDS_TAG_PAYMT_DATE              ="31Y";
	private static final String IDS_TAG_REPAYMT_DATE            ="31Z";
	private static final String IDS_TAG_DUE_DATE                ="31Z";
	private static final String IDS_TAG_CLOSE_DATE              ="31Z";
	private static final String IDS_TAG_LC_CURRENCY_AMT         ="32B";
	private static final String IDS_TAG_INC_DEC_AMT             ="32C";
	private static final String IDS_TAG_BILL_AMT                ="32C";
	private static final String IDS_TAG_PAYMT_CURRENCY_AMT      ="32D";
	private static final String IDS_TAG_PREV_PAY_AMT            ="32P";
	private static final String IDS_TAG_INVOICE_PERCENT         ="32V";
	private static final String IDS_TAG_FX_CONTRACT             ="32X";
	private static final String IDS_TAG_CURRENCY_OS_BAL         ="32Z";
	private static final String IDS_TAG_VARIANCE_HI_LO          ="39A";
	private static final String IDS_TAG_TRANSFERABLE            ="40A";
	private static final String IDS_TAG_TENOR_INFO              ="42" ;
	private static final String IDS_TAG_MIXED_PAYMENT_DETAIL_IND	="42I";
	private static final String IDS_TAG_MIXED_PAYMENT_DETAIL	="42M";
	private static final String IDS_TAG_TENOR_DESC              ="42X";
	private static final String IDS_TAG_NEW_TENOR_DAYS          ="42Z";
	private static final String IDS_TAG_LOAN_TENOR_DAYS         ="42Z";
	private static final String IDS_TAG_TRANS_SHIP_DETAILS      ="43D";
	private static final String IDS_TAG_PARTIAL_SHIP_DETAILS    ="43P";
	private static final String IDS_TAG_TRANS_SHIP_IND          ="43T";
	private static final String IDS_TAG_PARTIAL_SHIP_IND        ="43Z";
	private static final String IDS_TAG_SHIP_FROM               ="44A";
	private static final String IDS_TAG_SHIP_TO                 ="44B";
	private static final String IDS_TAG_SHIP_DATE               ="44C";
	private static final String IDS_TAG_SHIP_FROM_CTRY          ="44Y";
	private static final String IDS_TAG_SHIP_TO_CTRY            ="44Z";
	private static final String IDS_TAG_MERCH_DESC              ="45B";
	private static final String IDS_TAG_SHIP_TERMS              ="45C";
	private static final String IDS_TAG_SHIP_TERMS_DESC         ="45W";
	private static final String IDS_TAG_OTHER_INSTRUCTIONS      ="45X";
	private static final String IDS_TAG_MERCH_INVENTORY         ="45Y";
	private static final String IDS_TAG_MERC_PO_INV             ="45P";
	private static final String IDS_TAG_FREIGHT_CHARGES         ="45Z";
	private static final String IDS_TAG_DOC_REQ		    ="46B";
	private static final String IDS_TAG_DOC_REQ_IND		    ="46D";
	private static final String IDS_TAG_PACKING_LIST            ="46E";
	private static final String IDS_TAG_INSURANCE_CERT          ="46F";
	private static final String IDS_TAG_INSPECTION_CERT         ="46H";
	private static final String IDS_TAG_TRANSPORT_DOC_DETAILS   ="46I";
	private static final String IDS_TAG_PACKING_LIST_CNT        ="46U";
	private static final String IDS_TAG_INSURANCE_CERT_CNT      ="46V";
	private static final String IDS_TAG_INSPECTION_CERT_CNT     ="46W";
	private static final String IDS_TAG_COMMERCIAL_INVOICE_CNT  ="46X";
	private static final String IDS_TAG_COMMERCIAL_INVOICE      ="46Y";
	private static final String IDS_TAG_ADDITIONAL_DOC	    ="46Z";
	private static final String IDS_TAG_OTHCON_IND		    ="47D";
	private static final String IDS_TAG_ADDITIONAL_CONDITIONS   ="47Z";
	private static final String IDS_TAG_LCSPEC		    ="47X";
	private static final String IDS_TAG_PRESENTATION_PERIOD     ="48" ;
	private static final String IDS_TAG_CONFIRMED_IND           ="49" ;
	private static final String IDS_TAG_ACCT_PARTY_ADDR         ="50" ;
	private static final String IDS_TAG_ACCT_PARTY_CTRY         ="50Y";
	private static final String IDS_TAG_ACCT_PARTY_GCI          ="50Z";
	private static final String IDS_TAG_ISSUING_BANK_ADDR       ="52D";
	private static final String IDS_TAG_ISSUING_BANK_CTRY       ="52Y";
	private static final String IDS_TAG_ISSUING_BANK_GCI        ="52Z";
	private static final String IDS_TAG_ORIG_BANK_GCI           ="52Z";
	private static final String IDS_TAG_REIMBURSEMENT_BANK_ADDR ="53D";
	private static final String IDS_TAG_REIMBURSEMENT_BANK_CTRY ="53Y";
	private static final String IDS_TAG_REIMBURSEMENT_BANK_GCI  ="53Z";
	private static final String IDS_TAG_REIMBURSEMENT_BANK_IND  ="53I";
	private static final String IDS_TAG_ADVG_BANK_ADDR          ="57D";
	private static final String IDS_TAG_ADVG_BANK_CTRY          ="57Y";
	private static final String IDS_TAG_ADVG_BANK_GCI           ="57Z";
	private static final String IDS_TAG_APPLICANT_ADDR          ="58D";
	private static final String IDS_TAG_APPLICANT_CTRY          ="58Y";
	private static final String IDS_TAG_APPLICANT_GCI           ="58Z";
	private static final String IDS_TAG_BENE_ADDR               ="59D";
	private static final String IDS_TAG_BENE_CTRY               ="59Y";
	private static final String IDS_TAG_BENE_GCI                ="59Z";
	
	private static final String IDS_TAG_SENDER_GCI              ="SND";
	private static final String IDS_TAG_SENDER_STATION_ID       ="SDI";
	
	private static final String IDS_TAG_GTM_AMEND               ="707";
	private static final String IDS_TAG_PAYOR_INFO              ="71B";
	private static final String IDS_TAG_FEE_INFO                ="73" ;
	private static final String IDS_TAG_FEE_DATE                ="73Z";
	private static final String IDS_TAG_GTS_AMEND               ="77A";
	private static final String IDS_TAG_REASON_MESSAGE          ="77E";
	private static final String IDS_TAG_MSG_TEXT                ="77F";
	private static final String IDS_TAG_CHASE_INSTRUCTIONS      ="78" ;
	private static final String IDS_TAG_CHASE_INSTRUCTIONS_IND  ="78I";
	private static final String IDS_TAG_TERMS_CONDITIONS        ="79" ;
	private static final String IDS_TAG_SUBS_DESTINATIONS       ="79S";
	private static final String IDS_TAG_SUBSIDIARY_LIST         ="79Z";
	
	private static final String IDS_TAG_AMT_TO_DECREASE         ="33B";
	private static final String IDS_TAG_PRIOR_AMEND_AMT         ="32A";
	private static final String IDS_TAG_PRIOR_PAY_AMT           ="32P";
	private static final String IDS_TAG_PRIOR_NUM_AMEND         ="20N";
	private static final String IDS_TAG_PRIOR_NUM_PAY           ="20P";
	
	// #ifdef EBEC
	private static final String IDS_TAG_ADV_BY_METHOD           ="10A";
	private static final String IDS_TAG_COLLECT_BANK_ADDR       ="52D";
	private static final String IDS_TAG_COLLECT_BANK_CTRY       ="52Y";
	private static final String IDS_TAG_COLLECT_BANK_GCI        ="52Z";
	private static final String IDS_TAG_COLLECT_NBR             ="20" ;
	private static final String IDS_TAG_COLLECT_TYPE            ="00T";
	private static final String IDS_TAG_CURRENCY_AMT            ="32B";
	private static final String IDS_TAG_DT_OF_DRAFT             ="00D";
	private static final String IDS_TAG_DELIVER_DOC             ="00B";
	private static final String IDS_TAG_COLLECT_DISCOUNT        ="71A";
	private static final String IDS_TAG_DRAWEE_ADDR             ="50" ;
	private static final String IDS_TAG_DRAWEE_CTRY             ="50Y";
	private static final String IDS_TAG_DRAWEE_GCI              ="50Z";
	private static final String IDS_TAG_DRAWER_ADDR             ="59D";
	private static final String IDS_TAG_DRAWER_CTRY             ="59Y";
	private static final String IDS_TAG_DRAWER_GCI              ="59Z";
	private static final String IDS_TAG_COLLECT_INTEREST        ="71I";
	private static final String IDS_TAG_OTHER_INSTRUCT          ="45X";
	private static final String IDS_TAG_POWER_ATTORNEY          ="56D";
	private static final String IDS_TAG_PRESENT_BANK_ADDR       ="55D";
	private static final String IDS_TAG_PRESENT_BANK_CTRY       ="55Y";
	private static final String IDS_TAG_PRESENT_BANK_GCI        ="55Z";
	private static final String IDS_TAG_PROTEST                 ="71P";
	private static final String IDS_TAG_REIM_METHOD             ="71D";
	private static final String IDS_TAG_REMIT_BANK_ADDR         ="57D";
	private static final String IDS_TAG_REMIT_BANK_CTRY         ="57Y";
	private static final String IDS_TAG_REMIT_BANK_GCI          ="57Z";
	private static final String IDS_TAG_TENOR_START_DT          ="42D";
	private static final String IDS_TAG_WAIVE_CHARGE            ="71W";
	//private static final String IDS_TAG_ADDITIONAL_DOC          ="46Z";
	private static final String IDS_TAG_DOCUMENT_TYPE           ="46S";
	
	
	// New tags of ELF 
	private static final String IDS_TAG_ELF_LC_OPENING          ="ELF700";
	private static final String IDS_TAG_ELF_FORM_CODE           ="EFORM" ;
	private static final String IDS_TAG_ELF_USR_ID              ="EUSER" ;
	private static final String IDS_TAG_ELF_NPONUM              ="EMPON" ;
	private static final String IDS_TAG_ELF_PONUMS              ="EPON"  ;
	private static final String IDS_TAG_ELF_XCUR                ="EXCUR" ;
	private static final String IDS_TAG_ELF_RESTRICTED          ="ERES"  ;
	private static final String IDS_TAG_ELF_RES_BANK            ="ERESB" ;
	private static final String IDS_TAG_ELF_S_D                 ="ES_D"  ;
	
	// 10/97, Jason, EDI from version 1.0 
	// New tags for EDI Message
	
	private static final String IDS_TAG_EDI_IPTY_TYP            ="19A" ;
	private static final String IDS_TAG_EDI_TRANSFERABLE        ="40A" ;
	private static final String IDS_TAG_EDI_REVOCABLE           ="40B" ;
	private static final String IDS_TAG_EDI_ORG_REFNO           ="21"  ;
	private static final String IDS_TAG_EDI_AMEND_REFNO         ="22"  ;
	private static final String IDS_TAG_EDI_AGREE_PAY_DATE      ="63D" ;
	private static final String IDS_TAG_EDI_INST_ENACT_PTY      ="64P" ;
	private static final String IDS_TAG_EDI_LC_FREETEXT         ="20F" ;
	private static final String IDS_TAG_EDI_IB_SWIFTCD          ="52S" ;          // Issuing Bank
	private static final String IDS_TAG_EDI_IB_BANKNM           ="52N" ;
	private static final String IDS_TAG_EDI_IB_ADDR             ="52D" ;
	private static final String IDS_TAG_EDI_IB_POSTCODE         ="52P" ;
	private static final String IDS_TAG_EDI_IB_COUNTRY          ="52Y" ;
	private static final String IDS_TAG_EDI_AB_SWIFTCD          ="57S" ;          // Advising Bank
	private static final String IDS_TAG_EDI_AB_BANKNM           ="57N" ;
	private static final String IDS_TAG_EDI_AB_ADDR             ="57D" ;
	private static final String IDS_TAG_EDI_AB_POSTCODE         ="57P" ;
	private static final String IDS_TAG_EDI_AB_COUNTRY          ="57Y" ;
	private static final String IDS_TAG_EDI_CB_SWIFTCD          ="53S" ;          // Confirming Bank
	private static final String IDS_TAG_EDI_CB_BANKNM           ="53N" ;
	private static final String IDS_TAG_EDI_CB_ADDR             ="53D" ;
	private static final String IDS_TAG_EDI_CB_POSTCODE         ="53P" ;
	private static final String IDS_TAG_EDI_CB_COUNTRY          ="53Y" ;
	private static final String IDS_TAG_EDI_NB_SWIFTCD          ="54S" ;          // Negotiating Bank
	private static final String IDS_TAG_EDI_NB_BANKNM           ="54N" ;
	private static final String IDS_TAG_EDI_NB_ADDR             ="54D" ;
	private static final String IDS_TAG_EDI_NB_POSTCODE         ="54P" ;
	private static final String IDS_TAG_EDI_NB_COUNTRY          ="54Y" ;
	private static final String IDS_TAG_EDI_AP_PTYID            ="58R" ;          // Applicant
	private static final String IDS_TAG_EDI_AP_PTYNM            ="58N" ;
	private static final String IDS_TAG_EDI_BE_PTYID            ="59R" ;          // Beneficiary
	private static final String IDS_TAG_EDI_BE_BANKNM           ="59N" ;
	private static final String IDS_TAG_EDI_BE_ADDR             ="59D" ;
	private static final String IDS_TAG_EDI_BE_POSTCODE         ="59P" ;
	private static final String IDS_TAG_EDI_BE_COUNTRY          ="59Y" ;
	private static final String IDS_TAG_EDI_SB_BANKNM           ="60N" ;          // 2nd Beneficiary
	private static final String IDS_TAG_EDI_SB_ADDR             ="60D" ;
	private static final String IDS_TAG_EDI_SB_POSTCODE         ="60P" ;
	private static final String IDS_TAG_EDI_SB_COUNTRY          ="60Y" ;
	private static final String IDS_TAG_EDI_SB_PTYID            ="60R" ;
	private static final String IDS_TAG_EDI_BUYER_ORDER         ="66N" ;
	private static final String IDS_TAG_EDI_DOC_DETAILS         ="68C" ;
	private static final String IDS_TAG_EDI_AMND_LIST           ="45L" ;
	private static final String IDS_TAG_EDI_AUT_FREETEXT        ="77F" ;
	private static final String IDS_TAG_EDI_AUT_PO              ="45I" ;
	private static final String QVR_INVOICE_QUANTITY            ="47"  ;
	private static final String QVR_RECEIVE_QUANTITY            ="48"  ;
	private static final String QVR_TRANSIT_QUANTITY            ="57"  ;
	private static final String QVR_INVENTORY_QUANTITY          ="60"  ;
	private static final String QVR_CUMULATE_QUANTITY           ="71"  ;
	private static final String QVR_OUTSTAND_QUANTITY           ="73"  ;
	private static final String QVR_BACKORDER_QUANTITY          ="83"  ;
	private static final String QVR_URGENT_DEV_QUANTITY         ="84"  ;
	private static final String QVR_FINAL_DEV_QUANTITY          ="92"  ;
	private static final String QVR_SUBSEQ_DEV_QUANTITY         ="93"  ;
	private static final String QVR_SUBST_QUANTITY              ="94"  ;
	private static final String QVR_BE_DEV_QUANTITY             ="113" ;
	private static final String QVR_SHORT_SHIP                  ="119" ;
	private static final String QVR_SPLIT_SHIP                  ="120" ;
	private static final String QVR_OVER_SHIP                   ="121" ;
	private static final String QVR_DEV_QUANTITY                ="131" ;
	private static final String QVR_TOLERANCE                   ="144" ;
	private static final String DISC_BACKORDER                  ="BK"  ;
	private static final String DISC_PARTIAL_SHIP_BO            ="BP"  ;
	private static final String DISC_SHIP_INC_EXTRA             ="CE"  ;
	private static final String DISC_CANCEL_PERVIOUS            ="CK"  ;
	private static final String DISC_SHIP_COMP_WITH_ADD         ="CM"  ;
	private static final String DISC_PARTIAL_SHIP_NBO           ="CP"  ;
	private static final String DISC_SHIP_COMP_WITH_SUB         ="CS"  ;
	private static final String DISC_ITEM_CANCEL                ="IC"  ;
	private static final String DISC_ITEM_OOS_AT_WHOLE          ="OW"  ;
	private static final String DISC_ITEM_RATION                ="RA"  ;
	private static final String DISC_SHIP_TO_DATE               ="SL"  ;
	private static final String DISC_SPLIT_SHIP                 ="SS"  ;
	private static final String DISC_ITEM_TEMP_DISCON           ="TW"  ;
	private static final String CHG_OTHER                       ="AM"  ;
	private static final String CHG_BAL_QUANTITY                ="BQ"  ;
	private static final String CHG_QUANTITY_ORDER              ="QO"  ;
	private static final String CHG_QUANTITY_BASE_PRICE         ="QP"  ;
	private static final String CHG_QUANTITY_PRICE_BREAK        ="QT"  ;
	private static final String CHG_SIZE_DIFFERENCE             ="SC"  ;
	private static final String CHG_UNIT_PRICE                  ="UP"  ;
	// ********
	
	
	//private static final String IDS_TAG_DOC_AIR_INSUR         ="ASC" ;
	//private static final String IDS_TAG_DOC_AIR_WAYBILL       ="AWB" ;
	//private static final String IDS_TAG_DOC_BENE_CERT         ="BEC" ;
	
	// #endif  /* end ifdef EBEC */
	
	private static final String IDS_TAG_SWF_NEW_AMT             ="34B" ;
	private static final String IDS_TAG_SWF_TOTAL_CLM_AMT       ="34A" ;
	private static final String IDS_TAG_SWF_MAX_CR_AMT          ="39B" ;
	private static final String IDS_TAG_SWF_SND2RCV_INFO        ="72"  ;
	private static final String IDS_TAG_SWF_CHRG_BENE           ="71A" ;
	private static final String IDS_TAG_SWF_VAL_DT              ="00D" ;
	//Copy from qs/ointf/inc/msgdefs.h - End
  
	public IMParseMappingExtractor(MappingContext mc)
	{
		super(mc);
    }
    
	public IMParseMappingExtractor(MappingContext mc, Element me)
	{
		super(mc, me);
    }
    
    /**
     * The main extract method
       	 * It first generates keys, e.g. PT_REF_NBR, TRAN_REF_NBR...etc and extract the XML from SI_MSG_Q and put into rawData by extractXML()
    	 * And parseXML() extracts the LC info from the XML in rawData, e.g. Liab. Party and LC Amount.
     */
    public void extract(MappingProcess proc,MappingBatch batch) throws ExtractorException {
        
        DataTable _batchKeys=new DataTable(_sBatchKeysTblName);
        batch.setBatchKeys(_batchKeys);

        try{
	    
            long ts=System.currentTimeMillis();
            DataTable rawData=selectIMBatch(proc,batch);
            ts=System.currentTimeMillis()-ts;
            logDebug("SelectIMBatch :"+ ts);            
            
            ts=System.currentTimeMillis();
            DataSet dataSet=parseIMBatch(rawData, batch);
            ts=System.currentTimeMillis()-ts;
            logDebug("ParseIMBatch :"+ ts);
            
            batch.setDataSet(dataSet);
        }
        catch(Exception e) {
            
            logDebug((Throwable)e );
            throw (new ExtractorException(e.getMessage()));
        }
        
    }
    
    
    /**
     * extract xml messages from SI_MSG_Q into datatables
     * @param batch
     * @throws ExtractorException
     * @return
     */
    public DataTable selectIMBatch(MappingProcess proc,MappingBatch batch) throws ExtractorException {
        
        logDebug("*******Select IM Batch********");
        IDataConnection conn = null;
        DataTable rawData;
        
        if(proc.getMappingDefinition()==null) {
            logDebug("Err! No mapping definition");
            throw new ExtractorException("Err! No mapping definition");
        }
        
        try{
            conn = getConnection();
            
            Hashtable params = new Hashtable();
            params.put(FIELD_PROCESSOR_ID, batch.getProcessorID());
            params.put(FIELD_BATCH_ID, batch.getBatchID());
            
            rawData= conn.executeQuery(_sSelectIMBatch,params );
            close(conn);
        }
        catch(Exception e) {
            
            logDebug((Throwable) e);
            throw (new ExtractorException(e.getMessage()));
        }
        finally{
            
            try{
                if(conn!=null)
                    conn.close();
            }
            catch(Exception e){
                logDebug((Throwable)e);
            }
            
        }
        
        return rawData;
    }
    
    private void GTIParseMsg(Hashtable hParseResult) throws Exception {
		
    	String sProp="";
    	sProp=System.getProperty("awt.toolkit");
    	logDebug("GTIParseMsg: awt.toolkit["+sProp+"]");
    	sProp=System.getProperty("java.awt.graphicsenv");
    	logDebug("GTIParseMsg: java.awt.graphicsenv["+sProp+"]");
    	long lStartTime, lEndTime, lTimeSpent;
    	
    	//IDataConnection  conn = null;
    	try{
			logDebug("GTIParseMsg(): Start");
			
			String gtiMsg=(String)hParseResult.get(FIELD_MSG_CONTENT);
			String sProcUnit=(String)hParseResult.get(FIELD_PROC_UNIT);
			String sQueueTyp=(String)hParseResult.get(FIELD_QUEUE_TYP);
			int iQueueID=((Integer)hParseResult.get(FIELD_QUEUE_ID)).intValue();
			String sMsgTyp=(String)hParseResult.get(FIELD_MSG_TYP);
			String sProdCat=(String)hParseResult.get(FIELD_PROD_CAT);
			String sProdTyp=(String)hParseResult.get(FIELD_PROD_TYP);
			String sTranTyp=(String)hParseResult.get(FIELD_TRAN_TYP);
			String sBatchTag="";
			
			//Move RestoreNonASCII logic from Webservice GTSXmlMsgProcessor.java to IMParseMappingExtractor.java - Start
			lStartTime = Calendar.getInstance().getTime().getTime();
			logDebug("GTIParseMsg(): RestoreNonASCII(gtiMsg) Start Time:"+lStartTime);
			gtiMsg=GTSApplPrntConvertASCII.RestoreNonASCII(gtiMsg);
				
			lEndTime = Calendar.getInstance().getTime().getTime();
        	logDebug("GTIParseMsg(): RestoreNonASCII(gtiMsg) End Time(Text): "+lEndTime+" ms");
        	
        	lTimeSpent=lEndTime-lStartTime;
        	logDebug("GTIParseMsg(): Time Spent RestoreNonASCII(gtiMsg): "+lTimeSpent+" ms");
        	
        	logDebug("GTIParseMsg(): replace hParseResult(MSG_CONTENT)");
        	hParseResult.remove(FIELD_MSG_CONTENT);
	        hParseResult.put(FIELD_MSG_CONTENT, gtiMsg);
	        //Move RestoreNonASCII logic from Webservice GTSXmlMsgProcessor.java to IMParseMappingExtractor.java - End
			
			DocumentBuilderFactory _factory = DocumentBuilderFactory.newInstance();
			DocumentBuilder builder = _factory.newDocumentBuilder();
			logDebug("After Builder");

	        builder.setErrorHandler(new DefaultHandler());
	        logDebug("After setErrorHandler");
	        
	        ByteArrayInputStream XMLInputStream = new ByteArrayInputStream(gtiMsg.getBytes());
	        Document xmlDoc = builder.parse(XMLInputStream);
	        logDebug("After Parse XML");
	        
	        Element root = xmlDoc.getDocumentElement();
	        if (root.getElementsByTagName("MessageOriginator").getLength()>0 && root.getElementsByTagName("MessageOriginator").item(0).hasChildNodes()){
	    		sBatchTag=root.getElementsByTagName("MessageOriginator").item(0).getFirstChild().getNodeValue().trim();
	    		logDebug("MessageOriginator: " + sBatchTag);
	    	}
	    	else	// MessageOriginator is mandatory across all applications
	    		logDebug("Warning! MessageOriginator is missing.");
	        
			//////////////////////////////////////////////////////////////
            // Generate Application Print for messages from GTI (TC/TPX)
            //////////////////////////////////////////////////////////////
    		Hashtable map = new Hashtable();
    		map.put("PROC_UNIT", sProcUnit);
    		map.put("QUEUE_TYP", sQueueTyp);
    		map.put("BATCH_TAG", sBatchTag);
    		map.put("MSG_TYP", sMsgTyp);
    		map.put("PROD_CAT", sProdCat);
    		map.put("PROD_TYP", sProdTyp);
    		map.put("TRAN_TYP", sTranTyp);
    		
    		logDebug("GTIParseMsg: map: PROC_UNIT "+ sProcUnit);
    		logDebug("GTIParseMsg: map: QUEUE_TYP "+ sQueueTyp);
    		logDebug("GTIParseMsg: map: BATCH_TAG "+ sBatchTag);
    		logDebug("GTIParseMsg: map: MSG_TYP "+ sMsgTyp);
    		logDebug("GTIParseMsg: map: PROD_CAT "+ sProdCat);
    		logDebug("GTIParseMsg: map: PROD_TYP "+ sProdTyp);
    		logDebug("GTIParseMsg: map: TRAN_TYP "+ sTranTyp);
    		
    		//getTimeInMillis() not for JDK1.3
    		//long lStartTime = Calendar.getInstance().getTimeInMillis();
    		lStartTime = Calendar.getInstance().getTime().getTime();
    		logDebug("GTIParseMsg(): Appl Print Generate Start Time(Text): "+lStartTime+" ms");
    		
    		//logDebug("Hunter0609: before GTSApplPrnt");
    		//conn=getConnection();
    		GTSApplPrnt gtsApplPrnt = new GTSApplPrnt(new ByteArrayInputStream(gtiMsg.getBytes("UTF-8")), conn, map, (GenericLogger)_mappingContext.getLogger() );
    		//gtiMsg.getBytes() -> all char ASCII>127 become "?"
    		//getBytes("ISO-8859-1") -> all char ASCII>127 become "?", and even some char after special chars be eaten. eg. NA?dvising Bank?eference
    		//getBytes("UTF-8") -> can generate for char ASCII>127
    		
    		//Test close(conn) after gtsApplPrnt later
    		//close(conn);
    		//logDebug("Hunter0609: close(conn) after new GTSApplPrnt");
    		
    		String applPrntTextOut = "";
        	ByteArrayOutputStream applPrntPdfOut = null;
        	
        	//Generate of Text format(SI_MSG.MSG_TEXT) need to input with single-byte chars (mapped by GTSApplPrntConvertASCII.ReplaceNonASCII)
        	//As 2-byte char cannot be stored to GTS DB
        	if (gtsApplPrnt.isTemplateExist()){
            	applPrntTextOut = gtsApplPrnt.ExportToText();
            	//applPrntPdfOut = gtsApplPrnt.ExportToPdf();
            	
            	logDebug("##### KEITH: applPrntTextOut #####");
            	logDebug("applPrntTextOut.length(): "+ new Integer(applPrntTextOut.length()).toString());
            	
            	//sApplPrintText = applPrntTextOut;
            	logDebug("GTIParseMsg(): applPrntTextOut["+applPrntTextOut+"]");
            	
            	
    	        
        	}else{
        		throw(new Exception("Appl Prnt Exception (Text Format): isTemplateExist() is false"));
        	}
        	
        	//getTimeInMillis() not for JDK1.3
        	//long lEndTime = Calendar.getInstance().getTimeInMillis();
        	lEndTime = Calendar.getInstance().getTime().getTime();
        	logDebug("GTIParseMsg(): Appl Print Generate End Time(Text): "+lEndTime+" ms");
        	
        	lTimeSpent=lEndTime-lStartTime;
        	logDebug("GTIParseMsg(): Time Spent Appl Print(Text): "+lTimeSpent+" ms");
        	        	
        	if (gtsApplPrnt.isTemplateExist()){
	        	hParseResult.remove(FIELD_MSG_TEXT);
		        hParseResult.put(FIELD_MSG_TEXT, applPrntTextOut);
        	}
        	
        	if(GTSApplPrntConvertASCII.checkRequireASCTransform_MsgType(sProcUnit, sQueueTyp, sMsgTyp, conn, (GenericLogger)_mappingContext.getLogger())
        			&& GTSApplPrntConvertASCII.checkContentRequire_ASCII8_TO_CP1252(gtiMsg, (GenericLogger)_mappingContext.getLogger())){
        		logDebug("GTIParseMsg checkRequireASCTransform is true. Proceed ReplaceASCII8_TO_CP1252");
        		
        		//Generate of PDF format(APPL_PRNT) do not reconize mapped single-byte chars(not in ISO-8859-1 code page)
            	//Need to input with String of CP1252 (mapped by GTSApplPrntConvertASCII.ReplaceASCII8_TO_CP1252)
            	long lStartTime2 = Calendar.getInstance().getTime().getTime();
        		logDebug("GTIParseMsg(): Appl Print Generate Start Time(PDF): "+lStartTime2+" ms");
        		
            	String gtiMsg2=GTSApplPrntConvertASCII.ReplaceASCII8_TO_CP1252(gtiMsg);
            	GTSApplPrnt gtsApplPrnt2 = new GTSApplPrnt(new ByteArrayInputStream(gtiMsg2.getBytes("UTF-8")), conn, map, (GenericLogger)_mappingContext.getLogger() );
            	
            	if (gtsApplPrnt2.isTemplateExist()){
                	applPrntPdfOut = gtsApplPrnt2.ExportToPdf();
                	
                	logDebug("##### KEITH: applPrntPdfOut.size() #####");
                	logDebug("applPrntPdfOut.size(): "+ new Integer(applPrntPdfOut.size()).toString());

            	}else{
            		throw(new Exception("Appl Prnt Exception (PDF Format): isTemplateExist() is false"));
            	}
            	
            	long lEndTime2 = Calendar.getInstance().getTime().getTime();
            	logDebug("GTIParseMsg(): Appl Print Generate End Time(PDF): "+lEndTime2+" ms");
            	
            	long lTimeSpent2=lEndTime2-lStartTime2;
            	logDebug("GTIParseMsg(): Time Spent Appl Print(PDF): "+lTimeSpent2+" ms");
            	
    			if (gtsApplPrnt2.isTemplateExist()){
    	        	hParseResult.remove(FIELD_APPL_PRNT_PDF);
    	        	hParseResult.put(FIELD_APPL_PRNT_PDF, applPrntPdfOut);
            	}
        		
        	}else{
        		logDebug("GTIParseMsg checkRequireASCTransform is false. Bypass ReplaceASCII8_TO_CP1252");
        		
        		if (gtsApplPrnt.isTemplateExist()){
        			applPrntPdfOut = gtsApplPrnt.ExportToPdf();
                	
                	logDebug("##### KEITH: applPrntPdfOut.size() #####");
                	logDebug("applPrntPdfOut.size(): "+ new Integer(applPrntPdfOut.size()).toString());
        			
                	hParseResult.remove(FIELD_APPL_PRNT_PDF);
    	        	hParseResult.put(FIELD_APPL_PRNT_PDF, applPrntPdfOut);
            	}
        	}
        	
        	//Insert of GTDPEND1..APPL_PRNT move to commitParseResult()
			
			//close(conn);
			
		}catch(Exception e){
			logDebug(e.getMessage());
			logDebug("GTIParseMsg(): Catch Exception:"+ e.getMessage());
			throw new Exception("GTIParseMsg() Exception: "+e.getMessage());
		}
		finally {
            //close(conn);
        }
		
    }
    
    private void TELEXParseMsg(Hashtable hParseResult) throws Exception {
		
    	try{
			//TELEX Parsing, according EMEA telex_in.java
    		String sMsgHeader=(String)hParseResult.get(FIELD_MSG_HEADER);
			String ExtMsgRef = sMsgHeader.substring(22,28);
			logDebug("TELEXParseMsg: DEBUG ExtMsgRef[" + ExtMsgRef+"]");
			
			String LinkMsgSeq = "1";
		    String LnkMsgTol = "1"; 
			
			hParseResult.remove(FIELD_LNK_REF);
			hParseResult.remove(FIELD_EXT_MSG_REF);
			hParseResult.remove(FIELD_LNK_MSG_SEQ);
			hParseResult.remove(FIELD_LNK_MSG_TOTAL);
			
			hParseResult.put(FIELD_LNK_REF, ExtMsgRef);
			hParseResult.put(FIELD_EXT_MSG_REF, ExtMsgRef);
			hParseResult.put(FIELD_LNK_MSG_SEQ, new Integer(LinkMsgSeq));
			hParseResult.put(FIELD_LNK_MSG_TOTAL, new Integer(LnkMsgTol));
			
			logDebug("SWIFTParseLnkRef: FIELD_LNK_REF="+ExtMsgRef);
			logDebug("SWIFTParseLnkRef: FIELD_EXT_MSG_REF="+ExtMsgRef);
			logDebug("SWIFTParseLnkRef: FIELD_LNK_MSG_SEQ="+LinkMsgSeq);
			logDebug("SWIFTParseLnkRef: FIELD_LNK_MSG_TOTAL="+LnkMsgTol);
			
		}catch(Exception e){
			logDebug(e.getMessage());
			logDebug("TELEXParseMsg(): Catch Exception:"+ e.getMessage());
			throw new Exception("TELEXParseMsg() Exception: "+e.getMessage());
		}
		
    }
	private void SWIFTParseMsg(Hashtable hParseResult) throws Exception {
		try{
		
		String LinkMsgInfo = null;
		String LinkMsgSeq = null;
		String LnkMsgTol = null;
		String LinkRef = "";
		int ipos;
		 
		 String sProcUnit=(String)hParseResult.get(FIELD_PROC_UNIT);
		 //Integer ioQueueID=(Integer)hParseResult.get(FIELD_QUEUE_ID);
		 //int iQueueID=ioQueueID.intValue();
		 int iQueueID=Integer.parseInt((String)hParseResult.get(FIELD_QUEUE_ID).toString());
		 String sMsgText=(String)hParseResult.get(FIELD_MSG_CONTENT);
			 
		//swiftMsg = (String)m.content;
        String swiftMsg=sMsgText;

		//LinkRef = findTagContent(swiftMsg,"20:");
		//logDebug("ParseMsg() LinkRef : [" + LinkRef + "]");
		//logDebug("ParseMsg() MsgTyp : [" + MsgTyp +"]");
        SWIFTParseLnkRef(hParseResult);
        SWIFTParseTxnAmt(hParseResult);
        
        LinkMsgInfo = findTagContent(swiftMsg,"27:");
        if (LinkMsgInfo == null) {
		    LinkMsgSeq = "1";
		    LnkMsgTol = "1";    
        } else{
		    LinkMsgSeq = Left(LinkMsgInfo, 1);
		    //LnkMsgTol = LinkMsgInfo.substring(2, 3);    
		    LnkMsgTol = Mid(LinkMsgInfo, 2, 3);
        }
		logDebug("ParseMsg() LinkMsgInfo: [" + LinkMsgInfo+"]");
		logDebug("ParseMsg() LinkMsgSeq: [" + LinkMsgSeq+"]");
		logDebug("ParseMsg() LnkMsgTol: [" + LnkMsgTol+"]");
		
		hParseResult.remove(FIELD_LNK_MSG_SEQ);
		hParseResult.remove(FIELD_LNK_MSG_TOTAL);
		hParseResult.put(FIELD_LNK_MSG_SEQ, new Integer(LinkMsgSeq));
		hParseResult.put(FIELD_LNK_MSG_TOTAL, new Integer(LnkMsgTol));

		/* Remark:  
		 * 1. For SWIFT: KEY_1 = TAG21, KEY_2 = TAG20, KEY_3 = TAG40A/TAG40B, KEY_4 = TAG59 
		 * 2. For GTI: KEY_1 = Tag <Type>, KEY_2 = PTY_ID/EXT_REF_NBR, KEY_3 = BLANK, KEY_4 = BLANK 
		 */ 
		
		String sTag21=findTagContent(swiftMsg,"21:");
		if (sTag21 == null) {
			sTag21 = "";
		}
		logDebug("SWIFTParseMsg: sTag21["+sTag21+"]");
		
		String sTag20=findTagContent(swiftMsg,"20:");
		if (sTag20 == null) {
			sTag20 = "";
		}
		logDebug("SWIFTParseMsg: sTag20["+sTag20+"]");
		
		String sTag40A=findTagContent(swiftMsg,"40A:");
		if (sTag40A == null) {
			sTag40A = "";
		}
		logDebug("SWIFTParseMsg: sTag40A["+sTag40A+"]");
		
		String sTag40B=findTagContent(swiftMsg,"40B:");
		if (sTag40B == null) {
			sTag40B = "";
		}
		ipos=sTag40B.indexOf("\r\n");
		if (ipos != -1)
			sTag40B=Left(sTag40B,ipos);
		logDebug("SWIFTParseMsg: sTag40B["+sTag40B+"]");
		
		String sTag59=findTagContent(swiftMsg,"59:");
		if (sTag59 == null) {
			sTag59 = "";
		}
		ipos=sTag59.indexOf("\r\n");
		if (ipos != -1)
			sTag59=Left(sTag59,ipos);
		logDebug("SWIFTParseMsg: sTag59["+sTag59+"]");
				
		hParseResult.remove(FIELD_SWIFT_TAG21);
    	hParseResult.remove(FIELD_SWIFT_TAG20);
    	hParseResult.remove(FIELD_SWIFT_TAG40A);
    	hParseResult.remove(FIELD_SWIFT_TAG40B);
    	hParseResult.remove(FIELD_SWIFT_TAG59);
		hParseResult.put(FIELD_SWIFT_TAG21, sTag21);
    	hParseResult.put(FIELD_SWIFT_TAG20, sTag20);
    	hParseResult.put(FIELD_SWIFT_TAG40A, sTag40A);
    	hParseResult.put(FIELD_SWIFT_TAG40B, sTag40B);
    	hParseResult.put(FIELD_SWIFT_TAG59, sTag59);
    	
    	if(! getMsgRouteResult(hParseResult)){
    		logDebug("SWIFTParseMsg: execute getMsgRouteResult failed");
    		throw new Exception("SWIFTParseMsg: execute getMsgRouteResult failed");
    	}
    	logDebug("SWIFTParseMsg: execute getMsgRouteResult success");
    	
    	String s1=(String)hParseResult.get(FIELD_ROUTE_PROD_TYP);
    	String s2=(String)hParseResult.get(FIELD_ROUTE_LOCATION_CD);
    	logDebug("s1:"+s1+", s2:"+s2);
    	
		}catch(Exception e){
			logDebug("SWIFTParseMsg Catch Exception:"+ e.getMessage());
			throw new Exception(e.getMessage());
		}
		
	}    
    
	private void SWIFTerrLog2DB(String sProcUnit, int iQueueID, String err) throws Exception {
		
		//IDataConnection conn=null;
		CallableStatement stmt = null;
		int result;
		try {
			
			String sql = "GTDPEND1..USP_ISWF_INSSIERRLOG '" + sProcUnit + "', '" + sProcUnit + "', "
				+ iQueueID + ", 0, '" + err + "', '', ''";
			logDebug("In errLog2DB SQL : " + sql);

			//conn= getConnection();
			stmt = conn.prepareCall(sql);
			//close(conn);
	        
			result=stmt.executeUpdate();
			if (result != 0) {
				logDebug("SWIFTerrLog2DB failed with status: " + result);
				return;
			}
			
		} catch (SQLException ex) {
			logDebug((Throwable) ex);
		    logDebug("IMParseMappingExtractor.SWIFTerrLog2DB: "+ex.getMessage());
			//throw new SQLException("swift_in_merva.errLog2DB: " + e.getMessage());
		}finally{
			if (stmt != null) {
				try{
					stmt.close();
				} catch (SQLException e) {
					com.chase.infra.util.LogWrapper.instance.logDebug("IMParseMappingExtractor.SWIFTerrLog2DB failed to close PreparedStatement");
					e.printStackTrace();
				}
			}
		}
		logDebug("End SWIFTerrLog2DB ... ");
	}
	
	private boolean SWIFTisValidBasicHdr(String sProcUnit, int iQueueID, String basicHeader, String cID) throws Exception {
		int pos = 0;

		// check Basic Header
		if ((basicHeader.length() != 29) | (basicHeader.charAt(pos) != '{'
						|| basicHeader.charAt(++pos) != '1'
						|| basicHeader.charAt(++pos) != ':'
						|| basicHeader.charAt(++pos) != 'F'
						|| basicHeader.charAt(++pos) != '0'
						|| basicHeader.charAt(++pos) != '1' ))
		{
			//dbAcc.rollback();
			String errMsg = "got an invalid Basic Header on correl ID [" + cID + "]";	
			SWIFTerrLog2DB(sProcUnit, iQueueID, errMsg);
			return false;
		}
		return true;
	}
	
	private String findTagContent(String pStr,String pTag){
		 int lvPos = 1;
		 String lvTmpStr = pStr;
		 String lvTmpTagContent;

		 while ((lvPos = lvTmpStr.indexOf(TAGDELI, lvPos)) != -1) {
		         //lvTmpTagContent = lvTmpStr.substring(2, lvPos-1); 
		         lvTmpTagContent = Mid(lvTmpStr, 2, lvPos-1);
		         //printlog("findTagContent lvTmpTagContent : [" + lvTmpTagContent+"]");
		         if (Left(lvTmpTagContent,pTag.length()).equals(pTag))
		            //return lvTmpTagContent.substring(pTag.length()).trim();
		         	return Mid(lvTmpTagContent, pTag.length()).trim();
		         //lvTmpStr = lvTmpStr.substring(lvPos);
		         lvTmpStr = Mid(lvTmpStr,lvPos);
		         lvPos = 1;
		 }
			
		 return null;	
	}
	
	private int SWIFTgetLstMsgNbr(String sProcUnit) throws Exception {
		
		int lstMsgNbr = 0;
		//IDataConnection  conn = null;
        try {
        	String sql = "exec GTDPEND1..USP_TSI_MSG_NBR_RUN_SEL "; 
    		sql += "'";
    		sql += sProcUnit;
    		sql += "', '";
    		sql += QUEUE_TYP_SWIFT;
    		sql += "', '";
    		sql += lvDefDate;
    		sql += "'";
    		logDebug("SWIFTgetLstMsgNbr SQL : " + sql);
    		
        	//conn=getConnection();
            DataTable dt = conn.executeQuery(sql);
            dt.next();
            
            lstMsgNbr = ((Integer)dt.getField(FIELD_LST_MSG_NBR)).intValue();
            logDebug("SWIFTgetLstMsgNbr(): lstMsgNbr = " + lstMsgNbr ) ;
           
        }
        catch (Exception ex) {
            //throw new TriggerException(e.getMessage());
            logDebug((Throwable) ex);
		    logDebug("IMParseMappingExtractor.SWIFTgetLstMsgNbr: "+ex.getMessage());
			throw new Exception(ex.getMessage());
        }
        finally {
            //close(conn);
        }
		
        return lstMsgNbr;
	}
	
	private boolean SWIFTUpdMsgNbr(String sProcUnit, String lvMsgSeqNo) throws Exception {
		logDebug("UpdMsgNbr update with lvMsgSeqNo="+lvMsgSeqNo);
		CallableStatement stmt = null;
		int nRtnCode;
		//IDataConnection conn=null;
		try {
			
			String sql= "GTDPEND1..USP_TSI_MSG_NBR_RUN_UPD ";
			sql += "'";
			sql += sProcUnit;
			sql += "', '";
			sql += QUEUE_TYP_SWIFT;
			sql += "', ";
			sql += lvMsgSeqNo;
			sql += ", '";
			sql += lvDefDate;
			sql += "'";
			
			logDebug("SWIFTUpdMsgNbr SQL : " + sql);

			//conn= getConnection();
			stmt = conn.prepareCall(sql);
	        
			nRtnCode=stmt.executeUpdate();
			if (nRtnCode != 0) {
				logDebug("UpdMissMsg return status: " + nRtnCode);
				return false;
			}
			
		} catch (SQLException ex) {
			logDebug((Throwable) ex);
		    logDebug("IMParseMappingExtractor.SWIFTUpdMsgNbr: "+ex.getMessage());
		    throw new Exception(ex.getMessage());
		}finally {
			if (stmt != null) {
				try{
					stmt.close();
				} catch (SQLException e) {
					com.chase.infra.util.LogWrapper.instance.logDebug("IMParseMappingExtractor.SWIFTUpdMsgNbr failed to close PreparedStatement");
					e.printStackTrace();
				}
			}
		}
		return true;
	}
	
	private boolean SWIFTgetBlock(final int len, int lastPos, int currentPos, String swiftMsg) {
		int beginCnt = 0;
		int endCnt = 0;

		logDebug("Inide SWIFTgetBlock: Hunter lastPos Start : "+lastPos);
		
		for (lastPos = currentPos; currentPos < len; ++currentPos) {
			if (swiftMsg.charAt(currentPos) == '{')
				if (++beginCnt == 1)
					lastPos = currentPos;

			if (swiftMsg.charAt(currentPos) == '}')
				++endCnt;

			if (beginCnt < endCnt)
				return false;

			if ((beginCnt != 0) && (beginCnt == endCnt))
				break;
		}
		
		logDebug("Inide SWIFTgetBlock: Hunter lastPos End : "+lastPos);
		
		if (currentPos > len)
			return false;
		else
			return true;
	}
	
	private boolean SWIFTisValidTrailer(String sProcUnit, int iQueueID, String trailer, String cID) throws Exception {
		int pos = 0;
		int lastPos = 0;
		int len =  trailer.length();

		// check Trailer
		if ((len != 0) && (trailer.charAt(pos) != '{'
			|| trailer.charAt(++pos) != '5'
			|| trailer.charAt(++pos) != ':'))
		{
			String errMsg = "got an invalid Trailer on correl ID [" + cID + "]";
			SWIFTerrLog2DB(sProcUnit, iQueueID, errMsg);
			return false;
		}
		return true;
	}
	
    private void SWIFTTransformReadable(Hashtable hParseResult) throws Exception {
        try {
        	//printlog("WriteMsgText start");
        	
	       String lmsgText = "", lswiftText = null, ltagContent = null;
	       int iPos;
	       lswiftText = (String)hParseResult.get(FIELD_MSG_CONTENT);
	       
	       if(SWIFTCheckExistTagEnd(lswiftText)){
	            logDebug("SWIFTTransformReadable : SWIFTCheckExistTagEnd true");
	            //printlog("WriteMsgText lmsgText 1="+lmsgText);
	
	            StringBuffer sbAsterisk = new StringBuffer();
	            for (int i=0; i<69; i++)
	            	sbAsterisk.append('*');
	
	//                if (LinkMsgSeq == "1")
	//                      lmsgText = "QUEUE ID :: " + queueId + "\r\n";
	            
	            String lvMsgRecvDT="";
	            java.util.Date ldRecvDt=(java.util.Date)hParseResult.get(FIELD_RECV_DT);
	            SimpleDateFormat lvDFTo = new SimpleDateFormat("MMM dd yyyy hh:mm:ssa");
	            /*
	            try	
	            {
	            	lvMsgRecvDT = (lvDFTo.format(ldRecvDt));
	            	//printlog("ParseMsg() lvMsgRecvDT: [" + lvMsgRecvDT+"]");
	            }
	            catch (ParseException e)
	            {
	            	logDebug("SWIFTTransformReadable() Wrong Receive Date format :" + ldRecvDt);
	            }
	            */
	            lvMsgRecvDT = (lvDFTo.format(ldRecvDt));
	            
	            lmsgText += "RECEIVED TIME:" + lvMsgRecvDT + " \n\n";
	            lmsgText += sbAsterisk.toString() + "\n\n";
	            
	            String lsMsgTyp=(String)hParseResult.get(FIELD_MSG_TYP);
	
	            //String appHeader = lswiftText.substring((basicHdrLen), (basicHdrLen+appHdrLen));
	            String appHeader = Mid(lswiftText, (basicHdrLen), (basicHdrLen+appHdrLen));
	            logDebug("SWIFTParseMsg: appHeader="+appHeader);
	            //String lsSndrAddr=appHeader.substring(17, 29);
	            String lsSndrAddr=Mid(appHeader, 17, 29);
	            logDebug("lsSndrAddr="+lsSndrAddr);
	            
	            lmsgText += "SWIFT MT" + lsMsgTyp + " Received as Below\n\n";
	            lmsgText += sbAsterisk.toString() + "\n\n";
	            //printlog("WriteMsgText lmsgText 2="+lmsgText);
	
	            if (lsMsgTyp.trim().equals("701") || lsMsgTyp.trim().equals("711") || lsMsgTyp.trim().equals("721")){
	                lmsgText += "Sender's Address : " + lsSndrAddr + "\n\n";
	                    
	            } else if (lsMsgTyp.trim().equals("740") || lsMsgTyp.trim().equals("742") || lsMsgTyp.trim().equals("747") || Mid(lsMsgTyp,1,3).trim().equals("99")){
	                //printlog("WriteMsgText 3.2 SndrAddr=["+SndrAddr+"]");		  
	            	lmsgText += "Sender's Address : ";
	            	lmsgText += getBTBBIC(hParseResult, lsSndrAddr) + "\n\n";
	            } else  {  lmsgText += "Sender's Address : ";
	                //printlog("WriteMsgText 3.3 SndrAddr=["+SndrAddr+"]");		  
	            	lmsgText += getBIC(lsSndrAddr) + "\n\n";
	            }
	            //printlog("WriteMsgText lswiftText=["+lswiftText+"]");
	            //lswiftText = (String)hParseResult.get(FIELD_MSG_CONTENT);
	            //printlog("WriteMsgText lswiftText=["+lswiftText+"]");
	
	            // remove leading brackets & block indicator
	            iPos = lswiftText.indexOf(TAGDELI);
	            //printlog("WriteMsgText iPos="+iPos);
	            
	            //lswiftText = lswiftText.substring(iPos++);
	            lswiftText = Mid(lswiftText, iPos++);
	            //printlog("WriteMsgText lswiftText=["+lswiftText+"]");
	            iPos = 1;
	            // extract Tags content
	            while ((iPos = lswiftText.indexOf(TAGDELI, iPos)) != -1) {
	            	//ltagContent = lswiftText.substring(2, iPos); // keep LF and remove leading ":"
	            	ltagContent = Mid(lswiftText, 2, iPos); // keep LF and remove leading ":"
	            	//printlog("WriteMsgText loop ltagContent=["+ltagContent+"]");                                
	            	lmsgText += FmtTagContent(ltagContent, hParseResult);
	            	//lswiftText = lswiftText.substring(iPos);
	            	lswiftText = Mid(lswiftText, iPos);
	            	//printlog("WriteMsgText loop lswiftText=["+lswiftText+"]");                                
	            	iPos = 1;
	            }
	                // end of block 4 -- process last tag
	            //ltagContent = lswiftText.substring(2, (lswiftText.indexOf(SWIFTEND) -2));
	            ltagContent = Mid(lswiftText, 2, (lswiftText.indexOf(SWIFTEND) -2));
	            //printlog("WriteMsgText ltagContent=["+lswiftText+"]");                                
	            lmsgText += FmtTagContent(ltagContent, hParseResult);
	            lmsgText += "\n" + sbAsterisk.toString() + "\n";
	            // store to class variables
	            String msgText = lmsgText;
	            hParseResult.remove(FIELD_MSG_TEXT);
	            hParseResult.put(FIELD_MSG_TEXT, msgText);
	            //printlog("WriteMsgText: End..... msgText=["+msgText+"]");
	            //printlog("WriteMsgText: End..... ");
	            
	            logDebug("SWIFTTransformReadable: lmsgText=\n"+lmsgText);
	       }else
	    	   logDebug("SWIFTTransformReadable : SWIFTCheckExistTagEnd false");
	       
        } catch (Exception e) {
        	//isErrorTextFormat = true;
        	//hParseResult.remove(FIELD_ERR_TEXT_FMT);
        	//Boolean bErrTextFmt=new Boolean(true);
        	//hParseResult.put(FIELD_ERR_TEXT_FMT, bErrTextFmt);
        	logDebug("IMParseMappingExtractor.SWIFTTransformReadable failed "+e);
        	
        	throw new Exception(e.getMessage());
        }
    }
    
    private void SWIFTTransformReadableMHS(Hashtable hParseResult) throws Exception {

	   String lmsgText = null, lswiftText = null, lmsgContent = null, ltagContent = null;;
	   int Indbgn = 0, Indend = 0;
	   boolean WithFmt = false, WithResult = false;
	   String sql, sProcUnit, sConfigVal, sQueueID, sLinkMsgSeq, sSndrAddr;
	   try {
		   
 	       	lswiftText = (String)hParseResult.get(FIELD_MSG_CONTENT);
 	       	sProcUnit=(String)hParseResult.get(FIELD_PROC_UNIT);
 	       	sQueueID=(String)hParseResult.get(FIELD_QUEUE_ID).toString();
 	       	sSndrAddr=(String)hParseResult.get(FIELD_SEND_RECV_ADDR);
 	       	sLinkMsgSeq=(String)hParseResult.get(FIELD_LNK_MSG_SEQ).toString();
 	      
			sConfigVal=getPUConfig(sProcUnit, "EMEA_NEW_FMT");
			
			if (sConfigVal.trim().equals("Y")){
				WithResult = true;
			}
			else if (sConfigVal.trim().equals("N")){
				WithResult = true;
			}
			else{
				WithResult = false;
			}
			
			if (sConfigVal.trim().equals("Y")){
				if ((Indbgn = lswiftText.indexOf("\n:Fmt:")) == -1) {
					// start of mandatory field :Fmt: not present
					Indend = lswiftText.indexOf("\n-}");
					Indend -= 1;
					lmsgText = lswiftText.substring(0, Indend+4);
					lmsgContent = lswiftText;
					WithFmt = false;
				}
				else
				{
					Indend = lswiftText.indexOf("\n-}");
					Indend -= 1;
					lmsgText = lswiftText.substring(0, Indbgn) + lswiftText.substring(Indend, Indend+4);
					lmsgContent = lswiftText.substring(0, Indbgn) + lswiftText.substring(Indend, Indend+4);	
					WithFmt = true;
				}
			}
			
			if (WithResult == false || WithFmt == false)
			{
				int iPos;
		
				StringBuffer sbAsterisk = new StringBuffer();
				for (int i=0; i<80; i++)
					sbAsterisk.append('*');
		
				lmsgText="";
				if (sLinkMsgSeq == "1")
					lmsgText = "QUEUE ID :: " + sQueueID + "\r\n";
				lmsgText += sbAsterisk.toString() + "\nSender's Address :\n" + sSndrAddr + "\n";
				lswiftText = lmsgContent;
		
				// remove leading brackets & block indicator
				iPos = lswiftText.indexOf(TAGDELI);
				lswiftText = lswiftText.substring(iPos++);
		
				// extract Tags content
				while ((iPos = lswiftText.indexOf(TAGDELI, iPos)) != -1) {
					ltagContent = lswiftText.substring(2, iPos); // keep LF and remove leading ":"
					lmsgText += FmtTagContent(ltagContent, hParseResult);
					lswiftText = lswiftText.substring(iPos);
					iPos = 1;
				}
		
				// end of block 4 -- process last tag
				ltagContent = lswiftText.substring(2, (lswiftText.indexOf("-}") -2));
				lmsgText += FmtTagContent(ltagContent, hParseResult);
				lmsgText += "\n" + sbAsterisk.toString() + "\n";
			}
			else 
			{										
				if( (sConfigVal.trim().equals("Y")) && (WithFmt == true) )
				{
					lmsgText = lswiftText.substring(Indbgn+6, Indend+1);	// -} ending is removed
				}
			}
			
			logDebug("lmsgContent" + lmsgContent);
			
			hParseResult.remove(FIELD_MSG_CONTENT);
            hParseResult.put(FIELD_MSG_CONTENT, lmsgContent);
            hParseResult.remove(FIELD_MSG_TEXT);
            hParseResult.put(FIELD_MSG_TEXT, lmsgText);
	       
        } catch (Exception e) {
        	logDebug("IMParseMappingExtractor.SWIFTTransformReadableMHS failed "+e);
        	throw new Exception(e.getMessage());
        }
    }
    
    private boolean SWIFTCheckExistTagEnd(String sMsg){
    	boolean bExistTagEnd=false;
    	
    	if((sMsg.indexOf(TAGDELI)!=-1)&&(sMsg.indexOf(TAGDELI)!=-1)){
    		bExistTagEnd=true;
    	}
    	return bExistTagEnd;
    }

	private String getBIC(String id) throws Exception {
		String sName="", sAddr1="", sAddr2="", sAddr3="", sAddr4="", sFinal="";
		String sDelim = "\n";
		String swiftid="";
		int cnt, bPos;

		StringTokenizer st = new StringTokenizer(id, sDelim);

		cnt = st.countTokens();

	    if (st.hasMoreTokens()) {
	          swiftid = st.nextToken();
			  //swiftid = swiftid.replace('\n', ' ');
	    }

		if (swiftid.indexOf("/") != -1)
		{
			sFinal = swiftid;
			swiftid = st.nextToken();
		}
		if ((bPos = swiftid.indexOf("\r")) != -1)
		{
			swiftid = Left(swiftid, bPos);
		}
		
		//IDataConnection  conn = null;
        try {
   		
 		String sql = "select NAME, ADDR1, ADDR2, ADDR3, ADDR4 from GTDMAST1..BIC where SWIFT_ID = '"
				//+ Left(swiftid,8) + swiftid.substring(swiftid.length()-3)+"'";
 				+ Left(swiftid,8) + Right(swiftid,3)+"'";
		//printlog ("getBIC SQL1="+sql);
 		logDebug("getBIC SQL : " + sql);
 		
		//conn=getConnection();
        DataTable rs = conn.executeQuery(sql);
        //close(conn);

		if (rs.next() == true)
		{
			sName = (String)rs.getField("NAME");
			sName = DuplicateQuote(sName.trim());
			sAddr1 = (String)rs.getField("ADDR1");
			sAddr1 = DuplicateQuote(sAddr1.trim());
			sAddr2 = (String)rs.getField("ADDR2");
			sAddr2 = DuplicateQuote(sAddr2.trim());
			sAddr3 = (String)rs.getField("ADDR3");
			sAddr3 = DuplicateQuote(sAddr3.trim());
			sAddr4 = (String)rs.getField("ADDR4");
			sAddr4 = DuplicateQuote(sAddr4.trim());

			if (sFinal.length() > 0)
			{
				sFinal += "\n" + swiftid;
			}
			else
			{
				sFinal = swiftid;
			}
			if (sName.length() > 0)
			{
				sFinal += "\n" + sName;
			}

			if (sAddr1.length() > 0)
			{
				sFinal += "\n" + sAddr1;
			}

			if (sAddr2.length() > 0)
			{
				sFinal += "\n" + sAddr2;
			}

			if (sAddr3.length() > 0)
			{
				sFinal += "\n" + sAddr3;
			}

			if (sAddr4.length() > 0)
			{
				sFinal += "\n" + sAddr4;
			}

		}
		else
		{
			sql = "select NAME, ADDR1, ADDR2, ADDR3, ADDR4 from GTDMAST1..BIC where SWIFT_ID = '"
					+ Left(swiftid,8) + "'";
			//printlog ("getBIC SQL2="+sql);
			logDebug("getBIC SQL2 : " + sql);
			
			//conn=getConnection();
			rs = conn.executeQuery(sql);
			//close(conn);
			
			if (rs.next() == true)
			{
				sName = (String)(String)rs.getField("NAME");
				sName = DuplicateQuote(sName.trim());
				sAddr1 = (String)(String)rs.getField("ADDR1");
				sAddr1 = DuplicateQuote(sAddr1.trim());
				sAddr2 = (String)(String)rs.getField("ADDR2");
				sAddr2 = DuplicateQuote(sAddr2.trim());
				sAddr3 = (String)(String)rs.getField("ADDR3");
				sAddr3 = DuplicateQuote(sAddr3.trim());
				sAddr4 = (String)(String)rs.getField("ADDR4");
				sAddr4 = DuplicateQuote(sAddr4.trim());

				if (sFinal.length() > 0)
				{
					sFinal += "\n" + swiftid;
				}
				else
				{
					sFinal = swiftid;
				}

				if (sName.length() > 0)
				{
					sFinal += "\n" + sName;
				}
				
				//if (swiftid.substring(swiftid.length()-3).equalsIgnoreCase("XXX"))  //#6329, 6330
				if (Right(swiftid, 3).equalsIgnoreCase("XXX"))  //#6329, 6330
				{
					if (sAddr1.length() > 0)
					{
						sFinal += "\n" + sAddr1;
					}

					if (sAddr2.length() > 0)
					{
						sFinal += "\n" + sAddr2;
					}

					if (sAddr3.length() > 0)
					{
						sFinal += "\n" + sAddr3;
					}

					if (sAddr4.length() > 0)
					{
						sFinal += "\n" + sAddr4;
					}
				}
			}					
			else
			{
				sFinal = swiftid + "\n";
			}
		}

		while (st.hasMoreTokens())
		{
			sFinal = sFinal + "\n" + st.nextToken();
		}
//	printlog ("getBTBBIC SQL="+sql);
//	printlog ("getBTBBIC swiftid substring="+swiftid.substring(swiftid.length()-3));
//                printlog ("getBTBBIC sName "+sName );
//                printlog ("getBTBBIC sAddr1"+sAddr1);
//                printlog ("getBTBBIC sAddr2"+sAddr2);
//                printlog ("getBTBBIC sAddr3"+sAddr3);
//                printlog ("getBTBBIC sAddr4"+sAddr4);
//                printlog ("getBTBBIC sFinal="+sFinal);

        }
        catch (Exception ex) {
        	logDebug((Throwable) ex);
		    logDebug("IMParseMappingExtractor.getBIC: "+ex.getMessage());
			throw new Exception(ex.getMessage());
        }
        finally {
            //close(conn);
        }
		
		return sFinal;
	}
    
    
	private String getBTBBIC(Hashtable hParseResult, String id) throws Exception {
		String sName="", sAddr1="", sAddr2="", sAddr3="", sAddr4="", sFinal="";
		String sCity="", sChipId="", sABANo="", sAccNo="";
		String sDelim = "\n";
		String swiftid="";
		int cnt, bPos;

		StringTokenizer st = new StringTokenizer(id, sDelim);

		cnt = st.countTokens();

	    if (st.hasMoreTokens()) {
	          swiftid = st.nextToken();
			  //swiftid = swiftid.replace('\n', ' ');
	    }

		if (swiftid.indexOf("/") != -1)
		{
			sFinal = swiftid;
			swiftid = st.nextToken();
		}
		if ((bPos = swiftid.indexOf("\r")) != -1)
		{
			swiftid = Left(swiftid, bPos);
		}
		
		//IDataConnection  conn = null;
        try {
        	String sql = "select NAME, ADDR1, ADDR2, ADDR3, ADDR4, CITY_NAME, UID_ID, FED_ABA, ACCOUNT_NBR from GTDMAST1..BIC where SWIFT_ID = '"
				//+ Left(swiftid,8) + swiftid.substring(swiftid.length()-3)+ "'";
        		+ Left(swiftid,8) + Right(swiftid,3)+ "'";
		
    		logDebug("getBTBBIC SQL : " + sql);
    		
        	//conn=getConnection();
            DataTable rs = conn.executeQuery(sql);
            //close(conn);
            
 		if (rs.next() == true)
		{
 			sName = (String)rs.getField("NAME");
			sName = DuplicateQuote(sName.trim());
			
			sAddr1 = (String)rs.getField("ADDR1");
			sAddr1 = DuplicateQuote(sAddr1.trim());
			sAddr2 = (String)rs.getField("ADDR2");
			sAddr2 = DuplicateQuote(sAddr2.trim());
			sAddr3 = (String)rs.getField("ADDR3");
			sAddr3 = DuplicateQuote(sAddr3.trim());
			sAddr4 = (String)rs.getField("ADDR4");
			sAddr4 = DuplicateQuote(sAddr4.trim());
			
			sCity = (String)rs.getField("CITY_NAME");
			sCity = DuplicateQuote(sCity.trim());
			sChipId = (String)rs.getField("UID_ID");
			sChipId = DuplicateQuote(sChipId.trim());
			sABANo = (String)rs.getField("FED_ABA");
			sABANo = DuplicateQuote(sABANo.trim());
			sAccNo = (String)rs.getField("ACCOUNT_NBR");
			sAccNo = DuplicateQuote(sAccNo.trim());

			if (sFinal.length() > 0)
			{
				sFinal += "\n" + swiftid;
			}
			else
			{
				sFinal = swiftid;
			}
			if (sName.length() > 0)
			{
				sFinal += "\n" + sName;
			}

			if (sAddr1.length() > 0)
			{
				sFinal += "\n" + sAddr1;
			}

			if (sAddr2.length() > 0)
			{
				sFinal += "\n" + sAddr2;
			}

			if (sAddr3.length() > 0)
			{
				sFinal += "\n" + sAddr3;
			}

			if (sAddr4.length() > 0)
			{
				sFinal += "\n" + sAddr4;
			}
			
			if (sCity.length() > 0)
			{
				sFinal += "\n" + sCity;
			}
			
			sFinal += "\nCHIPS ID " + sChipId;
			sFinal += "\nABA NO " + sABANo;
			sFinal += "\nDDA NO " + sAccNo;
		}
		else
		{	
			sql = "select NAME, ADDR1, ADDR2, ADDR3, ADDR4, CITY_NAME, UID_ID, FED_ABA, ACCOUNT_NBR from GTDMAST1..BIC where SWIFT_ID = '"
					+ Left(swiftid,8) + "'";
			//printlog ("getBTBBIC SQL2="+sql);
			logDebug("getBTBBIC SQL2 : " + sql);
			
			//rs = dbAcc.executeSqlSelect(sql);
			//conn=getConnection();
			rs = conn.executeQuery(sql);
			//close(conn);
			
			if (rs.next() == true)
			{
				sName = (String)rs.getField("NAME");
				sName = DuplicateQuote(sName.trim());
				sAddr1 = (String)rs.getField("ADDR1");
				sAddr1 = DuplicateQuote(sAddr1.trim());
				sAddr2 = (String)rs.getField("ADDR2");
				sAddr2 = DuplicateQuote(sAddr2.trim());
				sAddr3 = (String)rs.getField("ADDR3");
				sAddr3 = DuplicateQuote(sAddr3.trim());
				sAddr4 = (String)rs.getField("ADDR4");
				sAddr4 = DuplicateQuote(sAddr4.trim());
				
				sCity = (String)rs.getField("CITY_NAME");
				sCity = DuplicateQuote(sCity.trim());
				sChipId = (String)rs.getField("UID_ID");
				sChipId = DuplicateQuote(sChipId.trim());
				sABANo = (String)rs.getField("FED_ABA");
				sABANo = DuplicateQuote(sABANo.trim());
				sAccNo = (String)rs.getField("ACCOUNT_NBR");
				sAccNo = DuplicateQuote(sAccNo.trim());

				if (sFinal.length() > 0)
				{
					sFinal += "\n" + swiftid;
				}
				else
				{
					sFinal = swiftid;
				}

				if (sName.length() > 0)
				{
					sFinal += "\n" + sName;
				}
				
				//if (swiftid.substring(swiftid.length()-3).equalsIgnoreCase("XXX"))  //#6329, 6330
				if (Right(swiftid, 3).equalsIgnoreCase("XXX"))  //#6329, 6330
				{
					if (sAddr1.length() > 0)
					{
						sFinal += "\n" + sAddr1;
					}

					if (sAddr2.length() > 0)
					{
						sFinal += "\n" + sAddr2;
					}

					if (sAddr3.length() > 0)
					{
						sFinal += "\n" + sAddr3;
					}

					if (sAddr4.length() > 0)
					{
						sFinal += "\n" + sAddr4;
					}
					
					if (sCity.length() > 0)
					{
						sFinal += "\n" + sCity;
					}
					
					sFinal += "\nCHIPS ID " + sChipId;
					sFinal += "\nABA NO " + sABANo;
					sFinal += "\nDDA NO " + sAccNo;
				}
			}					
			else
			{
				sFinal = swiftid + "\n";
			}
		}
 		
 		//Remove setting of FIELD_ISU_BNK_NAME in getBTBBIC(). Move to getMsgRouteResult()
		//hParseResult.remove(FIELD_ISU_BNK_NAME);
		//hParseResult.put(FIELD_ISU_BNK_NAME, sName);

		while (st.hasMoreTokens())
		{
			sFinal = sFinal + "\n" + st.nextToken();
		}
//	printlog ("getBTBBIC SQL="+sql);
//	printlog ("getBTBBIC swiftid substring ="+swiftid.substring(swiftid.length()-3));
//                printlog ("getBTBBIC sName "+sName );
//                printlog ("getBTBBIC sAddr1"+sAddr1);
//                printlog ("getBTBBIC sAddr2"+sAddr2);
//                printlog ("getBTBBIC sAddr3"+sAddr3);
//                printlog ("getBTBBIC sAddr4"+sAddr4);
//                printlog ("getBTBBIC sFinal="+sFinal);


        }
        catch (Exception ex) {
        	logDebug((Throwable) ex);
		    logDebug("IMParseMappingExtractor.getBTBBIC: "+ex.getMessage());
			throw new Exception(ex.getMessage());
         }
        finally {
            //close(conn);
        }
		
		return sFinal;
	}
    
	private String getBIC_Name(String id) throws Exception {
		String sName="";
		String sDelim = "\n";
		String swiftid="";
		int cnt, bPos;

		StringTokenizer st = new StringTokenizer(id, sDelim);

		cnt = st.countTokens();

	    if (st.hasMoreTokens()) {
	          swiftid = st.nextToken();
			  //swiftid = swiftid.replace('\n', ' ');
	    }

		if (swiftid.indexOf("/") != -1)
		{
			swiftid = st.nextToken();
		}
		if ((bPos = swiftid.indexOf("\r")) != -1)
		{
			swiftid = Left(swiftid, bPos);
		}
		
		//IDataConnection  conn = null;
        try {
        	String sql = "select NAME from GTDMAST1..BIC where SWIFT_ID = '"
				//+ Left(swiftid,8) + swiftid.substring(swiftid.length()-3)+ "'";
        		+ FixQuote1(Left(swiftid,8) + Right(swiftid,3))+ "'";
		
    		logDebug("getBIC_Name SQL : " + sql);
    		
        	//conn=getConnection();
            DataTable rs = conn.executeQuery(sql);
            //close(conn);
            
	 		if (rs.next() == true)
			{
	 			sName = (String)rs.getField("NAME");
				//sName = DuplicateQuote(sName.trim());
				logDebug("getBIC_Name(): getBIC_Name SQL1 rs.next()=true. sName["+sName+"]");
			}
			else
			{	
				sql = "select NAME from GTDMAST1..BIC where SWIFT_ID = '"
						+ FixQuote1(Left(swiftid,8)) + "'";
				//printlog ("getBTBBIC SQL2="+sql);
				logDebug("getBIC_Name SQL2 : " + sql);
				
				//rs = dbAcc.executeSqlSelect(sql);
				//conn=getConnection();
				rs = conn.executeQuery(sql);
				//close(conn);
				
				if (rs.next() == true)
				{
					sName = (String)rs.getField("NAME");
					//sName = DuplicateQuote(sName.trim());
					logDebug("getBIC_Name(): getBIC_Name SQL2 rs.next()=true. sName["+sName+"]");
				}					
				else
				{
					logDebug("getBIC_Name(): getBIC_Name SQL1 and SQL2 no result. sName[]");
					sName="";
				}
			}
 		
        }
        catch (Exception ex) {
        	logDebug((Throwable) ex);
		    logDebug("IMParseMappingExtractor.getBIC_Name(): "+ex.getMessage());
			throw new Exception(ex.getMessage());
         }
        finally {
            //close(conn);
        }
		
		return sName;
	}
	
	private String FixQuote(String str){
		return DuplicateQuote(str);
	}
	
	private String DuplicateQuote(String str) {
		int len = str.length();
		String finalStr = "";
		char c;

		for (int i = 0; i < len; ++i) {
			finalStr += (c = str.charAt(i));
			if (c == '\'')
			{
				finalStr += "'";
			}
			if (c == '\"')
			{
				finalStr += "\"";
			}
		}

		return finalStr;
	}
	
	private String FixQuote1(String str){
		return DuplicateQuote1(str);
	}
	
	private String DuplicateQuote1(String str) {
		
		int len = str.length();
		String finalStr = str;
		char c;
		int iAsc;
		
		long lStartTime, lEndTime, lTimeSpent;
		
		lStartTime = Calendar.getInstance().getTime().getTime();
		    	
		int iPos=0;
		int newlen=len;
		while(iPos<newlen){
			c = finalStr.charAt(iPos);
			if (c == '\'')
			{
				finalStr = finalStr.substring(0, iPos) + "'" + finalStr.substring(iPos);
				newlen=finalStr.length();
				iPos++;
			}
			iPos++;
		}
		
		lEndTime = Calendar.getInstance().getTime().getTime();
    	lTimeSpent=lEndTime-lStartTime;
    	logDebug("DuplicateQuote1: Time Spent: "+lTimeSpent+" ms");
		
		return finalStr;
	}
	
    private String FmtTagContent(String ltagContent, Hashtable hParseResult) throws Exception {
        String sTagNo = null, sTagDesc = null;
        StringBuffer sbTagContent = new StringBuffer();
        String Tag20LnkRef = "";
        String Tag21LnkRef = "";
        String Tag23LnkRef = "";
        int ePos, bPos;
        String MsgTyp=(String)hParseResult.get(FIELD_MSG_TYP);
        String LinkRef="";
        String ExtMsgRef="";
		int count = 0;
		int count2 = 0;
        
        ePos = ltagContent.indexOf(":");
        sTagNo = Left(ltagContent, ePos);
		
		// Search Tag Description
        //IDataConnection  conn = null;
        
        try {
        	
        	String sql = "select TAG_DESC, BIC, CRLF from GTDMAST1..SWIFT_TAG_DESC where MSG_TYP = '"
                + MsgTyp + "' and TAG_NO = '" + sTagNo + "'";
        //logDebug("FmtTagContent SQL : " + sql);
 		
		//conn=getConnection();
        DataTable rs = conn.executeQuery(sql);
        //close(conn);
        //rs = dbAcc.executeSqlSelect(sql);

        if (rs.next() == true) {
        	String lsCRLF=(String)rs.getField("CRLF");
        	String lsBIC=(String)rs.getField("BIC");
        	String lsTAG_DESC=(String)rs.getField("TAG_DESC");
        	
        	if (lsCRLF.trim().equals("Y") && lsBIC.trim().equals("Y")) {
		    	  //printlog ("FmtTagContent YY ePos="+ePos+" ltagContent=["+ltagContent+"]");
		                  sTagDesc = lsTAG_DESC + " :\n";
		                  //ltagContent = sTagDesc + getBIC(ltagContent.substring(ePos+1));
		                  ltagContent = sTagDesc + getBIC(Mid(ltagContent,ePos+1));
		                  //printlog("FmtTagContent YY end");
		    } else if (lsCRLF.trim().equals("Y") && lsBIC.trim().equals("N")) {
		    	  //printlog ("FmtTagContent YN ePos="+ePos+" ltagContent=["+ltagContent+"]");
		                  sTagDesc = lsTAG_DESC + " :\n";
		                  //ltagContent = sTagDesc + ltagContent.substring(ePos+1);
		                  ltagContent = sTagDesc + Mid(ltagContent, ePos+1);
		                  //printlog("FmtTagContent YN end");
		    } else if (lsCRLF.trim().equals("N") && lsBIC.trim().equals("Y")) {
		    	  //printlog ("FmtTagContent NY ePos="+ePos+" ltagContent=["+ltagContent+"]");
                  sTagDesc = lsTAG_DESC + " : ";
                  //ltagContent = sTagDesc + getBIC(ltagContent.substring(ePos+1));
                  ltagContent = sTagDesc + getBIC(Mid(ltagContent,ePos+1));
                  //printlog("FmtTagContent NY end");
            } else if (lsCRLF.trim().equals("N") && lsBIC.trim().equals("N")) {
            	//printlog ("FmtTagContent NN ePos="+ePos+" ltagContent=["+ltagContent+"]");
                  sTagDesc = lsTAG_DESC + " : ";
                  //ltagContent = sTagDesc + ltagContent.substring(ePos+1);
                  ltagContent = sTagDesc + Mid(ltagContent,ePos+1);
                  //printlog("FmtTagContent NN end");
            }      

        } else {
	    	//printlog ("FmtTagContent else start");
			sTagDesc = "(" + sTagNo + "):\n";
			//ltagContent = sTagDesc + ltagContent.substring(ePos+1);
			ltagContent = sTagDesc + Mid(ltagContent,ePos+1);
		                //printlog("FmtTagContent else");
		}


        while ((bPos = ltagContent.indexOf("\n")) != -1) {
        	//printlog ("FmtTagContent bPos="+bPos);
                sbTagContent.append(Left(ltagContent, bPos+1));
                //ltagContent = ltagContent.substring(bPos+1);
                ltagContent = Mid(ltagContent,bPos+1);
        	//printlog ("FmtTagContent bPos="+bPos+" ltagContent=["+ltagContent+"] end");
        }

        sbTagContent.append(ltagContent).append("\n\n");

        //printlog("FmtTagContent end");
	
        }
        catch (Exception ex) {
        	logDebug((Throwable) ex);
		    logDebug("IMParseMappingExtractor.FmtTagContent: "+ex.getMessage());
			throw new Exception(ex.getMessage());
         }
        finally {
            //close(conn);
        }
        
        
        return sbTagContent.toString();
    }
	
    private void SWIFTParseLnkRef(Hashtable hParseResult) throws Exception {
        try{
    	
    	String sTagNo = null;
        String Tag20LnkRef = "";
        String Tag21LnkRef = "";
        String Tag23LnkRef = "";
        int ePos, bPos;
        String MsgTyp=(String)hParseResult.get(FIELD_MSG_TYP);
        String LinkRef="";
        String ExtMsgRef="";
		int count = 0;
		int count2 = 0;
        
		String lswiftText="";
		int iPos;
		String ltagContent="";
        //printlog("WriteMsgText lswiftText=["+lswiftText+"]");
        lswiftText = (String)hParseResult.get(FIELD_MSG_CONTENT);
        //printlog("WriteMsgText lswiftText=["+lswiftText+"]");
        
        if(SWIFTCheckExistTagEnd(lswiftText)){
            logDebug("SWIFTParseLnkRef : SWIFTCheckExistTagEnd true");
        
	        // remove leading brackets & block indicator
	        iPos = lswiftText.indexOf(TAGDELI);
	        //printlog("WriteMsgText iPos="+iPos);
	           
	        //lswiftText = lswiftText.substring(iPos++);
	        lswiftText = Mid(lswiftText,iPos++);
	        //printlog("WriteMsgText lswiftText=["+lswiftText+"]");
	        iPos = 1;
	        // extract Tags content
	        while ((iPos = lswiftText.indexOf(TAGDELI, iPos)) != -1) {
	        	//ltagContent = lswiftText.substring(2, iPos); // keep LF and remove leading ":"
	        	ltagContent = Mid(lswiftText, 2, iPos); // keep LF and remove leading ":"
	        	
	        	ePos = ltagContent.indexOf(":");
	            sTagNo = Left(ltagContent, ePos);
	            if(sTagNo.trim().equals(TAG20)){
	            	//Tag20LnkRef = ltagContent.substring(ePos+1).trim();
	            	Tag20LnkRef = Mid(ltagContent,ePos+1).trim();
	            }
	            else if (sTagNo.trim().equals(TAG21)){
	            	//Tag21LnkRef = ltagContent.substring(ePos+1).trim();
	            	Tag21LnkRef = Mid(ltagContent,ePos+1).trim();
	            }
	            else if (sTagNo.trim().equals(TAG23)){
	            	//Tag23LnkRef = ltagContent.substring(ePos+1).trim();
	            	Tag23LnkRef = Mid(ltagContent,ePos+1).trim();
	            }
	            
	            //lswiftText = lswiftText.substring(iPos);
	            lswiftText = Mid(lswiftText,iPos);
	        	iPos = 1;
	        }
	        // end of block 4 -- process last tag
	        //ltagContent = lswiftText.substring(2, (lswiftText.indexOf(SWIFTEND) -2));
	        ltagContent = Mid(lswiftText, 2, (lswiftText.indexOf(SWIFTEND) -2));
	        ePos = ltagContent.indexOf(":");
	        sTagNo = Left(ltagContent, ePos);
	        if(sTagNo.trim().equals(TAG20)){
	        	//Tag20LnkRef = ltagContent.substring(ePos+1).trim();
	        	Tag20LnkRef = Mid(ltagContent,ePos+1).trim();
	        }
	        else if (sTagNo.trim().equals(TAG21)){
	        	//Tag21LnkRef = ltagContent.substring(ePos+1).trim();
	        	Tag21LnkRef = Mid(ltagContent,ePos+1).trim();
	        }
	        else if (sTagNo.trim().equals(TAG23)){
	        	//Tag23LnkRef = ltagContent.substring(ePos+1).trim();
	        	Tag23LnkRef = Mid(ltagContent,ePos+1).trim();
	        }
	        
	        logDebug("SWIFTParseLnkRef: Tag20LnkRef="+Tag20LnkRef);
	        logDebug("SWIFTParseLnkRef: Tag21LnkRef="+Tag21LnkRef);
	        logDebug("SWIFTParseLnkRef: Tag23LnkRef="+Tag23LnkRef);
	        
			if ((MsgTyp.trim().equals("700")) || (MsgTyp.trim().equals("740")) || (MsgTyp.trim().equals("701")) || (MsgTyp.trim().equals("705")) || (MsgTyp.trim().equals("799")))
			{
				//printlog("FmtTagContent.MsgTyp=700/701/705/799");
				if (!Tag20LnkRef.trim().equals(""))
				{
						LinkRef = DuplicateQuote(Tag20LnkRef);
				}
			}
			else if ((MsgTyp.trim().equals("710")) || (MsgTyp.trim().equals("711")) || (MsgTyp.trim().equals("720")) || (MsgTyp.trim().equals("721")) || (MsgTyp.trim().equals("730")) || (MsgTyp.trim().equals("750")) || (MsgTyp.trim().equals("754")) || (MsgTyp.trim().equals("768")) || (MsgTyp.trim().equals("769")) || (MsgTyp.trim().equals("767")))
			{
				//printlog("FmtTagContent.MsgTyp=710/711/720/721");
				if (!Tag21LnkRef.trim().equals(""))
				{
						LinkRef = DuplicateQuote(Tag21LnkRef);
				}
			}
			else if (MsgTyp.trim().equals("707") || MsgTyp.trim().equals("747") )
			{
				//printlog("FmtTagContent.MsgTyp=707");
				if (!Tag23LnkRef.trim().equals(""))
				{
						//printlog("FmtTagContent: Tag23LnkRef != NULL ");
						LinkRef = DuplicateQuote(Tag23LnkRef);
				}
				else if (!Tag20LnkRef.trim().equals(""))
				{
						//printlog("FmtTagContent: Tag20LnkRef != NULL ");
						LinkRef = DuplicateQuote(Tag20LnkRef);
				}
			}
			
			/* --!! */
			else if (MsgTyp.trim().equals("410") || MsgTyp.trim().equals("742") )
			{
				//printlog("FmtTagContent.MsgTyp=410/412/430");
				if (!Tag21LnkRef.trim().equals(""))
				{
						LinkRef = DuplicateQuote(Tag21LnkRef);
				}
				else if (!Tag20LnkRef.trim().equals(""))
				{
						LinkRef = DuplicateQuote(Tag20LnkRef);
				}
			}
			else if (MsgTyp.trim().equals("400") || MsgTyp.trim().equals("412") || MsgTyp.trim().equals("416"))
			{
				//printlog("FmtTagContent.MsgTyp=410/412/430");
				if (!Tag21LnkRef.trim().equals(""))
				{
						LinkRef = DuplicateQuote(Tag21LnkRef);
				}
				if (!Tag20LnkRef.trim().equals(""))
				{
						ExtMsgRef = DuplicateQuote(Tag20LnkRef);
				}
			}
			else if (MsgTyp.trim().equals("430"))
			{
				//printlog("FmtTagContent.MsgTyp=410/412/430");
				if (!Tag20LnkRef.trim().equals(""))
				{
						//printlog("FmtTagContent: Tag20LnkRef != NULL ");
						if (count<1){
							LinkRef = DuplicateQuote(Tag20LnkRef);
							count=count+1;
						}
				}
			
				else if (!Tag21LnkRef.trim().equals(""))
				{
						//printlog("FmtTagContent: Tag21LnkRef != NULL ");
						if ((count2<1) && (count<1)){
							LinkRef = DuplicateQuote(Tag21LnkRef);
							count2=count2+1;
						}
				}
	
			}			
			//////
			
			else
			{
				//printlog("FmtTagContent.MsgTyp=others");
				if (!Tag20LnkRef.trim().equals(""))
				{
					LinkRef = DuplicateQuote(Tag20LnkRef);
				}
			}
	
			if ( MsgTyp.trim().equals("747"))
	        {       							//printlog("Angus 2");
	
	                ExtMsgRef = DuplicateQuote(Tag21LnkRef);
	
	        }else if (MsgTyp.trim().equals("742") || MsgTyp.trim().equals("740"))
	        {
	                ExtMsgRef = "";
	
	        }
	
			//Special log in swift_in_merva.UpdateDB()
			if (!((MsgTyp.trim().equals("742")) || (MsgTyp.trim().equals("412")) || (MsgTyp.trim().equals("747")) || (MsgTyp.trim().equals("740")) && (hParseResult.get(FIELD_QUEUE_TYP).toString().trim().equals(QUEUE_TYP_SWIFT)))){
		       	//printlog("Angus 3 MsgTyp="+MsgTyp);
				ExtMsgRef = LinkRef;
			}
        }
        else{
        	logDebug("SWIFTParseLnkRef : SWIFTCheckExistTagEnd false");
        	//The default logic from ccs_in.java. LinkRef default APPL_MSG_REF(SendTransID)
        	LinkRef=(String)hParseResult.get(FIELD_APPL_MSG_REF);
        	if (!((MsgTyp.trim().equals("742")) || (MsgTyp.trim().equals("412")) || (MsgTyp.trim().equals("747")) || (MsgTyp.trim().equals("740")) && (hParseResult.get(FIELD_QUEUE_TYP).toString().trim().equals(QUEUE_TYP_SWIFT)))){
		       	//printlog("Angus 3 MsgTyp="+MsgTyp);
				ExtMsgRef = LinkRef;
			}
        }
        
        hParseResult.remove(FIELD_LNK_REF);
		hParseResult.remove(FIELD_EXT_MSG_REF);
		hParseResult.put(FIELD_LNK_REF, LinkRef);
		hParseResult.put(FIELD_EXT_MSG_REF, ExtMsgRef);

		logDebug("SWIFTParseLnkRef: FIELD_LNK_REF="+LinkRef);
		logDebug("SWIFTParseLnkRef: FIELD_EXT_MSG_REF="+ExtMsgRef);
        
        }
        catch(Exception ex){
        	logDebug((Throwable) ex);
		    logDebug("IMParseMappingExtractor.SWIFTParseLnkRef: "+ex.getMessage());
			throw new Exception(ex.getMessage());
        }
    }
    
    private void SWIFTParseTxnAmt(Hashtable hParseResult) throws Exception {
        try{
    		
    	String sTagNo = null;
        String sTag32A = "";
        String sTag32B = "";
        String sTag32K = "";
        String sTag32C = "";
        String sTag32D = "";
        String sTag33A = "";
        String sTag33B = "";
        String sTag33K = "";
        
        int ePos, bPos;
        String sMsgTyp=(String)hParseResult.get(FIELD_MSG_TYP);
        String sMsgCcyCd="";
        String sMsgAmt="0";
		//int count = 0;
		//int count2 = 0;
        
		String lswiftText="";
		int iPos;
		String ltagContent="";
        //printlog("WriteMsgText lswiftText=["+lswiftText+"]");
        lswiftText = (String)hParseResult.get(FIELD_MSG_CONTENT);
        //printlog("WriteMsgText lswiftText=["+lswiftText+"]");
        
        if(SWIFTCheckExistTagEnd(lswiftText)){
            logDebug("SWIFTParseTxnAmt : SWIFTCheckExistTagEnd true");
	        
	        // remove leading brackets & block indicator
	        iPos = lswiftText.indexOf(TAGDELI);
	        //printlog("WriteMsgText iPos="+iPos);
	           
	        //lswiftText = lswiftText.substring(iPos++);
	        lswiftText = Mid(lswiftText,iPos++);
	        //printlog("WriteMsgText lswiftText=["+lswiftText+"]");
	        iPos = 1;
	        // extract Tags content
	        while ((iPos = lswiftText.indexOf(TAGDELI, iPos)) != -1) {
	        	//ltagContent = lswiftText.substring(2, iPos); // keep LF and remove leading ":"
	        	ltagContent = Mid(lswiftText, 2, iPos); // keep LF and remove leading ":"
	        	
	        	ePos = ltagContent.indexOf(":");
	            sTagNo = Left(ltagContent, ePos);
	            if(sTagNo.trim().equals(TAG32A)){
	            	//sTag32A = ltagContent.substring(ePos+1).trim();
	            	sTag32A = Mid(ltagContent,ePos+1).trim();
	            }
	            else if (sTagNo.trim().equals(TAG32B)){
	            	//sTag32B = ltagContent.substring(ePos+1).trim();
	            	sTag32B = Mid(ltagContent,ePos+1).trim();
	            }
	            else if (sTagNo.trim().equals(TAG32K)){
	            	//sTag32K = ltagContent.substring(ePos+1).trim();
	            	sTag32K = Mid(ltagContent,ePos+1).trim();
	            }
	            else if (sTagNo.trim().equals(TAG32C)){
	            	//sTag32C = ltagContent.substring(ePos+1).trim();
	            	sTag32C = Mid(ltagContent,ePos+1).trim();
	            }
	            else if (sTagNo.trim().equals(TAG32D)){
	            	//sTag32D = ltagContent.substring(ePos+1).trim();
	            	sTag32D = Mid(ltagContent,ePos+1).trim();
	            }
	            else if (sTagNo.trim().equals(TAG33A)){
	            	//sTag33A = ltagContent.substring(ePos+1).trim();
	            	sTag33A = Mid(ltagContent,ePos+1).trim();
	            }
	            else if (sTagNo.trim().equals(TAG33B)){
	            	//sTag33B = ltagContent.substring(ePos+1).trim();
	            	sTag33B = Mid(ltagContent,ePos+1).trim();
	            }
	            else if (sTagNo.trim().equals(TAG33K)){
	            	//sTag33K = ltagContent.substring(ePos+1).trim();
	            	sTag33K = Mid(ltagContent,ePos+1).trim();
	            }
	                        
	            //lswiftText = lswiftText.substring(iPos);
	            lswiftText = Mid(lswiftText,iPos);
	        	iPos = 1;
	        }
	        // end of block 4 -- process last tag
	        //ltagContent = lswiftText.substring(2, (lswiftText.indexOf(SWIFTEND) -2));
	        ltagContent = Mid(lswiftText, 2, (lswiftText.indexOf(SWIFTEND) -2));
	        ePos = ltagContent.indexOf(":");
	        sTagNo = Left(ltagContent, ePos);
	        if(sTagNo.trim().equals(TAG32A)){
	        	//sTag32A = ltagContent.substring(ePos+1).trim();
	        	sTag32A = Mid(ltagContent,ePos+1).trim();
	        }
	        else if (sTagNo.trim().equals(TAG32B)){
	        	//sTag32B = ltagContent.substring(ePos+1).trim();
	        	sTag32B = Mid(ltagContent,ePos+1).trim();
	        }
	        else if (sTagNo.trim().equals(TAG32K)){
	        	//sTag32K = ltagContent.substring(ePos+1).trim();
	        	sTag32K = Mid(ltagContent,ePos+1).trim();
	        }
	        else if (sTagNo.trim().equals(TAG32C)){
	        	//sTag32C = ltagContent.substring(ePos+1).trim();
	        	sTag32C = Mid(ltagContent,ePos+1).trim();
	        }
	        else if (sTagNo.trim().equals(TAG32D)){
	        	//sTag32D = ltagContent.substring(ePos+1).trim();
	        	sTag32D = Mid(ltagContent,ePos+1).trim();
	        }
	        else if (sTagNo.trim().equals(TAG33A)){
	        	//sTag33A = ltagContent.substring(ePos+1).trim();
	        	sTag33A = Mid(ltagContent,ePos+1).trim();
	        }
	        else if (sTagNo.trim().equals(TAG33B)){
	        	//sTag33B = ltagContent.substring(ePos+1).trim();
	        	sTag33B = Mid(ltagContent,ePos+1).trim();
	        }
	        else if (sTagNo.trim().equals(TAG33K)){
	        	//sTag33K = ltagContent.substring(ePos+1).trim();
	        	sTag33K = Mid(ltagContent,ePos+1).trim();
	        }
	        
	        logDebug("SWIFTParseTxnAmt: sTag32A=["+sTag32A+"]");
	        logDebug("SWIFTParseTxnAmt: sTag32B=["+sTag32B+"]");
	        logDebug("SWIFTParseTxnAmt: sTag32K=["+sTag32K+"]");
	        logDebug("SWIFTParseTxnAmt: sTag32C=["+sTag32C+"]");
	        logDebug("SWIFTParseTxnAmt: sTag32D=["+sTag32D+"]");
	        logDebug("SWIFTParseTxnAmt: sTag33A=["+sTag33A+"]");
	        logDebug("SWIFTParseTxnAmt: sTag33B=["+sTag33B+"]");
	        logDebug("SWIFTParseTxnAmt: sTag33K=["+sTag33K+"]");
	        
	        if(sMsgTyp.trim().equals("400")||sMsgTyp.trim().equals("416")||sMsgTyp.trim().equals("420")||sMsgTyp.trim().equals("422")){
	        	if(!sTag32A.trim().equals("")){
	            	sMsgCcyCd=Mid(sTag32A.trim(),6,9);
	            	sMsgAmt=Mid(sTag32A.trim(),9);
	            	sMsgAmt=sMsgAmt.replace(',', '.');
	            }
	            else if(!sTag32B.trim().equals("")){
	            	sMsgCcyCd=Left(sTag32B.trim(),3);
	            	sMsgAmt=Mid(sTag32B.trim(),3);
	            	sMsgAmt=sMsgAmt.replace(',', '.');
	            }
	            else if(!sTag32K.trim().equals("")){
	            	sMsgCcyCd=Mid(sTag32K.trim(),6,9);
	            	sMsgAmt=Mid(sTag32K.trim(),9);
	            	sMsgAmt=sMsgAmt.replace(',', '.');
	            }
	        }
	        //QC#27172: GWF: Message Queue: transaction amount mapping update
	        else if(sMsgTyp.trim().equals("410")){
	        	if(!sTag32A.trim().equals("")){
	            	sMsgCcyCd=Mid(sTag32A.trim(),6,9);
	            	sMsgAmt=Mid(sTag32A.trim(),9);
	            	sMsgAmt=sMsgAmt.replace(',', '.');
	            }
	            else if(!sTag32B.trim().equals("")){
	            	sMsgCcyCd=Left(sTag32B.trim(),3);
	            	sMsgAmt=Mid(sTag32B.trim(),3);
	            	sMsgAmt=sMsgAmt.replace(',', '.');
	            }
	            else if(!sTag32K.trim().equals("")){
	            	sMsgCcyCd=Mid(sTag32K.trim(),6,9);
	            	sMsgAmt=Mid(sTag32K.trim(),9);
	            	sMsgAmt=sMsgAmt.replace(',', '.');
	            }
	        }
	        else if(sMsgTyp.trim().equals("412")||sMsgTyp.trim().equals("734")){
	        	if(!sTag32A.trim().equals("")){
	            	sMsgCcyCd=Mid(sTag32A.trim(),6,9);
	            	sMsgAmt=Mid(sTag32A.trim(),9);
	            	sMsgAmt=sMsgAmt.replace(',', '.');
	            }
	        }
	        else if(sMsgTyp.trim().equals("430")){
	        	if(!sTag33A.trim().equals("")){
	            	sMsgCcyCd=Mid(sTag33A.trim(),6,9);
	            	sMsgAmt=Mid(sTag33A.trim(),9);
	            	sMsgAmt=sMsgAmt.replace(',', '.');
	            }
	            else if(!sTag33K.trim().equals("")){
	            	sMsgCcyCd=Mid(sTag33K.trim(),6,9);
	            	sMsgAmt=Mid(sTag33K.trim(),9);
	            	sMsgAmt=sMsgAmt.replace(',', '.');
	            }
	        }
	        else if(sMsgTyp.trim().equals("700")||sMsgTyp.trim().equals("705")||sMsgTyp.trim().equals("710")||sMsgTyp.trim().equals("720")||sMsgTyp.trim().equals("732")
	        			||sMsgTyp.trim().equals("740")||sMsgTyp.trim().equals("742")||sMsgTyp.trim().equals("750")||sMsgTyp.trim().equals("752")||sMsgTyp.trim().equals("756")||sMsgTyp.trim().equals("791")){
	        	if(!sTag32B.trim().equals("")){
	            	sMsgCcyCd=Left(sTag32B.trim(),3);
	            	sMsgAmt=Mid(sTag32B.trim(),3);
	            	sMsgAmt=sMsgAmt.replace(',', '.');
	            }
	        }
	        else if(sMsgTyp.trim().equals("707")||sMsgTyp.trim().equals("747")){
	        	if(!sTag32B.trim().equals("")){
	            	sMsgCcyCd=Left(sTag32B.trim(),3);
	            	sMsgAmt=Mid(sTag32B.trim(),3);
	            	sMsgAmt=sMsgAmt.replace(',', '.');
	            }
	        	else if(!sTag33B.trim().equals("")){
	            	sMsgCcyCd=Left(sTag33B.trim(),3);
	            	sMsgAmt=Mid(sTag33B.trim(),3);
	            	sMsgAmt=sMsgAmt.replace(',', '.');
	            }
	        }
	        else if(sMsgTyp.trim().equals("730")){
	        	if(!sTag32B.trim().equals("")){
	            	sMsgCcyCd=Left(sTag32B.trim(),3);
	            	sMsgAmt=Mid(sTag32B.trim(),3);
	            	sMsgAmt=sMsgAmt.replace(',', '.');
	            }
	        	else if(!sTag32D.trim().equals("")){
	            	sMsgCcyCd=Mid(sTag32D.trim(),6,9);
	            	sMsgAmt=Mid(sTag32D.trim(),9);
	            	sMsgAmt=sMsgAmt.replace(',', '.');
	            }
	        }
	        else if(sMsgTyp.trim().equals("754")){
	        	if(!sTag32A.trim().equals("")){
	            	sMsgCcyCd=Mid(sTag32A.trim(),6,9);
	            	sMsgAmt=Mid(sTag32A.trim(),9);
	            	sMsgAmt=sMsgAmt.replace(',', '.');
	            }
	            else if(!sTag32B.trim().equals("")){
	            	sMsgCcyCd=Left(sTag32B.trim(),3);
	            	sMsgAmt=Mid(sTag32B.trim(),3);
	            	sMsgAmt=sMsgAmt.replace(',', '.');
	            }
	        }
	        else if(sMsgTyp.trim().equals("790")){
	        	if(!sTag32C.trim().equals("")){
	            	sMsgCcyCd=Mid(sTag32C.trim(),6,9);
	            	sMsgAmt=Mid(sTag32C.trim(),9);
	            	sMsgAmt=sMsgAmt.replace(',', '.');
	            }
	            else if(!sTag32D.trim().equals("")){
	            	sMsgCcyCd=Mid(sTag32D.trim(),6,9);
	            	sMsgAmt=Mid(sTag32D.trim(),9);
	            	sMsgAmt=sMsgAmt.replace(',', '.');
	            }
	        }
        
        }else
        	logDebug("SWIFTParseTxnAmt : SWIFTCheckExistTagEnd false");
        
        logDebug("sMsgCcyCd=["+sMsgCcyCd+"]");
        logDebug("sMsgAmt=["+sMsgAmt+"]");
        
        hParseResult.remove(FIELD_MSG_CCY_CD);
        hParseResult.remove(FIELD_MSG_AMT);
		hParseResult.put(FIELD_MSG_CCY_CD, sMsgCcyCd);
		hParseResult.put(FIELD_MSG_AMT, sMsgAmt);
		
        }
        catch(Exception ex){
        	logDebug((Throwable) ex);
		    logDebug("IMParseMappingExtractor.SWIFTParseTxnAmt: "+ex.getMessage());
			throw new Exception(ex.getMessage());
        }
    }
	
    /**
     * Parse the xml messages and build the dataset from it
     * @param rawData the raw xml messages date table
     * @param batch current mappingbatch
     * @throws ExtractorException
     * @return
     */
   
    public DataSet parseIMBatch(DataTable rawData, MappingBatch batch) throws ExtractorException  {
        
    	logDebug("*******Parse IM Batch********");

	    DataSet dataSet=new DataSet();
	    //String tranTyp="";
	    String sProcUnit="";
	    String sMsgTyp="";
	    String sQueueTyp="";
	    //Integer iQueueID=new Integer(0);
	    int iQueueID=0;
	    int iParentQueueID=0;
	    String sMsgText="";
	    String sMsgHeader="";
	    String sMsgTranslated="";
	    //String sMsgContent="";
	    String sSendRecvAddr="";
	    String sApplMsgRef="";
	    java.util.Date dRecvDt=new java.util.Date();
	    String sLnkRef="";
	    int iLnkMsgSeq=0;
	    int iLnkMsgTotal=0;
	    String sExtMsgRef="";
	    String sRepairInd="";
	    String sRouteProdTyp="";
	    String sRouteLocationCd="";
	    String sRouteExtRefNbr="";
	    String sCustNm="";
	    String sMsgCcyCd="";
	    String sMsgAmt="0";
	    String sProdCat="";
	    String sProdTyp="";
	    String sTranTyp="";
	    long liAudID=0;
	    String sProcessorID=batch.getProcessorID();
	    Timestamp tBatchID=batch.getBatchID();
	    	    
	    //Comment connection object of parseIMBatch()
	    //IDataConnection  conn = null;
	    CallableStatement stmt = null;
	    String lsSql="";
	    
	    try{
	    	logDebug("parseIMBatch(): conn=getConnection()");
	    	conn=getConnection();
	    	
	        rawData.BOF();
	        
	        //createAllDataTableSchema(dataSet);
	 
	        while(rawData.next()) {
	        	
	        	//Test 2 begin tran still lock
	        	//conn=getConnection();
	        	//Hunter0620
	        	//lsSql="begin tran TRAN_IMPARSE_"+batch.getProcessorID();
	        	//logDebug("parseIMBatch(): "+lsSql);
		    	//stmt = conn.prepareCall(lsSql);
		        //stmt.executeUpdate();
		        //close(conn);
		        
		        Hashtable hParseResult=new Hashtable();
	        	
	        	//tranTyp = (String)rawData.getField(FIELD_TRAN_TYP);
	        	//logDebug(" tranTyp: "+ tranTyp);	 
	        	sProcUnit=(String)rawData.getField(FIELD_PROC_UNIT);
	        	sMsgTyp= (String)rawData.getField(FIELD_MSG_TYP);
		        sQueueTyp = (String)rawData.getField(FIELD_QUEUE_TYP);
		        iQueueID= Integer.parseInt(rawData.getField(FIELD_QUEUE_ID).toString());
		        iParentQueueID = iQueueID;
		        
		        //sMsgContent=(String)rawData.getField(FIELD_MSG_CONTENT);
		        //GWF: TLX parse with SI_MSG.MSG_TEXT, SWF parse with SI_MSG.MSG_CONTENT
		        if (sQueueTyp.trim().equals(QUEUE_TYP_TELEX))
		        	sMsgText=(String)rawData.getField(FIELD_MSG_TEXT);
		        else	//SWF/GTI
		        	sMsgText=(String)rawData.getField(FIELD_MSG_CONTENT);
		        
		        sMsgTranslated=(String)rawData.getField(FIELD_MSG_TEXT);
		        sSendRecvAddr=(String)rawData.getField(FIELD_SEND_RECV_ADDR);
		        sApplMsgRef=(String)rawData.getField(FIELD_APPL_MSG_REF);
		        dRecvDt=(java.util.Date)rawData.getField(FIELD_RECV_DT);
		        sLnkRef=(String)rawData.getField(FIELD_LNK_REF);
			    iLnkMsgSeq=Integer.parseInt(rawData.getField(FIELD_LNK_MSG_SEQ).toString());
			    iLnkMsgTotal=Integer.parseInt(rawData.getField(FIELD_LNK_MSG_TOTAL).toString());
			    sExtMsgRef=(String)rawData.getField(FIELD_EXT_MSG_REF);
			    sRepairInd=(String)rawData.getField(FIELD_REPAIR_IND);
			    sRouteProdTyp=(String)rawData.getField(FIELD_ROUTE_PROD_TYP);
			    sRouteLocationCd=(String)rawData.getField(FIELD_ROUTE_LOCATION_CD);
			    sCustNm=(String)rawData.getField(FIELD_CUST_NM);
			    sRouteExtRefNbr=(String)rawData.getField(FIELD_EXT_REF_NBR);
			    sMsgCcyCd=(String)rawData.getField(FIELD_MSG_CCY_CD);
			    sMsgAmt=(String)rawData.getField(FIELD_MSG_AMT).toString();	    
			    sProdCat=(String)rawData.getField(FIELD_PROD_CAT).toString();
			    sProdTyp=(String)rawData.getField(FIELD_PROD_TYP).toString();
			    sTranTyp=(String)rawData.getField(FIELD_TRAN_TYP).toString();
			    sMsgHeader=(String)rawData.getField(FIELD_MSG_HEADER).toString();
			    
			    logDebug(FIELD_PROCESSOR_ID +" : "+ sProcessorID);
			    logDebug(FIELD_BATCH_ID +" : "+ tBatchID);
			    logDebug(FIELD_PROC_UNIT +" : "+ sProcUnit);
		        logDebug(FIELD_MSG_TYP +" : "+ sMsgTyp);
		        logDebug(FIELD_QUEUE_TYP +" : "+ sQueueTyp);
		        logDebug(FIELD_QUEUE_ID +" : "+ iQueueID);
		        //logDebug(FIELD_MSG_CONTENT +" : "+ sMsgText);
		        //logDebug(FIELD_MSG_TEXT +" : "+ sMsgText);
		        logDebug(FIELD_SEND_RECV_ADDR +" : "+ sSendRecvAddr);
		        logDebug(FIELD_APPL_MSG_REF +" : "+ sApplMsgRef);
		        logDebug(FIELD_RECV_DT +" : "+ dRecvDt);
		        logDebug(FIELD_ROUTE_PROD_TYP +" : "+ sRouteProdTyp);
		        logDebug(FIELD_ROUTE_LOCATION_CD +" : "+ sRouteLocationCd);
		        logDebug(FIELD_CUST_NM +" : "+ sCustNm);
		        logDebug(FIELD_ROUTE_EXT_REF_NBR +" : "+ sRouteExtRefNbr);
		        logDebug(FIELD_MSG_CCY_CD +" : "+ sMsgCcyCd);
		        logDebug(FIELD_MSG_AMT +" : "+ sMsgAmt);
		        logDebug(FIELD_PROD_CAT +" : "+ sProdCat);
		        logDebug(FIELD_PROD_TYP +" : "+ sProdTyp);
		        logDebug(FIELD_TRAN_TYP +" : "+ sTranTyp);
		        logDebug(FIELD_MSG_HEADER +" : "+ sMsgHeader);
		        
		        hParseResult.put(FIELD_PROCESSOR_ID, sProcessorID);
		        hParseResult.put(FIELD_BATCH_ID, tBatchID);
		        hParseResult.put(FIELD_PROC_UNIT, sProcUnit);
		        hParseResult.put(FIELD_MSG_TYP, sMsgTyp);
		        hParseResult.put(FIELD_QUEUE_TYP, sQueueTyp);
		        hParseResult.put(FIELD_QUEUE_ID, new Integer(iQueueID));
		        hParseResult.put(FIELD_MSG_CONTENT, sMsgText);
		        //hParseResult.put(FIELD_MSG_TEXT, sMsgText);
		        hParseResult.put(FIELD_SEND_RECV_ADDR, sSendRecvAddr);
		        hParseResult.put(FIELD_APPL_MSG_REF, sApplMsgRef);
		        hParseResult.put(FIELD_RECV_DT, dRecvDt);
		        hParseResult.put(FIELD_LNK_REF, sLnkRef);
		        hParseResult.put(FIELD_LNK_MSG_SEQ, new Integer(iLnkMsgSeq));
		        hParseResult.put(FIELD_LNK_MSG_TOTAL, new Integer(iLnkMsgTotal));
		        hParseResult.put(FIELD_EXT_MSG_REF, sExtMsgRef);
		        hParseResult.put(FIELD_REPAIR_IND, sRepairInd);
		        hParseResult.put(FIELD_ROUTE_PROD_TYP, sRouteProdTyp);
	            hParseResult.put(FIELD_ROUTE_LOCATION_CD, sRouteLocationCd);
	            hParseResult.put(FIELD_CUST_NM, sCustNm);
	            hParseResult.put(FIELD_ROUTE_EXT_REF_NBR, sRouteExtRefNbr);
	            hParseResult.put(FIELD_MSG_CCY_CD, sMsgCcyCd);
		        hParseResult.put(FIELD_MSG_AMT, sMsgAmt);
		        hParseResult.put(FIELD_PROD_CAT, sProdCat);
		        hParseResult.put(FIELD_PROD_TYP, sProdTyp);
		        hParseResult.put(FIELD_TRAN_TYP, sTranTyp);
		        hParseResult.put(FIELD_MSG_HEADER, sMsgHeader);
		        
		        //Put Default Parsing Result
		        //Boolean bErrTextFmt=new Boolean(false);
		        //hParseResult.put(FIELD_ERR_TEXT_FMT, bErrTextFmt);
		        
		        // Default Message Translated format
		        hParseResult.put(FIELD_MSG_TEXT, sMsgTranslated);
		        hParseResult.put(FIELD_DUPLICATE_IND, "");
		        hParseResult.put(FIELD_NEED_GROUPING, "");
		        hParseResult.put(FIELD_GROUP_COMPLETE, "");
		        hParseResult.put(FIELD_PARENT_QUEUE_ID, new Integer(iQueueID));
		        hParseResult.put(FIELD_OFAC_IND, "");
		        hParseResult.put(FIELD_QUEUE_STATUS, "");
		        hParseResult.put(FIELD_ISU_BNK_NAME, "");

		        //Get AUD_ID before Begin tran
		        liAudID=GetAudID(sProcUnit);
		        hParseResult.put(FIELD_AUD_ID, new Long(liAudID));
		        
		        try{			        
			        if (sRepairInd.trim().equals("Y")){
			        	logDebug("parseIMBatch: Message Repaired. Skip Parsing");
			        }
			        else{
			        	if (sQueueTyp.trim().equals(QUEUE_TYP_SWIFT)){
			        		logDebug("parseIMBatch: call SWIFTParseMsg()");
			        		SWIFTParseMsg(hParseResult);
			        	}else if (sQueueTyp.trim().equals(QUEUE_TYP_TELEX)){
			        		logDebug("parseIMBatch: call TELEXParseMsg()");
			        		TELEXParseMsg(hParseResult);
			        	}else if (sQueueTyp.trim().equals(QUEUE_TYP_GTI)){
			        		logDebug("parseIMBatch: call GTIParseMsg()");
			        		GTIParseMsg(hParseResult);
			        	}else{
			        		logDebug("Other Queue Type. Skip Parsing");
			        	}
			        }
			        
			        if (sQueueTyp.trim().equals(QUEUE_TYP_SWIFT)){
			        	if (sMsgTranslated.trim().equals("")){
				        	String sConfigVal=getPUConfig(sProcUnit, "SWF_TRANSFORM_READABLE_MHS");
							
							if (sConfigVal.trim().equals("Y")){
								logDebug("parseIMBatch: Start Transform Readable Format (SWIFTTransformReadableMHS)");
								SWIFTTransformReadableMHS(hParseResult);
							}else{
								logDebug("parseIMBatch: Start Transform Readable Format (SWIFTTransformReadable)");
								SWIFTTransformReadable(hParseResult);
							}
			        	}else{
			        		logDebug("parseIMBatch: MSG_TEXT is initialized. Skip Transform Readable Fromat");
			        	}
			        }
			        else{
			        	logDebug("parseIMBatch: Message not SWIFT. Skip Transform Readable Format");
			        }
			        
			        logDebug("parseIMBatch(): Start checkDuplication()");
			        if(checkDuplication(hParseResult)){
			        	logDebug("Msg Duplicated. To set QUEUE_STATUS=E");
			        }else{
			        	logDebug("parseIMBatch(): Start checkGrouping()");
				        if(checkGrouping(hParseResult)){
				        	logDebug("Check Grouping Completes");
			        	}else{
				        	logDebug("Check Grouping Incompletes");
				        }
			        }
			        
			        iParentQueueID=((Integer)hParseResult.get(FIELD_PARENT_QUEUE_ID)).intValue();
			        
			        //20080628: Skip begin tran and rollback tran
			        //lsSql="begin tran TRAN_IMPARSE_"+batch.getProcessorID();
		        	//logDebug("parseIMBatch(): "+lsSql);
			    	//stmt = conn.prepareCall(lsSql);
			        //stmt.executeUpdate();
			        
			        //logDebug("parseIMBatch(): Start commitParseResult()");
			        //commitParseResult(hParseResult);
			        
			        Hashtable hParentResult=new Hashtable();
			        hParentResult.put(FIELD_PROC_UNIT, sProcUnit);
			        hParentResult.put(FIELD_QUEUE_TYP, sQueueTyp);
			        hParentResult.put(FIELD_QUEUE_ID, new Integer(iParentQueueID));
			        hParentResult.put(FIELD_MSG_TYP, sMsgTyp);
		        	hParentResult.put(FIELD_MSG_TEXT,"");
		        	hParentResult.put(FIELD_NEED_TRANSFORM_SYSFMT, "");
		        	hParentResult.put(FIELD_TRANSFORM_SYSFMT_SUCCESS, "N");
		        	hParentResult.put(FIELD_ACTION_TYP, "");
		        	hParentResult.put(FIELD_OFAC_IND, "");
		        	hParentResult.put(FIELD_AUD_ID, new Long(liAudID));
		        	hParentResult.put(FIELD_PROCESSOR_ID,sProcessorID);
		        	hParentResult.put(FIELD_BATCH_ID,tBatchID);
		        	hParentResult.put(FIELD_COMPLETE_PARENT_PROCESS, "N");
	
		        	String lsGroupComplete=(String)hParseResult.get(FIELD_GROUP_COMPLETE);
			        String lsDuplicateInd=(String)hParseResult.get(FIELD_DUPLICATE_IND);
			        
			        if(lsDuplicateInd.trim().equals("N") && lsGroupComplete.trim().equals("Y")){
			        	
			        	if(!GetParentMsg(hParseResult, hParentResult)){
			        		logDebug("parseIMBatch(): GetParentMsg Failed");
			        		throw new Exception("parseIMBatch(): Cannot select Parent Message");
			        	}
			        	
			        	if(TransformSystemFmt(hParentResult)){
			        		logDebug("parseIMBatch(): TransformSystemFmt Success");
			        		
			        		if(checkNeedOFAC(hParentResult)){
				        		logDebug("parseIMBatch(): Need OFAC");
				        	}else{
				        		logDebug("parseIMBatch(): No Need OFAC");
				        	}
			        		
			        		//Mark Parent Process Complete
			        		hParentResult.remove(FIELD_COMPLETE_PARENT_PROCESS);
			        		hParentResult.put(FIELD_COMPLETE_PARENT_PROCESS, "Y");
			        		
		        		}else{
		        			logDebug("parseIMBatch(): TransformSystemFmt Failed");
		        			throw new Exception("parseIMBatch(): TransformSystemFmt Failed");
		        			//Sql  =  "USP_CUPD_SIMSGQ_STAT '";
		        		}
			        	
			        	//logDebug("parseIMBatch(): Before commitParentResult");
			        	//commitParentResult(hParentResult);
			        	
			        }
		        
			        //logDebug("call commitSiMsgQ_P2T():");
			        //commitSiMsgQ_P2T(sProcUnit, sQueueTyp, iParentQueueID, liAudID);
			        
			        logDebug("parseIMBath(): call commitResult():");
			        commitResult(hParseResult, hParentResult);
			        
			        //conn=getConnection();
			        //20080628: Skip begin tran and rollback tran
			        //lsSql="commit tran TRAN_IMPARSE_"+batch.getProcessorID();
		        	//logDebug("parseIMBatch(): "+lsSql);
			    	//stmt = conn.prepareCall(lsSql);
			        //stmt.executeUpdate();
			        //close(conn);
			        
			        
		        }catch(Exception e){
		        	logDebug(e.getMessage());
		        	logDebug("parseIMBatch(): Catch Exception in Batch while loop. Start exception handling");
		            try{
			        	
		            	/*
		            	String r1=""; String r2=""; String r3="";
		            	DataTable dt1;
		            	r1=""; r2=""; r3="";
		            	//conn=getConnection();
		            	lsSql="select QUEUE_STATUS, EXT_REF, ROUTE_PROD_TYP from GTDPEND1..SI_MSG_Q ";
		            	lsSql += "where INTF_PROC_UNIT='"+sProcUnit+"' and QUEUE_TYP='"+sQueueTyp+"' and QUEUE_ID="+iParentQueueID+" ";
		            	logDebug("Before Rollback: lsSql:"+lsSql);
		            	dt1=conn.executeQuery(lsSql);
		            	//close(conn);
		            	dt1.next();
		            	r1=(String)dt1.getField("QUEUE_STATUS");
		            	r2=(String)dt1.getField("EXT_REF");
		            	r2=r2.trim();
		            	r3=(String)dt1.getField("ROUTE_PROD_TYP");
		            	logDebug("Before Rollback : Result :"+r1+", "+r2+", "+r3);
		            	
		            	
		            	int tc1=-1;
		            	//conn=getConnection();
		            	lsSql="select @@trancount TRANCOUNT";
		            	//logDebug("Hunter0115: Before Rollback: Sql:"+lsSql);
		            	dt1=conn.executeQuery(lsSql);
		            	//close(conn);
		            	dt1.next();
		            	tc1=Integer.parseInt(dt1.getField("TRANCOUNT").toString());
		            	logDebug("Before Rollback: TRANCOUNT:"+tc1);
		            	
		            	//conn=getConnection();
		            	//20080628: Skip begin tran and rollback tran
		            	//lsSql="rollback tran TRAN_IMPARSE_"+batch.getProcessorID();
			        	//logDebug("parseIMBatch(): "+lsSql);
				    	//stmt = conn.prepareCall(lsSql);
				        //stmt.executeUpdate();
				        //close(conn);
				        
				        r1=""; r2=""; r3="";
		            	//conn=getConnection();
		            	lsSql="select QUEUE_STATUS, EXT_REF, ROUTE_PROD_TYP from GTDPEND1..SI_MSG_Q ";
		            	lsSql += "where INTF_PROC_UNIT='"+sProcUnit+"' and QUEUE_TYP='"+sQueueTyp+"' and QUEUE_ID="+iParentQueueID+" ";
		            	logDebug("After Rollback: lsSql:"+lsSql);
		            	dt1=conn.executeQuery(lsSql);
		            	//close(conn);
		            	dt1.next();
		            	r1=(String)dt1.getField("QUEUE_STATUS");
		            	r2=(String)dt1.getField("EXT_REF");
		            	r2=r2.trim();
		            	r3=(String)dt1.getField("ROUTE_PROD_TYP");
		            	logDebug("After Rollback : Result :"+r1+", "+r2+", "+r3);
				        
		            	//conn=getConnection();
		            	lsSql="select @@trancount TRANCOUNT";
		            	//logDebug("Hunter0115: After Rollback: Sql:"+lsSql);
		            	dt1=conn.executeQuery(lsSql);
		            	//close(conn);
		            	dt1.next();
		            	tc1=Integer.parseInt(dt1.getField("TRANCOUNT").toString());
		            	logDebug("After Rollback: TRANCOUNT:"+tc1);
		            	
		            	*/
		            	
				        logDebug("Error in extraction PROC_UNIT = "+sProcUnit+", QUEUE_TYP = "+sQueueTyp+", QUEUE_ID = "+iQueueID+", To exec updSi_Msg_Q");
				        updSi_Msg_Q(sProcUnit, sQueueTyp, iQueueID, _ExtractErrCode, "Error: "+e.getMessage(), liAudID);
				        
		            }catch(Exception e1){
	                	logDebug("parseIMBatch(): rollback tran failed");
	                	throw new Exception("parseIMBatch(): rollback tran failed. Exception:"+e1.getMessage());
		            }
	            }
	        }   //while(rawData.next())     
        
	    }catch(Exception e) {
            logDebug("parseIMBatch() Exception Start");
            logDebug((Throwable) e);
            
            //logDebug("Error in extraction PROC_UNIT = "+sProcUnit+", QUEUE_TYP = "+sQueueTyp+", QUEUE_ID = "+iQueueID+", To exec handleDataPrepError");
            //handleDataPrepError(sProcUnit, sQueueTyp, iQueueID, e.getMessage(),rawData);
            
            throw (new ExtractorException(e.getMessage()) );
        
	    }finally {
			if (stmt != null) {
				try{
					stmt.close();
				} catch (SQLException e) {
					com.chase.infra.util.LogWrapper.instance.logDebug("IMParseMappingExtractor.SWIFTUpdMsgNbr failed to close PreparedStatement");
					e.printStackTrace();
				}
			}
//			Close connection at end of parseIMBatch()
	    	logDebug("parseIMBatch(): close(conn)");
	    	close(conn);
		}

        return  dataSet;
        
    }
    
private boolean checkDuplication(Hashtable hParseResult) throws Exception {
		
		String lsDuplicateInd;
		boolean lbduplicated=false;
		
		//IDataConnection  conn = null;
        try {
        	String p1=(String)hParseResult.get(FIELD_PROC_UNIT);
            String p2=(String)hParseResult.get(FIELD_QUEUE_TYP);
            Integer p3=(Integer)hParseResult.get(FIELD_QUEUE_ID);
            String p4=(String)hParseResult.get(FIELD_MSG_TYP);
            String p5=(String)hParseResult.get(FIELD_LNK_REF);
            Integer p6=(Integer)hParseResult.get(FIELD_LNK_MSG_SEQ);
            Integer p7=(Integer)hParseResult.get(FIELD_LNK_MSG_TOTAL);
            String p8=(String)hParseResult.get(FIELD_SEND_RECV_ADDR);
            String p9=(String)hParseResult.get(FIELD_APPL_MSG_REF);
 
            Hashtable params = new Hashtable();
            params.put(FIELD_PROC_UNIT, p1);
            params.put(FIELD_QUEUE_TYP, p2);
            params.put(FIELD_QUEUE_ID, p3);
            params.put(FIELD_MSG_TYP, p4);
            params.put(FIELD_LNK_REF, p5);
            params.put(FIELD_LNK_MSG_SEQ, p6);
            params.put(FIELD_LNK_MSG_TOTAL, p7);
            params.put(FIELD_SEND_RECV_ADDR, p8);
            params.put(FIELD_CORRE_ID, p9);
 
            logDebug("checkDuplication() sql : "+_sCheckDuplication+" ("+p1+"|"+p2+"|"+ p3+"|"+p4+"|"+ p5+"|"+p6+"|"+p7+"|"+p8+"|"+p9+")");
            
            //conn=getConnection();
            DataTable dt= conn.executeQuery(_sCheckDuplication,params );
            //close(conn);
            dt.next();
            
            lsDuplicateInd = (String)dt.getField(FIELD_DUPLICATE_IND);
            if(lsDuplicateInd.trim().equals("Y"))
            	lbduplicated=true;
            
            hParseResult.remove(FIELD_DUPLICATE_IND);
            hParseResult.put(FIELD_DUPLICATE_IND, lsDuplicateInd);
                        
            logDebug("checkDuplication(): lsDuplicateInd = " + lsDuplicateInd ) ;
        
        }
        catch (Exception ex) {
            logDebug((Throwable) ex);
		    logDebug("IMParseMappingExtractor.checkDuplication: "+ex.getMessage());
			throw new Exception(ex.getMessage());
        }
        finally {
            //close(conn);
        }
        
        return lbduplicated;
	}
    
	private boolean checkGrouping(Hashtable hParseResult) throws Exception {
		
		String lsNeedGrouping;
		String lsGroupComplete;
		int liParentQueueID;
		boolean lbGroupComplete=false;
		
		//IDataConnection  conn = null;
        try {
        	String p1=(String)hParseResult.get(FIELD_PROC_UNIT);
            String p2=(String)hParseResult.get(FIELD_QUEUE_TYP);
            Integer p3=(Integer)hParseResult.get(FIELD_QUEUE_ID);
            String p4=(String)hParseResult.get(FIELD_MSG_TYP);
            String p5=(String)hParseResult.get(FIELD_LNK_REF);
            Integer p6=(Integer)hParseResult.get(FIELD_LNK_MSG_SEQ);
            Integer p7=(Integer)hParseResult.get(FIELD_LNK_MSG_TOTAL);
            String p8=(String)hParseResult.get(FIELD_SEND_RECV_ADDR);
            String p9=(String)hParseResult.get(FIELD_PROCESSOR_ID);
            Timestamp p10=(Timestamp)hParseResult.get(FIELD_BATCH_ID);
             
            Hashtable params = new Hashtable();
            params.put(FIELD_PROC_UNIT, p1);
            params.put(FIELD_QUEUE_TYP, p2);
            params.put(FIELD_QUEUE_ID, p3);
            params.put(FIELD_MSG_TYP, p4);
            params.put(FIELD_LNK_REF, p5);
            params.put(FIELD_LNK_MSG_SEQ, p6);
            params.put(FIELD_LNK_MSG_TOTAL, p7);
            params.put(FIELD_SEND_RECV_ADDR, p8);
            params.put(FIELD_PROCESSOR_ID, p9);
            params.put(FIELD_BATCH_ID, p10);
             
            logDebug("checkGrouping() sql : "+_sCheckGrouping+" ("+p1+"|"+p2+"|"+ p3+"|"+p4+"|"+ p5+"|"+p6+"|"+p7+"|"+p8+"|"+p9+"|"+p10+")");
            
            //conn=getConnection();
            DataTable dt= conn.executeQuery(_sCheckGrouping,params );
            //close(conn);
            dt.next();
            
            lsNeedGrouping = (String)dt.getField(FIELD_NEED_GROUPING);
            lsGroupComplete = (String)dt.getField(FIELD_GROUP_COMPLETE);
            liParentQueueID= Integer.parseInt(dt.getField(FIELD_PARENT_QUEUE_ID).toString());
            
            if(lsGroupComplete.trim().equals("Y"))
            	lbGroupComplete=true;
            
            hParseResult.remove(FIELD_NEED_GROUPING);
            hParseResult.remove(FIELD_GROUP_COMPLETE);
            hParseResult.remove(FIELD_PARENT_QUEUE_ID);
            hParseResult.put(FIELD_NEED_GROUPING, lsNeedGrouping);
            hParseResult.put(FIELD_GROUP_COMPLETE, lsGroupComplete);
            hParseResult.put(FIELD_PARENT_QUEUE_ID, new Integer(liParentQueueID));
            
            logDebug("checkGrouping(): lsNeedGrouping = " + lsNeedGrouping ) ;
            logDebug("checkGrouping(): lsGroupComplete = " + lsGroupComplete ) ;
            logDebug("checkGrouping(): liParentQueueID = " + liParentQueueID) ;
            
        }
        catch (Exception ex) {
            logDebug((Throwable) ex);
		    logDebug("IMParseMappingExtractor.checkGrouping: "+ex.getMessage());
			throw new Exception(ex.getMessage());
        }
        finally {
            //close(conn);
        }
        
        return lbGroupComplete;
	}
	
	private boolean checkNeedOFAC(Hashtable hParseResult) throws Exception {
		
		String lsOFACInd="";
		boolean lbNeedOFAC=false;
		
		//IDataConnection  conn = null;
        try {
        	String p1=(String)hParseResult.get(FIELD_PROC_UNIT);
            String p2=(String)hParseResult.get(FIELD_QUEUE_TYP);
            String p3=(String)hParseResult.get(FIELD_MSG_TYP);
            String p4="";
              
            Hashtable params = new Hashtable();
            params.put(FIELD_PROC_UNIT, p1);
            params.put(FIELD_QUEUE_TYP, p2);
            params.put(FIELD_MSG_TYP, p3);
            params.put(FIELD_OFAC_IND, p4);
                         
            logDebug("checkNeedOFAC() sql : "+_sChkNeedOFAC+" ("+p1+"|"+p2+"|"+p3+"|"+p4+")");
            
            //conn=getConnection();
            DataTable dt= conn.executeQuery(_sChkNeedOFAC,params );
            //close(conn);
            dt.next();
            
            lsOFACInd = (String)dt.getField(FIELD_OFAC_IND);
              
            if(lsOFACInd.trim().equals("Y"))
            	lbNeedOFAC=true;
            
            hParseResult.remove(FIELD_OFAC_IND);
            hParseResult.put(FIELD_OFAC_IND, lsOFACInd);
            
            logDebug("checkNeedOFAC(): lsOFACInd = " + lsOFACInd) ;
            
        }
        catch (Exception ex) {
            //throw new TriggerException(e.getMessage());
            logDebug((Throwable) ex);
		    logDebug("IMParseMappingExtractor.checkNeedOFAC: "+ex.getMessage());
			throw new Exception(ex.getMessage());
        }
        finally {
            //close(conn);
        }
        
        return lbNeedOFAC;
	}
	
	private boolean TransformSystemFmt(Hashtable hParentResult) throws Exception {
		
		boolean lbTransformSuccess=false;
		String lsUserID="";
		String lsOpTeamCd="";
		//IDataConnection  conn = null;
		DataTable dtMsgContent;
		
		try {
         	/*
         	logDebug("Test GetMessage after open conn");
        	DataTable dtMsgContent1=GetMessage(hParentResult);
        	*/
        	
    		String lsProcUnit=(String)hParentResult.get(FIELD_PROC_UNIT);
            String lsQueueTyp=(String)hParentResult.get(FIELD_QUEUE_TYP);
            Integer liQueueID=(Integer)hParentResult.get(FIELD_QUEUE_ID);
            String lsMsgTyp=(String)hParentResult.get(FIELD_MSG_TYP);

            if (lsQueueTyp.trim().equals(QUEUE_TYP_GTI)){
            	
            	logDebug("TransformSystemFmt(): QUEUE_TYP=GTI. Skip Transform System Format");
            	
            	hParentResult.remove(FIELD_NEED_TRANSFORM_SYSFMT);
            	hParentResult.remove(FIELD_ACTION_TYP);
            	hParentResult.put(FIELD_NEED_TRANSFORM_SYSFMT, "N");
            	hParentResult.put(FIELD_ACTION_TYP, "RTRY");
            	
            	lbTransformSuccess=true;
            
            }else{	//SWF/TLX (Logic according qs_swift_map.c)

	            // Gary Start 20030626
	            String lsSql  = "select USER_ID, OP_TEAM_CD from GTDMAST1..SI_USR_CTL_MAP "; 
	            lsSql += "where INTF_PROC_UNIT = "; 
	            lsSql += "'" + lsProcUnit + "' and ";
	    		lsSql += "QUEUE_TYP = '" + lsQueueTyp + "' and ";
	            lsSql += "MSG_TYP = '" + lsMsgTyp + "'";
	    		// Gary End
	            
	            logDebug("TransformSystemFmt(): Get OP_TEAM_CD: "+lsSql);
	            
	            //conn=getConnection();
	            DataTable dt = conn.executeQuery(lsSql);
	            //close(conn);
	            
	            if(dt.size()==0){
	            	logDebug("TransformSystemFmt(): MSG_TYP not in GTDMAST1..SI_USR_CTL_MAP. Skip Transform System Format");
	            	//lbTransformSystemFmt=false;
	            	
	            	hParentResult.remove(FIELD_NEED_TRANSFORM_SYSFMT);
	            	hParentResult.remove(FIELD_ACTION_TYP);
	            	hParentResult.put(FIELD_NEED_TRANSFORM_SYSFMT, "N");
	            	hParentResult.put(FIELD_ACTION_TYP, "RTRY");
	            	
	            	lbTransformSuccess=true;
	            	//->USP_CUPD_SIMSGQ_STAT RTRY (QS_SWIFT_Parse::ProcessEntry())
	            }else{
	            	logDebug("TransformSystemFmt(): MSG_TYP in GTDMAST1..SI_USR_CTL_MAP. Continue Transform System Format");
	            	//lbTransformSystemFmt=true;
	            	hParentResult.remove(FIELD_NEED_TRANSFORM_SYSFMT);
	            	hParentResult.put(FIELD_NEED_TRANSFORM_SYSFMT, "Y");
	            	
		            dt.next();
		            
		            lsUserID = (String)dt.getField(FIELD_USER_ID);
		            lsOpTeamCd = (String)dt.getField(FIELD_OP_TEAM_CD);
		            logDebug("SWIFTTransormSystemFmt(): lsUserID = " + lsUserID ) ;
		            logDebug("SWIFTTransormSystemFmt(): lsOpTeamCd = " + lsOpTeamCd ) ;
		            hParentResult.remove(FIELD_USER_ID);
		            hParentResult.remove(FIELD_OP_TEAM_CD);
		            hParentResult.remove(FIELD_DUMMY_ID);
		            hParentResult.put(FIELD_USER_ID, lsUserID);
		            hParentResult.put(FIELD_OP_TEAM_CD, lsOpTeamCd);
		            hParentResult.put(FIELD_DUMMY_ID, "");
		            
		            if (lsQueueTyp.trim().equals(QUEUE_TYP_TELEX)){
		            	logDebug("TransformSystemFmt(): Processing TELEX");
		            	
		            	if(!ProcessTELEX(hParentResult)){
		            		logDebug("ProcessTELEX Failed");
		            		lbTransformSuccess=false;
		            		hParentResult.remove(FIELD_ACTION_TYP);
		                	hParentResult.put(FIELD_ACTION_TYP, "FAIL");
		            		
		            	}else{
		            		logDebug("ProcessTELEX Success");
		            		lbTransformSuccess=true;
		            		hParentResult.remove(FIELD_ACTION_TYP);
		                	hParentResult.put(FIELD_ACTION_TYP, "RTRY");
		            	}
		            	
		            	
		            }else if (lsQueueTyp.trim().equals(QUEUE_TYP_SWIFT)&&(( lsMsgTyp.trim().equals(IDS_MSG_LC_OPENING) ) || (lsMsgTyp.trim().equals(IDS_MSG_LC_OPENING_CONT )) /* | (sMsgTyp == IDS_MSG_LC_PADV)*/)) {
		            	logDebug("TransformSystemFmt(): Processing 700");
		            	if(!Process700(hParentResult)){
		            		logDebug("Process700 Failed");
		            		lbTransformSuccess=false;
		            		hParentResult.remove(FIELD_ACTION_TYP);
		                	hParentResult.put(FIELD_ACTION_TYP, "FAIL");
		            		
		            		//cout << "Testing 700 Fail " << endl;
	                        //Sql  =  "USP_CUPD_SIMSGQ_STAT '"; FAIL
		            	}else{
			            	logDebug("Process700 Success");
			            	lbTransformSuccess=true;
			            	hParentResult.remove(FIELD_ACTION_TYP);
		                	hParentResult.put(FIELD_ACTION_TYP, "RTRY");
		            	}
	            	
		            }else if(lsQueueTyp.trim().equals(QUEUE_TYP_SWIFT)&&lsMsgTyp.trim().equals(IDS_MSG_AMEND_APPL)){
		            	logDebug("TransformSystemFmt(): Processing 707");
		            	if(!Process707(hParentResult)){
		            		logDebug("Process707 Failed");
		            		lbTransformSuccess=false;
		            		hParentResult.remove(FIELD_ACTION_TYP);
		                	hParentResult.put(FIELD_ACTION_TYP, "FAIL");
	
		            	}else{
			            	logDebug("Process707 Success");
			            	lbTransformSuccess=true;
			            	hParentResult.remove(FIELD_ACTION_TYP);
		                	hParentResult.put(FIELD_ACTION_TYP, "RTRY");
		            	}
		            	
		            }else if(lsQueueTyp.trim().equals(QUEUE_TYP_SWIFT)&&(lsMsgTyp.equals(IDS_MSG_LC_ADV) || lsMsgTyp.trim().equals(IDS_MSG_LC_ADV_CONT))){
		            	logDebug("TransformSystemFmt(): Processing 710");
		            	if(!Process710(hParentResult)){
		            		logDebug("Process710 Failed");
		            		lbTransformSuccess=false;
		            		hParentResult.remove(FIELD_ACTION_TYP);
		                	hParentResult.put(FIELD_ACTION_TYP, "FAIL");
	
		            	}else{
			            	logDebug("Process710 Success");
			            	lbTransformSuccess=true;
			            	hParentResult.remove(FIELD_ACTION_TYP);
		                	hParentResult.put(FIELD_ACTION_TYP, "RTRY");
		            	}
		            	
	            	}else if(lsQueueTyp.trim().equals(QUEUE_TYP_SWIFT)&&(lsMsgTyp.trim().equals("740"))){
	            		logDebug("TransformSystemFmt(): Processing 740");
		            	if(!Process740(hParentResult)){
		            		logDebug("Process740 Failed");
		            		lbTransformSuccess=false;
		            		hParentResult.remove(FIELD_ACTION_TYP);
		                	hParentResult.put(FIELD_ACTION_TYP, "FAIL");
	
		            	}else{
			            	logDebug("Process740 Success");
			            	lbTransformSuccess=true;
			            	hParentResult.remove(FIELD_ACTION_TYP);
		                	hParentResult.put(FIELD_ACTION_TYP, "RTRY");
		            	}
	            	}else if(lsQueueTyp.trim().equals(QUEUE_TYP_SWIFT)&&(lsMsgTyp.trim().equals("747"))){
	            		logDebug("TransformSystemFmt(): Processing 747");
		            	if(!Process747(hParentResult)){
		            		logDebug("Process747 Failed");
		            		lbTransformSuccess=false;
		            		hParentResult.remove(FIELD_ACTION_TYP);
		                	hParentResult.put(FIELD_ACTION_TYP, "FAIL");
	
		            	}else{
			            	logDebug("Process747 Success");
			            	lbTransformSuccess=true;
			            	hParentResult.remove(FIELD_ACTION_TYP);
		                	hParentResult.put(FIELD_ACTION_TYP, "RTRY");
		            	}
	            	}else if(lsQueueTyp.trim().equals(QUEUE_TYP_SWIFT)&&(lsMsgTyp.trim().equals("742"))){
	            		logDebug("TransformSystemFmt(): Processing 742");
		            	if(!Process742(hParentResult)){
		            		logDebug("Process742 Failed");
		            		lbTransformSuccess=false;
		            		hParentResult.remove(FIELD_ACTION_TYP);
		                	hParentResult.put(FIELD_ACTION_TYP, "FAIL");
	
		            	}else{
			            	logDebug("Process742 Success");
			            	lbTransformSuccess=true;
			            	hParentResult.remove(FIELD_ACTION_TYP);
		                	hParentResult.put(FIELD_ACTION_TYP, "RTRY");
		            	}
	            		
	            	}else if(lsQueueTyp.trim().equals(QUEUE_TYP_SWIFT)&&(lsMsgTyp.trim().equals("940"))){
	            		logDebug("TransformSystemFmt(): Processing 940");
		            	if(!Process940(hParentResult)){
		            		logDebug("Process940 Failed");
		            		lbTransformSuccess=false;
		            		hParentResult.remove(FIELD_ACTION_TYP);
		                	hParentResult.put(FIELD_ACTION_TYP, "FAIL");
	
		            	}else{
			            	logDebug("Process940 Success");
			            	lbTransformSuccess=true;
			            	hParentResult.remove(FIELD_ACTION_TYP);
		                	hParentResult.put(FIELD_ACTION_TYP, "RELS");
		            	}
	            	}else if(lsQueueTyp.trim().equals(QUEUE_TYP_SWIFT)&&(lsMsgTyp.trim().equals("942"))){
	            		logDebug("TransformSystemFmt(): Processing 942");
		            	if(!Process942(hParentResult)){
		            		logDebug("Process942 Failed");
		            		lbTransformSuccess=false;
		            		hParentResult.remove(FIELD_ACTION_TYP);
		                	hParentResult.put(FIELD_ACTION_TYP, "FAIL");
	
		            	}else{
			            	logDebug("Process942 Success");
			            	lbTransformSuccess=true;
			            	hParentResult.remove(FIELD_ACTION_TYP);
		                	hParentResult.put(FIELD_ACTION_TYP, "RELS");
		            	}
	            	
	            	}else if(lsQueueTyp.trim().equals(QUEUE_TYP_SWIFT)&&(lsMsgTyp.trim().equals("950"))){
	            		logDebug("TransformSystemFmt(): Processing 950");
		            	if(!Process950(hParentResult)){
		            		logDebug("Process950 Failed");
		            		lbTransformSuccess=false;
		            		hParentResult.remove(FIELD_ACTION_TYP);
		                	hParentResult.put(FIELD_ACTION_TYP, "FAIL");
	
		            	}else{
			            	logDebug("Process950 Success");
			            	lbTransformSuccess=true;
			            	hParentResult.remove(FIELD_ACTION_TYP);
		                	hParentResult.put(FIELD_ACTION_TYP, "RELS");
		            	}
	            	
	            	}else if(lsQueueTyp.trim().equals(QUEUE_TYP_SWIFT)&&(lsMsgTyp.trim().equals("720"))){
	            		logDebug("TransformSystemFmt(): Processing 720");
		            	if(!Process720(hParentResult)){
		            		logDebug("Process720 Failed");
		            		lbTransformSuccess=false;
		            		hParentResult.remove(FIELD_ACTION_TYP);
		                	hParentResult.put(FIELD_ACTION_TYP, "FAIL");
	
		            	}else{
			            	logDebug("Process720 Success");
			            	lbTransformSuccess=true;
			            	hParentResult.remove(FIELD_ACTION_TYP);
		                	hParentResult.put(FIELD_ACTION_TYP, "RTRY");
		            	}
	            	
	            	}else if(lsQueueTyp.trim().equals(QUEUE_TYP_SWIFT)&&(lsMsgTyp.trim().equals("705"))){	
	            		logDebug("TransformSystemFmt(): Processing 705");
		            	if(!Process705(hParentResult)){
		            		logDebug("Process705 Failed");
		            		lbTransformSuccess=false;
		            		hParentResult.remove(FIELD_ACTION_TYP);
		                	hParentResult.put(FIELD_ACTION_TYP, "FAIL");
	
		            	}else{
			            	logDebug("Process705 Success");
			            	lbTransformSuccess=true;
			            	hParentResult.remove(FIELD_ACTION_TYP);
		                	hParentResult.put(FIELD_ACTION_TYP, "RTRY");
		            	}
	            	}else if(lsQueueTyp.trim().equals(QUEUE_TYP_SWIFT)&&(lsMsgTyp.trim().equals("798"))){
	            		logDebug("TransformSystemFmt(): Processing 798");
		            	if(!Process799(hParentResult)){
		            		logDebug("Process799 Failed");
		            		lbTransformSuccess=false;
		            		hParentResult.remove(FIELD_ACTION_TYP);
		                	hParentResult.put(FIELD_ACTION_TYP, "FAIL");
	
		            	}else{
			            	logDebug("Process799 Success");
			            	lbTransformSuccess=true;
			            	hParentResult.remove(FIELD_ACTION_TYP);
		                	hParentResult.put(FIELD_ACTION_TYP, "RTRY");
		            	}
	            	}else if(lsQueueTyp.trim().equals(QUEUE_TYP_SWIFT)&&(lsMsgTyp.trim().equals("799"))){
	            		logDebug("TransformSystemFmt(): Processing 799");
		            	if(!Process799(hParentResult)){
		            		logDebug("Process799 Failed");
		            		lbTransformSuccess=false;
		            		hParentResult.remove(FIELD_ACTION_TYP);
		                	hParentResult.put(FIELD_ACTION_TYP, "FAIL");
	
		            	}else{
			            	logDebug("Process799 Success");
			            	lbTransformSuccess=true;
			            	hParentResult.remove(FIELD_ACTION_TYP);
		                	hParentResult.put(FIELD_ACTION_TYP, "RTRY");
		            	}
	            	}else if(lsQueueTyp.trim().equals(QUEUE_TYP_SWIFT)&&(lsMsgTyp.trim().equals("760"))){	
	            		logDebug("TransformSystemFmt(): Processing 760");
		            	if(!Process760(hParentResult)){
		            		logDebug("Process760 Failed");
		            		lbTransformSuccess=false;
		            		hParentResult.remove(FIELD_ACTION_TYP);
		                	hParentResult.put(FIELD_ACTION_TYP, "FAIL");
	
		            	}else{
			            	logDebug("Process760 Success");
			            	lbTransformSuccess=true;
			            	hParentResult.remove(FIELD_ACTION_TYP);
		                	hParentResult.put(FIELD_ACTION_TYP, "RTRY");
		            	}
	            	}else if(lsQueueTyp.trim().equals(QUEUE_TYP_SWIFT)&&(lsMsgTyp.trim().equals("767"))){	
	            		logDebug("TransformSystemFmt(): Processing 767");
		            	if(!Process767(hParentResult)){
		            		logDebug("Process767 Failed");
		            		lbTransformSuccess=false;
		            		hParentResult.remove(FIELD_ACTION_TYP);
		                	hParentResult.put(FIELD_ACTION_TYP, "FAIL");
	
		            	}else{
			            	logDebug("Process767 Success");
			            	lbTransformSuccess=true;
			            	hParentResult.remove(FIELD_ACTION_TYP);
		                	hParentResult.put(FIELD_ACTION_TYP, "RTRY");
		            	}
		            	
	            	}else if(lsQueueTyp.trim().equals(QUEUE_TYP_SWIFT)&&(lsMsgTyp.trim().equals(IDS_MSG_DOC_COLL_ACK))){	
	            		logDebug("TransformSystemFmt(): Processing 410");
		            	if(!Process410(hParentResult)){
		            		logDebug("Process410 Failed");
		            		lbTransformSuccess=false;
		            		hParentResult.remove(FIELD_ACTION_TYP);
		                	hParentResult.put(FIELD_ACTION_TYP, "FAIL");
	
		            	}else{
			            	logDebug("Process410 Success");
			            	lbTransformSuccess=true;
			            	hParentResult.remove(FIELD_ACTION_TYP);
			            	//GWF: Original QS_SWIFT_PARSE of MT410 call Update_SI_MSGQ_AutoReg() 
			            	//that exec "USP_ISWF_AUTO_REG" and "USP_CUPD_SIMSGQ_STAT AUTO" (-> QUEUE_STATUS=I)
			            	//GWF put "RTRY" to give QUEUE_STATUS=A
		                	hParentResult.put(FIELD_ACTION_TYP, "RTRY");
		            	}
	            	}else if(lsQueueTyp.trim().equals(QUEUE_TYP_SWIFT)&&(lsMsgTyp.trim().equals("412"))){
	            		logDebug("TransformSystemFmt(): Processing 412");
		            	if(!Process412(hParentResult)){
		            		logDebug("Process412 Failed");
		            		lbTransformSuccess=false;
		            		hParentResult.remove(FIELD_ACTION_TYP);
		                	hParentResult.put(FIELD_ACTION_TYP, "FAIL");
	
		            	}else{
			            	logDebug("Process412 Success");
			            	lbTransformSuccess=true;
			            	hParentResult.remove(FIELD_ACTION_TYP);
			            	//GWF: Original QS_SWIFT_PARSE of MT412 call Update_SI_MSGQ_AutoReg() 
			            	//that exec "USP_ISWF_AUTO_REG" and "USP_CUPD_SIMSGQ_STAT AUTO" (-> QUEUE_STATUS=I)
			            	//GWF put "RTRY" to give QUEUE_STATUS=A
		                	hParentResult.put(FIELD_ACTION_TYP, "RTRY");
		            	}
	            	}else if(lsQueueTyp.trim().equals(QUEUE_TYP_SWIFT)&&(lsMsgTyp.trim().equals("430"))){
	            		logDebug("TransformSystemFmt(): Processing 430");
		            	if(!Process430(hParentResult)){
		            		logDebug("Process430 Failed");
		            		lbTransformSuccess=false;
		            		hParentResult.remove(FIELD_ACTION_TYP);
		                	hParentResult.put(FIELD_ACTION_TYP, "FAIL");
	
		            	}else{
			            	logDebug("Process430 Success");
			            	lbTransformSuccess=true;
			            	hParentResult.remove(FIELD_ACTION_TYP);
		                	hParentResult.put(FIELD_ACTION_TYP, "RTRY");
		            	}
	            	}else if(lsQueueTyp.trim().equals(QUEUE_TYP_SWIFT)&&(lsMsgTyp.trim().equals("499"))){
	            		logDebug("TransformSystemFmt(): Processing 499");
		            	if(!Process799(hParentResult)){
		            		logDebug("Process799 Failed");
		            		lbTransformSuccess=false;
		            		hParentResult.remove(FIELD_ACTION_TYP);
		                	hParentResult.put(FIELD_ACTION_TYP, "FAIL");
	
		            	}else{
			            	logDebug("Process799 Success");
			            	lbTransformSuccess=true;
			            	hParentResult.remove(FIELD_ACTION_TYP);
		                	hParentResult.put(FIELD_ACTION_TYP, "RTRY");
		            	}
	            	}else if(lsQueueTyp.trim().equals(QUEUE_TYP_SWIFT)&&(lsMsgTyp.trim().equals("400"))){
	            		logDebug("TransformSystemFmt(): Processing 400");
		            	if(!Process799(hParentResult)){
		            		logDebug("Process799 Failed");
		            		lbTransformSuccess=false;
		            		hParentResult.remove(FIELD_ACTION_TYP);
		                	hParentResult.put(FIELD_ACTION_TYP, "FAIL");
	
		            	}else{
			            	logDebug("Process799 Success");
			            	lbTransformSuccess=true;
			            	hParentResult.remove(FIELD_ACTION_TYP);
		                	hParentResult.put(FIELD_ACTION_TYP, "RTRY");
		            	}
	            		
	            	}else{
		            	logDebug("TransformSystemFmt(): Processing Other MSG_TYP");
		            	lbTransformSuccess=true;
	            		hParentResult.remove(FIELD_ACTION_TYP);
	                	hParentResult.put(FIELD_ACTION_TYP, "RTRY");
		            }
		            
	           }	//else dt.size()!=0
            
            }	//else QUEUE_TYP<>GTI
            
            if (lbTransformSuccess){
            	hParentResult.remove(FIELD_TRANSFORM_SYSFMT_SUCCESS);
            	hParentResult.put(FIELD_TRANSFORM_SYSFMT_SUCCESS, "Y");
            }
            
            return lbTransformSuccess;
        }
        catch (Exception ex) {
            //throw new TriggerException(e.getMessage());
            logDebug((Throwable) ex);
		    logDebug("IMParseMappingExtractor.SWIFTTransormSystemFmt: "+ex.getMessage());
			throw new Exception(ex.getMessage());
        }
        finally {
            //close(conn);
        }
	}
    
	private String GetTok(DataTable dtMsgContent, String sTok) {

        int posBegin, posEnd;
        //CString sTok = CString(Tok);
        String sMsg = "";
        String sRetMsg = "";
        
        //int ArraySz = dtMsgContent.size();

        //for (int incr = 0; incr < ArraySz; incr++) {
        dtMsgContent.BOF();
        while(dtMsgContent.next()) {
        	posBegin=0;
        	posEnd=0;
        		sMsg = (String)dtMsgContent.getField(FIELD_MSG_CONTENT);
        		
        		if ((posBegin=sMsg.indexOf(sTok))!= -1){
        			posBegin+=sTok.length();
        			
        			/*
        			if (( sMsg[posEnd] == ':' ) & ( sMsg[posEnd - 1] == '\n' )) 
                        break;

        			if ((sMsg[posEnd] == '-' ) & ( sMsg[posEnd + 1] == '}' )) 
                        break;
        			*/
        			
        			if((posEnd=sMsg.indexOf(TAGDELI, posBegin))==-1){
        				posEnd=sMsg.indexOf(SWIFTEND,posBegin);
        			}
        			else
        				posEnd=posEnd +1;	//For \n: case, sMsg should include \n
        			
        			if(posEnd!=-1)
        				//sRetMsg=sRetMsg+sMsg.substring(posBegin, posEnd);
        				sRetMsg=sRetMsg+Mid(sMsg, posBegin, posEnd);
        			else
        				//sRetMsg=sRetMsg+sMsg.substring(posBegin);
        				sRetMsg=sRetMsg+Mid(sMsg,posBegin);
        		}
        		//logDebug("Hunter 333: sRetMsg:"+sRetMsg);
        }
        
        //logDebug("GetTok(): sRetMsg:"+sRetMsg);
        return sRetMsg;
	}
	
//	 search for TAG20 in Mandatory Seq A in MT430
	private String GetTok2(DataTable dtMsgContent, String sTok, int count) {

	        int posBegin, posEnd;
	        //CString sTok = CString(Tok);
	        String sMsg = "";
	        String sRetMsg = "";

	        //int ArraySz = MsgArray.GetSize();

	        //for (int incr = 0; incr < ArraySz; incr++) {
	        dtMsgContent.BOF();
	        while(dtMsgContent.next()){
	        	posBegin=0;
	        	posEnd=0;
	        	
	            //sMsg = *((CString *) MsgArray[incr]);
	        	sMsg = (String)dtMsgContent.getField(FIELD_MSG_CONTENT);
	        	
	        	while (count >0){
	        		count=count-1; 
	                if ((posBegin = sMsg.indexOf(sTok)) > 0) {
	                    //Tok: TAG20
		                //posBegin += strlen(Tok);
	                	posBegin += sTok.length();
						logDebug("GetTok2 TAG20 sTok.length() = ***" + sTok.length() +"***");
		                //logDebug("GetTok2 posBegin = "+incr+posBegin);
						logDebug("GetTok2 posBegin = "+posBegin);
						if (count<1){	//at this point, posBegin is after the sTok of "count"#
	                        /*
							for (posEnd = posBegin; (sMsg[posEnd] != '\0'); posEnd++) {

	                                if (( sMsg[posEnd] == ':' ) & ( sMsg[posEnd - 1] == '\n' )) 
	                                        break;

	                                if ((sMsg[posEnd] == '-' ) & ( sMsg[posEnd + 1] == '}' )) 
	                                        break;
	                        }
	                        
	                        sRetMsg += sMsg.Mid(posBegin, posEnd - posBegin);
	                        
	                        break;
							*/
							if((posEnd=sMsg.indexOf(TAGDELI, posBegin))==-1){
		        				posEnd=sMsg.indexOf(SWIFTEND,posBegin);
		        			}
		        			else
		        				posEnd=posEnd +1;	//For \n: case, sMsg should include \n
		        			
		        			if(posEnd!=-1)
		        				//sRetMsg=sRetMsg+sMsg.substring(posBegin, posEnd);
		        				sRetMsg=sRetMsg+Mid(sMsg, posBegin, posEnd);
		        			else
		        				//sRetMsg=sRetMsg+sMsg.substring(posBegin);
		        				sRetMsg=sRetMsg+Mid(sMsg, posBegin);
							
		        			break;     //Put break to skip retrive from another split(s) ?            
						}
	                    //sMsg=sMsg.Mid(posBegin);
						//sMsg=sMsg.substring(posBegin);
						sMsg=Mid(sMsg,posBegin);
	            
	                }
	            }
	        }

	        return sRetMsg;
	}

//	 search for TAGs other than TAG20 in Mandatory Seq A in MT430
	private String GetTok3(DataTable dtMsgContent, String sTok, int count) {

	        int posBegin, posEnd, seqBegin, seqEnd;
	        //CString sTok = CString(Tok);
	        String sMsg = "";
	        String sRetMsg = "";
	        //String sTag20 = "\r\n:20:";
	        
	        //int ArraySz = MsgArray.GetSize();
	        //cout<<"ArraySz = "<<ArraySz<<endl;
			seqBegin = 0;
	        seqEnd = -1;
			
	        // search for TAG20 in a certain seq
	        //for (int incr = 0; incr < ArraySz; incr++) {
	        dtMsgContent.BOF();
	        while(dtMsgContent.next()){
	        	posBegin=0;
	        	posEnd=0;
	                //sMsg = *((CString *) MsgArray[incr]);
	        		sMsg=(String)dtMsgContent.getField(FIELD_MSG_CONTENT);
	        		
					while (count >0){
						count=count-1;
	                	if ((posBegin = sMsg.indexOf("\r\n:20:")) > 0) {
	                    	//count=count-1;    
		                	//posBegin += strlen("\r\n:20:");
	                		posBegin += String.valueOf("\r\n:20:").length();
	                		
		                	logDebug("GetTok3 this TAG20 - ***" + String.valueOf("\r\n:20:").length() + "***");
		                	logDebug("LOOP COUNT = " + count);
		                	//seqBegin+=posBegin;
							
							
		                	/*    
							for (posEnd = posBegin; (sMsg[posEnd] != '\0'); posEnd++) {

	                                if (( sMsg[posEnd] == ':' ) & ( sMsg[posEnd - 1] == '\n' )) 
	                                        break;

	                                if ((sMsg[posEnd] == '-' ) & ( sMsg[posEnd + 1] == '}' )) 
	                                        break;
	                        }
	                        */

	                        //sRetMsg += sMsg.Mid(posBegin, posEnd - posBegin);
	                        	
	                    	//sMsg=sMsg.Mid(posBegin);
		                	//sMsg=sMsg.substring(posBegin);
		                	sMsg=Mid(sMsg,posBegin);
	                	}
	            	}
	        

					// search for TAG20 in next repetitive seq
	                //sMsg = *((CString *) MsgArray[incr]);

	                if ((posBegin = sMsg.indexOf("\r\n:20:")) > 0) {
	                        //posBegin += strlen("\r\n:20:");
	                		posBegin += String.valueOf("\r\n:20:").length();
							logDebug("GetTok3 next TAG20 - ***" + String.valueOf("\r\n:20:").length() +"***");
							/*
							for (posEnd = posBegin; (sMsg[posEnd] != '\0'); posEnd++) {

	                                if (( sMsg[posEnd] == ':' ) & ( sMsg[posEnd - 1] == '\n' )) 
	                                        break;

	                                if ((sMsg[posEnd] == '-' ) & ( sMsg[posEnd + 1] == '}' )) 
	                                        break;
	                        }
							*/
	                        //sRetMsg += sMsg.Mid(posBegin, posEnd - posBegin);
	                        seqEnd=posBegin;
	                }
	        
	            logDebug("GetTok3 seqBegin = "+seqBegin);
	            logDebug("GetTok3 seqEnd = "+seqEnd);
	        // search for the TAG in that seq
				// sMsg = *((CString *) MsgArray[incr]);
				if (seqEnd != -1){	//there are another :20:, cut the Segment
					//sMsg=sMsg.Mid(0, seqEnd);
					sMsg=Left(sMsg, seqEnd);
				}
	                if ((posBegin = sMsg.indexOf(sTok)) > 0) {
	                        //posBegin += strlen(sTok);
	                		posBegin += sTok.length();
							logDebug("GetTok3 TAG found - ***" + sTok.length() +"***");
							logDebug("GetTok3 posBegin = "+ posBegin);
	                        
							/*
							for (posEnd = posBegin; (sMsg[posEnd] != '\0'); posEnd++) {

	                                if (( sMsg[posEnd] == ':' ) & ( sMsg[posEnd - 1] == '\n' )) 
	                                        break;

	                                if ((sMsg[posEnd] == '-' ) & ( sMsg[posEnd + 1] == '}' )) 
	                                        break;
	                        }

	                        sRetMsg += sMsg.Mid(posBegin, posEnd - posBegin);
	                        */
							if((posEnd=sMsg.indexOf(TAGDELI, posBegin))==-1){
		        				posEnd=sMsg.indexOf(SWIFTEND,posBegin);
		        			}
		        			else
		        				posEnd=posEnd +1;	//For \n: case, sMsg should include \n
		        			
		        			if(posEnd!=-1)
		        				//sRetMsg=sRetMsg+sMsg.substring(posBegin, posEnd);
		        				sRetMsg=sRetMsg+Mid(sMsg, posBegin, posEnd);
		        			else
		        				//sRetMsg=sRetMsg+sMsg.substring(posBegin);
		        				sRetMsg=sRetMsg+Mid(sMsg, posBegin);
							
	                }
	        }
	        
	        return sRetMsg;
	}
	
	private boolean GetParentMsg(Hashtable hParseResult, Hashtable hParentResult)throws Exception{
		//boolean lbGetParentMsg=false;
		//IDataConnection  conn = null;
		
		try{
			String lsProcUnit=(String)hParseResult.get(FIELD_PROC_UNIT);
            String lsQueueTyp=(String)hParseResult.get(FIELD_QUEUE_TYP);
            Integer liParentQueueID=(Integer)hParseResult.get(FIELD_PARENT_QUEUE_ID);
            //String lsMsgTyp=(String)hParseResult.get(FIELD_MSG_TYP);

			Hashtable params = new Hashtable();
	        params.put(FIELD_PROC_UNIT, lsProcUnit);
	        params.put(FIELD_QUEUE_TYP, lsQueueTyp);
	        params.put(FIELD_PARENT_QUEUE_ID, liParentQueueID);
	
	        logDebug("GetParentMsg() Select Parent Msg:"+_sSelectParentMsg+" ("+lsProcUnit+"|"+lsQueueTyp+"|"+ liParentQueueID+")");
	        
	        //conn=getConnection();
	        DataTable dtParentMsg= conn.executeQuery(_sSelectParentMsg,params );
	        //close(conn);
	        if(dtParentMsg.size()==0){
	        	logDebug("GetParentMsg(): Cannot select Parent Msg");
	        	return false;
	        }
	        
	        dtParentMsg.next();
			String sProcUnit=(String)dtParentMsg.getField(FIELD_PROC_UNIT);
	        String sQueueTyp=(String)dtParentMsg.getField(FIELD_QUEUE_TYP);
			int iQueueID=Integer.parseInt(dtParentMsg.getField(FIELD_QUEUE_ID).toString());
	        String sMsgTyp=(String)dtParentMsg.getField(FIELD_MSG_TYP);
	        String sMsgHeader=(String)dtParentMsg.getField(FIELD_MSG_HEADER);
	        String sSendRecvAddr=(String)dtParentMsg.getField(FIELD_SEND_RECV_ADDR);
	        
	        Timestamp sRecvDt=(Timestamp)dtParentMsg.getField(FIELD_RECV_DT);
	        String sExtMsgRef=(String)dtParentMsg.getField(FIELD_EXT_MSG_REF);
	        String sApplMsgRef=(String)dtParentMsg.getField(FIELD_APPL_MSG_REF);
	        
	        //if Current QueueID is Parent QueueID, GTDPEND1..SI_MSG.EXT_MSG_REF not yet updated. Get from Parsing result instead. 
	        int iParsingQueueID=Integer.parseInt(hParseResult.get(FIELD_QUEUE_ID).toString());
	        if (iParsingQueueID==iQueueID){
	        	sExtMsgRef=(String)hParseResult.get(FIELD_EXT_MSG_REF);
	        }
	        
	        hParentResult.remove(FIELD_PROC_UNIT);
	        hParentResult.remove(FIELD_QUEUE_TYP);
	        hParentResult.remove(FIELD_QUEUE_ID);
	        hParentResult.remove(FIELD_MSG_TYP);
	        hParentResult.remove(FIELD_MSG_HEADER);
	        hParentResult.remove(FIELD_SEND_RECV_ADDR);
	        hParentResult.remove(FIELD_RECV_DT);
	        hParentResult.remove(FIELD_EXT_MSG_REF);
	        hParentResult.remove(FIELD_APPL_MSG_REF);
	        
	        hParentResult.put(FIELD_PROC_UNIT, sProcUnit);
	        hParentResult.put(FIELD_QUEUE_TYP, sQueueTyp);
	        hParentResult.put(FIELD_QUEUE_ID, new Integer(iQueueID));
	        hParentResult.put(FIELD_MSG_TYP, sMsgTyp);
	        hParentResult.put(FIELD_MSG_HEADER, sMsgHeader);
	        hParentResult.put(FIELD_SEND_RECV_ADDR, sSendRecvAddr);
	        hParentResult.put(FIELD_RECV_DT, sRecvDt);
	        hParentResult.put(FIELD_EXT_MSG_REF, sExtMsgRef);
	        hParentResult.put(FIELD_APPL_MSG_REF, sApplMsgRef);
	        
	        return true;
	        
		}catch (Exception ex) {
            //throw new TriggerException(e.getMessage());
            logDebug((Throwable) ex);
		    logDebug("IMParseMappingExtractor.GetParentMsg: "+ex.getMessage());
			throw new Exception(ex.getMessage());
        }
        finally {
            //close(conn);
        }
		
	}
	
	private DataTable GetMessage(Hashtable hParentResult)throws Exception{
		
		//IDataConnection  conn = null;
		DataTable dtMsgContent;
		
		try{
			String lsProcUnit=(String)hParentResult.get(FIELD_PROC_UNIT);
            String lsQueueTyp=(String)hParentResult.get(FIELD_QUEUE_TYP);
            Integer liQueueID=(Integer)hParentResult.get(FIELD_QUEUE_ID);
            //String lsMsgTyp=(String)hParseResult.get(FIELD_MSG_TYP);
            String lsProcessorID=(String)hParentResult.get(FIELD_PROCESSOR_ID);
            Timestamp ltBatchID=(Timestamp)hParentResult.get(FIELD_BATCH_ID);

			Hashtable params = new Hashtable();
	        params.put(FIELD_PROC_UNIT, lsProcUnit);
	        params.put(FIELD_QUEUE_TYP, lsQueueTyp);
	        params.put(FIELD_PARENT_QUEUE_ID, liQueueID);
	        params.put(FIELD_PROCESSOR_ID, lsProcessorID);
	        params.put(FIELD_BATCH_ID, ltBatchID);
	
	        logDebug("GetMessage() Select MSG_CONTENT:"+_sSelectMsgContent+" ("+lsProcUnit+"|"+lsQueueTyp+"|"+ liQueueID+"|"+lsProcessorID+"|"+ltBatchID+")");
	        
	        //conn=getConnection();
	        dtMsgContent= conn.executeQuery(_sSelectMsgContent,params );
	        //close(conn);
	        logDebug("GetMessage(): dtMsgContent.size():"+dtMsgContent.size());
	        
	        /*
	        int liLnkMsgSeq=0;
	        int liLnkMsgTotal=0;
	        String lsMsgContent="";
	        while(dtMsgContent.next()) {
	        	//int iQueueID=Integer.parseInt((String)hParseResult.get(FIELD_QUEUE_ID).toString());
	        	liLnkMsgSeq=Integer.parseInt(dtMsgContent.getField(FIELD_LNK_MSG_SEQ).toString());
	        	liLnkMsgTotal=Integer.parseInt(dtMsgContent.getField(FIELD_LNK_MSG_TOTAL).toString());
	        	lsMsgContent=(String)dtMsgContent.getField(FIELD_MSG_CONTENT);
	        	
	        }
	        */
        
	        return dtMsgContent;
	        
		}catch (Exception ex) {
            //throw new TriggerException(e.getMessage());
            logDebug((Throwable) ex);
		    logDebug("IMParseMappingExtractor.GetMessage: "+ex.getMessage());
			throw new Exception(ex.getMessage());
        }
        finally {
            //close(conn);
        }
		
	}
	
	private boolean ProcessTELEX(Hashtable hParentResult) throws Exception{
		//boolean lbProcessSuccess=false;
		logDebug("Processing TELEX Msg");
		
		DataTable dtMsgContent=GetMessage(hParentResult);
        String sGtlMsg="";
		
		if(dtMsgContent.size()>0){
			logDebug("ProcessTELEX(): GetMessage Success");
			while(dtMsgContent.next()){
				sGtlMsg=sGtlMsg+(String)dtMsgContent.getField(FIELD_MSG_CONTENT);
			}
		}
		else{
			logDebug("ProcessTELEX(): GetMessage give no entry");
			return false;
		}

		hParentResult.remove(FIELD_MSG_TEXT);
		hParentResult.put(FIELD_MSG_TEXT, sGtlMsg);
		
		//return lbProcessSuccess;
        return true;
	}
	
	private boolean Process700(Hashtable hParentResult) throws Exception{
		logDebug("Processing MT700 Msg");
		
		DataTable dtMsgContent=GetMessage(hParentResult);
        
        if (MT700_to_Gtl(hParentResult, dtMsgContent)){
        	logDebug("Process700(): MT700_to_Gtl Success");
        	/* GWF: Move to commitParentResult - Begin
        	try{
        		Update_SI_MSGQ(hParentResult);
        	}catch(Exception ex){
        		logDebug("Process700(): Catch Exception from Update_SI_MSGQ");
        		return false;
        	}
        	GWF: Move to commitParentResult - End */
        }
        else
        {
        	logDebug("Process700(): MT700_to_Gtl Failed");
            //Update_SI_MSGQ_Fail();
            return false;
        }

        return true;
	}
	
	private boolean Process707(Hashtable hParentResult) throws Exception{
		logDebug("Processing MT707 Msg");
		
		DataTable dtMsgContent=GetMessage(hParentResult);
        
        if (MT707_to_Gtl(hParentResult, dtMsgContent)){
        	logDebug("Process707(): MT707_to_Gtl Success");
        }
        else
        {
        	logDebug("Process707(): MT707_to_Gtl Failed");
            //Update_SI_MSGQ_Fail();
            return false;
        }

        return true;
	}

	private boolean Process710(Hashtable hParentResult) throws Exception{
		logDebug("Processing MT710 Msg");
		
		DataTable dtMsgContent=GetMessage(hParentResult);
        
        if (MT710_to_Gtl(hParentResult, dtMsgContent)){
        	logDebug("Process710(): MT710_to_Gtl Success");
        }
        else
        {
        	logDebug("Process710(): MT710_to_Gtl Failed");
            //Update_SI_MSGQ_Fail();
            return false;
        }

        return true;
	}
	
	private boolean Process740(Hashtable hParentResult) throws Exception{
		logDebug("Processing MT740 Msg");
		
		DataTable dtMsgContent=GetMessage(hParentResult);
        
		//IDataConnection  conn = null;
		
		if (MT740_to_Gtl(hParentResult, dtMsgContent)){
        	logDebug("Process740(): MT740_to_Gtl Success");
        }
        else
        {
        	logDebug("Process740(): MT740_to_Gtl Failed");
            //Update_SI_MSGQ_Fail();
            return false;
        }

        return true;
	}
	
	private boolean Process747(Hashtable hParentResult) throws Exception{
		logDebug("Processing MT747 Msg");
		
		DataTable dtMsgContent=GetMessage(hParentResult);
        
        if (MT747_to_Gtl(hParentResult, dtMsgContent)){
        	logDebug("Process747(): MT747_to_Gtl Success");
        }
        else
        {
        	logDebug("Process747(): MT747_to_Gtl Failed");
            //Update_SI_MSGQ_Fail();
            return false;
        }

        return true;
	}
	
	private boolean Process742(Hashtable hParentResult) throws Exception{
		logDebug("Processing MT742 Msg");
		
		DataTable dtMsgContent=GetMessage(hParentResult);
        
        if (MT742_to_Gtl(hParentResult, dtMsgContent)){
        	logDebug("Process742(): MT742_to_Gtl Success");
        }
        else
        {
        	logDebug("Process742(): MT742_to_Gtl Failed");
            //Update_SI_MSGQ_Fail();
            return false;
        }

        return true;
	}
	
	private boolean Process940(Hashtable hParentResult) throws Exception{
		logDebug("Processing MT940 Msg");
		//IDataConnection  conn = null;
		DataTable dt;
		
		try{
	        String sProdCat  = "";
	        String sProdType = "";
	        String sExtRefNbr = "";
	        String sTranType = " ";
	        String sOrigRefNbr = " ";
	        
	        String sProcUnit=(String)hParentResult.get(FIELD_PROC_UNIT);
	        String sMsgTyp=(String)hParentResult.get(FIELD_MSG_TYP);
	        String sQueueTyp=(String)hParentResult.get(FIELD_QUEUE_TYP);
	        int sQueueId=((Integer)hParentResult.get(FIELD_QUEUE_ID)).intValue();
		    String sGtlMsg="";
	        String Sql="";
	        String sTranRefNbr="";
	        hParentResult.remove(FIELD_EXT_REF_NBR);
	        hParentResult.remove(FIELD_PROD_CAT);
	        hParentResult.remove(FIELD_PROD_TYP);
	        hParentResult.remove(FIELD_TRAN_REF_NBR);
	        hParentResult.put(FIELD_EXT_REF_NBR, sExtRefNbr);
	        hParentResult.put(FIELD_PROD_CAT, sProdCat);
	        hParentResult.put(FIELD_PROD_TYP, sProdType);
	        hParentResult.put(FIELD_TRAN_REF_NBR, sTranRefNbr);
			
	        String sOpTeamCd=(String)hParentResult.get(FIELD_OP_TEAM_CD);
	        String sMsgHeader=(String)hParentResult.get(FIELD_MSG_HEADER);
	        Timestamp sRecvDt=(Timestamp)hParentResult.get(FIELD_RECV_DT);
	        String sExtMsgRef=(String)hParentResult.get(FIELD_EXT_MSG_REF);
	        String sApplMsgRef=(String)hParentResult.get(FIELD_APPL_MSG_REF);
	        String sSendRecvAddr=(String)hParentResult.get(FIELD_SEND_RECV_ADDR);
	        
		DataTable dtMsgContent=GetMessage(hParentResult);
        
		// [Herman Lam] -- [11SEPT2006] 
		int len=0, head=0, headfront =0, headback =0, mid=0, tail=0, msgcount = 0, nComma;
		int mid_nxt=0; 
		// [Herman Lam] -- [END] 
		int isNonRef=0;
		int rowcount;
		
		String sDDANbr="";
		String sStmtSeqNbr="";
		String sCurCd="";
		String sProcDt="";
		String sStmtLine="";
		String sInfo2AcctOnr="";
		String sDrCrInd="";
		int sTranSeqNbr=0;
		int sMsgId=0;
		String sGtlMsg1="";
		String sItemOs="";
		String sGtlMsg2="";
		long sNewAudId = 0;
		String sValDt= "";
		String sMsgAmt = "";
		String sNYCrRef="";
		int sNewQueueId=0;
		
		String SwiftTag, tempStr;
		
		//To keep general information about the completed MT940 message
		//:20: (External) Transaction Reference Number
		if ( ! (SwiftTag =  GetTok(dtMsgContent, "\r\n:20:")).trim().equals(""))
		{
			len = SwiftTag.length();
			//if (SwiftTag.Right(2) == "\r\n")
			//tempStr=SwiftTag.substring(len-2);
			tempStr=Right(SwiftTag, 2);
			if(tempStr.trim().equals("\r\n"))
				sOrigRefNbr = Left(SwiftTag, len-2);
			else
				sOrigRefNbr = SwiftTag;
		}

		//:25: Account Identification [ie DDA Acount Number]
		if ( ! (SwiftTag = GetTok(dtMsgContent, "\r\n:25:")).trim().equals(""))
		{
			len = SwiftTag.length();
			//tempStr=SwiftTag.substring(len-2);
			tempStr=Right(SwiftTag, 2);
			//if (SwiftTag.Right(2) == "\r\n")
			if (tempStr.trim().equals("\r\n"))
				sDDANbr = Left(SwiftTag, len-2);
			else
				sDDANbr = SwiftTag;
		}

		//:28C: Statement Number/Sequence Number
		if ( ! (SwiftTag = GetTok(dtMsgContent, "\r\n:28C:")).trim().equals(""))
		{
			len = SwiftTag.length();
			//if (SwiftTag.Right(2) == "\r\n")
			//tempStr=SwiftTag.substring(len-2);
			tempStr=Right(SwiftTag, 2);
			if (tempStr.trim().equals("\r\n"))
				sStmtSeqNbr = Left(SwiftTag, len-2);
			else
				sStmtSeqNbr = SwiftTag;
		}

		//Get Currency in :60F: or :60M:
		if ( ! (SwiftTag = GetTok(dtMsgContent, "\r\n:60F:")).trim().equals(""))
		{
			//len = SwiftTag.GetLength();
			//sCurCd = SwiftTag.Mid(7, 3);
			//sCurCd = SwiftTag.substring(7, 7+3);
			sCurCd = Mid(SwiftTag, 7, 7+3);
		}
		else if ( ! (SwiftTag = GetTok(dtMsgContent, "\r\n:60M:")).trim().equals(""))
		{
			//len = SwiftTag.GetLength();
			//sCurCd = SwiftTag.Mid(7, 3);
			//sCurCd = SwiftTag.substring(7, 7+3);
			sCurCd = Mid(SwiftTag, 7, 7+3);
		}

		//Get PROC_DT
		//Sql  = "select THIS_PROC_DT ";
		Sql  = "select THIS_PROC_DT=convert(char(8), THIS_PROC_DT, 112) ";
		Sql += "from GTDMAST1..PROC_UNIT ";
		Sql += "where PROC_UNIT = '";
		Sql += sProcUnit;
		Sql += "'";
		logDebug("Exec Sql: [" + Sql + "]");
		/*
		SetSql(Sql);
		ExecSql();

		if (!GetResult(&pDBRows))
		{
	                //ThrowQSException(QS_QSERVER_ERROR);
	                WriteErrLog("Error return from stored proc [" + Sql + "]");
	                cout << "Error return from stored proc" << endl;
			return (QS_FAIL) ;
		}

		rowcount = (pDBRows->GetRowCount());
		*/
		//conn=getConnection();
		dt=conn.executeQuery(Sql);
		//close(conn);
		rowcount=dt.size();
		
		if ( rowcount == 1)
		{	
			/*
			p = pDBRows->GetAttr("THIS_PROC_DT");
			ASSERT(p != NULL);
			if (p != NULL)
				p->GetValue(sProcDt);
			*/
			dt.next();
			sProcDt=(String)dt.getField("THIS_PROC_DT");
		}

//	RM	
//	cout << "Process940: sOrigRefNbr:20:-> " << sOrigRefNbr << endl;
//	cout << "Process940: sDDANbr:25:-> " << sDDANbr << endl;
//	cout << "Process940: sStmtSeqNbr:28C:-> " << sStmtSeqNbr << endl;
//	cout << "Process940: sCurCd:60:-> " << sCurCd << endl;

		//Parsing SWIFT message
		//1. Keep fields 61 and 86
		//2. Extract MsgAmt, ExtRefNbr and NYCrRef in field 61
		//3. Using ExtRefNbr, check if any matched transaction in M1..TP_TRAN_HDR
		//4. If a matched transaction is found, create a new entry in SI_MSG and SI_MSG_Q with status = 'A'
		//   and create a new entry in WK_AUTO_EC_CANC
		
		for (msgcount = 1; !(tempStr = GetRepeatTok(dtMsgContent, "\r\n:61:",msgcount)).trim().equals(""); msgcount++)
		//for (msgcount = 1; (!(tempStr = GetRepeatTok("\r\n:61:",msgcount)).Compare("")); msgcount++)
		{
			Hashtable hEntryResult=new Hashtable();
			if (! (SwiftTag = GetRepeatTok(dtMsgContent, "\r\n:61:",msgcount)).trim().equals(""))
			{
				len = SwiftTag.length();
				//if (SwiftTag.Right(2) == "\r\n")
				//tempStr=SwiftTag.substring(len-2);	
				tempStr=Right(SwiftTag, 2);
				if (tempStr.trim().equals("\r\n"))
					sStmtLine = Left(SwiftTag, len-2);
				else
					sStmtLine = SwiftTag;
			//	sStmtLine = SwiftTag;
			} 

//			if ((SwiftTag = GetRepeatTok("\r\n:86:",msgcount)) != "")
			if (! (SwiftTag = GetRepeatTok(dtMsgContent, "\r\n:61:",msgcount,"\r\n:86:")).trim().equals(""))
			{
				len = SwiftTag.length();
				//if (SwiftTag.Right(2) == "\r\n")
				//tempStr=SwiftTag.substring(len-2);
				tempStr=Right(SwiftTag, 2);
				if (tempStr=="\r\n")
					sInfo2AcctOnr = Left(SwiftTag, len-2);
				else
					sInfo2AcctOnr = SwiftTag;
			//	sInfo2AcctOnr = SwiftTag;
			} else {
				sInfo2AcctOnr = "";
			}

	logDebug("");
	logDebug("Process940: Looping -> Reading #" + msgcount + " transaction");
//	 cout << "	Process940: sStmtLine:61:-> " << sStmtLine << endl;
//	 cout << "	Process940: sInfo2AcctOnr:86:-> " << sInfo2AcctOnr << endl;

			// [Herman Lam] -- [11SEPT2006] 
			//To extract MsgAmt, ExtRefNbr and NYCrRef in field 61
			head = sStmtLine.indexOf("C");
			if ((head == -1) || (head > 10)) {
				head = sStmtLine.indexOf("D");	
				if ((head == -1) || (head > 10)) {
					head = -1;
				}
			}
			//cout << " head=" << head << ", value=" << sStmtLine.GetAt(head) << ", valuefront=" << sStmtLine.GetAt(head-1) << ", valueback=" << sStmtLine.GetAt(head+1) << endl;
			if(head != -1)
				logDebug(" head=" + head + ", value=" + sStmtLine.charAt(head) + ", valuefront=" + sStmtLine.charAt(head-1) + ", valueback=" + sStmtLine.charAt(head+1));
			else
				logDebug(" head=" + head);
			
			if (head != -1 ) {
				//sDrCrInd =sStmtLine.substring(head, head+1);
				sDrCrInd =Mid(sStmtLine, head, head+1);
				if (!(Character.isDigit(sStmtLine.charAt(head+1)))) {	//For case 20061212CR10000
					headback = 1;
				} else {					//For case 20061212C10000
					headback = 0;
				}
				if (!(Character.isDigit(sStmtLine.charAt(head-1)))) {	//For case 20061212RC10000
					headfront = 1;
				} else {					//For case 20061212C10000
					headfront = 0;
				}
			}
			logDebug(" mid_nxt1=" + sStmtLine.charAt(mid+1) + ",  mid_nxt2=" + sStmtLine.charAt(mid+2));

			mid  = sStmtLine.indexOf(",");
			if (mid != -1) {
				if (!(Character.isDigit(sStmtLine.charAt(mid+1)))) {		//For case 10000,NTR
					mid_nxt = 0;
				} else if (!(Character.isDigit(sStmtLine.charAt(mid+2)))) {	//For case 10000,0NTR
					mid_nxt = 1;
				} else {					//For case 10000,00NTR
					mid_nxt = 2;
				}	
			}			
			tail = sStmtLine.indexOf("//");
			logDebug(" head=" + head + " headfront=" + headfront + " headback=" + headback + ", mid=" + mid + ", mid_nxt=" + mid_nxt +", tail=" + tail );
			// [Herman Lam] -- [END] 
			
	
			if ((head != -1) && (mid != -1) && (tail != -1))
			{
				//sValDt = sStmtLine.Mid(head-6-headfront, 6);
				//sMsgAmt = sStmtLine.Mid(head+1+headback, mid+mid_nxt+1-(head+1+headback));
				//sValDt = sStmtLine.substring(head-6-headfront, head-headfront);
				sValDt = Mid(sStmtLine, head-6-headfront, head-headfront);
				//sMsgAmt = sStmtLine.substring(head+1+headback, mid+mid_nxt+1);
				sMsgAmt = Mid(sStmtLine, head+1+headback, mid+mid_nxt+1);
				//int nComma = sMsgAmt.Find(',');
				//if (nComma >= 0)
				//	sMsgAmt.SetAt(nComma, '.');
				sMsgAmt=sMsgAmt.replace(',','.');
				
				//sExtRefNbr = sStmtLine.Mid(mid+5+mid_nxt, tail-(mid+5+mid_nxt));
				//sExtRefNbr = sStmtLine.substring(mid+5+mid_nxt, tail);
				sExtRefNbr = Mid(sStmtLine, mid+5+mid_nxt, tail);
				
				//sNYCrRef = sStmtLine.Mid(tail+2, 14);
				//sNYCrRef = sStmtLine.substring(tail+2, tail+2+14);
				sNYCrRef = Mid(sStmtLine, tail+2, tail+2+14);
				//if (sNYCrRef.Right(2) == "\r\n")
				//tempStr=sNYCrRef.substring(sNYCrRef.length()-2);
				tempStr=Right(sNYCrRef, 2);
				if (tempStr.trim().equals("\r\n"))
					sNYCrRef = Left(sNYCrRef, sNYCrRef.length() - 2);
					
				logDebug("EXT_REF_NBR = " + sExtRefNbr);

				// [Herman Lam] -- [30AUG2006] 
				if ((sExtRefNbr.indexOf(CntNonRefNbr) == -1) && (sDrCrInd.indexOf("D") == -1) ){
					Sql = "exec GTDPEND1..USP_CCHK_EXIST_ENTRY '";
				        Sql += sProcUnit;
				        Sql += "', '";
					Sql += sExtRefNbr;
				        Sql += "', '";
				        Sql += sDDANbr;
				        Sql += "', '";
				        Sql += sCurCd;
				        Sql += "', '";
				        Sql += sQueueTyp;
				        Sql += "', '";
				        Sql += sMsgTyp;
				        Sql += "'";
					
					logDebug("Sql:   " + Sql);

				    //conn=getConnection();
				    dt=conn.executeQuery(Sql);
				    //close(conn);
					
				    if(dt.size()>0){
					
						logDebug("Get Result ");
						
						dt.next();
						sTranRefNbr=(String)dt.getField("TRAN_REF_NBR");
						logDebug("TRAN_REF_NBR: "+ sTranRefNbr );
						
						sTranSeqNbr=Integer.parseInt(dt.getField("TRAN_SEQ_NBR").toString());
						logDebug("TRAN_SEQ_NBR: "+ sTranSeqNbr);
	
						sProdCat=(String)dt.getField("PROD_CAT");
						logDebug("PROD_CAT: "+ sProdCat);
	
						sProdType=(String)dt.getField("PROD_TYP");
						logDebug("PROD_TYP: "+ sProdType);
	
						sTranType=(String)dt.getField("TRAN_TYP");
						logDebug("TRAN_TYP: "+ sTranType );
	
						sMsgId=Integer.parseInt(dt.getField("MSG_ID").toString());
						logDebug("MSG_ID: "+ sMsgId);
	
						sGtlMsg1=(String)dt.getField("MESSAGE");
						logDebug("MESSAGE: "+ sGtlMsg1);
						
						sItemOs=(String)dt.getField("ITEM_OS");
						logDebug("ITEM_OS: "+ sItemOs);
						
						
						sGtlMsg2 =(sMsgId==0)?"":"No SI_MSG created.";
						logDebug("MESSAGE2: "+ sGtlMsg2);
						
		       			//sNewAudId = "000000";
						sNewAudId = 0;
						
				    }
				} else {	//else ((sExtRefNbr.indexOf(CntNonRefNbr) == -1) && (sDrCrInd.indexOf("D") == -1) )
					if (sExtRefNbr.indexOf(CntNonRefNbr) > -1) {
		       				sGtlMsg1 = "Not Link Transaction, due to DDA_REF = NONREF  ";
		       				//sMsgId = "49118";
		       				sMsgId=49118;
					} else if (sDrCrInd.indexOf("D") > -1) {
		       				sGtlMsg1 = "Not Link Transaction, due to debit entry  ";
		       				//sMsgId = "49119";
		       				sMsgId = 49119;
					} else {
		       				sGtlMsg1 = "Not Link Transaction, due to invalid message ";
		       				//sMsgId = "49120";
		       				sMsgId = 49120;
					}		
							
					sTranRefNbr = "";		
					//sTranSeqNbr = "0";
					sTranSeqNbr = 0;
	       				sProdCat = " ";
	       				sProdType = " ";
	       				sTranType  = "";
	       				sGtlMsg2 = "No SI_MSG created.";
	       				//sNewAudId = "000000";
	       				sNewAudId = 0;
	       				sItemOs = "X";
				}
			} else {
				sValDt = "19000101";
				sMsgAmt = "0";
				//sExtRefNbr = FixQuote(sStmtLine.Mid(0,35));		// Use for Reconcilation Report
				//sNYCrRef = FixQuote(sStmtLine.Mid(36,16));		// Use for Reconcilation Report
				sExtRefNbr = DuplicateQuote(Left(sStmtLine,35));		// Use for Reconcilation Report
				//sNYCrRef = DuplicateQuote(sStmtLine.substring(36,36+16));		// Use for Reconcilation Report
				sNYCrRef = DuplicateQuote(Mid(sStmtLine,36,36+16));		// Use for Reconcilation Report
				
				sGtlMsg1 = "Not Link Transaction, due to invalid swift message  ";
				//sMsgId = "49120";
				sMsgId = 49120;
				sTranRefNbr = "";		
				//sTranSeqNbr = "0";
				sTranSeqNbr = 0;
				sProdCat = " ";
				sProdType = " ";
				sTranType  = "";
				sGtlMsg2 = "No SI_MSG created.";
				//sNewAudId = "000000";
				sNewAudId = 0;
				sItemOs = "X";
			}
			// [Herman Lam] -- [END]
//	RM
//	cout << "M1..TP_MST_HDR Sql rowcount = " << rowcount << endl;
				//if a matched transaction is found for this sExtRefNbr
				
			//if (sMsgId == "0")
			if (sMsgId == 0)
			{
				logDebug("sMsgId == 0. Matched transaction found! [" + sTranRefNbr + "]");
				logDebug("	Process940: Matched transaction found!");
				logDebug("		sTranRefNbr: " + sTranRefNbr);
				// cout << "		sProdCat: " << sProdCat << endl;
				// cout << "		sProdTyp: " << sProdType << endl;

				sGtlMsg1 = ""; sGtlMsg2 = "";

				sGtlMsg1 = "MT";
				sGtlMsg1 += sMsgTyp;
				sGtlMsg1 += "\r\n";
				sGtlMsg1 +=  sProdCat;
				sGtlMsg1 += "/ ";
				sGtlMsg1 += sProdType;
				sGtlMsg1 += "\r\n";
				sGtlMsg1 += "Ref Nbr-> ";
				sGtlMsg1 += sExtRefNbr;
				sGtlMsg1 += "\r\n";
				sGtlMsg1 += "Tran Amt-> ";
				sGtlMsg1 += sCurCd;
				sGtlMsg1 += sMsgAmt;
				sGtlMsg1 += "\r\n";
				sGtlMsg1 += "NY Cr Ref-> ";
				sGtlMsg1 += sNYCrRef;
				sGtlMsg1 += "\r\n\n";

			//	sGtlMsg1 += ":61E: ";
			//	sGtlMsg1 += sExtRefNbr;
			//	sGtlMsg1 += "\r\n";
			//	sGtlMsg1 += ":60C ";
			//	sGtlMsg1 += sCurCd;
			//	sGtlMsg1 += "\r\n";
			//	sGtlMsg1 += ":61A ";
			//	sGtlMsg1 += sMsgAmt;
			//	sGtlMsg1 += "\r\n\n";

				sGtlMsg2 += ":20: ";
				sGtlMsg2 += sOrigRefNbr;
				sGtlMsg2 += "\r\n";
				sGtlMsg2 += ":25: ";
				sGtlMsg2 += sDDANbr;
				sGtlMsg2 += "\r\n";
				sGtlMsg2 += ":28C: ";
				sGtlMsg2 += sStmtSeqNbr;
				sGtlMsg2 += "\r\n";
				sGtlMsg2 += ":61: ";
				sGtlMsg2 += sStmtLine;
				sGtlMsg2 += "\r\n";
				sGtlMsg2 += ":86: ";
				sGtlMsg2 += sInfo2AcctOnr;
				sGtlMsg2 += "\r\n";

				//Insert record into SI_MSG and SI_MSG_Q status must be 'A'

				//Get QUEUE_ID
				Sql  = "exec GTDPEND1..USP_CGET_QUEUEID1 '";
				Sql += sProcUnit;
				Sql += "'";
				logDebug("Exec Sql: [" + Sql + "]");

				//conn=getConnection();
				dt=conn.executeQuery(Sql);
				//close(conn);
				
				rowcount = dt.size();
				if ( rowcount == 1) {

					dt.next();
					sNewQueueId=Integer.parseInt(dt.getField("QUEUE_ID").toString());
				}

				//Get AUD_ID
				Sql  = "exec GTDPEND1..USP_CGET_AUDID1 '";
				Sql += sProcUnit;
				Sql += "'";
				logDebug("Exec Sql: [" + Sql + "]");

				//conn=getConnection();
				dt=conn.executeQuery(Sql);
				//close(conn);
				
				rowcount = dt.size();
				if ( rowcount == 1) {
					dt.next();
					sNewAudId=Long.parseLong(dt.getField("AUD_ID").toString());
				}

				logDebug("		sNewQueueId: " + sNewQueueId );

				hEntryResult.clear();
				hEntryResult.put(FIELD_PROC_UNIT, sProcUnit);
				hEntryResult.put(FIELD_QUEUE_TYP, sQueueTyp);
				hEntryResult.put(FIELD_MSG_TYP, sMsgTyp);
				hEntryResult.put(FIELD_QUEUE_ID, new Integer(sQueueId));
				hEntryResult.put(FIELD_NEW_QUEUE_ID, new Integer(sNewQueueId));
				hEntryResult.put(FIELD_ORIG_REF_NBR, sOrigRefNbr);
				hEntryResult.put(FIELD_PROD_CAT, sProdCat);
				hEntryResult.put(FIELD_PROD_TYP, sProdType);
				hEntryResult.put(FIELD_TRAN_TYP, sTranType);
				hEntryResult.put(FIELD_GTL_MSG_1, sGtlMsg1);
				hEntryResult.put(FIELD_GTL_MSG_2, sGtlMsg2);
				hEntryResult.put(FIELD_OP_TEAM_CD, sOpTeamCd);
				hEntryResult.put(FIELD_PROC_DT, sProcDt);
				hEntryResult.put(FIELD_AUD_ID, new Long(sNewAudId));
				hEntryResult.put(FIELD_RECV_DT, sRecvDt);
				hEntryResult.put(FIELD_EXT_REF_NBR, sExtRefNbr);
				hEntryResult.put(FIELD_SEND_RECV_ADDR, sSendRecvAddr);
				hEntryResult.put(FIELD_APPL_MSG_REF, sApplMsgRef);

				hEntryResult.put(FIELD_MSG_HEADER, sMsgHeader);
				hEntryResult.put(FIELD_CUR_CD, sCurCd);
				hEntryResult.put(FIELD_MSG_AMT, sMsgAmt);
				hEntryResult.put(FIELD_EXT_MSG_REF, sExtMsgRef);
				
				hEntryResult.put(FIELD_TRAN_REF_NBR, sTranRefNbr);
				hEntryResult.put(FIELD_TRAN_SEQ_NBR, new Integer(sTranSeqNbr));
				
				hEntryResult.put(FIELD_DDA_NBR, sDDANbr);
				hEntryResult.put(FIELD_NY_CR_REF, sNYCrRef);
				hEntryResult.put(FIELD_VAL_DT, sValDt);
				hEntryResult.put(FIELD_ITEM_OS, sItemOs);
				hEntryResult.put(FIELD_MSG_ID, new Integer(sMsgId));
				hEntryResult.put(FIELD_DR_CR_IND, sDrCrInd);
				hEntryResult.put(FIELD_STMT_SEQ_NBR, sStmtSeqNbr);
				hEntryResult.put(FIELD_STMT_LINE, sStmtLine);
				hEntryResult.put(FIELD_INFO2_ACCT_ONR, sInfo2AcctOnr);
					
				
				//if ((Insert_SI_MSG() == QS_SUCCEED) && (Insert_SI_MSG_Q() == QS_SUCCEED)){	
				if ((Insert_SI_MSG(hEntryResult)) && (Insert_SI_MSG_Q(hEntryResult))){
					//if (Insert_AUD_TRAIL() != QS_SUCCEED){	
					if (! Insert_AUD_TRAIL(hEntryResult)){
						logDebug("Fail to insert child message into AUD_TRAIL");
						logDebug("WARNING:: Process940: Fail to insert child message into AUD_TRAIL.");
						//return (QS_FAIL);
						return false;
					}
					logDebug("	Process940: Matched transaction created successfully.");
				}
				else {	
					logDebug("Fail to insert child message into SI_MSG and/or SI_MSG_Q");
					logDebug("WARNING:: Process940: Fail to insert child message into SI_MSG and/or SI_MSG_Q.");
					//return (QS_FAIL);
					return false;
					//return (QS_FAIL);
				}
					
				//Create a new entry in WK_AUTO_EC_CANC
				//if (Insert_WK_AUTO_EC_CANC() != QS_SUCCEED){
				if (! Insert_WK_AUTO_EC_CANC(hEntryResult)){
					logDebug("Fail to insert child message into WK_AUTO_EC_CANC.");
					logDebug("WARNING:: Process940: Fail to insert child message into WK_AUTO_EC_CANC.");
					//return (QS_FAIL);
					return false;
				}
				logDebug("Matched transaction created successfully [" + sNewQueueId + "]");
			}
			//More than 1 transaction, with different TRAN_REF_NBR, found in GTS
			//Do not create any child transaction, but keep in WK_AUTO_EC_CANC table
			//for user reference
			else {		//else (sMsgId == 0)

				//Need to create a new QUEUE_ID as it is the primary key in WK_AUTO_EC_CANC
				//Get QUEUE_ID
				Sql  = "GTDPEND1..USP_CGET_QUEUEID1 '";
				Sql += sProcUnit;
				Sql += "'";
				logDebug("Exec Sql: [" + Sql + "]");

				//conn=getConnection();
				dt=conn.executeQuery(Sql);
				//close(conn);
				
				
				//rowcount = (pDBRows->GetRowCount());
				rowcount = dt.size();
				if ( rowcount == 1){
					dt.next();
					sNewQueueId=Integer.parseInt(dt.getField("QUEUE_ID").toString());
				}
				
				hEntryResult.clear();
				hEntryResult.put(FIELD_PROC_UNIT, sProcUnit);
				hEntryResult.put(FIELD_QUEUE_TYP, sQueueTyp);
				hEntryResult.put(FIELD_MSG_TYP, sMsgTyp);
				hEntryResult.put(FIELD_QUEUE_ID, new Integer(sQueueId));
				hEntryResult.put(FIELD_NEW_QUEUE_ID, new Integer(sNewQueueId));
				hEntryResult.put(FIELD_ORIG_REF_NBR, sOrigRefNbr);
				hEntryResult.put(FIELD_PROD_CAT, sProdCat);
				hEntryResult.put(FIELD_PROD_TYP, sProdType);
				hEntryResult.put(FIELD_TRAN_TYP, sTranType);
				hEntryResult.put(FIELD_GTL_MSG_1, sGtlMsg1);
				hEntryResult.put(FIELD_GTL_MSG_2, sGtlMsg2);
				hEntryResult.put(FIELD_OP_TEAM_CD, sOpTeamCd);
				hEntryResult.put(FIELD_PROC_DT, sProcDt);
				hEntryResult.put(FIELD_AUD_ID, new Long(sNewAudId));
				hEntryResult.put(FIELD_RECV_DT, sRecvDt);
				hEntryResult.put(FIELD_EXT_REF_NBR, sExtRefNbr);
				hEntryResult.put(FIELD_SEND_RECV_ADDR, sSendRecvAddr);
				hEntryResult.put(FIELD_APPL_MSG_REF, sApplMsgRef);

				hEntryResult.put(FIELD_MSG_HEADER, sMsgHeader);
				hEntryResult.put(FIELD_CUR_CD, sCurCd);
				hEntryResult.put(FIELD_MSG_AMT, sMsgAmt);
				hEntryResult.put(FIELD_EXT_MSG_REF, sExtMsgRef);
				
				hEntryResult.put(FIELD_TRAN_REF_NBR, sTranRefNbr);
				hEntryResult.put(FIELD_TRAN_SEQ_NBR, new Integer(sTranSeqNbr));
				
				hEntryResult.put(FIELD_DDA_NBR, sDDANbr);
				hEntryResult.put(FIELD_NY_CR_REF, sNYCrRef);
				hEntryResult.put(FIELD_VAL_DT, sValDt);
				hEntryResult.put(FIELD_ITEM_OS, sItemOs);
				hEntryResult.put(FIELD_MSG_ID, new Integer(sMsgId));
				hEntryResult.put(FIELD_DR_CR_IND, sDrCrInd);
				hEntryResult.put(FIELD_STMT_SEQ_NBR, sStmtSeqNbr);
				hEntryResult.put(FIELD_STMT_LINE, sStmtLine);
				hEntryResult.put(FIELD_INFO2_ACCT_ONR, sInfo2AcctOnr);
				
				//if (Insert_WK_AUTO_EC_CANC() != QS_SUCCEED){	
				if (! Insert_WK_AUTO_EC_CANC(hEntryResult)){
					logDebug("Fail to insert into WK_AUTO_EC_CANC.");
					logDebug("WARNING:: Process940: Fail to insert into WK_AUTO_EC_CANC.");
					//return (QS_FAIL) ;
					return false;
				}
				//if (WK_AUTO_EC_CANC_P2T() != QS_SUCCEED){	
				if (! WK_AUTO_EC_CANC_P2T(hEntryResult)){	
					logDebug("Fail to insert into WK_AUTO_EC_CANC_P2T.");
					logDebug("WARNING:: Process940: Fail to WK_AUTO_EC_CANC_P2T.");
					//return (QS_FAIL) ;
					return false;
				}
				logDebug("Not Link Transaction or Debit Transaction.  No SI_MSG created [" + sExtRefNbr + "]");
			}	
		}	//for (msgcount = 1; (tempStr = GetRepeatTok(dtMsgContent, "\r\n:61:",msgcount))!= ""; msgcount++)

		hParentResult.remove(FIELD_ORIG_REF_NBR);
		hParentResult.remove(FIELD_DDA_NBR);
		hParentResult.put(FIELD_ORIG_REF_NBR, sOrigRefNbr);
		hParentResult.put(FIELD_DDA_NBR, sDDANbr);
		   
		//Update original message status to 'R' in SI_MSG_Q
		//if (Update_SI_MSGQ_P2R() != QS_SUCCEED)
		if (! Update_SI_MSGQ_P2R(hParentResult))
		{	logDebug("Fail to update parent message queue status in SI_MSG_Q.");


			logDebug("WARNING:: Process940: Fail to update parent message queue status in SI_MSG_Q.");
			//return (QS_FAIL);
			return false;
		}
		//cout << "	Process940: Parent message status update." << endl;
		logDebug("Process940: Parent message status updated [" + sQueueId + "]");
		
		//GWF: 940 MSG_TEXT=sMsgTxt(SI_MSG.MSG_CONTENT), that SI_MSG_Q.MSG_TEXT update in Update_SI_MSGQ_P2R before
		//Set in hParentResult and update in commitParentResult()
		dtMsgContent.BOF();
		sGtlMsg="";
		while(dtMsgContent.next())
			sGtlMsg=sGtlMsg+(String)dtMsgContent.getField(FIELD_MSG_CONTENT);
		
		logDebug("sGtlMsg = \n" + sGtlMsg);
		hParentResult.remove(FIELD_MSG_TEXT);
    	hParentResult.put(FIELD_MSG_TEXT, sGtlMsg);
		
		//return (QS_SUCCEED);
        return true;
	     
		}catch (Exception ex) {
	            logDebug((Throwable) ex);
			    logDebug("IMParseMappingExtractor.Process940: "+ex.getMessage()+". Return false");
				//throw new Exception(ex.getMessage());
			    return false;
	     }finally{
	    	 //close(conn);
	     }
	}
	
	private boolean Process942(Hashtable hParentResult) throws Exception{
		logDebug("Processing MT942 Msg");
		//IDataConnection  conn = null;
		DataTable dt;
		try{
	        String sProdCat  = "";
	        String sProdType = "";
	        String sExtRefNbr = "";
	        String sTranType = " ";
	        String sOrigRefNbr = " ";
	        
	        String sProcUnit=(String)hParentResult.get(FIELD_PROC_UNIT);
	        String sMsgTyp=(String)hParentResult.get(FIELD_MSG_TYP);
	        String sQueueTyp=(String)hParentResult.get(FIELD_QUEUE_TYP);
	        int sQueueId=((Integer)hParentResult.get(FIELD_QUEUE_ID)).intValue();
		    String sGtlMsg="";
	        String Sql="";
	        String sTranRefNbr="";
	        hParentResult.remove(FIELD_EXT_REF_NBR);
	        hParentResult.remove(FIELD_PROD_CAT);
	        hParentResult.remove(FIELD_PROD_TYP);
	        hParentResult.remove(FIELD_TRAN_REF_NBR);
	        hParentResult.put(FIELD_EXT_REF_NBR, sExtRefNbr);
	        hParentResult.put(FIELD_PROD_CAT, sProdCat);
	        hParentResult.put(FIELD_PROD_TYP, sProdType);
	        hParentResult.put(FIELD_TRAN_REF_NBR, sTranRefNbr);
			
	        String sOpTeamCd=(String)hParentResult.get(FIELD_OP_TEAM_CD);
	        String sMsgHeader=(String)hParentResult.get(FIELD_MSG_HEADER);
	        Timestamp sRecvDt=(Timestamp)hParentResult.get(FIELD_RECV_DT);
	        String sExtMsgRef=(String)hParentResult.get(FIELD_EXT_MSG_REF);
	        String sApplMsgRef=(String)hParentResult.get(FIELD_APPL_MSG_REF);
	        String sSendRecvAddr=(String)hParentResult.get(FIELD_SEND_RECV_ADDR);
	        
		DataTable dtMsgContent=GetMessage(hParentResult);
		
		// [Herman Lam] -- [11SEPT2006] 
		int len=0, head=0, headfront =0, headback =0, mid=0, tail=0, msgcount = 0, nComma;
		int mid_nxt=0; 
		// [Herman Lam] -- [END] 
		int isNonRef=0;
		int rowcount;
		
		String SwiftTag, tempStr;
		
		String sDDANbr="";
		String sStmtSeqNbr="";
		String sCurCd="";
		String sProcDt="";
		String sStmtLine="";
		String sInfo2AcctOnr="";
		String sDrCrInd="";
		int sTranSeqNbr=0;
		int sMsgId=0;
		String sGtlMsg1="";
		String sItemOs="";
		String sGtlMsg2="";
		long sNewAudId = 0;
		String sValDt= "";
		String sMsgAmt = "";
		String sNYCrRef="";
		int sNewQueueId=0;
		
		//To keep general information about the completed MT942 message

		//:20: (External) Transaction Reference Number
		if ( ! (SwiftTag =  GetTok(dtMsgContent, "\r\n:20:")).trim().equals(""))
		{
			len = SwiftTag.length();
			//if (SwiftTag.Right(2) == "\r\n")
			//tempStr=SwiftTag.substring(len-2);
			tempStr=Right(SwiftTag, 2);
			if (tempStr.trim().equals("\r\n"))
				sOrigRefNbr = Left(SwiftTag, len-2);
			else
				sOrigRefNbr = SwiftTag;
		}

		//:25: Account Identification [ie DDA Acount Number]
		if ( ! (SwiftTag = GetTok(dtMsgContent, "\r\n:25:")).trim().equals(""))
		{
			len = SwiftTag.length();
			//if (SwiftTag.Right(2) == "\r\n")
			//tempStr=SwiftTag.substring(len-2);
			tempStr=Right(SwiftTag, 2);
			if (tempStr.trim().equals("\r\n"))
				sDDANbr = Left(SwiftTag, len-2);
			else
				sDDANbr = SwiftTag;
		}

		//:28C: Statement Number/Sequence Number
		if ( ! (SwiftTag = GetTok(dtMsgContent, "\r\n:28C:")).trim().equals(""))
		{
			len = SwiftTag.length();
			//if (SwiftTag.Right(2) == "\r\n")
			//tempStr=SwiftTag.substring(len-2);
			tempStr=Right(SwiftTag, 2);
			if (tempStr.trim().equals("\r\n"))
				sStmtSeqNbr = Left(SwiftTag, len-2);
			else
				sStmtSeqNbr = SwiftTag;
		}

		//Get Currency in :60F: or :60M:
		if ( ! (SwiftTag = GetTok(dtMsgContent, "\r\n:34F:")).trim().equals(""))
		{
			//len = SwiftTag.GetLength();
			sCurCd = Left(SwiftTag, 3);
		}

		//Get PROC_DT
		//Sql  = "select THIS_PROC_DT ";
		Sql  = "select THIS_PROC_DT=convert(char(8), THIS_PROC_DT, 112) ";
		Sql += "from GTDMAST1..PROC_UNIT ";
		Sql += "where PROC_UNIT = '";
		Sql += sProcUnit;
		Sql += "'";
		logDebug("Exec Sql: [" + Sql + "]");

		//conn=getConnection();
		dt=conn.executeQuery(Sql);
		//close(conn);
		if(dt.size()==1){
			dt.next();
			sProcDt=(String)dt.getField("THIS_PROC_DT");
		}
		
		//Parsing SWIFT message
		//1. Keep fields 61 and 86
		//2. Extract MsgAmt, ExtRefNbr and NYCrRef in field 61
		//3. Using ExtRefNbr, check if any matched transaction in M1..TP_TRAN_HDR
		//4. If a matched transaction is found, create a new entry in SI_MSG and SI_MSG_Q with status = 'A'
		//   and create a new entry in WK_AUTO_EC_CANC
		for (msgcount = 1; !(tempStr = GetRepeatTok(dtMsgContent, "\r\n:61:",msgcount)).trim().equals(""); msgcount++)
		//for (msgcount = 1; (!(tempStr = GetRepeatTok("\r\n:61:",msgcount)).Compare("")); msgcount++)
		{
			//GWF: new Hashtable for entry result
			Hashtable hEntryResult=new Hashtable();
			
			if (! (SwiftTag = GetRepeatTok(dtMsgContent, "\r\n:61:",msgcount)).trim().equals(""))
			{
				len = SwiftTag.length();
				//if (SwiftTag.Right(2) == "\r\n")
				//tempStr=SwiftTag.substring(len-2);
				tempStr=Right(SwiftTag, 2);
				if (tempStr.trim().equals("\r\n"))
					sStmtLine = Left(SwiftTag, len-2);
				else
					sStmtLine = SwiftTag;
			//	sStmtLine = SwiftTag;
			}

//			if ((SwiftTag = GetRepeatTok("\r\n:86:",msgcount)) != "")
			if (! (SwiftTag = GetRepeatTok(dtMsgContent, "\r\n:61:",msgcount,"\r\n:86:")).trim().equals(""))
			{
				len = SwiftTag.length();
				//if (SwiftTag.Right(2) == "\r\n")
				//tempStr=SwiftTag.substring(len-2);
				tempStr=Right(SwiftTag, 2);
				if (tempStr.trim().equals("\r\n"))
					sInfo2AcctOnr = Left(SwiftTag, len-2);
				else
					sInfo2AcctOnr = SwiftTag;
			//	sInfo2AcctOnr = SwiftTag;
			} else {
				sInfo2AcctOnr = "";
			}

	logDebug("");
	logDebug("Process942: Looping -> Reading #" + msgcount + " transaction");
//	 cout << "	Process942: sStmtLine:61:-> " << sStmtLine << endl;
//	 cout << "	Process942: sInfo2AcctOnr:86:-> " << sInfo2AcctOnr << endl;

			// [Herman Lam] -- [11SEPT2006] 
			//To extract MsgAmt, ExtRefNbr and NYCrRef in field 61
			head = sStmtLine.indexOf("C");
			if ((head == -1) || (head > 10)) {
				head = sStmtLine.indexOf("D");	
				if ((head == -1) || (head > 10)) {
					head = -1;
				}
			}
			if (head != -1)
				logDebug(" head=" + head + ", value=" + sStmtLine.charAt(head) + ", valuefront=" + sStmtLine.charAt(head-1) + ", valueback=" + sStmtLine.charAt(head+1));
			else
				logDebug(" head == -1");
			
			if (head != -1 ) {
				//sDrCrInd =sStmtLine.substring(head, head + 1);
				sDrCrInd =Mid(sStmtLine, head, head + 1);
				if (!(Character.isDigit(sStmtLine.charAt(head+1)))) {	//For case 20061212CR10000
					headback = 1;
				} else {					//For case 20061212C10000
					headback = 0;
				}
				//if (!(ISNUM(sStmtLine.GetAt(head-1)))) {	//For case 20061212RC10000
				if (!(Character.isDigit(sStmtLine.charAt(head-1)))) {	//For case 20061212RC10000
					headfront = 1;
				} else {					//For case 20061212C10000
					headfront = 0;
				}
			}
			logDebug(" mid_nxt1=" + sStmtLine.charAt(mid+1) + ",  mid_nxt2=" + sStmtLine.charAt(mid+2));

			mid  = sStmtLine.indexOf(",");
			if (mid != -1) {
				if (!(Character.isDigit(sStmtLine.charAt(mid+1)))) {		//For case 10000,NTR
					mid_nxt = 0;
				} else if (!(Character.isDigit(sStmtLine.charAt(mid+2)))) {	//For case 10000,0NTR
					mid_nxt = 1;
				} else {					//For case 10000,00NTR
					mid_nxt = 2;
				}	
			}	
					
			tail = sStmtLine.indexOf("//");
			logDebug(" head=" + head + " headfront=" + headfront + " headback=" + headback + ", mid=" + mid + ", mid_nxt=" + mid_nxt +", tail=" + tail);
			// [Herman Lam] -- [END] 
			
			if (head != -1 && mid != -1 && tail != -1)
			{
				//sValDt = sStmtLine.Mid(head-6-headfront, 6);
				//sMsgAmt = sStmtLine.Mid(head+1+headback, mid+2+1-head-1-headback);
				//sValDt = sStmtLine.substring(head-6-headfront, head-headfront);
				sValDt = Mid(sStmtLine, head-6-headfront, head-headfront);
				//sMsgAmt = sStmtLine.substring(head+1+headback, mid+2+1);
				sMsgAmt = Mid(sStmtLine, head+1+headback, mid+2+1);
				
				//int nComma = sMsgAmt.Find(',');
				//if (nComma >= 0)
				//	sMsgAmt.SetAt(nComma, '.');
				sMsgAmt=sMsgAmt.replace(',', '.');
				
				//sExtRefNbr = sStmtLine.Mid(mid+7, tail-mid-7);
				//sExtRefNbr = sStmtLine.substring(mid+7, tail);
				sExtRefNbr = Mid(sStmtLine, mid+7, tail);
				
				//sNYCrRef = sStmtLine.Mid(tail+2, 14);
				//sNYCrRef = sStmtLine.substring(tail+2, tail+2+14);
				sNYCrRef = Mid(sStmtLine, tail+2, tail+2+14);
				//if (sNYCrRef.Right(2) == "\r\n")
				//tempStr=sNYCrRef.substring(sNYCrRef.length()-2);
				tempStr=Right(sNYCrRef, 2);
				if (tempStr.trim().equals("\r\n"))
					sNYCrRef = Left(sNYCrRef, sNYCrRef.length() - 2);
					
				logDebug("EXT_REF_NBR = " + sExtRefNbr);


				// [Herman Lam] -- [30AUG2006] 
				if ((sExtRefNbr.indexOf(CntNonRefNbr) == -1) && (sDrCrInd.indexOf("D") == -1) ){
					Sql = "exec GTDPEND1..USP_CCHK_EXIST_ENTRY '";
				        Sql += sProcUnit;
				        Sql += "', '";
					Sql += sExtRefNbr;
				        Sql += "', '";
				        Sql += sDDANbr;
				        Sql += "', '";
				        Sql += sCurCd;
				        Sql += "', '";
				        Sql += sQueueTyp;
				        Sql += "', '";
				        Sql += sMsgTyp;
				        Sql += "'";
					
					logDebug("Sql:   " + Sql);
					/*
					SetSql(Sql);
					ExecSql();

					if (!GetResult(&pDBRows)) {return (QS_FAIL) ;	}
					
					cout << "Get Result " << endl;
					*/
					//conn=getConnection();
					dt=conn.executeQuery(Sql);
					//close(conn);
					
					if(dt.size()>0){
						dt.next();
						sTranRefNbr=(String)dt.getField("TRAN_REF_NBR");
						logDebug("TRAN_REF_NBR: "+ sTranRefNbr);
						
						sTranSeqNbr=Integer.parseInt(dt.getField("TRAN_SEQ_NBR").toString());
						logDebug("TRAN_SEQ_NBR: "+ sTranSeqNbr);
	
						sProdCat=(String)dt.getField("PROD_CAT");
						logDebug("PROD_CAT: "+ sProdCat);
	
						sProdType=(String)dt.getField("PROD_TYP");
						logDebug("PROD_TYP: "+ sProdType);
	
						sTranType=(String)dt.getField("TRAN_TYP");
						logDebug("TRAN_TYP: "+ sTranType);
	
						sMsgId=Integer.parseInt(dt.getField("MSG_ID").toString());
						logDebug("MSG_ID: "+ sMsgId);
	
						sGtlMsg1=(String)dt.getField("MESSAGE");
						logDebug("MESSAGE: "+ sGtlMsg1 );
						
						sItemOs=(String)dt.getField("ITEM_OS");
						logDebug("ITEM_OS: "+ sItemOs );
					}
					//sGtlMsg2 =(sMsgId=="0")?"":"No SI_MSG created.";
					sGtlMsg2 =(sMsgId==0)?"":"No SI_MSG created.";
					logDebug("MESSAGE2: "+ sGtlMsg2 );

	       				//sNewAudId = "000000";
					sNewAudId = 0;
					
				} else {
					if (sExtRefNbr.indexOf(CntNonRefNbr) > -1) {
		       				sGtlMsg1 = "Not Link Transaction, due to DDA_REF = NONREF  ";
		       				//sMsgId = "49118";
		       				sMsgId = 49118;
					} else if (sDrCrInd.indexOf("D") > -1) {
		       				sGtlMsg1 = "Not Link Transaction, due to debit entry  ";
		       				//sMsgId = "49119";
		       				sMsgId = 49119;
					} else {
		       				sGtlMsg1 = "Not Link Transaction, due to invalid message ";
		       				//sMsgId = "49120";
		       				sMsgId = 49120;
					}		
							
					sTranRefNbr = "";		
					//sTranSeqNbr = "0";
					sTranSeqNbr = 0;
	       				sProdCat = " ";
	       				sProdType = " ";
	       				sTranType  = "";
	       				sGtlMsg2 = "No SI_MSG created.";
	       				//sNewAudId = "000000";
	       				sNewAudId = 0;
	       				sItemOs = "X";
				}
			} else {
				sValDt = "19000101";
				sMsgAmt = "0";
				//sExtRefNbr = FixQuote(sStmtLine.Mid(0,35));		// Use for Reconcilation Report
				//sNYCrRef = FixQuote(sStmtLine.Mid(36,16));		// Use for Reconcilation Report
				sExtRefNbr = FixQuote(Left(sStmtLine,35));		// Use for Reconcilation Report
				//sNYCrRef = FixQuote(sStmtLine.substring(36,36+16));		// Use for Reconcilation Report
				sNYCrRef = FixQuote(Mid(sStmtLine,36,36+16));		// Use for Reconcilation Report
				sGtlMsg1 = "Not Link Transaction, due to invalid swift message  ";
				//sMsgId = "49120";
				sMsgId = 49120;
				sTranRefNbr = "";		
				//sTranSeqNbr = "0";
				sTranSeqNbr = 0;
				sProdCat = " ";
				sProdType = " ";
				sTranType  = "";
				sGtlMsg2 = "No SI_MSG created.";
				//sNewAudId = "000000";
				sNewAudId = 0;
				sItemOs = "X";
			}

				// [Herman Lam] -- [END]
//	RM
//	cout << "M1..TP_MST_HDR Sql rowcount = " << rowcount << endl;
				//if a matched transaction is found for this sExtRefNbr
				
			//if (sMsgId == "0")
			if (sMsgId == 0)
			{
				logDebug( "Matched transaction found! [" + sTranRefNbr + "]");
				logDebug("	Process942: Matched transaction found!");
				logDebug("		sTranRefNbr: " + sTranRefNbr);
				// cout << "		sProdCat: " << sProdCat << endl;
				// cout << "		sProdTyp: " << sProdType << endl;

				sGtlMsg1 = ""; sGtlMsg2 = "";

				sGtlMsg1 = "MT";
				sGtlMsg1 += sMsgTyp;
				sGtlMsg1 += "\r\n";
				sGtlMsg1 +=  sProdCat;
				sGtlMsg1 += "/ ";
				sGtlMsg1 += sProdType;
				sGtlMsg1 += "\r\n";
				sGtlMsg1 += "Ref Nbr-> ";
				sGtlMsg1 += sExtRefNbr;
				sGtlMsg1 += "\r\n";
				sGtlMsg1 += "Tran Amt-> ";
				sGtlMsg1 += sCurCd;
				sGtlMsg1 += sMsgAmt;
				sGtlMsg1 += "\r\n";
				sGtlMsg1 += "NY Cr Ref-> ";
				sGtlMsg1 += sNYCrRef;
				sGtlMsg1 += "\r\n\n";

			//	sGtlMsg1 += ":61E: ";
			//	sGtlMsg1 += sExtRefNbr;
			//	sGtlMsg1 += "\r\n";
			//	sGtlMsg1 += ":60C ";
			//	sGtlMsg1 += sCurCd;
			//	sGtlMsg1 += "\r\n";
			//	sGtlMsg1 += ":61A ";
			//	sGtlMsg1 += sMsgAmt;
			//	sGtlMsg1 += "\r\n\n";

				sGtlMsg2 += ":20: ";
				sGtlMsg2 += sOrigRefNbr;
				sGtlMsg2 += "\r\n";
				sGtlMsg2 += ":25: ";
				sGtlMsg2 += sDDANbr;
				sGtlMsg2 += "\r\n";
				sGtlMsg2 += ":28C: ";
				sGtlMsg2 += sStmtSeqNbr;
				sGtlMsg2 += "\r\n";
				sGtlMsg2 += ":61: ";
				sGtlMsg2 += sStmtLine;
				sGtlMsg2 += "\r\n";
				sGtlMsg2 += ":86: ";
				sGtlMsg2 += sInfo2AcctOnr;
				sGtlMsg2 += "\r\n";

				//Insert record into SI_MSG and SI_MSG_Q status must be 'A'

				//Get QUEUE_ID
				Sql  = "exec GTDPEND1..USP_CGET_QUEUEID1 '";
				Sql += sProcUnit;
				Sql += "'";
				logDebug("Exec Sql: [" + Sql + "]");

				//conn=getConnection();
				dt=conn.executeQuery(Sql);
				//close(conn);
				
				//rowcount = (pDBRows->GetRowCount());
				rowcount = dt.size();
				if ( rowcount == 1) {
					dt.next();
					sNewQueueId=Integer.parseInt(dt.getField("QUEUE_ID").toString());
				}

//				//Get AUD_ID
//				Sql  = "USP_CGET_AUDID1 '";
//				Sql += sProcUnit;
//				Sql += "'";
//				WriteErrLog("Exec Sql: [" + Sql + "]");
//				SetSql(Sql);
//				ExecSql();
	//
//				if (!GetResult(&pDBRows)) {
//			                //ThrowQSException(QS_QSERVER_ERROR);
//			                WriteErrLog("Error return from stored proc [" + Sql + "]");
//			                cout << "Error return from stored proc USP_CGET_AUDID1" << endl;
//					return (QS_FAIL) ;
//				}
	//
//				rowcount = (pDBRows->GetRowCount());
//				if ( rowcount == 1) {
//					p = pDBRows->GetAttr("AUD_ID");
//					ASSERT(p != NULL);
//					if (p != NULL)
//						p->GetValue(sNewAudId);
//				}
	//
//				cout << "		sNewQueueId: " << sNewQueueId << endl;
				//cout << "		sNewAudId: " << sNewAudId << endl;
				//cout << "		sProcDt: " << sProcDt << endl;

//				if ((Insert_SI_MSG() == QS_SUCCEED) && (Insert_SI_MSG_Q() == QS_SUCCEED)){	
//					if (Insert_AUD_TRAIL() != QS_SUCCEED){	
//						WriteErrLog("Fail to insert child message into AUD_TRAIL");
//						cout << "WARNING:: Process942: Fail to insert child message into AUD_TRAIL." << endl;
//	        				return (QS_FAIL) ;
//					}
//					cout << "	Process942: Matched transaction created successfully." << endl;
//				}
//				else {	
//					WriteErrLog("Fail to insert child message into SI_MSG and/or SI_MSG_Q");
//					cout << "WARNING:: Process942: Fail to insert child message into SI_MSG and/or SI_MSG_Q." << endl;
//					return (QS_FAIL) ;
//					//return (QS_FAIL);
//				}
				
				
				hEntryResult.clear();
				hEntryResult.put(FIELD_PROC_UNIT, sProcUnit);
				hEntryResult.put(FIELD_QUEUE_TYP, sQueueTyp);
				hEntryResult.put(FIELD_MSG_TYP, sMsgTyp);
				hEntryResult.put(FIELD_QUEUE_ID, new Integer(sQueueId));
				hEntryResult.put(FIELD_NEW_QUEUE_ID, new Integer(sNewQueueId));
				hEntryResult.put(FIELD_ORIG_REF_NBR, sOrigRefNbr);
				hEntryResult.put(FIELD_PROD_CAT, sProdCat);
				hEntryResult.put(FIELD_PROD_TYP, sProdType);
				hEntryResult.put(FIELD_TRAN_TYP, sTranType);
				hEntryResult.put(FIELD_GTL_MSG_1, sGtlMsg1);
				hEntryResult.put(FIELD_GTL_MSG_2, sGtlMsg2);
				hEntryResult.put(FIELD_OP_TEAM_CD, sOpTeamCd);
				hEntryResult.put(FIELD_PROC_DT, sProcDt);
				hEntryResult.put(FIELD_AUD_ID, new Long(sNewAudId));
				hEntryResult.put(FIELD_RECV_DT, sRecvDt);
				hEntryResult.put(FIELD_EXT_REF_NBR, sExtRefNbr);
				hEntryResult.put(FIELD_SEND_RECV_ADDR, sSendRecvAddr);
				hEntryResult.put(FIELD_APPL_MSG_REF, sApplMsgRef);

				hEntryResult.put(FIELD_MSG_HEADER, sMsgHeader);
				hEntryResult.put(FIELD_CUR_CD, sCurCd);
				hEntryResult.put(FIELD_MSG_AMT, sMsgAmt);
				hEntryResult.put(FIELD_EXT_MSG_REF, sExtMsgRef);
				
				hEntryResult.put(FIELD_TRAN_REF_NBR, sTranRefNbr);
				hEntryResult.put(FIELD_TRAN_SEQ_NBR, new Integer(sTranSeqNbr));
				
				hEntryResult.put(FIELD_DDA_NBR, sDDANbr);
				hEntryResult.put(FIELD_NY_CR_REF, sNYCrRef);
				hEntryResult.put(FIELD_VAL_DT, sValDt);
				hEntryResult.put(FIELD_ITEM_OS, sItemOs);
				hEntryResult.put(FIELD_MSG_ID, new Integer(sMsgId));
				hEntryResult.put(FIELD_DR_CR_IND, sDrCrInd);
				hEntryResult.put(FIELD_STMT_SEQ_NBR, sStmtSeqNbr);
				hEntryResult.put(FIELD_STMT_LINE, sStmtLine);
				hEntryResult.put(FIELD_INFO2_ACCT_ONR, sInfo2AcctOnr);
				
				
				//Create a new entry in WK_AUTO_EC_CANC
				//if (Insert_WK_AUTO_EC_CANC() != QS_SUCCEED){	
				if (! Insert_WK_AUTO_EC_CANC(hEntryResult)){
					logDebug("Fail to insert child message into WK_AUTO_EC_CANC.");
					logDebug("WARNING:: Process942: Fail to insert child message into WK_AUTO_EC_CANC.");
					//return (QS_FAIL) ;
					return false;
				}
				//if (WK_AUTO_EC_CANC_P2T() != QS_SUCCEED){	
				if (! WK_AUTO_EC_CANC_P2T(hEntryResult)){
					logDebug("Fail to insert into WK_AUTO_EC_CANC_P2T.");
					logDebug("WARNING:: Process942: Fail to WK_AUTO_EC_CANC_P2T.");
					//return (QS_FAIL) ;
					return false;
				}
				logDebug("Matched transaction created successfully [" + sNewQueueId + "]");
			}
			//More than 1 transaction, with different TRAN_REF_NBR, found in GTS
			//Do not create any child transaction, but keep in WK_AUTO_EC_CANC table
			//for user reference
			else {		//else if (sMsgId == 0)
				//Need to create a new QUEUE_ID as it is the primary key in WK_AUTO_EC_CANC
				//Get QUEUE_ID
				Sql  = "exec GTDPEND1..USP_CGET_QUEUEID1 '";
				Sql += sProcUnit;
				Sql += "'";
				logDebug("Exec Sql: [" + Sql + "]");
				
				//conn=getConnection();
				dt=conn.executeQuery(Sql);
				//close(conn);
				rowcount = dt.size();
				if ( rowcount == 1){
					dt.next();
					sNewQueueId=Integer.parseInt(dt.getField("QUEUE_ID").toString());
				}
				
				hEntryResult.clear();
				hEntryResult.put(FIELD_PROC_UNIT, sProcUnit);
				hEntryResult.put(FIELD_QUEUE_TYP, sQueueTyp);
				hEntryResult.put(FIELD_MSG_TYP, sMsgTyp);
				hEntryResult.put(FIELD_QUEUE_ID, new Integer(sQueueId));
				hEntryResult.put(FIELD_NEW_QUEUE_ID, new Integer(sNewQueueId));
				hEntryResult.put(FIELD_ORIG_REF_NBR, sOrigRefNbr);
				hEntryResult.put(FIELD_PROD_CAT, sProdCat);
				hEntryResult.put(FIELD_PROD_TYP, sProdType);
				hEntryResult.put(FIELD_TRAN_TYP, sTranType);
				hEntryResult.put(FIELD_GTL_MSG_1, sGtlMsg1);
				hEntryResult.put(FIELD_GTL_MSG_2, sGtlMsg2);
				hEntryResult.put(FIELD_OP_TEAM_CD, sOpTeamCd);
				hEntryResult.put(FIELD_PROC_DT, sProcDt);
				hEntryResult.put(FIELD_AUD_ID, new Long(sNewAudId));
				hEntryResult.put(FIELD_RECV_DT, sRecvDt);
				hEntryResult.put(FIELD_EXT_REF_NBR, sExtRefNbr);
				hEntryResult.put(FIELD_SEND_RECV_ADDR, sSendRecvAddr);
				hEntryResult.put(FIELD_APPL_MSG_REF, sApplMsgRef);

				hEntryResult.put(FIELD_MSG_HEADER, sMsgHeader);
				hEntryResult.put(FIELD_CUR_CD, sCurCd);
				hEntryResult.put(FIELD_MSG_AMT, sMsgAmt);
				hEntryResult.put(FIELD_EXT_MSG_REF, sExtMsgRef);
				
				hEntryResult.put(FIELD_TRAN_REF_NBR, sTranRefNbr);
				hEntryResult.put(FIELD_TRAN_SEQ_NBR, new Integer(sTranSeqNbr));
				
				hEntryResult.put(FIELD_DDA_NBR, sDDANbr);
				hEntryResult.put(FIELD_NY_CR_REF, sNYCrRef);
				hEntryResult.put(FIELD_VAL_DT, sValDt);
				hEntryResult.put(FIELD_ITEM_OS, sItemOs);
				hEntryResult.put(FIELD_MSG_ID, new Integer(sMsgId));
				hEntryResult.put(FIELD_DR_CR_IND, sDrCrInd);
				hEntryResult.put(FIELD_STMT_SEQ_NBR, sStmtSeqNbr);
				hEntryResult.put(FIELD_STMT_LINE, sStmtLine);
				hEntryResult.put(FIELD_INFO2_ACCT_ONR, sInfo2AcctOnr);
				
				//if (Insert_WK_AUTO_EC_CANC() != QS_SUCCEED){	
				if (! Insert_WK_AUTO_EC_CANC(hEntryResult)){
					logDebug("Fail to insert into WK_AUTO_EC_CANC.");
					logDebug("WARNING:: Process942: Fail to insert into WK_AUTO_EC_CANC.");
					//return (QS_FAIL) ;
					return false;
				}
				//if (WK_AUTO_EC_CANC_P2T() != QS_SUCCEED){	
				if (! WK_AUTO_EC_CANC_P2T(hEntryResult)){
					logDebug("Fail to insert into WK_AUTO_EC_CANC_P2T.");
					logDebug("WARNING:: Process942: Fail to WK_AUTO_EC_CANC_P2T.");
					//return (QS_FAIL) ;
					return false;
				}
				logDebug("Not Link Transaction or Debit Transaction.  No SI_MSG created [" + sExtRefNbr + "]");
			}	
		}
		
		hParentResult.remove(FIELD_ORIG_REF_NBR);
		hParentResult.remove(FIELD_DDA_NBR);
		hParentResult.put(FIELD_ORIG_REF_NBR, sOrigRefNbr);
		hParentResult.put(FIELD_DDA_NBR, sDDANbr);
		//Update original message status to 'R' in SI_MSG_Q
		//if (Update_SI_MSGQ_P2R() != QS_SUCCEED)
		if (! Update_SI_MSGQ_P2R(hParentResult))
		{	logDebug("Fail to update parent message queue status in SI_MSG_Q.");
			logDebug("WARNING:: Process942: Fail to update parent message queue status in SI_MSG_Q.");
			//return (QS_FAIL);
			return false;
		}
		//cout << "	Process942: Parent message status update." << endl;
		logDebug("Process942: Parent message status updated [" + sQueueId + "]");
		
		//return (QS_SUCCEED);
		
		
		//GWF: 942 MSG_TEXT=sMsgTxt(SI_MSG.MSG_CONTENT), that SI_MSG_Q.MSG_TEXT update in Update_SI_MSGQ_P2R before
		//Set in hParentResult and update in commitParentResult()
		dtMsgContent.BOF();
		sGtlMsg="";
		while(dtMsgContent.next())
			sGtlMsg=sGtlMsg+(String)dtMsgContent.getField(FIELD_MSG_CONTENT);
		
		logDebug("sGtlMsg = \n" + sGtlMsg);
		hParentResult.remove(FIELD_MSG_TEXT);
    	hParentResult.put(FIELD_MSG_TEXT, sGtlMsg);
        return true;
	     
	 }catch (Exception ex) {
            logDebug((Throwable) ex);
		    logDebug("IMParseMappingExtractor.Process942: "+ex.getMessage()+". Return false");
			//throw new Exception(ex.getMessage());
		    return false;
     }finally{
    	 //close(conn);
     }
	}
	
	private boolean Process950(Hashtable hParentResult) throws Exception{
		logDebug("Processing MT950 Msg");
		//IDataConnection  conn = null;
		DataTable dt;
		try{
	        String sProdCat  = "";
	        String sProdType = "";
	        String sExtRefNbr = "";
	        String sTranType = " ";
	        String sOrigRefNbr = " ";
	        
	        String sProcUnit=(String)hParentResult.get(FIELD_PROC_UNIT);
	        String sMsgTyp=(String)hParentResult.get(FIELD_MSG_TYP);
	        String sQueueTyp=(String)hParentResult.get(FIELD_QUEUE_TYP);
	        int sQueueId=((Integer)hParentResult.get(FIELD_QUEUE_ID)).intValue();
		    String sGtlMsg="";
	        String Sql="";
	        String sTranRefNbr="";
	        hParentResult.remove(FIELD_EXT_REF_NBR);
	        hParentResult.remove(FIELD_PROD_CAT);
	        hParentResult.remove(FIELD_PROD_TYP);
	        hParentResult.remove(FIELD_TRAN_REF_NBR);
	        hParentResult.put(FIELD_EXT_REF_NBR, sExtRefNbr);
	        hParentResult.put(FIELD_PROD_CAT, sProdCat);
	        hParentResult.put(FIELD_PROD_TYP, sProdType);
	        hParentResult.put(FIELD_TRAN_REF_NBR, sTranRefNbr);
			
	        String sOpTeamCd=(String)hParentResult.get(FIELD_OP_TEAM_CD);
	        String sMsgHeader=(String)hParentResult.get(FIELD_MSG_HEADER);
	        Timestamp sRecvDt=(Timestamp)hParentResult.get(FIELD_RECV_DT);
	        String sExtMsgRef=(String)hParentResult.get(FIELD_EXT_MSG_REF);
	        String sApplMsgRef=(String)hParentResult.get(FIELD_APPL_MSG_REF);
	        String sSendRecvAddr=(String)hParentResult.get(FIELD_SEND_RECV_ADDR);
	        
		DataTable dtMsgContent=GetMessage(hParentResult);

		// [Herman Lam] -- [11SEPT2006] 
		int len=0, head=0, headfront =0, headback =0, mid=0, tail=0, msgcount = 0, nComma;
		int mid_nxt=0; 
		// [Herman Lam] -- [END] 
		String SwiftTag, tempStr;
		int rowcount;
		
		String sDDANbr="";
		String sStmtSeqNbr="";
		String sCurCd="";
		String sProcDt="";
		String sStmtLine="";
		String sInfo2AcctOnr="";
		String sDrCrInd="";
		int sTranSeqNbr=0;
		int sMsgId=0;
		String sGtlMsg1="";
		String sItemOs="";
		String sGtlMsg2="";
		long sNewAudId = 0;
		String sValDt= "";
		String sMsgAmt = "";
		String sNYCrRef="";
		int sNewQueueId=0;
		
		//To keep general information about the completed MT940 message
		//:20: (External) Transaction Reference Number
		if ( ! (SwiftTag =  GetTok(dtMsgContent, "\r\n:20:")).trim().equals(""))
		{
			len = SwiftTag.length();
			//if (SwiftTag.Right(2) == "\r\n")
			//tempStr=SwiftTag.substring(len-2);
			tempStr=Right(SwiftTag,2);
			if (tempStr.trim().equals("\r\n"))
				sOrigRefNbr = Left(SwiftTag, len-2);
			else
				sOrigRefNbr = SwiftTag;
		}

		//:25: Account Identification [ie DDA Acount Number]
		if ( ! (SwiftTag = GetTok(dtMsgContent, "\r\n:25:")).trim().equals(""))
		{
			len = SwiftTag.length();
			//if (SwiftTag.Right(2) == "\r\n")
			//tempStr=SwiftTag.substring(len-2);
			tempStr=Right(SwiftTag,2);
			if (tempStr.trim().equals("\r\n"))
				sDDANbr = Left(SwiftTag, len-2);
			else
				sDDANbr = SwiftTag;
		}

		//:28C: Statement Number/Sequence Number
		if ( ! (SwiftTag = GetTok(dtMsgContent, "\r\n:28C:")).trim().equals(""))
		{
			len = SwiftTag.length();
			//if (SwiftTag.Right(2) == "\r\n")
			//tempStr=SwiftTag.substring(len-2);
			tempStr=Right(SwiftTag,2);
			if (tempStr.trim().equals("\r\n"))
				sStmtSeqNbr = Left(SwiftTag, len-2);
			else
				sStmtSeqNbr = SwiftTag;
		}

		//Get Currency in :60F: or :60M:
		if ( ! (SwiftTag = GetTok(dtMsgContent, "\r\n:60F:")).trim().equals(""))
		{
			//len = SwiftTag.GetLength();
			//sCurCd = SwiftTag.Mid(7, 3);
			//sCurCd = SwiftTag.substring(7, 7+3);
			sCurCd = Mid(SwiftTag, 7, 7+3);
		}
		else if ( ! (SwiftTag = GetTok(dtMsgContent, "\r\n:60M:")).trim().equals(""))
		{
			//len = SwiftTag.GetLength();
			//sCurCd = SwiftTag.Mid(7, 3);
			//sCurCd = SwiftTag.substring(7, 7+3);
			sCurCd = Mid(SwiftTag, 7, 7+3);
		}

		//Get PROC_DT
		//Sql  = "select THIS_PROC_DT ";
		Sql  = "select THIS_PROC_DT=convert(char(8), THIS_PROC_DT, 112) ";
		Sql += "from GTDMAST1..PROC_UNIT ";
		Sql += "where PROC_UNIT = '";
		Sql += sProcUnit;
		Sql += "'";
		logDebug("Exec Sql: [" + Sql + "]");
		
		//conn=getConnection();
		dt=conn.executeQuery(Sql);
		//close(conn);
				
		rowcount = dt.size();
		if ( rowcount == 1)
		{
			dt.next();
			sProcDt=(String)dt.getField("THIS_PROC_DT");
		}
//	RM
//	cout << "Process950: sOrigRefNbr:20:-> " << sOrigRefNbr << endl;
//	cout << "Process950: sDDANbr:25:-> " << sDDANbr << endl;
//	cout << "Process950: sStmtSeqNbr:28C:-> " << sStmtSeqNbr << endl;
//	cout << "Process950: sCurCd:60:-> " << sCurCd << endl;

		//Parsing SWIFT message
		//1. Keep field 61
		//2. Extract MsgAmt, ExtRefNbr and NYCrRef in field 61
		//3. Using ExtRefNbr, check if any matched transaction in M1..TP_TRAN_HDR
		//4. If a matched transaction is found, create a new entry in SI_MSG and SI_MSG_Q
		//   and create a new entry in WK_AUTO_EC_CANC
		for (msgcount = 1; !(tempStr = GetRepeatTok(dtMsgContent, "\r\n:61:",msgcount)).trim().equals(""); msgcount++)
		{
			//GWF: New Hashtable for entry result
			Hashtable hEntryResult=new Hashtable();
			
			if (! (SwiftTag = GetRepeatTok(dtMsgContent, "\r\n:61:",msgcount)).trim().equals(""))
			{
				len = SwiftTag.length();
				//if (SwiftTag.Right(2) == "\r\n")
				//tempStr=SwiftTag.substring(len-2);
				tempStr=Right(SwiftTag,2);
				if (tempStr.trim().equals("\r\n"))
					sStmtLine = Left(SwiftTag, len-2);
				else
					sStmtLine = SwiftTag;
			//	sStmtLine = SwiftTag;
			}

	logDebug("Process950: Looping -> Reading #" + msgcount + " transaction");
//	 cout << "	Process950: sStmtLine:61:-> " << sStmtLine << endl;

			// [Herman Lam] -- [11SEPT2006] 
			//To extract MsgAmt, ExtRefNbr and NYCrRef in field 61
			head = sStmtLine.indexOf("C");
			if ((head == -1) || (head > 10)) {
				head = sStmtLine.indexOf("D");	
				if ((head == -1) || (head > 10)) {
					head = -1;
				}
			}
			if (head != -1)
				logDebug(" head=" + head + ", value=" + sStmtLine.charAt(head) + ", valuefront=" + sStmtLine.charAt(head-1) + ", valueback=" + sStmtLine.charAt(head+1));
			else
				logDebug(" head == -1");
			if (head != -1 ) {
				//sDrCrInd =sStmtLine.Mid(head, 1);
				//sDrCrInd =sStmtLine.substring(head, head+1);
				sDrCrInd =Mid(sStmtLine, head, head+1);
				//if (!(ISNUM(sStmtLine.GetAt(head+1)))) {	//For case 20061212CR10000
				if (!(Character.isDigit(sStmtLine.charAt(head+1)))) {	//For case 20061212CR10000
					headback = 1;
				} else {					//For case 20061212C10000
					headback = 0;
				}
				if (!(Character.isDigit(sStmtLine.charAt(head-1)))) {	//For case 20061212RC10000
					headfront = 1;
				} else {					//For case 20061212C10000
					headfront = 0;
				}
			}
			logDebug(" mid_nxt1=" + sStmtLine.charAt(mid+1) + ",  mid_nxt2=" + sStmtLine.charAt(mid+2));

			mid  = sStmtLine.indexOf(",");
			if (mid != -1) {
				//if (!(ISNUM(sStmtLine.GetAt(mid+1)))) {		//For case 10000,NTR
				if (!(Character.isDigit(sStmtLine.charAt(mid+1)))) {		//For case 10000,NTR
					mid_nxt = 0;
				//} else if (!(ISNUM(sStmtLine.GetAt(mid+2)))) {	//For case 10000,0NTR
				} else if (!(Character.isDigit(sStmtLine.charAt(mid+2)))) {	//For case 10000,0NTR
					mid_nxt = 1;
				} else {					//For case 10000,00NTR
					mid_nxt = 2;
				}	
			}	
			
			tail = sStmtLine.indexOf("//");
			logDebug(" head=" + head + " headfront=" + headfront + " headback=" + headback + ", mid=" + mid + ", mid_nxt=" + mid_nxt +", tail=" + tail);
			// [Herman Lam] -- [END] 

			if (head != -1 && mid != -1 && tail != -1)
			{
				//sValDt = sStmtLine.Mid(head-6-headfront, 6);
				//sMsgAmt = sStmtLine.Mid(head+1+headback, mid+2+1-head-1-headback);
				//sValDt = sStmtLine.substring(head-6-headfront, head-headfront);
				sValDt = Mid(sStmtLine, head-6-headfront, head-headfront);
				//sMsgAmt = sStmtLine.substring(head+1+headback, mid+2+1);
				sMsgAmt = Mid(sStmtLine, head+1+headback, mid+2+1);
				//int nComma = sMsgAmt.Find(',');
				//if (nComma >= 0)
				//	sMsgAmt.SetAt(nComma, '.');
				sMsgAmt=sMsgAmt.replace(',', '.');
				
				//sExtRefNbr = sStmtLine.Mid(mid+7, tail-mid-7);
				//sExtRefNbr = sStmtLine.substring(mid+7, tail);
				sExtRefNbr = Mid(sStmtLine, mid+7, tail);
				
				//sNYCrRef = sStmtLine.Mid(tail+2, 14);
				//sNYCrRef = sStmtLine.substring(tail+2, tail+2+14);
				sNYCrRef = Mid(sStmtLine, tail+2, tail+2+14);
				//if (sNYCrRef.Right(2) == "\r\n")
				//tempStr=sNYCrRef.substring(sNYCrRef.length()-2);
				tempStr=Right(sNYCrRef, 2);
				if (tempStr.trim().equals("\r\n"))
					sNYCrRef = Left(sNYCrRef, sNYCrRef.length() - 2);

				logDebug("EXT_REF_NBR = " + sExtRefNbr);

				// [Herman Lam] -- [30AUG2006] 
				if ((sExtRefNbr.indexOf(CntNonRefNbr) == -1) && (sDrCrInd.indexOf("D") == -1) ){
					Sql = "exec GTDPEND1..USP_CCHK_EXIST_ENTRY '";
				        Sql += sProcUnit;
				        Sql += "', '";
					Sql += sExtRefNbr;
				        Sql += "', '";
				        Sql += sDDANbr;
				        Sql += "', '";
				        Sql += sCurCd;
				        Sql += "', '";
				        Sql += sQueueTyp;
				        Sql += "', '";
				        Sql += sMsgTyp;
				        Sql += "'";
					
					logDebug("Sql:   " + Sql);
					/*
					SetSql(Sql);
					ExecSql();

					if (!GetResult(&pDBRows)) {return (QS_FAIL) ;	}
					*/
					//conn=getConnection();
					dt=conn.executeQuery(Sql);
					//close(conn);
					
					logDebug("Get Result ");
					
					if(dt.size()>0){
						dt.next();
						
						sTranRefNbr=(String)dt.getField("TRAN_REF_NBR");
						logDebug("TRAN_REF_NBR: "+ sTranRefNbr);
						
						sTranSeqNbr=Integer.parseInt(dt.getField("TRAN_SEQ_NBR").toString());
						logDebug("TRAN_SEQ_NBR: "+ sTranSeqNbr);
	
						sProdCat=(String)dt.getField("PROD_CAT");
						logDebug("PROD_CAT: "+ sProdCat);
	
						sProdType=(String)dt.getField("PROD_TYP");
						logDebug("PROD_TYP: "+ sProdType);
	
						sTranType=(String)dt.getField("TRAN_TYP");
						logDebug("TRAN_TYP: "+ sTranType);
	
						sMsgId=Integer.parseInt(dt.getField("MSG_ID").toString());
						logDebug("MSG_ID: "+ sMsgId );
	
						sGtlMsg1=(String)dt.getField("MESSAGE");
						logDebug("MESSAGE: "+ sGtlMsg1);
						
						sItemOs=(String)dt.getField("ITEM_OS");
						logDebug("ITEM_OS: "+ sItemOs);
					}
					//sGtlMsg2 =(sMsgId=="0")?"":"No SI_MSG created.";
					sGtlMsg2 =(sMsgId==0)?"":"No SI_MSG created.";
					logDebug("MESSAGE2: "+ sGtlMsg2);

	       				//sNewAudId = "000000";
					sNewAudId = 0;
					
				} else {
					if (sExtRefNbr.indexOf(CntNonRefNbr) > -1) {
		       				sGtlMsg1 = "Not Link Transaction, due to DDA_REF = NONREF  ";
		       				//sMsgId = "49118";
		       				sMsgId = 49118;
					} else if (sDrCrInd.indexOf("D") > -1) {
		       				sGtlMsg1 = "Not Link Transaction, due to debit entry  ";
		       				//sMsgId = "49119";
		       				sMsgId = 49119;
					} else {
		       				sGtlMsg1 = "Not Link Transaction, due to invalid message  ";
		       				//sMsgId = "49120";
		       				sMsgId = 49120;
					}		
							
					sTranRefNbr = "";		
					//sTranSeqNbr = "0";
					sTranSeqNbr = 0;
	       				sProdCat = " ";
	       				sProdType = " ";
	       				sTranType  = "";
	       				sGtlMsg2 = "No SI_MSG created.";
	       				//sNewAudId = "000000";
	       				sNewAudId = 0;
	       				sItemOs = "X";
				}
			} else {
				sValDt = "19000101";
				sMsgAmt = "0";
				//sExtRefNbr = FixQuote(sStmtLine.Mid(0,35));		// Use for Reconcilation Report
				//sNYCrRef = FixQuote(sStmtLine.Mid(36,16));		// Use for Reconcilation Report
				sExtRefNbr = FixQuote(Left(sStmtLine,35));		// Use for Reconcilation Report
				//sNYCrRef = FixQuote(sStmtLine.substring(36,36+16));		// Use for Reconcilation Report
				sNYCrRef = FixQuote(Mid(sStmtLine,36,36+16));		// Use for Reconcilation Report
				sGtlMsg1 = "Not Link Transaction, due to invalid swift message  ";
				//sMsgId = "49120";
				sMsgId = 49120;
				sTranRefNbr = "";		
				//sTranSeqNbr = "0";
				sTranSeqNbr = 0;
				sProdCat = " ";
				sProdType = " ";
				sTranType  = "";
				sGtlMsg2 = "No SI_MSG created.";
				//sNewAudId = "000000";
				sNewAudId = 0;
				sNewAudId = 0;
				sItemOs = "X";
			}
			// [Herman Lam] -- [END]
//	RM 
//	cout << "M1..TP_MST_HDR Sql rowcount = " << rowcount << endl;

				//if a matched transaction is found for this sExtRefNbr
			//if (sMsgId == "0")
			if (sMsgId == 0)
			{

	logDebug( "Matched transaction found! [" + sTranRefNbr + "]");
	logDebug("	Process950: Matched transaction found.");
	logDebug("		sTranRefNbr: " + sTranRefNbr);
//	 cout << "		sProdCat: " << sProdCat << endl;
//	 cout << "		sProdTyp: " << sProdType << endl;

				sGtlMsg1 = ""; sGtlMsg2 = "";

				sGtlMsg1 = "MT";
				sGtlMsg1 += sMsgTyp;
				sGtlMsg1 += "\r\n";
				sGtlMsg1 +=  sProdCat;
				sGtlMsg1 += "/ ";
				sGtlMsg1 += sProdType;
				sGtlMsg1 += "\r\n";
				sGtlMsg1 += "Ref Nbr-> ";
				sGtlMsg1 += sExtRefNbr;
				sGtlMsg1 += "\r\n";
				sGtlMsg1 += "Tran Amt-> ";
				sGtlMsg1 += sCurCd;
				sGtlMsg1 += sMsgAmt;
				sGtlMsg1 += "\r\n";
				sGtlMsg1 += "NY Cr Ref-> ";
				sGtlMsg1 += sNYCrRef;
				sGtlMsg1 += "\r\n\n";

			//	sGtlMsg1 += ":61E: ";
			//	sGtlMsg1 += sExtRefNbr;
			//	sGtlMsg1 += "\r\n";
			//	sGtlMsg1 += ":60C ";
			//	sGtlMsg1 += sCurCd;
			//	sGtlMsg1 += "\r\n";
			//	sGtlMsg1 += ":61A ";
			//	sGtlMsg1 += sMsgAmt;
			//	sGtlMsg1 += "\r\n";

				sGtlMsg2 += ":20: ";
				sGtlMsg2 += sOrigRefNbr;
				sGtlMsg2 += "\r\n";
				sGtlMsg2 += ":25: ";
				sGtlMsg2 += sDDANbr;
				sGtlMsg2 += "\r\n";
				sGtlMsg2 += ":28C: ";
				sGtlMsg2 += sStmtSeqNbr;
				sGtlMsg2 += "\r\n";
				sGtlMsg2 += ":61: ";
				sGtlMsg2 += sStmtLine;
				sGtlMsg2 += "\r\n";

				//Insert record into SI_MSG and SI_MSG_Q  status must be 'A'

				//Get QUEUE_ID
				Sql  = "GTDPEND1..USP_CGET_QUEUEID1 '";
				Sql += sProcUnit;
				Sql += "'";
				logDebug("Exec Sql: [" + Sql + "]");

				//conn=getConnection();
				dt=conn.executeQuery(Sql);
				//close(conn);
								
				//int rowcount = (pDBRows->GetRowCount());
				rowcount = dt.size();
				
				if ( rowcount == 1)
				{
					dt.next();
					sNewQueueId=Integer.parseInt(dt.getField("QUEUE_ID").toString());
				}

				//Get AUD_ID
				Sql  = "exec GTDPEND1..USP_CGET_AUDID1 '";
				Sql += sProcUnit;
				Sql += "'";
				logDebug("Exec Sql: [" + Sql + "]");

				//conn=getConnection();
				dt=conn.executeQuery(Sql);
				//close(conn);

				rowcount = dt.size();
				if ( rowcount == 1)
				{
					dt.next();
					sNewAudId=Long.parseLong(dt.getField("AUD_ID").toString());
				}

				logDebug("		sNewQueueId: " + sNewQueueId);

				hEntryResult.clear();
				hEntryResult.put(FIELD_PROC_UNIT, sProcUnit);
				hEntryResult.put(FIELD_QUEUE_TYP, sQueueTyp);
				hEntryResult.put(FIELD_MSG_TYP, sMsgTyp);
				hEntryResult.put(FIELD_QUEUE_ID, new Integer(sQueueId));
				hEntryResult.put(FIELD_NEW_QUEUE_ID, new Integer(sNewQueueId));
				hEntryResult.put(FIELD_ORIG_REF_NBR, sOrigRefNbr);
				hEntryResult.put(FIELD_PROD_CAT, sProdCat);
				hEntryResult.put(FIELD_PROD_TYP, sProdType);
				hEntryResult.put(FIELD_TRAN_TYP, sTranType);
				hEntryResult.put(FIELD_GTL_MSG_1, sGtlMsg1);
				hEntryResult.put(FIELD_GTL_MSG_2, sGtlMsg2);
				hEntryResult.put(FIELD_OP_TEAM_CD, sOpTeamCd);
				hEntryResult.put(FIELD_PROC_DT, sProcDt);
				hEntryResult.put(FIELD_AUD_ID, new Long(sNewAudId));
				hEntryResult.put(FIELD_RECV_DT, sRecvDt);
				hEntryResult.put(FIELD_EXT_REF_NBR, sExtRefNbr);
				hEntryResult.put(FIELD_SEND_RECV_ADDR, sSendRecvAddr);
				hEntryResult.put(FIELD_APPL_MSG_REF, sApplMsgRef);

				hEntryResult.put(FIELD_MSG_HEADER, sMsgHeader);
				hEntryResult.put(FIELD_CUR_CD, sCurCd);
				hEntryResult.put(FIELD_MSG_AMT, sMsgAmt);
				hEntryResult.put(FIELD_EXT_MSG_REF, sExtMsgRef);
				
				hEntryResult.put(FIELD_TRAN_REF_NBR, sTranRefNbr);
				hEntryResult.put(FIELD_TRAN_SEQ_NBR, new Integer(sTranSeqNbr));
				
				hEntryResult.put(FIELD_DDA_NBR, sDDANbr);
				hEntryResult.put(FIELD_NY_CR_REF, sNYCrRef);
				hEntryResult.put(FIELD_VAL_DT, sValDt);
				hEntryResult.put(FIELD_ITEM_OS, sItemOs);
				hEntryResult.put(FIELD_MSG_ID, new Integer(sMsgId));
				hEntryResult.put(FIELD_DR_CR_IND, sDrCrInd);
				hEntryResult.put(FIELD_STMT_SEQ_NBR, sStmtSeqNbr);
				hEntryResult.put(FIELD_STMT_LINE, sStmtLine);
				hEntryResult.put(FIELD_INFO2_ACCT_ONR, sInfo2AcctOnr);
				
				//if ((Insert_SI_MSG() == QS_SUCCEED) && (Insert_SI_MSG_Q() == QS_SUCCEED))
				if ((Insert_SI_MSG(hEntryResult)) && (Insert_SI_MSG_Q(hEntryResult)))
				{
					//if (Insert_AUD_TRAIL() != QS_SUCCEED)
					if (! Insert_AUD_TRAIL(hEntryResult))
					{		
						logDebug("Fail to insert child message into AUD_TRAIL");
						logDebug("WARNING:: Process950: Fail to insert child message into AUD_TRAIL.");
	        				//return (QS_FAIL) ;
						return false;
					}
					logDebug("	Process950: Matched transaction created successfully.");
				}
				else
				{	
					logDebug("Fail to insert child message into SI_MSG and/or SI_MSG_Q");
					logDebug("WARNING:: Process950: Fail to insert child message into SI_MSG and/or SI_MSG_Q.");
					//return (QS_FAIL) ;
					return false;
					//return (QS_FAIL);
				}

				//Create a new entry in WK_AUTO_EC_CANC
				//if (Insert_WK_AUTO_EC_CANC() != QS_SUCCEED)
				if (! Insert_WK_AUTO_EC_CANC(hEntryResult))
				{	
					logDebug("Fail to insert child message into WK_AUTO_EC_CANC.");
					logDebug("WARNING:: Process950: Fail to insert child message into WK_AUTO_EC_CANC.");
					//return (QS_FAIL) ;
					return false;
				}
				logDebug("Matched transaction created successfully [" + sNewQueueId + "]");
			}
			//More than 1 transaction, with different TRAN_REF_NBR, found in GTS
			//Do not create any child transaction, but keep in WK_AUTO_EC_CANC table
			//for user reference
			else 
			{		
				//Need to create a new QUEUE_ID as it is the primary key in WK_AUTO_EC_CANC
				//Get QUEUE_ID
				Sql  = "GTDPEND1..USP_CGET_QUEUEID1 '";
				Sql += sProcUnit;
				Sql += "'";
				logDebug("Exec Sql: [" + Sql + "]");

				//conn=getConnection();
				dt=conn.executeQuery(Sql);
				//close(conn);
				rowcount=dt.size();
				if ( rowcount == 1)
				{
					dt.next();
					sNewQueueId=Integer.parseInt(dt.getField("QUEUE_ID").toString());
				}
				
				hEntryResult.clear();
				hEntryResult.put(FIELD_PROC_UNIT, sProcUnit);
				hEntryResult.put(FIELD_QUEUE_TYP, sQueueTyp);
				hEntryResult.put(FIELD_MSG_TYP, sMsgTyp);
				hEntryResult.put(FIELD_QUEUE_ID, new Integer(sQueueId));
				hEntryResult.put(FIELD_NEW_QUEUE_ID, new Integer(sNewQueueId));
				hEntryResult.put(FIELD_ORIG_REF_NBR, sOrigRefNbr);
				hEntryResult.put(FIELD_PROD_CAT, sProdCat);
				hEntryResult.put(FIELD_PROD_TYP, sProdType);
				hEntryResult.put(FIELD_TRAN_TYP, sTranType);
				hEntryResult.put(FIELD_GTL_MSG_1, sGtlMsg1);
				hEntryResult.put(FIELD_GTL_MSG_2, sGtlMsg2);
				hEntryResult.put(FIELD_OP_TEAM_CD, sOpTeamCd);
				hEntryResult.put(FIELD_PROC_DT, sProcDt);
				hEntryResult.put(FIELD_AUD_ID, new Long(sNewAudId));
				hEntryResult.put(FIELD_RECV_DT, sRecvDt);
				hEntryResult.put(FIELD_EXT_REF_NBR, sExtRefNbr);
				hEntryResult.put(FIELD_SEND_RECV_ADDR, sSendRecvAddr);
				hEntryResult.put(FIELD_APPL_MSG_REF, sApplMsgRef);

				hEntryResult.put(FIELD_MSG_HEADER, sMsgHeader);
				hEntryResult.put(FIELD_CUR_CD, sCurCd);
				hEntryResult.put(FIELD_MSG_AMT, sMsgAmt);
				hEntryResult.put(FIELD_EXT_MSG_REF, sExtMsgRef);
				
				hEntryResult.put(FIELD_TRAN_REF_NBR, sTranRefNbr);
				hEntryResult.put(FIELD_TRAN_SEQ_NBR, new Integer(sTranSeqNbr));
				
				hEntryResult.put(FIELD_DDA_NBR, sDDANbr);
				hEntryResult.put(FIELD_NY_CR_REF, sNYCrRef);
				hEntryResult.put(FIELD_VAL_DT, sValDt);
				hEntryResult.put(FIELD_ITEM_OS, sItemOs);
				hEntryResult.put(FIELD_MSG_ID, new Integer(sMsgId));
				hEntryResult.put(FIELD_DR_CR_IND, sDrCrInd);
				hEntryResult.put(FIELD_STMT_SEQ_NBR, sStmtSeqNbr);
				hEntryResult.put(FIELD_STMT_LINE, sStmtLine);
				hEntryResult.put(FIELD_INFO2_ACCT_ONR, sInfo2AcctOnr);
				
				//if (Insert_WK_AUTO_EC_CANC() != QS_SUCCEED)
				if (! Insert_WK_AUTO_EC_CANC(hEntryResult))
				{	logDebug("Fail to insert into WK_AUTO_EC_CANC.");
					logDebug("WARNING:: Process950: Fail to insert into WK_AUTO_EC_CANC.");
					//return (QS_FAIL) ;
					return false;
				}
				//if (WK_AUTO_EC_CANC_P2T() != QS_SUCCEED)
				if (! WK_AUTO_EC_CANC_P2T(hEntryResult))
				{	logDebug("Fail to insert into WK_AUTO_EC_CANC_P2T.");
					logDebug("WARNING:: Process950: Fail to WK_AUTO_EC_CANC_P2T.");
					//return (QS_FAIL) ;
					return false;
				}
				logDebug("Not Link Transaction or Debit Transaction.  No SI_MSG created [" + sExtRefNbr + "]");
			}	
			// Herman Lam --End
		}	//for (msgcount = 1; (tempStr = GetRepeatTok(dtMsgContent, "\r\n:61:",msgcount))!= ""; msgcount++)

		hParentResult.remove(FIELD_ORIG_REF_NBR);
		hParentResult.remove(FIELD_DDA_NBR);
		hParentResult.put(FIELD_ORIG_REF_NBR, sOrigRefNbr);
		hParentResult.put(FIELD_DDA_NBR, sDDANbr);
		
		//Update original message status to 'R' in SI_MSG_Q
		//if (Update_SI_MSGQ_P2R() != QS_SUCCEED)
		if (! Update_SI_MSGQ_P2R(hParentResult))
		{	logDebug("Fail to update parent message queue status in SI_MSG_Q.");

			logDebug("WARNING:: Process950: Fail to update parent message queue status in SI_MSG_Q.");
			//return (QS_FAIL);
			return false;
		}
		//cout << "	Process950: Parent message status update." << endl;
		logDebug("Process950: Parent message status updated [" + sQueueId + "]");

		//return (QS_SUCCEED);
		
		//GWF: 950 MSG_TEXT=sMsgTxt(SI_MSG.MSG_CONTENT), that SI_MSG_Q.MSG_TEXT update in Update_SI_MSGQ_P2R before
		//Set in hParentResult and update in commitParentResult()
		dtMsgContent.BOF();
		sGtlMsg="";
		while(dtMsgContent.next())
			sGtlMsg=sGtlMsg+(String)dtMsgContent.getField(FIELD_MSG_CONTENT);
		
		logDebug("sGtlMsg = \n" + sGtlMsg);
		hParentResult.remove(FIELD_MSG_TEXT);
    	hParentResult.put(FIELD_MSG_TEXT, sGtlMsg);
        return true;
	     
	 }catch (Exception ex) {
            logDebug((Throwable) ex);
		    logDebug("IMParseMappingExtractor.Process950: "+ex.getMessage()+". Return false");
			//throw new Exception(ex.getMessage());
		    return false;
     }finally{
    	 //close(conn);
     }
	}
	
	private boolean Process720(Hashtable hParentResult) throws Exception{
		logDebug("Processing MT720 Msg");
		
		DataTable dtMsgContent=GetMessage(hParentResult);
        
		/*
        CString sMsg = CString("");

        int ArraySz = MsgArray.GetSize();

        for (int incr = 0; incr < ArraySz; incr++) {

                sMsg += *((CString *) MsgArray[incr]);
        }

		sGtlMsg = sMsg;

		cout << "MT720 sGtlMsg = [" << sGtlMsg << "]" << endl;
        Update_SI_MSGQ();
 
        return (QS_SUCCEED);
		*/
		
		String sGtlMsg="";
		dtMsgContent.BOF();
		while(dtMsgContent.next())
			sGtlMsg=sGtlMsg+(String)dtMsgContent.getField(FIELD_MSG_CONTENT);
		
		logDebug("sGtlMsg = \n" + sGtlMsg);
		//Update_SI_MSGQ();
		
    	hParentResult.remove(FIELD_MSG_TEXT);
    	hParentResult.put(FIELD_MSG_TEXT, sGtlMsg);
    	
        return true;
	}
	
	private boolean Process705(Hashtable hParentResult) throws Exception{
		logDebug("Processing MT705 Msg");
		
		DataTable dtMsgContent=GetMessage(hParentResult);
        
		String sGtlMsg="";
		dtMsgContent.BOF();
		while(dtMsgContent.next())
			sGtlMsg=sGtlMsg+(String)dtMsgContent.getField(FIELD_MSG_CONTENT);
		
		logDebug("sGtlMsg = \n" + sGtlMsg);
		//Update_SI_MSGQ();
		
    	hParentResult.remove(FIELD_MSG_TEXT);
    	hParentResult.put(FIELD_MSG_TEXT, sGtlMsg);
    	
        return true;
	}
	
	private boolean Process799(Hashtable hParentResult) throws Exception{
		logDebug("Processing MT799 Msg");
		
		DataTable dtMsgContent=GetMessage(hParentResult);
        
		String sGtlMsg="";
		dtMsgContent.BOF();
		while(dtMsgContent.next())
			sGtlMsg=sGtlMsg+(String)dtMsgContent.getField(FIELD_MSG_CONTENT);
		
		logDebug("sGtlMsg = \n" + sGtlMsg);
		//Update_SI_MSGQ();
		
    	hParentResult.remove(FIELD_MSG_TEXT);
    	hParentResult.put(FIELD_MSG_TEXT, sGtlMsg);
    	
        return true;
	}
	
	private boolean Process760(Hashtable hParentResult) throws Exception{
		logDebug("Processing MT760 Msg");
		
		DataTable dtMsgContent=GetMessage(hParentResult);
        
        if (MT760_to_Gtl(hParentResult, dtMsgContent)){
        	logDebug("Process760(): MT760_to_Gtl Success");
        }
        else
        {
        	logDebug("Process760(): MT760_to_Gtl Failed");
            //Update_SI_MSGQ_Fail();
            return false;
        }

        return true;
	}
	
	private boolean Process767(Hashtable hParentResult) throws Exception{
		logDebug("Processing MT767 Msg");
		
		DataTable dtMsgContent=GetMessage(hParentResult);
        
        if (MT767_to_Gtl(hParentResult, dtMsgContent)){
        	logDebug("Process767(): MT767_to_Gtl Success");
        }
        else
        {
        	logDebug("Process767(): MT767_to_Gtl Failed");
            //Update_SI_MSGQ_Fail();
            return false;
        }

        return true;
	}

	private boolean Process410(Hashtable hParentResult) throws Exception{
		logDebug("Processing MT410 Msg");
		
		DataTable dtMsgContent=GetMessage(hParentResult);
        
        if (MT410_to_Gtl(hParentResult, dtMsgContent)){
        	logDebug("Process410(): MT410_to_Gtl Success");
        	//Update_SI_MSGQ_AutoReg();
        }
        else
        {
        	logDebug("Process410(): MT410_to_Gtl Failed");
            //Update_SI_MSGQ_Fail();
            return false;
        }

        return true;
	}
	
	private boolean Process412(Hashtable hParentResult) throws Exception{
		logDebug("Processing MT412 Msg");
		
		DataTable dtMsgContent=GetMessage(hParentResult);
        
        if (MT412_to_Gtl(hParentResult, dtMsgContent)){
        	logDebug("Process412(): MT412_to_Gtl Success");
        	//Update_SI_MSGQ_AutoReg();
        }
        else
        {
        	logDebug("Process412(): MT412_to_Gtl Failed");
            //Update_SI_MSGQ_Fail();
            return false;
        }

        return true;
	}
	
	private boolean Process430(Hashtable hParentResult) throws Exception{
		logDebug("Processing MT430 Msg");
		
		DataTable dtMsgContent=GetMessage(hParentResult);
        
        if (MT430_to_Gtl(hParentResult, dtMsgContent)){
        	logDebug("Process430(): MT430_to_Gtl Success");
        	//Update_SI_MSGQ();
        }
        else
        {
        	logDebug("Process430(): MT430_to_Gtl Failed");
            //Update_SI_MSGQ_Fail();
            return false;
        }

        return true;
	}
	
	
	private boolean MT700_to_Gtl(Hashtable hParentResult, DataTable dtMsgContent) throws Exception
	{
		 logDebug("Start MT700_to_Gtl()");
	     try{
			// Convert Swift to GTL and update the SI_MSG_Q
	        int len = 0;
	        String sTag40A  = "C\r\n";
	        String SwiftTag;
	        String sCustId;
	        String SndSwfAddr=(String)hParentResult.get(FIELD_SEND_RECV_ADDR);
	        String sMsgHeader=(String)hParentResult.get(FIELD_MSG_HEADER);
	        String sTmpTranType;

	        String sProdCat  = "ELC";
	        String sLcTyp    = "C";
	        String sProdType = "";
	        String sExtRefNbr = "";
	        String sSenderRef = " ";
	        String sRecvRef = " ";
	        String sIssuBnkRef = " ";
	        String sTranType = " ";
	        String sOrigRefNbr = " ";
	        //20021113, Davy, Start
	        String sConfigVal = " ";
	        String sIsDefaultDummyCust = " ";
	        String sDummyId = " ";
	        DataTable dt;
	        //20021113, Davy, End
	        
	        String sProcUnit=(String)hParentResult.get(FIELD_PROC_UNIT);
	        String sMsgTyp=(String)hParentResult.get(FIELD_MSG_TYP);
	        String sGtlMsg="";
	        String Sql="";
	        String sTranRefNbr="";
	        hParentResult.remove(FIELD_EXT_REF_NBR);
	        hParentResult.remove(FIELD_PROD_CAT);
	        hParentResult.remove(FIELD_PROD_TYP);
	        hParentResult.remove(FIELD_TRAN_REF_NBR);
	        hParentResult.put(FIELD_EXT_REF_NBR, sExtRefNbr);
	        hParentResult.put(FIELD_PROD_CAT, sProdCat);
	        hParentResult.put(FIELD_PROD_TYP, sProdType);
	        hParentResult.put(FIELD_TRAN_REF_NBR, sTranRefNbr);
	        
	        hParentResult.remove(FIELD_LC_TYP);
	        hParentResult.put(FIELD_LC_TYP, sLcTyp);
	        
	        //char cFirstChar=' ';
	        
        //	20030818
		/*
	        // Documentary Credit Number (Tag 20)
	        if ((SwiftTag = GetTok("\r\n:20:")) != "") {
	                len = SwiftTag.Find("\r\n");
	                if (len != -1)
	                        sOrigRefNbr = SwiftTag.Mid(0, len);
	        else
	            sOrigRefNbr = SwiftTag;
	        }

	        sSenderRef  = sOrigRefNbr;
	        sIssuBnkRef = sOrigRefNbr;
		*/
//	20030818
	        
	    	//**** [EMEA]---[20060706]
	    	sGtlMsg = sProdCat; sGtlMsg += sMsgTyp;
	    	sGtlMsg += "\r\n";

	    	if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:20:")).trim().equals("")) {
	    		len = SwiftTag.indexOf("\r\n");
	    		if (len != -1)
	    			sOrigRefNbr = Left(SwiftTag, len);
	    		else
	    			sOrigRefNbr = SwiftTag;
	    	}

	    	sSenderRef  = sOrigRefNbr;
	    	sIssuBnkRef = sOrigRefNbr;
	    	
	    	hParentResult.remove(FIELD_SENDER_REF);
	    	hParentResult.remove(FIELD_RECV_REF);
	    	hParentResult.remove(FIELD_ISSU_BNK_REF);
	    	hParentResult.put(FIELD_SENDER_REF, sSenderRef);
		    hParentResult.put(FIELD_RECV_REF, sRecvRef);
		    hParentResult.put(FIELD_ISSU_BNK_REF, sIssuBnkRef);


	    	if (! sOrigRefNbr.trim().equals("")) {
	    		sGtlMsg += ":20:";
	    		sGtlMsg += sOrigRefNbr;
	    		sGtlMsg += "\r\n";
	    	}
	    	//**** [EMEA]---[END]

		//20021113, Davy, Start
// /* GWF: Skip Generate EXT_REF_NBR/TRAN_REF_NBR - Comment Start
	    	
//	    	20021113, Davy, Start
	    	if (sMsgTyp == "700") {
	    		sConfigVal=getPUConfig(sProcUnit, "INSWF_PARSE_GEN_REF");
	    		//sConfigVal = sConfigVal.SpanExcluding(" ");
	    		if (sConfigVal.trim().equals("Y"))	{
	    			logDebug("Before the process to Generate the ExtRefNbr...");
	    			
	    			//Get the CUST_ID first for get EXT_REF_NBR
	    			if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:59:")).trim().equals("")) {
    					if (SwiftTag.charAt(0) == '/') { // using [/34x] format. Ignore Acct Num
    						int nLineFeed = SwiftTag.indexOf('\n');
    						++nLineFeed;
    						SwiftTag = Mid(SwiftTag, nLineFeed, nLineFeed + SwiftTag.length());
    					}
    					
    					//---[EMEA]---[20060928]
    					sIsDefaultDummyCust=getPUConfig(sProcUnit, "DEFAULT_DUMMY_WALKIN_CUST");

						if (sIsDefaultDummyCust.trim().equals("Y"))
						{
							sDummyId=getPUConfig(sProcUnit, "DUMMY_WALKIN_CUST");
						}
						else
						{
							sDummyId=FindCustIdFromName(SwiftTag, sProcUnit);
							if(sDummyId.trim().equals("")){
								sDummyId=getPUConfig(sProcUnit, "DEFAULT_DUMMY_WALKIN_CUST");
								logDebug("Cannot find CustID for (" + SwiftTag + "), so use DUMMY_WALKIN_CUST (" + sDummyId + ")");
							}
						}
						
						hParentResult.remove(FIELD_DUMMY_ID);
				    	hParentResult.put(FIELD_DUMMY_ID, sDummyId);
    					// ---[EMEA]---[END]
	    			}			
	    			
	    			if (! GetExtRefNbr (hParentResult)) {
                        logDebug("Testing for the GetExtRefNbr ......... GetExtRefNbr failed");
                        // GWF: Do not return false if GetExtRefNbr failure
                        //return false;
	                }else{
	                	logDebug("Testing for the GetExtRefNbr ......... GetExtRefNbr success");
	                	sExtRefNbr=(String)hParentResult.get(FIELD_EXT_REF_NBR);
                    	sProdCat=(String)hParentResult.get(FIELD_PROD_CAT);
                    	sProdType=(String)hParentResult.get(FIELD_PROD_TYP);
                    	sTranRefNbr=(String)hParentResult.get(FIELD_TRAN_REF_NBR);
	                }
	    			if (sExtRefNbr.trim().equals("")) {
	    				if (! selectTranType (hParentResult)) {
	    					logDebug("Testing for selectTranType..........selectTranType failed");
	    					//GWF: Do not return false if selectTranType failed
	    					//return (QS_FAIL);
	    				}else{
	    					sProdType=(String)hParentResult.get(FIELD_PROD_TYP);
                			sTranType=(String)hParentResult.get(FIELD_TRAN_TYP);
                			sProdCat=(String)hParentResult.get(FIELD_PROD_CAT);
	    				}
	    				if (! GenNewTranRefNbr(hParentResult)) {
                            logDebug("Testing for GenNewTranRefNbr.......... GenNewTranRefNbr failed");
                            //GWF: Do not return false if GenNewTranRefNbr failed
                            //return (QS_FAIL);
	                    }
						else{
							logDebug("Testing for GenNewTranRefNbr.......... GenNewTranRefNbr success");
							sExtRefNbr=(String)hParentResult.get(FIELD_EXT_REF_NBR);
						}
	    				if (sExtRefNbr.trim().equals("")) {
	    					logDebug("Error in getting EXT_REF_NBR for MT700");
                            logDebug("The ExtRefNbr is not generated");
                            //GWF: Do not return false if generate sExtRefNbr fail
                            //return (QS_FAIL);
	    				}
	    				logDebug("The ExtRefNbr is generated");
	    			}else{
	    				// [EMEA]---[20060706]
	    				// Get the TranType in the PADV case
	    				sTmpTranType = sTranType;
	    				sTmpTranType.trim();
	    				if (sTmpTranType.equals(""))
	    				{
	    					if (! selectTranType (hParentResult)) {
	    						logDebug("Testing for selectTranType..........selectTranType failed");
	    						//GWF: Do not return false if selectTranType failed
		    					//return (QS_FAIL);
	    					}else
	    					{
	    						sProdType=(String)hParentResult.get(FIELD_PROD_TYP);
                    			sTranType=(String)hParentResult.get(FIELD_TRAN_TYP);
                    			sProdCat=(String)hParentResult.get(FIELD_PROD_CAT);
	    					}

	    					logDebug("The TranType is generated. sTranType = " + sTranType);
	    				}
	    			}

	    		}
	    		else if (sConfigVal.trim().equals("N"))	{
	    			/*if (selectTranType () == QS_FAIL) {
	    				cout << "Testing for selectTranType.........." << endl;
	    				return (QS_FAIL);
	    			}*/
	    			logDebug("The process will not Generate the ExtRefNbr..." );
	    		}

	    	}
	    	//20021113, Davy, End
	    	else if (sMsgTyp.trim().equals("705")) {
				/*if (selectTranType () == QS_FAIL)
				return (QS_FAIL);*/
				//if (GenNewTranRefNbr() == QS_FAIL)
	        	if(! GenNewTranRefNbr(hParentResult)){
					logDebug("sMsgTyp=700. GenNewTranRefNbr failed");
	        		//GWF: Do not return false
					//return (QS_FAIL);
	        	}else{
	        		logDebug("sMsgTyp=700. GenNewTranRefNbr success");
	        		sExtRefNbr=(String)hParentResult.get(FIELD_EXT_REF_NBR);
	        	}
				if (sExtRefNbr.trim().equals(""))
	            {
					logDebug("Error in getting EXT_REF_NBR for MT705");
					//GWF: Do not return false
					//return (QS_FAIL);
				}
	    	}

	        
// GWF: Skip Generate EXT_REF_NBR/TRAN_REF_NBR - Comment End */
	        
	        // Construct GTL alike Msg

//	20030818
	/*
	        sGtlMsg += "\r\n:00B:";
	        sGtlMsg += sTag40A;
	*/
//	20030818
//	20030818
	/*
	        if (sOrigRefNbr != "") {
				sGtlMsg += ":20:";
	            sGtlMsg += sExtRefNbr;
				sGtlMsg += "\r\n";
				sGtlMsg += ":20Z:";
				sGtlMsg += sOrigRefNbr;
				sGtlMsg += "\r\n";
				sGtlMsg += ":20Y:";
				sGtlMsg += sOrigRefNbr;
				sGtlMsg += "\r\n";
	        }

		// Value Date
		CString sValDt;
		Sql  = "select convert(char(6), getdate(), 12) as VALUE_DT";
		SetSql(Sql);
		ExecSql();
		if (!GetResult(&pDBRows))
			return (QS_FAIL) ;
	        p = pDBRows->GetAttr("VALUE_DT");
			ASSERT(p != NULL);
			if (p != NULL)
				p->GetValue(sValDt);
			sGtlMsg += ":00D:";
			sGtlMsg += CheckDt(sValDt);
			sGtlMsg += "\r\n";
		*/
//	20030818

//	****

//	      ASIA3.0
			// Value Date
			String sValDt="";
			Sql  = "select convert(char(6), getdate(), 12) as VALUE_DT";
			/*
			SetSql(Sql);
			ExecSql();
			if (!GetResult(&pDBRows))
				return (QS_FAIL) ;
	        p = pDBRows->GetAttr("VALUE_DT");
			ASSERT(p != NULL);
			if (p != NULL)
				p->GetValue(sValDt);
			*/
			//conn=getConnection();
			dt=conn.executeQuery(Sql);
			//close(conn);
			if(dt.size()>0){
				dt.next();
				sValDt=(String)dt.getField("VALUE_DT");
			}
			sGtlMsg += ":00D:";
			sGtlMsg += CheckDt(sValDt);
			sGtlMsg += "\r\n";
	    	
	    	//ASIA3.0		
	    	// Reference to Pre-Advice (Tag 23)
	    	if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:23:")).trim().equals("")){
	    		sGtlMsg += ":23:";
	    		sGtlMsg += SwiftTag;
	    		sGtlMsg += "\r\n";
	    	}

	    	// Sequence of Total (Tag 27)
	    	if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:27:")).trim().equals("")){
	    		sGtlMsg += ":27:";
	    		sGtlMsg += SwiftTag;
	    		sGtlMsg += "\r\n";
	    	}

	    	//ASIA3.0
	    	// Date of Issue (Tag 31C)
	    	if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:31C:")).trim().equals("")){
	    		sConfigVal=getPUConfig(sProcUnit, "SWF_USE_AUTO_MAP");
	    		if (! sConfigVal.equals("")) {   		
	    			sGtlMsg += ":31C:";
	    			sGtlMsg += CheckDt(SwiftTag);
	    			sGtlMsg += "\r\n";
	    		}
	    		else {
	    			sGtlMsg += ":31C:";
	    			sGtlMsg += SwiftTag;
	    			sGtlMsg += "\r\n";			
	    		}
	    	}

	    	// Date and Place of Expiry (Tag 31D)
	    	if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:31D:")).trim().equals("")){
	    		sConfigVal=getPUConfig(sProcUnit, "SWF_USE_AUTO_MAP");
	    		if (! sConfigVal.equals("")) {   		
	    			sGtlMsg += ":31D:";
	    			sGtlMsg += CheckDt(Mid(SwiftTag, 0, 6));
	    			sGtlMsg += "X";
	    			sGtlMsg += Mid(SwiftTag, 6, 6 + (SwiftTag.length() - 6));
	    			sGtlMsg += "\r\n";
	    		}
	    		else {
	    			sGtlMsg += ":31D:";
	    			sGtlMsg += SwiftTag;
	    			sGtlMsg += "\r\n";			
	    		}	
	    	}
	    	//ASIA3.0
	    	// Currency Code, Amount (Tag 32B)
	    	if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:32B:")).trim().equals("")){
	    		sGtlMsg += ":32B:";
	    		sGtlMsg += SwiftTag;
	    		sGtlMsg += "\r\n";
	    	}

	    	// Currency Code, Amount (Tag 39A)
	    	if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:39A:")).trim().equals("")){
	    		sGtlMsg += ":39A:";
	    		sGtlMsg += SwiftTag;
	    		sGtlMsg += "\r\n";
	    	}

	    	// Maximum Credit Amount (Tag 39B)
	    	if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:39B:")).trim().equals("")){
	    		sGtlMsg += ":39B:";
	    		sGtlMsg += SwiftTag;
	    		sGtlMsg += "\r\n";
	    	}

	    	// Additional Amounts Covered (Tag 39C)
	    	if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:39C:")).trim().equals("")){
	    		sGtlMsg += ":39C:";
	    		sGtlMsg += SwiftTag;
	    		sGtlMsg += "\r\n";
	    	}

	    	// Form of Documentary Credit (Tag 40A)
	    	if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:40A:")).trim().equals("")){
	    		sGtlMsg += ":40A:";
	    		sGtlMsg += SwiftTag;
	    		sGtlMsg += "\r\n";
	    	}

	    	// Applicable Rule (Tag 40E)
	    	if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:40E:")).trim().equals("")){
	    		sGtlMsg += ":40E:";
	    		sGtlMsg += SwiftTag;
	    		sGtlMsg += "\r\n";
	    	}

	    	// Available With... By... (Tag 41A)
	    	if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:41A:")).trim().equals("")){
	    		sGtlMsg += ":41A:";
	    		sGtlMsg += SwiftTag;
	    		sGtlMsg += "\r\n";
	    	}

	    	// Available With... By... (Tag 41D)
	    	if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:41D:")).trim().equals("")){
	    		sGtlMsg += ":41D:";
	    		sGtlMsg += SwiftTag;
	    		sGtlMsg += "\r\n";
	    	}

	    	// Drawee (Tag 42A)
	    	if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:42A:")).trim().equals("")){
	    		sGtlMsg += ":42A:";
	    		sGtlMsg += SwiftTag;
	    		sGtlMsg += "\r\n";
	    	}

	    	// Drafts at... (Tag 42C)
	    	if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:42C:")).trim().equals("")){
	    		sGtlMsg += ":42C:";
	    		sGtlMsg += SwiftTag;
	    		sGtlMsg += "\r\n";
	    	}

	    	// Drawee (Tag 42D)
	    	if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:42D:")).trim().equals("")){
	    		sGtlMsg += ":42D:";
	    		sGtlMsg += SwiftTag;
	    		sGtlMsg += "\r\n";
	    	}

	    	// Mixed Payment Details (Tag 42M)
	    	if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:42M:")).trim().equals("")){
	    		sGtlMsg += ":42M:";
	    		sGtlMsg += SwiftTag;
	    		sGtlMsg += "\r\n";
	    	}

	    	// Deferred Payment Details (Tag 42P)
	    	if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:42P:")).trim().equals("")){
	    		sGtlMsg += ":42P:";
	    		sGtlMsg += SwiftTag;
	    		sGtlMsg += "\r\n";
	    	}

	    	// Partial Shipments (Tag 43P)
	    	if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:43P:")).trim().equals("")){
	    		sGtlMsg += ":43P:";
	    		sGtlMsg += SwiftTag;
	    		sGtlMsg += "\r\n";
	    	}

	    	// Transshipment (Tag 43T)
	    	if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:43T:")).trim().equals("")){
	    		sGtlMsg += ":43T:";
	    		sGtlMsg += SwiftTag;
	    		sGtlMsg += "\r\n";
	    	}

	    	// Loading on Board/Dispatch/Taking in Charge at/from... (Tag 44A)
	    	if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:44A:")).trim().equals("")){
	    		sGtlMsg += ":44A:";
	    		sGtlMsg += SwiftTag;
	    		sGtlMsg += "\r\n";
	    	}

	    	// For Transportation to... (Tag 44B)
	    	if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:44B:")).trim().equals("")){
	    		sGtlMsg += ":44B:";
	    		sGtlMsg += SwiftTag;
	    		sGtlMsg += "\r\n";
	    	}

	    	// Latest Date of Shipment (Tag 44C)
	    	if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:44C:")).trim().equals("")){
	    		sGtlMsg += ":44C:";
	    		sGtlMsg += SwiftTag;
	    		sGtlMsg += "\r\n";
	    	}

	    	// Shipment Period (Tag 44D)
	    	if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:44D:")).trim().equals("")){
	    		sGtlMsg += ":44D:";
	    		sGtlMsg += SwiftTag;
	    		sGtlMsg += "\r\n";
	    	}

	    	// Port From (Tag 44E)
	    	if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:44E:")).trim().equals("")){
	    		sGtlMsg += ":44E:";
	    		sGtlMsg += SwiftTag;
	    		sGtlMsg += "\r\n";
	    	}

	    	// Port To (Tag 44F)
	    	if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:44F:")).trim().equals("")){
	    		sGtlMsg += ":44F:";
	    		sGtlMsg += SwiftTag;
	    		sGtlMsg += "\r\n";
	    	}

	    	// Description of Goods (Tag 45A and 45B of 701)
	    	if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:45A:")).trim().equals("")) {
	    		sGtlMsg += ":45A:";
	    		sGtlMsg += SwiftTag;
	    		if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:45B:")).trim().equals(""))
	    		sGtlMsg += SwiftTag;
	    		sGtlMsg += "\r\n";
	    	} else if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:45B:")).trim().equals("")) {
	    		sGtlMsg += ":45A:";
	    		sGtlMsg += SwiftTag;
	    		sGtlMsg += "\r\n";
	    	}

	    	// Documents Required (Tag 46A and 46B of 701)
	    	if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:46A:")).trim().equals("")) {
	    		sGtlMsg += ":46A:";
	    		sGtlMsg += SwiftTag;
	    		if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:46B:")).trim().equals(""))
	    		sGtlMsg += SwiftTag;
	    		sGtlMsg += "\r\n";
	    	} else if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:46B:")).trim().equals("")) {
	    		sGtlMsg += ":46A:";
	    		sGtlMsg += SwiftTag;
	    		sGtlMsg += "\r\n";
	    	}

	    	// Additional Conditions (Tag 47A)
	    	if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:47A:")).trim().equals("")) {
	    		sGtlMsg += ":47A:";
	    		sGtlMsg += SwiftTag;
	    		if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:47B:")).trim().equals(""))
	    		sGtlMsg += SwiftTag;
	    		sGtlMsg += "\r\n";
	    	} else if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:47B:")).trim().equals("")) {
	    		sGtlMsg += ":47A:";
	    		sGtlMsg += SwiftTag;
	    		sGtlMsg += "\r\n";
	    	}

	    	// Period for Presentation (Tag 48)
	    	if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:48:")).trim().equals("")) {
	    		sGtlMsg += ":48:";
	    		sGtlMsg += SwiftTag;
	    		sGtlMsg += "\r\n";
	    	}

	    	// Confirmation Instructions (Tag 49)
	    	if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:49:")).trim().equals("")) {
	    		sGtlMsg += ":49:";
	    		sGtlMsg += SwiftTag;
	    		sGtlMsg += "\r\n";
	    	}

	    	//ASIA3.0
	    	// Applicant (Tag 50)
	    	if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:50:")).trim().equals("")) {
	    		sConfigVal=getPUConfig(sProcUnit, "SWF_USE_AUTO_MAP");
	    		if (! sConfigVal.equals("")) {   		
	    			sCustId=FindCustIdFromName(SwiftTag, sProcUnit);
					if(! sCustId.trim().equals("")){
	    				sGtlMsg += ":58Z:";
	    				sGtlMsg += sCustId;
	    				sGtlMsg += "\r\n";
	    				sGtlMsg += ":50Z:";
	    				sGtlMsg += sCustId;
	    				sGtlMsg += "\r\n";
	    			}
	    			else {
	    				sGtlMsg += ":58D:";
	    				sGtlMsg += SwiftTag;
	    				sGtlMsg += "\r\n";
	    				sGtlMsg += ":50:";
	    				sGtlMsg += SwiftTag;
	    				sGtlMsg += "\r\n";
	    			}
	    		}
	    		else {
	    			sGtlMsg += ":50:";
	    			sGtlMsg += SwiftTag;
	    			sGtlMsg += "\r\n";			
	    		}    		
	    	}
	    	
	    	// Issuing Bank (from SWIFT Address) (Tag 52D/Z)
	    	SndSwfAddr = Mid(sMsgHeader, 46, 46+12);
	    	sCustId=FindCustIdFromSwf(SndSwfAddr, sProcUnit);
        	if (! sCustId.trim().equals("")) {
	    		sGtlMsg += ":52Z:";
	    		sGtlMsg += sCustId;
	    		sGtlMsg += "\r\n";
	    	}
	    	else if (! getPUConfig(sProcUnit, "DUMMY_FOREIGN_BANK").equals("")) {
	    		sCustId = getPUConfig(sProcUnit, "DUMMY_FOREIGN_BANK");    		
	    		sGtlMsg += ":52Z:";
	    		sGtlMsg += sCustId;
	    		sGtlMsg += "\r\n";
	    	}
	    	else {
	    		sGtlMsg += ":52D:";
	    		sGtlMsg += SndSwfAddr;
	    		sGtlMsg += "\r\n";
	    		sGtlMsg += "(Sender SWIFT Address)";
	    		sGtlMsg += "\r\n";
	    	}
	    	//ASIA3.0

	    	// Applicant Bank (Tag 51A)
	    	if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:51A:")).trim().equals("")) {
	    		sGtlMsg += ":51A:";
	    		sGtlMsg += SwiftTag;
	    		sGtlMsg += "\r\n";
	    	}

	    	// Applicant Bank (Tag 51D)
	    	if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:51D:")).trim().equals("")) {
	    		sGtlMsg += ":51D:";
	    		sGtlMsg += SwiftTag;
	    		sGtlMsg += "\r\n";
	    	}

	    	// Reimbursing Bank (Tag 53A)
	    	if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:53A:")).trim().equals("")) {
	    		sGtlMsg += ":53A:";
	    		sGtlMsg += SwiftTag;
	    		sGtlMsg += "\r\n";
	    	}

	    	// Reimbursing Bank (Tag 53D)
	    	if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:53D:")).trim().equals("")) {
	    		sGtlMsg += ":53D:";
	    		sGtlMsg += SwiftTag;
	    		sGtlMsg += "\r\n";
	    	}

	    	//ASIA3.0
	    	// 'Advise Through' Bank (Tag 57A/B/D)
	    	sConfigVal=getPUConfig(sProcUnit, "SWF_USE_AUTO_MAP");
	    	if (! sConfigVal.equals("")) {   		
	    		if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:57A:")).trim().equals("")) {
	    			String SndAddr;
	    			if (SwiftTag.charAt(0) == '/') { // using [/34x] acct num
	    				int nLineFeed = SwiftTag.indexOf('\n');
	    				++nLineFeed;
	    				SndAddr = Mid(SwiftTag, nLineFeed, nLineFeed + SwiftTag.length() - 2 );
	    			}
	    			else
	    			SndAddr = Left(SwiftTag, SwiftTag.length() - 2);
	    			sCustId=FindCustIdFromSwf(SndAddr, sProcUnit);
		        	if (! sCustId.trim().equals("")) {
	    				sGtlMsg += ":57Y:";
	    				sGtlMsg += sCustId;
	    				sGtlMsg += "\r\n";
	    			}
	    			else {
	    				sGtlMsg += ":52D:";
	    				sGtlMsg += SndAddr;
	    				sGtlMsg += "\r\n";
	    			}
		        	
	    		} else if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:57B:")).trim().equals("")) { // 06/24 Need to clarify
	    			sGtlMsg += ":57E:";                           // how to handle 2nd Advising
	    			sGtlMsg += SwiftTag;                          // Bank info.
	    			sGtlMsg += "\r\n";
	    		} else if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:57D:")).trim().equals("")) {
	    			sGtlMsg += ":57E:";
	    			sGtlMsg += SwiftTag;
	    			sGtlMsg += "\r\n";
	    		}
	    	}
	    	else {
	    		// "Advise Through" Bank (Tag 57A)
	    		if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:57A:")).trim().equals("")) {
	    			sGtlMsg += ":57A:";
	    			sGtlMsg += SwiftTag;
	    			sGtlMsg += "\r\n";
	    		}
	    		
	    		// "Advise Through" Bank (Tag 57B)
	    		if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:57B:")).trim().equals("")) {
	    			sGtlMsg += ":57B:";
	    			sGtlMsg += SwiftTag;
	    			sGtlMsg += "\r\n";
	    		}
	    		
	    		// "Advise Through" Bank (Tag 57D)
	    		if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:57D:")).trim().equals("")) {
	    			sGtlMsg += ":57D:";
	    			sGtlMsg += SwiftTag;
	    			sGtlMsg += "\r\n";
	    		}
	    	}

	    	// Beneficiary (Tag 59)
	    	if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:59:")).trim().equals("")) {
	    		sConfigVal=getPUConfig(sProcUnit, "SWF_USE_AUTO_MAP");
	    		if (! sConfigVal.equals("")) {   		
	    			if (SwiftTag.charAt(0) == '/') { // using [/34x] format. Ignore Acct Num
	    				int nLineFeed = SwiftTag.indexOf('\n');
	    				++nLineFeed;
	    				SwiftTag = Mid(SwiftTag, nLineFeed, nLineFeed + SwiftTag.length());
	    			}
	    			
	    			sCustId=FindCustIdFromName(SwiftTag, sProcUnit);
					if(! sCustId.trim().equals("")){
	    				sGtlMsg += ":59Z:";
	    				sGtlMsg += sCustId;
	    				sGtlMsg += "\r\n";
	    			}
	    			else if (! getPUConfig(sProcUnit, "DUMMY_WALKIN_CUST").equals("")) {
	    				sCustId=getPUConfig(sProcUnit, "DUMMY_WALKIN_CUST");
	    				sGtlMsg += ":59Z:";
	    				sGtlMsg += sCustId;
	    				sGtlMsg += "\r\n";
	    				sGtlMsg += ":59D:";
	    				sGtlMsg += SwiftTag;				
	    			}		
	    			else {
	    				sGtlMsg += ":59D:";
	    				sGtlMsg += SwiftTag;
	    			}
	    		}
	    		else {
	    			sGtlMsg += ":59:";
	    			sGtlMsg += SwiftTag;
	    			sGtlMsg += "\r\n";
	    		}    		
	    	}
	    	//ASIA3.0
	    	// Charges (Tag 71B)
	    	if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:71B:")).trim().equals("")) {
	    		sGtlMsg += ":71B:";
	    		sGtlMsg += SwiftTag;
	    		sGtlMsg += "\r\n";
	    	}

	    	// Sender to Receiver Information (Tag 72)
	    	if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:72:")).trim().equals("")) {
	    		sGtlMsg += ":72:";
	    		sGtlMsg += SwiftTag;
	    		sGtlMsg += "\r\n";
	    	}

	    	// Instructions to the Paying/Accepting/Negotiating Bank (Tag 78)
	    	if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:78:")).trim().equals("")) {
	    		sGtlMsg += ":78:";
	    		sGtlMsg += SwiftTag;
	    		sGtlMsg += "\r\n";
	    	}

			//logDebug(" sGtlMsg: \n"+sGtlMsg);
	    	logDebug("sGtlMsg = \n" + sGtlMsg);
	    	hParentResult.remove(FIELD_MSG_TEXT);
	    	hParentResult.put(FIELD_MSG_TEXT, sGtlMsg);

	        return true;
	        
	     }catch (Exception ex) {
	            logDebug((Throwable) ex);
			    logDebug("IMParseMappingExtractor.MT700_to_Gtl: "+ex.getMessage());
				//throw new Exception(ex.getMessage());
			    logDebug("ERROR MT700_to_Gtl(). Return false");
			    return false;
	     }
	}
	
	private boolean MT707_to_Gtl(Hashtable hParentResult, DataTable dtMsgContent) throws Exception{
		logDebug("Start MT700_to_Gtl()");
	try{
        // Convert Swift to GTL and update the SI_MSG_Q
       String SwiftTag;

       String sExtRefNbr = "";
       String sSenderRef = " ";
       String sRecvRef = " ";
       String sIssuBnkRef = "";
       String sProdType = " ";
       String sProdCat = "ELC";
       String sTranType = " ";
       String sOrigRefNbr = " ";
       String sLcTyp = " ";

       String sProcUnit=(String)hParentResult.get(FIELD_PROC_UNIT);
       String sMsgTyp=(String)hParentResult.get(FIELD_MSG_TYP);
       String sGtlMsg="";
       String Sql="";

       sGtlMsg = sProdCat; sGtlMsg += sMsgTyp;
       sGtlMsg += "\r\n";
	
	//Receiver's Reference
       if ( ! (SwiftTag = GetTok(dtMsgContent, "\r\n:21:")).trim().equals("") ) {
               sGtlMsg += ":21:";
               sGtlMsg += SwiftTag;
		sGtlMsg += "\r\n";
		//GWF: Replace RightTrim to .trim()
		//RightTrim(SwiftTag);
		SwiftTag=SwiftTag.trim();
		sRecvRef = SwiftTag;
	} 

	//Issuing Bank's Reference
       if ( ! (SwiftTag = GetTok(dtMsgContent, "\r\n:23:")).trim().equals("") ) {
               sGtlMsg += ":23:";
               sGtlMsg += SwiftTag;
		sGtlMsg += "\r\n";
		//RightTrim(SwiftTag);
		SwiftTag=SwiftTag.trim();
		SwiftTag=SwiftTag.trim();
		sIssuBnkRef = SwiftTag;
	} 

	//Sender's Reference
       if ( ! (SwiftTag = GetTok(dtMsgContent, "\r\n:20:")).trim().equals("") ) {
               sGtlMsg += ":20:";
               sGtlMsg += SwiftTag;
		sGtlMsg += "\r\n";
		//RightTrim(SwiftTag);
		SwiftTag=SwiftTag.trim();
		sOrigRefNbr = SwiftTag;
               if (sIssuBnkRef.trim().equals(""))
                       sIssuBnkRef = sOrigRefNbr;
       }
       
       	hParentResult.remove(FIELD_SENDER_REF);
		hParentResult.remove(FIELD_RECV_REF);
		hParentResult.remove(FIELD_ISSU_BNK_REF);
		hParentResult.put(FIELD_SENDER_REF, sSenderRef);
	    hParentResult.put(FIELD_RECV_REF, sRecvRef);
	    hParentResult.put(FIELD_ISSU_BNK_REF, sIssuBnkRef);
       
	if (! GetExtRefNbr (hParentResult)){
		logDebug("Testing for the GetExtRefNbr ......... GetExtRefNbr failed");
		//GWF: Do not return false if GetExtRefNbr failed
		//return (QS_FAIL);
	}
	
	logDebug("ExtRefNbr = " + sExtRefNbr);
	
	if (sExtRefNbr == "")
	{
		//cout << "<shrivasm> " << "EXTERNAL REFRENCE NUMBER EMPTY ........" << endl;
		//ThrowQSException(QS_QSERVER_ERROR);
		logDebug("EXT_REF_NBR is null ......");
		//return (QS_FAIL);
	}

	//Number of Amendment
       if ( ! (SwiftTag = GetTok(dtMsgContent, "\r\n:26E:")).trim().equals("") ) {
               sGtlMsg += ":26E:";
               sGtlMsg += SwiftTag;
		sGtlMsg += "\r\n";
       } 

	//Date of Amendment
       if ( ! (SwiftTag = GetTok(dtMsgContent, "\r\n:30:")).trim().equals("") ) {
               sGtlMsg += ":30:";
               sGtlMsg += SwiftTag;
		sGtlMsg += "\r\n";
       } 

	//Date of Issue
       if ( ! (SwiftTag = GetTok(dtMsgContent, "\r\n:31C:")).trim().equals("") ) {
               sGtlMsg += ":31C:";
               sGtlMsg += SwiftTag;
		sGtlMsg += "\r\n";
       } 

	//New Date of Expiry
       if ( ! (SwiftTag = GetTok(dtMsgContent, "\r\n:31E:")).trim().equals("") ) {
               sGtlMsg += ":31E:";
               sGtlMsg += SwiftTag;
		sGtlMsg += "\r\n";
       } 

	//Increase of D/C Amt
       if ( ! (SwiftTag = GetTok(dtMsgContent, "\r\n:32B:")).trim().equals("") ) {
               sGtlMsg += ":32B:";
               sGtlMsg += SwiftTag;
		sGtlMsg += "\r\n";
       } 

	//Decrease of D/C Amt
       if ( ! (SwiftTag = GetTok(dtMsgContent, "\r\n:33B:")).trim().equals("") ) {
               sGtlMsg += ":33B:";
               sGtlMsg += SwiftTag;
		sGtlMsg += "\r\n";
       } 

	//New D/C Amt after Amendment
       if ( ! (SwiftTag = GetTok(dtMsgContent, "\r\n:34B:")).trim().equals("") ) {
               sGtlMsg += ":34B:";
               sGtlMsg += SwiftTag;
		sGtlMsg += "\r\n";
       } 

	//% Credit Amt Tolerance
       if ( ! (SwiftTag = GetTok(dtMsgContent, "\r\n:39A:")).trim().equals("") ) {
               sGtlMsg += ":39A:";
               sGtlMsg += SwiftTag;
		sGtlMsg += "\r\n";
       } 

	//Max Credit Amt
       if ( ! (SwiftTag = GetTok(dtMsgContent, "\r\n:39B:")).trim().equals("") ) {
               sGtlMsg += ":39B:";
               sGtlMsg += SwiftTag;
		sGtlMsg += "\r\n";
       } 

	//Addl Amt Covered
       if ( ! (SwiftTag = GetTok(dtMsgContent, "\r\n:39C:")).trim().equals("") ) {
               sGtlMsg += ":39C:";
               sGtlMsg += SwiftTag;
		sGtlMsg += "\r\n";
       } 

	//Loading on Board/Dispatch/Taking in Charge at/from ...
       if ( ! (SwiftTag = GetTok(dtMsgContent, "\r\n:44A:")).trim().equals("") ) {
               sGtlMsg += ":44A:";
               sGtlMsg += SwiftTag;
		sGtlMsg += "\r\n";
       } 

	//For Transportation to ...
       if ( ! (SwiftTag = GetTok(dtMsgContent, "\r\n:44B:")).trim().equals("") ) {
               sGtlMsg += ":44B:";
               sGtlMsg += SwiftTag;
		sGtlMsg += "\r\n";
       } 

	//Latest Date of Shipment
       if ( ! (SwiftTag = GetTok(dtMsgContent, "\r\n:44C:")).trim().equals("") ) {
               sGtlMsg += ":44C:";
               sGtlMsg += SwiftTag;
		sGtlMsg += "\r\n";
       } 

	//Shipment Period
       if ( ! (SwiftTag = GetTok(dtMsgContent, "\r\n:44D:")).trim().equals("") ) {
               sGtlMsg += ":44D:";
               sGtlMsg += SwiftTag;
		sGtlMsg += "\r\n";
       } 

   // Port From
       if ( ! (SwiftTag = GetTok(dtMsgContent, "\r\n:44E:")).trim().equals("") ) {
				sGtlMsg += ":44E:";
				sGtlMsg += SwiftTag;
		sGtlMsg += "\r\n";
       } 

   // Port To
       if ( ! (SwiftTag = GetTok(dtMsgContent, "\r\n:44F:")).trim().equals("") ) {
				sGtlMsg += ":44F:";
				sGtlMsg += SwiftTag;
		sGtlMsg += "\r\n";
       }

	//Issuing Bank
       if ( ! (SwiftTag = GetTok(dtMsgContent, "\r\n:52A:")).trim().equals("") ) {
               sGtlMsg += ":52A:";
               sGtlMsg += SwiftTag;
		sGtlMsg += "\r\n";
       } 
       if ( ! (SwiftTag = GetTok(dtMsgContent, "\r\n:52D:")).trim().equals("") ) {
               sGtlMsg += ":52D:";
               sGtlMsg += SwiftTag;
		sGtlMsg += "\r\n";
       } 

	//Beneficiary
       if ( ! (SwiftTag = GetTok(dtMsgContent, "\r\n:59:")).trim().equals("") ) {
               sGtlMsg += ":59:";
               sGtlMsg += SwiftTag;
		sGtlMsg += "\r\n";
       } 

	//Sender to Receiver Information
       if ( ! (SwiftTag = GetTok(dtMsgContent, "\r\n:72:")).trim().equals("") ) {
               sGtlMsg += ":72:";
               sGtlMsg += SwiftTag;
		sGtlMsg += "\r\n";
       } 

	//Narrative
       if ( ! (SwiftTag = GetTok2(dtMsgContent, "\r\n:79:",1)).trim().equals("") ) {
               sGtlMsg += ":79:";
               sGtlMsg += SwiftTag;
               if ( ! (SwiftTag = GetTok2(dtMsgContent, "\r\n:79:",2)).trim().equals("") ) {
            	   sGtlMsg += SwiftTag;
               }
               sGtlMsg += "\r\n";
       }

       	logDebug("sGtlMsg = \n" + sGtlMsg);
		hParentResult.remove(FIELD_MSG_TEXT);
		hParentResult.put(FIELD_MSG_TEXT, sGtlMsg);
	
	    return true;
	 }catch (Exception ex) {
	        logDebug((Throwable) ex);
		    logDebug("IMParseMappingExtractor.MT707_to_Gtl: "+ex.getMessage());
			//throw new Exception(ex.getMessage());
		    logDebug("ERROR MT707_to_Gtl(). Return false");
		    return false;
	 }
	}
	
	private boolean MT710_to_Gtl(Hashtable hParentResult, DataTable dtMsgContent) throws Exception
	{
		 logDebug("Start MT710_to_Gtl()");
	     try{
	    	 String sProcUnit=(String)hParentResult.get(FIELD_PROC_UNIT);
		     String sMsgTyp=(String)hParentResult.get(FIELD_MSG_TYP);
		     String sMsgHeader=(String)hParentResult.get(FIELD_MSG_HEADER);
		     String sGtlMsg="";
		     String Sql="";
	    	 
		        // Convert Swift to GTL and update the SI_MSG_Q
		        int len = 0;
		        String sTag40A  = "C\r\n";
		        String SwiftTag;
		        String sCustId;
		        String SndSwfAddr = (String)hParentResult.get(FIELD_SEND_RECV_ADDR);

		        String sProdCat  = "ELC";
		        String sLcTyp    = "C";
		        String sProdType = "";
		        String sExtRefNbr = "";
		        String sSenderRef = " ";
		        String sRecvRef = " ";
		        String sIssuBnkRef = " ";
		        String sTranType = " ";
		        String sOrigRefNbr = " ";
		        String s3rdPtyRefNbr = " ";
		        String sTranRefNbr = " ";
		        //20021113, Davy, Start
		        String sConfigVal = " ";
		        String sIsDefaultDummyCust = " ";
		        String sDummyId = " ";
		        String sApplMsgRef = (String)hParentResult.get(FIELD_APPL_MSG_REF);
		        DataTable dt;
		        //20021113, Davy, End
		        
		        hParentResult.remove(FIELD_EXT_REF_NBR);
		        hParentResult.remove(FIELD_PROD_CAT);
		        hParentResult.remove(FIELD_PROD_TYP);
		        hParentResult.remove(FIELD_TRAN_REF_NBR);
		        hParentResult.put(FIELD_EXT_REF_NBR, sExtRefNbr);
		        hParentResult.put(FIELD_PROD_CAT, sProdCat);
		        hParentResult.put(FIELD_PROD_TYP, sProdType);
		        hParentResult.put(FIELD_TRAN_REF_NBR, sTranRefNbr);
		        hParentResult.remove(FIELD_LC_TYP);
		        hParentResult.put(FIELD_LC_TYP, sLcTyp);
		        
		        sGtlMsg = sProdCat; sGtlMsg += sMsgTyp;
		    	sGtlMsg += "\r\n";

		    	int automap = 0;
		    	
		    	sConfigVal=getPUConfig(sProcUnit, "SWF_USE_AUTO_MAP");
		    	if (! sConfigVal.equals("")){
		    		if (sConfigVal.indexOf("710")>=0){
		    			automap=1;
		    		}
		    	}
		    	if (automap==0){	
		    		// Sender's Reference (Tag 20)
		    		if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:20:")).trim().equals("")) {
		    			len = SwiftTag.indexOf("\r\n");
		    			if (len != -1)
		    				s3rdPtyRefNbr = Mid(SwiftTag, 0, len);
		    			else
		    				s3rdPtyRefNbr = SwiftTag;
		    			sGtlMsg += "\r\n";
		    		}

		    		// Documentary Credit Number (Tag 21)
		    		if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:21:")).trim().equals("")) {
		    			len = SwiftTag.indexOf("\r\n");
		    			if (len != -1)
		    				sOrigRefNbr = Mid(SwiftTag, 0, len);
		    			else
		    				sOrigRefNbr = SwiftTag;
		    			sGtlMsg += "\r\n";
		    		}

		    		sSenderRef  = sOrigRefNbr;
		    		sIssuBnkRef = sOrigRefNbr;
		    		
		    		hParentResult.remove(FIELD_SENDER_REF);
			    	hParentResult.remove(FIELD_RECV_REF);
			    	hParentResult.remove(FIELD_ISSU_BNK_REF);
			    	hParentResult.put(FIELD_SENDER_REF, sSenderRef);
				    hParentResult.put(FIELD_RECV_REF, sRecvRef);
				    hParentResult.put(FIELD_ISSU_BNK_REF, sIssuBnkRef);

		    		if (! s3rdPtyRefNbr.equals("")) {
		    			sGtlMsg += ":20:";
		    			sGtlMsg += s3rdPtyRefNbr;
		    			sGtlMsg += "\r\n";
		    		}
		    		if (! sOrigRefNbr.equals("")) {
		    			sGtlMsg += ":21:";
		    			sGtlMsg += sOrigRefNbr;
		    			sGtlMsg += "\r\n";
		    		}

		    		// Reference to Pre-Advice (Tag 23)
		    		if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:23:")).trim().equals("")) {
		    			sGtlMsg += ":23:";
		    			sGtlMsg += SwiftTag;
		    			sGtlMsg += "\r\n";
		    		}

		    		// Sequence of Total (Tag 27)
		    		if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:27:")).trim().equals("")) {
		    			sGtlMsg += ":27:";
		    			sGtlMsg += SwiftTag;
		    			sGtlMsg += "\r\n";
		    		}

		    		// Date of Issue (Tag 31C)
		    		if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:31C:")).trim().equals("")) {
		    			sGtlMsg += ":31C:";
		    			sGtlMsg += SwiftTag;
		    			sGtlMsg += "\r\n";
		    		}

		    		// Date and Place of Expiry (Tag 31D)
		    		if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:31D:")).trim().equals("")) {
		    			sGtlMsg += ":31D:";
		    			sGtlMsg += SwiftTag;
		    			sGtlMsg += "\r\n";
		    		}

		    		// Currency Code, Amount (Tag 32B)
		    		if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:32B:")).trim().equals("")) {
		    			sGtlMsg += ":32B:";
		    			sGtlMsg += SwiftTag;
		    			sGtlMsg += "\r\n";
		    		}

		    		// Currency Code, Amount (Tag 39A)
		    		if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:39A:")).trim().equals("")) {
		    			sGtlMsg += ":39A:";
		    			sGtlMsg += SwiftTag;
		    			sGtlMsg += "\r\n";
		    		}

		    		// Maximum Credit Amount (Tag 39B)
		    		if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:39B:")).trim().equals("")) {
		    			sGtlMsg += ":39B:";
		    			sGtlMsg += SwiftTag;
		    			sGtlMsg += "\r\n";
		    		}

		    		// Additional Amounts Covered (Tag 39C)
		    		if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:39C:")).trim().equals("")) {
		    			sGtlMsg += ":39C:";
		    			sGtlMsg += SwiftTag;
		    			sGtlMsg += "\r\n";
		    		}

		    		// Form of Documentary Credit (Tag 40B)
		    		if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:40B:")).trim().equals("")) {
		    			sGtlMsg += ":40B:";
		    			sGtlMsg += SwiftTag;
		    			sGtlMsg += "\r\n";
		    		}

		    		// Applicable Rule (Tag 40E)
		    		if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:40E:")).trim().equals("")) {
		    			sGtlMsg += ":40E:";
		    			sGtlMsg += SwiftTag;
		    			sGtlMsg += "\r\n";
		    		}

		    		// Available With... By... (Tag 41A)
		    		if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:41A:")).trim().equals("")) {
		    			sGtlMsg += ":41A:";
		    			sGtlMsg += SwiftTag;
		    			sGtlMsg += "\r\n";
		    		}

		    		// Available With... By... (Tag 41D)
		    		if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:41D:")).trim().equals("")) {
		    			sGtlMsg += ":41D:";
		    			sGtlMsg += SwiftTag;
		    			sGtlMsg += "\r\n";
		    		}

		    		// Drawee (Tag 42A)
		    		if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:42A:")).trim().equals("")) {
		    			sGtlMsg += ":42A:";
		    			sGtlMsg += SwiftTag;
		    			sGtlMsg += "\r\n";
		    		}

		    		// Drafts at... (Tag 42C)
		    		if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:42C:")).trim().equals("")) {
		    			sGtlMsg += ":42C:";
		    			sGtlMsg += SwiftTag;
		    			sGtlMsg += "\r\n";
		    		}

		    		// Drawee (Tag 42D)
		    		if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:42D:")).trim().equals("")) {
		    			sGtlMsg += ":42D:";
		    			sGtlMsg += SwiftTag;
		    			sGtlMsg += "\r\n";
		    		}

		    		// Mixed Payment Details (Tag 42M)
		    		if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:42M:")).trim().equals("")) {
		    			sGtlMsg += ":42M:";
		    			sGtlMsg += SwiftTag;
		    			sGtlMsg += "\r\n";
		    		}

		    		// Deferred Payment Details (Tag 42P)
		    		if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:42P:")).trim().equals("")) {
		    			sGtlMsg += ":42P:";
		    			sGtlMsg += SwiftTag;
		    			sGtlMsg += "\r\n";
		    		}

		    		// Partial Shipments (Tag 43P)
		    		if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:43P:")).trim().equals("")) {
		    			sGtlMsg += ":43P:";
		    			sGtlMsg += SwiftTag;
		    			sGtlMsg += "\r\n";
		    		}

		    		// Transshipment (Tag 43T)
		    		if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:43T:")).trim().equals("")) {
		    			sGtlMsg += ":43T:";
		    			sGtlMsg += SwiftTag;
		    			sGtlMsg += "\r\n";
		    		}

		    		// Loading on Board/Dispatch/Taking in Charge at/from... (Tag 44A)
		    		if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:44A:")).trim().equals("")) {
		    			sGtlMsg += ":44A:";
		    			sGtlMsg += SwiftTag;
		    			sGtlMsg += "\r\n";
		    		}

		    		// For Transportation to... (Tag 44B)
		    		if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:44B:")).trim().equals("")) {
		    			sGtlMsg += ":44B:";
		    			sGtlMsg += SwiftTag;
		    			sGtlMsg += "\r\n";
		    		}

		    		// Latest Date of Shipment (Tag 44C)
		    		if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:44C:")).trim().equals("")) {
		    			sGtlMsg += ":44C:";
		    			sGtlMsg += SwiftTag;
		    			sGtlMsg += "\r\n";
		    		}

		    		// Shipment Period (Tag 44D)
		    		if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:44D:")).trim().equals("")) {
		    			sGtlMsg += ":44D:";
		    			sGtlMsg += SwiftTag;
		    			sGtlMsg += "\r\n";
		    		}

		    		// Port From
		    		if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:44E:")).trim().equals("")) {
		    			sGtlMsg += ":44E:";
		    			sGtlMsg += SwiftTag;
		    			sGtlMsg += "\r\n";
		    		}

		    		// Port To
		    		if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:44F:")).trim().equals("")) {
		    			sGtlMsg += ":44F:";
		    			sGtlMsg += SwiftTag;
		    			sGtlMsg += "\r\n";
		    		}

		    		// Description of Goods (Tag 45A and 45B of 701)
		    		if (!(SwiftTag = GetTok(dtMsgContent, "\r\n:45A:")).trim().equals("")) {
		    			sGtlMsg += ":45A:";
		    			sGtlMsg += SwiftTag;
		    			if (!(SwiftTag = GetTok(dtMsgContent, "\r\n:45B:")).trim().equals("") )
		    				sGtlMsg += SwiftTag;
		    			sGtlMsg += "\r\n";
		    		} else if (!(SwiftTag = GetTok(dtMsgContent, "\r\n:45B:")).trim().equals("")) {
		    			sGtlMsg += ":45A:";
		    			sGtlMsg += SwiftTag;
		    			sGtlMsg += "\r\n";
		    		}

		    		// Documents Required (Tag 46A and 46B of 701)
		    		if (!(SwiftTag = GetTok(dtMsgContent, "\r\n:46A:")).trim().equals("")) {
		    			sGtlMsg += ":46A:";
		    			sGtlMsg += SwiftTag;
		    			if (!(SwiftTag = GetTok(dtMsgContent, "\r\n:46B:")).trim().equals(""))
		    				sGtlMsg += SwiftTag;
		    			sGtlMsg += "\r\n";
		    		} else if (!(SwiftTag = GetTok(dtMsgContent, "\r\n:46B:")).trim().equals("")) {
		    			sGtlMsg += ":46A:";
		    			sGtlMsg += SwiftTag;
		    			sGtlMsg += "\r\n";
		    		}

		    		// Additional Conditions (Tag 47A)
		    		if (!(SwiftTag = GetTok(dtMsgContent, "\r\n:47A:")).trim().equals("")) {
		    			sGtlMsg += ":47A:";
		    			sGtlMsg += SwiftTag;
		    			if (!(SwiftTag = GetTok(dtMsgContent, "\r\n:47B:")).trim().equals("") )
		    				sGtlMsg += SwiftTag;
		    			sGtlMsg += "\r\n";
		    		} else if (!(SwiftTag = GetTok(dtMsgContent, "\r\n:47B:")).trim().equals("")) {
		    			sGtlMsg += ":47A:";
		    			sGtlMsg += SwiftTag;
		    			sGtlMsg += "\r\n";
		    		}

		    		// Period for Presentation (Tag 48)
		    		if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:48:")).trim().equals("")) {
		    			sGtlMsg += ":48:";
		    			sGtlMsg += SwiftTag;
		    			sGtlMsg += "\r\n";
		    		}

		    		// Confirmation Instructions (Tag 49)
		    		if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:49:")).trim().equals("")) {
		    			sGtlMsg += ":49:";
		    			sGtlMsg += SwiftTag;
		    			sGtlMsg += "\r\n";
		    		}

		    		// Applicant (Tag 50)
		    		if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:50:")).trim().equals("")) {
		    			sGtlMsg += ":50:";
		    			sGtlMsg += SwiftTag;
		    			sGtlMsg += "\r\n";
		    		}

		    		// Non Bank Issuer (Tag 50B)
		    		if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:50B:")).trim().equals("")) {
		    			sGtlMsg += ":50B:";
		    			sGtlMsg += SwiftTag;
		    			sGtlMsg += "\r\n";
		    		}

		    		// Applicant Bank (Tag 51A)
		    		if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:51A:")).trim().equals("")) {
		    			sGtlMsg += ":51A:";
		    			sGtlMsg += SwiftTag;
		    			sGtlMsg += "\r\n";
		    		}

		    		// Applicant Bank (Tag 51D)
		    		if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:51D:")).trim().equals("") ) {
		    			sGtlMsg += ":51D:";
		    			sGtlMsg += SwiftTag;
		    			sGtlMsg += "\r\n";
		    		}

		    		// Issuing Bank (Tag 51A)
		    		if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:52A:")).trim().equals("") ) {
		    			sGtlMsg += ":52A:";
		    			sGtlMsg += SwiftTag;
		    			sGtlMsg += "\r\n";
		    		}

		    		// Issuing Bank (Tag 51D)
		    		if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:52D:")).trim().equals("") ) {
		    			sGtlMsg += ":52D:";
		    			sGtlMsg += SwiftTag;
		    			sGtlMsg += "\r\n";
		    		}

		    		// Reimbursing Bank (Tag 53A)
		    		if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:53A:")).trim().equals("")) {
		    			sGtlMsg += ":53A:";
		    			sGtlMsg += SwiftTag;
		    			sGtlMsg += "\r\n";
		    		}

		    		// Reimbursing Bank (Tag 53D)
		    		if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:53D:")).trim().equals("")) {
		    			sGtlMsg += ":53D:";
		    			sGtlMsg += SwiftTag;
		    			sGtlMsg += "\r\n";
		    		}

		    		// "Advise Through" Bank (Tag 57A)
		    		if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:57A:")).trim().equals("") ) {
		    			sGtlMsg += ":57A:";
		    			sGtlMsg += SwiftTag;
		    			sGtlMsg += "\r\n";
		    		}

		    		// "Advise Through" Bank (Tag 57B)
		    		if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:57B:")).trim().equals("")) {
		    			sGtlMsg += ":57B:";
		    			sGtlMsg += SwiftTag;
		    			sGtlMsg += "\r\n";
		    		}

		    		// "Advise Through" Bank (Tag 57D)
		    		if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:57D:")).trim().equals("") ) {
		    			sGtlMsg += ":57D:";
		    			sGtlMsg += SwiftTag;
		    			sGtlMsg += "\r\n";
		    		}

		    		// Beneficiary (Tag 59)
		    		if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:59:")).trim().equals("") ) {
		    			sGtlMsg += ":59:";
		    			sGtlMsg += SwiftTag;
		    			sGtlMsg += "\r\n";
		    		}

		    		// Charges (Tag 71B)
		    		if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:71B:")).trim().equals("") ) {
		    			sGtlMsg += ":71B:";
		    			sGtlMsg += SwiftTag;
		    			sGtlMsg += "\r\n";
		    		}

		    		// Sender to Receiver Information (Tag 72)
		    		if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:72:")).trim().equals("") ) {
		    			sGtlMsg += ":72:";
		    			sGtlMsg += SwiftTag;
		    			sGtlMsg += "\r\n";
		    		}

		    		// Instructions to the Paying/Accepting/Negotiating Bank (Tag 78)
		    		if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:78:")).trim().equals("")) {
		    			sGtlMsg += ":78:";
		    			sGtlMsg += SwiftTag;
		    			sGtlMsg += "\r\n";
		    		}
		    	}

		    	else{
		    		//20030818
		    		logDebug("MT710 automap");
		    		// Documentary Credit Number (Tag 20)
		    		if (!(SwiftTag = GetTok(dtMsgContent, "\r\n:20:")).trim().equals("")) {
		    			len = SwiftTag.indexOf("\r\n");
		    			if (len != -1)
		    				s3rdPtyRefNbr = Mid(SwiftTag, 0, len);
		    			else
		    				s3rdPtyRefNbr = SwiftTag;
		    		}

		    		// Documentary Credit Number (Tag 21)
		    		if (!(SwiftTag = GetTok(dtMsgContent, "\r\n:21:")).trim().equals("")) {
		    			len = SwiftTag.indexOf("\r\n");
		    			if (len != -1)
		    				sOrigRefNbr = Mid(SwiftTag, 0, len);
		    			else
		    				sOrigRefNbr = SwiftTag;
		    		}

		    		sSenderRef  = sOrigRefNbr;
		    		sIssuBnkRef = sOrigRefNbr;
		    		
		    		hParentResult.remove(FIELD_SENDER_REF);
			    	hParentResult.remove(FIELD_RECV_REF);
			    	hParentResult.remove(FIELD_ISSU_BNK_REF);
			    	hParentResult.put(FIELD_SENDER_REF, sSenderRef);
				    hParentResult.put(FIELD_RECV_REF, sRecvRef);
				    hParentResult.put(FIELD_ISSU_BNK_REF, sIssuBnkRef);

		    		//20021113, Davy, Start
		    		if (sMsgTyp == "710") {
		    			sConfigVal=getPUConfig(sProcUnit, "INSWF_PARSE_GEN_REF");
		    			//sConfigVal = sConfigVal.SpanExcluding(" ");
		    			if (sConfigVal.trim().equals("Y"))	{
		    				logDebug("Before the process to Generate the ExtRefNbr...");
		    				
		    				//Get the CUST_ID first for get EXT_REF_NBR
		    				
		    				if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:20:")).trim().equals("") ) {
		    					sConfigVal=getPUConfig(sProcUnit, "SWF_USE_AUTO_MAP");
		    					if (!sConfigVal.trim().equals("")) {   		
		    						/*if (SwiftTag[0] == '/') { // using [/34x] format. Ignore Acct Num
		    								int nLineFeed = SwiftTag.Find('\n');
		    								++nLineFeed;
		    								SwiftTag = SwiftTag.Mid(nLineFeed, SwiftTag.GetLength());
		    						}*/
		    						

		    						// ---[EMEA]---[20060928]
		    						sIsDefaultDummyCust=getPUConfig(sProcUnit, "DEFAULT_DUMMY_WALKIN_CUST");
		    						if (!sIsDefaultDummyCust.trim().equals(""))
		    						{
		    							if (sIsDefaultDummyCust.trim().equals("Y"))
		    							{
		    								sDummyId=getPUConfig(sProcUnit, "DUMMY_WALKIN_CUST");
		    							}
		    							else
		    							{
		    								sDummyId=FindCustIdFromName(SwiftTag, sProcUnit);
		    								if (sDummyId.trim().equals("")) {
		    									sDummyId=getPUConfig(sProcUnit, "DUMMY_WALKIN_CUST");
		    									logDebug("Cannot find CustID for (" + SwiftTag + "), so use DUMMY_WALKIN_CUST (" + sDummyId + ")");
		    								}
		    							}
		    						}
		    						
		    						hParentResult.remove(FIELD_DUMMY_ID);
		    				    	hParentResult.put(FIELD_DUMMY_ID, sDummyId);
		    						// ---[EMEA]---[END]
		    					}
		    				}
		    				if (! GetExtRefNbr (hParentResult)) {
		    					logDebug("Testing for the GetExtRefNbr .........");
		    					//return (QS_FAIL);
		    				}else{
		    					logDebug("Testing for GetExtRefNbr.......... GetExtRefNbr success");
		    					sExtRefNbr=(String)hParentResult.get(FIELD_EXT_REF_NBR);
		                    	sProdCat=(String)hParentResult.get(FIELD_PROD_CAT);
		                    	sProdType=(String)hParentResult.get(FIELD_PROD_TYP);
		                    	sTranRefNbr=(String)hParentResult.get(FIELD_TRAN_REF_NBR);
		    				}
		    				if (sExtRefNbr.equals("")) {
		    					if (! selectTranType (hParentResult)) {
		    						logDebug("Testing for selectTranType..........");
		    						//return (QS_FAIL);
		    					}else{
		    						logDebug("Testing for selectTranType.......... selectTranType success");
		    						sProdType=(String)hParentResult.get(FIELD_PROD_TYP);
                        			sTranType=(String)hParentResult.get(FIELD_TRAN_TYP);
                        			sProdCat=(String)hParentResult.get(FIELD_PROD_CAT);
		    					}
		    						
		    					if (! GenNewTranRefNbr(hParentResult)) {
		    						logDebug("Testing for GenNewTranRefNbr..........");
		    						//return (QS_FAIL);
		    					}else{
		    						logDebug("Testing for GenNewTranRefNbr.......... GenNewTranRefNbr success");
                                	sExtRefNbr=(String)hParentResult.get(FIELD_EXT_REF_NBR);
		    					}
		    					if (sExtRefNbr.equals("")) {
		    						logDebug("Error in getting EXT_REF_NBR for MT710");
		    						//return (QS_FAIL);
		    					}
		    					logDebug("The ExtRefNbr is generated");
		    				}
		    			}
		    			else if (sConfigVal == "N")	{
		    				//if (selectTranType () == QS_FAIL) {
		    				//	cout << "Testing for selectTranType.........." << endl;
		    				//	return (QS_FAIL);
		    				//}
		    				logDebug("The process will not Generate the ExtRefNbr...");
		    			}

		    		}
		    		//20021113, Davy, End
		    		else if (sMsgTyp == "705") {
		    			//if (selectTranType () == QS_FAIL)
		    			//	return (QS_FAIL);
		    			if (! GenNewTranRefNbr(hParentResult)){
    						logDebug("Testing for GenNewTranRefNbr..........");
    						//return (QS_FAIL);
    					}else{
    						logDebug("Testing for GenNewTranRefNbr.......... GenNewTranRefNbr success");
                        	sExtRefNbr=(String)hParentResult.get(FIELD_EXT_REF_NBR);
    					}
		    			if (sExtRefNbr.equals(""))
		    			{
		    				logDebug("Error in getting EXT_REF_NBR for MT705");
		    				//return (QS_FAIL);
		    			}
		    		}

		    		// Construct GTL alike Msg
		    		sGtlMsg  = sProdCat;
		    		sGtlMsg += sMsgTyp;

		    		sGtlMsg += "\r\n:00B:";
		    		sGtlMsg += sTag40A;

		    		if (! sOrigRefNbr.trim().equals("")) {
		    			sGtlMsg += ":20:";
		    			sGtlMsg += sExtRefNbr;
		    			sGtlMsg += "\r\n";
		    			sGtlMsg += ":20Z:";
		    			sGtlMsg += s3rdPtyRefNbr;
		    			sGtlMsg += "\r\n";
		    			sGtlMsg += ":20Y:";
		    			sGtlMsg += sOrigRefNbr;
		    			sGtlMsg += "\r\n";
		    		}

					// Value Date
					String sValDt="";
					Sql  = "select convert(char(6), getdate(), 12) as VALUE_DT";
					dt=conn.executeQuery(Sql);
					if(dt.size()>0){
						dt.next();
						sValDt=(String)dt.getField("VALUE_DT");
					}
					sGtlMsg += ":00D:";
					sGtlMsg += CheckDt(sValDt);
					sGtlMsg += "\r\n";

		    		// Revocable Indicator
		    		// If IRREVOCABLE/IRREVOC, set the value to "Y", as the S.P USP_TLC_CTRY_EXT_INS will reverse the value
		    		if (!(SwiftTag = GetTok(dtMsgContent, "\r\n:40B:")).trim().equals("")) {
		    			SwiftTag.toUpperCase();
		    			if (( SwiftTag.indexOf("IRREVOCABLE") != -1) || ( SwiftTag.indexOf("IRREVOC") != -1) ) {
		    				sGtlMsg += ":40R:";
		    				sGtlMsg += "Y\r\n";
		    			} else {
		    				sGtlMsg += ":40R:";
		    				sGtlMsg += "N\r\n";
		    			}
		    			if (( SwiftTag.indexOf("TRANSFERABLE") != -1) || ( SwiftTag.indexOf("TRANS") != -1) ) {
		    				sGtlMsg += ":40A:";
		    				sGtlMsg += "Y\r\n";
		    			} else {
		    				sGtlMsg += ":40A:";
		    				sGtlMsg += "N\r\n";
		    			}
		    		}

		    		// Date of Issue
		    		if (!(SwiftTag = GetTok(dtMsgContent, "\r\n:31C:")).trim().equals("")) {
		    			sGtlMsg += ":31C:";
		    			sGtlMsg += CheckDt(SwiftTag);
		    			sGtlMsg += "\r\n";
		    		}
		    		else {
		    			sGtlMsg += ":31C:";
		    			sGtlMsg += Left(sApplMsgRef, 8);
		    			sGtlMsg += "\r\n";
		    		}

		    		// Expiration Date (Tag 31D)
		    		if (!(SwiftTag = GetTok(dtMsgContent, "\r\n:31D:")).trim().equals("")) {
		    			sGtlMsg += ":31D:";
		    			sGtlMsg += CheckDt(Mid(SwiftTag, 0, 6));
		    			sGtlMsg += "X";
		    			sGtlMsg += Mid(SwiftTag, 6, 6 + (SwiftTag.length() - 6));
		    			sGtlMsg += "\r\n";
		    		}

		    		// Applicant (Tag 50) -- also map to Account Party & Addr
		    		if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:50:")).trim().equals("") ) {
		    			sCustId=FindCustIdFromName(SwiftTag, sProcUnit);
		    			if (! sCustId.equals("")) {
		    				sGtlMsg += ":58Z:";
		    				sGtlMsg += sCustId;
		    				sGtlMsg += "\r\n";
		    				sGtlMsg += ":50Z:";
		    				sGtlMsg += sCustId;
		    				sGtlMsg += "\r\n";
		    			} else {
		    				sGtlMsg += ":58D:";
		    				sGtlMsg += SwiftTag;
		    				sGtlMsg += "\r\n";
		    			}
		    		}

		    		// Beneficiary (Tag 59)
		    		if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:59:")).trim().equals("") ) {
		    			
		    			if (SwiftTag.charAt(0) == '/') { // using [/34x] format. Ignore Acct Num
		    				int nLineFeed = SwiftTag.indexOf('\n');
		    				++nLineFeed;
		    				SwiftTag = Mid(SwiftTag, nLineFeed, nLineFeed + SwiftTag.length());
		    			}
		    			
		    			sCustId=FindCustIdFromName(SwiftTag, sProcUnit);
		    			if (!sCustId.equals("")) {
		    				sGtlMsg += ":59Z:";
		    				sGtlMsg += sCustId;
		    				sGtlMsg += "\r\n";
		    			}
		    			else if (!getPUConfig(sProcUnit, "DUMMY_WALKIN_CUST").trim().equals("")){
		    				sCustId=getPUConfig(sProcUnit, "DUMMY_WALKIN_CUST");
		    				sGtlMsg += ":59Z:";
		    				sGtlMsg += sCustId;
		    				sGtlMsg += "\r\n";
		    				sGtlMsg += ":59D:";
		    				sGtlMsg += SwiftTag;				
		    			}		
		    			else {
		    				sGtlMsg += ":59D:";
		    				sGtlMsg += SwiftTag;
		    			}
		    			
		    		}

		    		// Currency Name (Tag 32B)
		    		if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:32B:")).trim().equals("")) {
		    			sGtlMsg += ":32B:";	    			
		    			SwiftTag = SwiftTag.replace(',', '.');
				 		sGtlMsg += SwiftTag;
		    		}
		    		
		    		SndSwfAddr = Mid(sMsgHeader, 46, 46+12);
		    		sCustId=FindCustIdFromSwf(SndSwfAddr, sProcUnit);
		    		if (!sCustId.equals("")) {
		    			logDebug( " TAG52Z Find Cust ID From Swf !!!");
		    			sGtlMsg += ":52Z:";
		    			sGtlMsg += sCustId;
		    			sGtlMsg += "\r\n";
		    		}
		    		else if (!getPUConfig(sProcUnit, "DUMMY_FOREIGN_BANK").trim().equals("")){
		    			sCustId=getPUConfig(sProcUnit, "DUMMY_FOREIGN_BANK");
		    			logDebug(" TAG52Z dummy foreign bnk !!!");
		    			sGtlMsg += ":52Z:";
		    			sGtlMsg += sCustId;
		    			sGtlMsg += "\r\n";
		    		}
		    		else {
		    			logDebug(" TAG52D Sender Swf addr !!!");
		    			sGtlMsg += ":52D:";
		    			sGtlMsg += SndSwfAddr;
		    			sGtlMsg += "\r\n";
		    			sGtlMsg += "(Sender SWIFT Address)";
		    			sGtlMsg += "\r\n";
		    		}

		    		// Variance (Tag 39A)
		    		if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:39A:")).trim().equals("") ) {
		    			sGtlMsg += ":39A:";
		    			sGtlMsg += SwiftTag;
		    		}


		    		// Start - EMEA 20060706
		    		// Applicable Rule (Tag 40E)
		    		if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:40E:")).trim().equals("") ) {
		    			sGtlMsg += ":40E:";
		    			sGtlMsg += SwiftTag;
		    			sGtlMsg += "\r\n";
		    		}

		    		// Available With... By... (Tag 41A)
		    		if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:41A:")).trim().equals("") ) {
		    			sGtlMsg += ":41A:";
		    			sGtlMsg += SwiftTag;
		    			sGtlMsg += "\r\n";
		    		}

		    		// Available With... By... (Tag 41D)
		    		if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:41D:")).trim().equals("") ) {
		    			sGtlMsg += ":41D:";
		    			sGtlMsg += SwiftTag;
		    			sGtlMsg += "\r\n";
		    		}

		    		// Drawee (Tag 42A)
		    		if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:42A:")).trim().equals("") ) {
		    			sGtlMsg += ":42A:";
		    			sGtlMsg += SwiftTag;
		    			sGtlMsg += "\r\n";
		    			
		    			sGtlMsg += ":52D:";
		    			sGtlMsg += SwiftTag;
		    			sGtlMsg += "\r\n";
		    		}

		    		// Drafts at... (Tag 42C)
		    		if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:42C:")).trim().equals("")) {
		    			sGtlMsg += ":42C:";
		    			sGtlMsg += SwiftTag;
		    			sGtlMsg += "\r\n";
		    		}

		    		// Drawee (Tag 42D)
		    		if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:42D:")).trim().equals("") ) {
		    			sGtlMsg += ":42D:";
		    			sGtlMsg += SwiftTag;
		    			sGtlMsg += "\r\n";
		    		}

		    		// Mixed Payment Details (Tag 42M)
		    		if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:42M:")).trim().equals("")) {
		    			sGtlMsg += ":42M:";
		    			sGtlMsg += SwiftTag;
		    			sGtlMsg += "\r\n";
		    		}

		    		// Deferred Payment Details (Tag 42P)
		    		if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:42P:")).trim().equals("") ) {
		    			sGtlMsg += ":42P:";
		    			sGtlMsg += SwiftTag;
		    			sGtlMsg += "\r\n";
		    		}

		    		// Partial Shipments (Tag 43P)
		    		if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:43P:")).trim().equals("")) {
		    			sGtlMsg += ":43P:";
		    			sGtlMsg += SwiftTag;
		    			sGtlMsg += "\r\n";
		    		}

		    		// Transshipment (Tag 43T)
		    		if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:43T:")).trim().equals("") ) {
		    			sGtlMsg += ":43T:";
		    			sGtlMsg += SwiftTag;
		    			sGtlMsg += "\r\n";
		    		}

		    		// Loading on Board/Dispatch/Taking in Charge at/from... (Tag 44A)
		    		if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:44A:")).trim().equals("")) {
		    			sGtlMsg += ":44A:";
		    			sGtlMsg += SwiftTag;
		    			sGtlMsg += "\r\n";
		    		}

		    		// For Transportation to... (Tag 44B)
		    		if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:44B:")).trim().equals("") ) {
		    			sGtlMsg += ":44B:";
		    			sGtlMsg += SwiftTag;
		    			sGtlMsg += "\r\n";
		    		}

		    		// Latest Date of Shipment (Tag 44C)
		    		if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:44C:")).trim().equals("")) {
		    			sGtlMsg += ":44C:";
		    			sGtlMsg += SwiftTag;
		    			sGtlMsg += "\r\n";
		    		}

		    		// Shipment Period (Tag 44D)
		    		if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:44D:")).trim().equals("")) {
		    			sGtlMsg += ":44D:";
		    			sGtlMsg += SwiftTag;
		    			sGtlMsg += "\r\n";
		    		}

		    		// Port From
		    		if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:44E:")).trim().equals("")) {
		    			sGtlMsg += ":44E:";
		    			sGtlMsg += SwiftTag;
		    			sGtlMsg += "\r\n";
		    		}

		    		// Port To
		    		if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:44F:")).trim().equals("")) {
		    			sGtlMsg += ":44F:";
		    			sGtlMsg += SwiftTag;
		    			sGtlMsg += "\r\n";
		    		}

		    		// Description of Goods (Tag 45A and 45B of 701)
		    		if (!(SwiftTag = GetTok(dtMsgContent, "\r\n:45A:")).trim().equals("")) {
		    			sGtlMsg += ":45A:";
		    			sGtlMsg += SwiftTag;
		    			if (!(SwiftTag = GetTok(dtMsgContent, "\r\n:45B:")).trim().equals("") )
		    				sGtlMsg += SwiftTag;
		    			sGtlMsg += "\r\n";
		    		} else if (!(SwiftTag = GetTok(dtMsgContent, "\r\n:45B:")).trim().equals("")) {
		    			sGtlMsg += ":45A:";
		    			sGtlMsg += SwiftTag;
		    			sGtlMsg += "\r\n";
		    		}

		    		// Documents Required (Tag 46A and 46B of 701)
		    		if (!(SwiftTag = GetTok(dtMsgContent, "\r\n:46A:")).trim().equals("")) {
		    			sGtlMsg += ":46A:";
		    			sGtlMsg += SwiftTag;
		    			if (!(SwiftTag = GetTok(dtMsgContent, "\r\n:46B:")).trim().equals("") )
		    				sGtlMsg += SwiftTag;
		    			sGtlMsg += "\r\n";
		    		} else if (!(SwiftTag = GetTok(dtMsgContent, "\r\n:46B:")).trim().equals("") ) {
		    			sGtlMsg += ":46A:";
		    			sGtlMsg += SwiftTag;
		    			sGtlMsg += "\r\n";
		    		}

		    		// Additional Conditions (Tag 47A)
		    		if (!(SwiftTag = GetTok(dtMsgContent, "\r\n:47A:")).trim().equals("")) {
		    			sGtlMsg += ":47A:";
		    			sGtlMsg += SwiftTag;
		    			if (!(SwiftTag = GetTok(dtMsgContent, "\r\n:47B:")).trim().equals(""))
		    				sGtlMsg += SwiftTag;
		    			sGtlMsg += "\r\n";
		    		} else if (!(SwiftTag = GetTok(dtMsgContent, "\r\n:47B:")).trim().equals("")) {
		    			sGtlMsg += ":47A:";
		    			sGtlMsg += SwiftTag;
		    			sGtlMsg += "\r\n";
		    		}

		    		// Period for Presentation (Tag 48)
		    		if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:48:")).trim().equals("") ) {
		    			sGtlMsg += ":48:";
		    			sGtlMsg += SwiftTag;
		    			sGtlMsg += "\r\n";
		    		}

		    		// Confirmation Instructions (Tag 49)
		    		if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:49:")).trim().equals("") ) {
		    			sGtlMsg += ":49:";
		    			sGtlMsg += SwiftTag;
		    			sGtlMsg += "\r\n";
		    		}

		    		// Applicant (Tag 50)
		    		if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:50:")).trim().equals("") ) {
		    			sGtlMsg += ":50:";
		    			sGtlMsg += SwiftTag;
		    			sGtlMsg += "\r\n";
		    		}

		    		// Applicant Bank (Tag 51A)
		    		if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:51A:")).trim().equals("") ) {
		    			sGtlMsg += ":51A:";
		    			sGtlMsg += SwiftTag;
		    			sGtlMsg += "\r\n";
		    		}

		    		// Applicant Bank (Tag 51D)
		    		if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:51D:")).trim().equals("") ) {
		    			sGtlMsg += ":51D:";
		    			sGtlMsg += SwiftTag;
		    			sGtlMsg += "\r\n";
		    		}

		    		// Issuing Bank (Tag 52A)
		    		if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:52A:")).trim().equals("")) {
		    			sGtlMsg += ":52A:";
		    			sGtlMsg += SwiftTag;
		    			sGtlMsg += "\r\n";
		    		}


		    		// Reimbursing Bank (Tag 53A)
		    		if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:53A:")).trim().equals("") ) {
		    			sGtlMsg += ":53A:";
		    			sGtlMsg += SwiftTag;
		    			sGtlMsg += "\r\n";
		    		}

		    		// Reimbursing Bank (Tag 53D)
		    		if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:53D:")).trim().equals("") ) {
		    			sGtlMsg += ":53D:";
		    			sGtlMsg += SwiftTag;
		    			sGtlMsg += "\r\n";
		    		}

		    		// "Advise Through" Bank (Tag 57A)
		    		if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:57A:")).trim().equals("") ) {
		    			sGtlMsg += ":57A:";
		    			sGtlMsg += SwiftTag;
		    			sGtlMsg += "\r\n";
		    		}

		    		// "Advise Through" Bank (Tag 57B)
		    		if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:57B:")).trim().equals("")) {
		    			sGtlMsg += ":57B:";
		    			sGtlMsg += SwiftTag;
		    			sGtlMsg += "\r\n";
		    		}

		    		// "Advise Through" Bank (Tag 57D)
		    		if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:57D:")).trim().equals("")) {
		    			sGtlMsg += ":57D:";
		    			sGtlMsg += SwiftTag;
		    			sGtlMsg += "\r\n";
		    		}

		    		// Beneficiary (Tag 59)
		    		if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:59:")).trim().equals("")) {
		    			sGtlMsg += ":59:";
		    			sGtlMsg += SwiftTag;
		    			sGtlMsg += "\r\n";
		    		}

		    		// Charges (Tag 71B)
		    		if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:71B:")).trim().equals("") ) {
		    			sGtlMsg += ":71B:";
		    			sGtlMsg += SwiftTag;
		    			sGtlMsg += "\r\n";
		    		}
		    		
		    		//End - EMEA 20060706

		    		// Reimbursement Bank (Tag 53A/D)
		    		if ((!(SwiftTag = GetTok(dtMsgContent, "\r\n:53A:")).trim().equals("")) || (!(SwiftTag = GetTok(dtMsgContent, "\r\n:53D:")).trim().equals("") )) {
		    			sGtlMsg += ":53I:";
		    			sGtlMsg += "Y";
		    			sGtlMsg += "\r\n";
		    			String SndAddr;
		    			if ( SwiftTag.charAt(0) == '/' ) {
		    				int nLineFeed = SwiftTag.indexOf('\n');
		    				++nLineFeed;
		    				// GetLength() - 2 to remove \r\n
		    				SndAddr = Mid(SwiftTag, nLineFeed, nLineFeed + SwiftTag.length() - 2 );
		    			} else {
		    				SndAddr = Left(SwiftTag, SwiftTag.length() - 2);
		    			}
		    			sGtlMsg += ":53D:";
		    			sGtlMsg += SndAddr;
		    			sGtlMsg += "\r\n";
		    		}
		    		
		    		
		    		if (!(SwiftTag = GetTok(dtMsgContent, "\r\n:57A:")).trim().equals("")) {
		    			String SndAddr;
		    			if (SwiftTag.charAt(0) == '/') { // using [/34x] acct num
		    				int nLineFeed = SwiftTag.indexOf('\n');
		    				++nLineFeed;
		    				SndAddr = Mid(SwiftTag, nLineFeed, nLineFeed + SwiftTag.length() - 2 );
		    			}
		    			else
		    				SndAddr = Left(SwiftTag, SwiftTag.length() - 2);
		    			
		    			sCustId=FindCustIdFromSwf(SndAddr, sProcUnit);
		    			if (!sCustId.trim().equals("")) {
		    				sGtlMsg += ":57Y:";
		    				sGtlMsg += sCustId;
		    				sGtlMsg += "\r\n";
		    			}
		    			else {
		    				logDebug(" TAG52D Sender Swf addr 2 !!!");
		    				sGtlMsg += ":52D:";
		    				sGtlMsg += SndAddr;
		    				sGtlMsg += "\r\n";
		    			}
		    		} else if (!(SwiftTag = GetTok(dtMsgContent, "\r\n:57B:")).trim().equals("") ) { // 06/24 Need to clarify
		    			sGtlMsg += ":57E:";                           // how to handle 2nd Advising
		    			sGtlMsg += SwiftTag;                          // Bank info.
		    			sGtlMsg += "\r\n";
		    		} else if (!(SwiftTag = GetTok(dtMsgContent, "\r\n:57D:")).trim().equals("") ) {
		    			sGtlMsg += ":57E:";
		    			sGtlMsg += SwiftTag;
		    			sGtlMsg += "\r\n";
		    		}

		    		// Instruction to the Paying/Accepting/Negotiation Bank (Tag 78)
		    		if (!(SwiftTag = GetTok(dtMsgContent, "\r\n:78:")).trim().equals("")) {
		    			sGtlMsg += ":78I:";
		    			sGtlMsg += "Y";
		    			sGtlMsg += "\r\n";
		    			sGtlMsg += ":78:";
		    			sGtlMsg += SwiftTag;
		    		}

		    		//20030804, Davy, Start
		    		// Handle for the LCSPEC Mapping
		    		// Reformat the Tags for LCSPEC use Tag 47X --> IDS_TAG_LCSPEC
		    		if ( (!(SwiftTag = GetTok(dtMsgContent, "\r\n:72:")).trim().equals("") ) || (!(SwiftTag = GetTok(dtMsgContent, "\r\n:39B:")).trim().equals("") ) || (!(SwiftTag = GetTok(dtMsgContent, "\r\n:39C:")).trim().equals("") ) || (!(SwiftTag = GetTok(dtMsgContent, "\r\n:51A:")).trim().equals("") ) || (!(SwiftTag = GetTok(dtMsgContent, "\r\n:51D:")).trim().equals("") ) || (!(SwiftTag = GetTok(dtMsgContent, "\r\n:52A:")).trim().equals("") ) || (!(SwiftTag = GetTok(dtMsgContent, "\r\n:52D:")).trim().equals("") ) || (!(SwiftTag = GetTok(dtMsgContent, "\r\n:57A:")).trim().equals("") ) || (!(SwiftTag = GetTok(dtMsgContent, "\r\n:57B:")).trim().equals("") ) || (!(SwiftTag = GetTok(dtMsgContent, "\r\n:57D:")).trim().equals("") ) || (!(SwiftTag = GetTok(dtMsgContent, "\r\n:59:")).trim().equals("") ) || (!(SwiftTag = GetTok(dtMsgContent, "\r\n:42A:")).trim().equals("") ) || (!(SwiftTag = GetTok(dtMsgContent, "\r\n:42D:")).trim().equals("") ) || (!(SwiftTag = GetTok(dtMsgContent, "\r\n:53A:")).trim().equals("") ) || (!(SwiftTag = GetTok(dtMsgContent, "\r\n:53D:")).trim().equals("") )){
		    			sGtlMsg += ":47X:";
		    			if (!(SwiftTag = GetTok(dtMsgContent, "\r\n:23:")).trim().equals("") ) {
		    				sGtlMsg += "Tag 23 (REFERENCE TO PRE-ADVICE) IS PRESENT. ";
		    				sGtlMsg += "\r\n";
		    			}
		    			if (!(SwiftTag = GetTok(dtMsgContent, "\r\n:39B:")).trim().equals("") ) {
		    				sGtlMsg += "Tag 39B (MAXIMUM CREDIT AMOUNT) IS PRESENT. ";
		    				sGtlMsg += "\r\n";
		    			}
		    			if (!(SwiftTag = GetTok(dtMsgContent, "\r\n:39C:")).trim().equals("") ) {
		    				sGtlMsg += "Tag 39C (ADDITIONAL AMOUNTS COVERED) IS PRESENT. ";
		    				sGtlMsg += "\r\n";
		    			}
		    			if (!(SwiftTag = GetTok(dtMsgContent, "\r\n:42A:")).trim().equals("") ) {
		    				if ( SwiftTag.charAt(0) == '/' ) {
		    					sGtlMsg += "Tag 42A (DRAWEE) contains Party Identifier. ";
		    					sGtlMsg += "\r\n";
		    				}
		    			}
		    			if (!(SwiftTag = GetTok(dtMsgContent, "\r\n:42D:")).trim().equals("") ) {
		    				if ( SwiftTag.charAt(0) == '/' ) {
		    					sGtlMsg += "Tag 42D (DRAWEE) contains Party Identifier. ";
		    					sGtlMsg += "\r\n";
		    				}
		    			}
		    			if ( (!(SwiftTag = GetTok(dtMsgContent, "\r\n:51A:")).trim().equals("") ) || (!(SwiftTag = GetTok(dtMsgContent, "\r\n:51D:")).trim().equals("") ) ) {
		    				if (!(SwiftTag = GetTok(dtMsgContent, "\r\n:51A:")).trim().equals("") ) {
		    					if ( SwiftTag.charAt(0) == '/' ) {
		    						sGtlMsg += "Tag 51A (APPLICANT BANK) contains Party Identifier. ";
		    						sGtlMsg += "\r\n";
		    					}
		    					sGtlMsg += "Tag 51A (APPLICANT BANK) IS PRESENT. ";
		    					sGtlMsg += "\r\n";
		    				}
		    				else if (!(SwiftTag = GetTok(dtMsgContent, "\r\n:51D:")).trim().equals("") ) {
		    					if ( SwiftTag.charAt(0) == '/' ) {
		    						sGtlMsg += "Tag 51D (APPLICANT BANK) contains Party Identifier. ";
		    						sGtlMsg += "\r\n";
		    					}
		    					sGtlMsg += "Tag 51D (APPLICANT BANK) IS PRESENT. ";
		    					sGtlMsg += "\r\n";
		    				}
		    			}
		    			//20030813
		    			if ( (!(SwiftTag = GetTok(dtMsgContent, "\r\n:52A:")).trim().equals("") ) || (!(SwiftTag = GetTok(dtMsgContent, "\r\n:52D:")).trim().equals("") ) ) {
		    				if (!(SwiftTag = GetTok(dtMsgContent, "\r\n:52A:")).trim().equals("") ) {
		    					if ( SwiftTag.charAt(0) == '/' ) {
		    						sGtlMsg += "Tag 52A (ISSUING BANK) contains Party Identifier. ";
		    						sGtlMsg += "\r\n";
		    					}
		    					sGtlMsg += "Tag 52A (ISSUING BANK) IS PRESENT. ";
		    					sGtlMsg += "\r\n";
		    				}
		    				else if (!(SwiftTag = GetTok(dtMsgContent, "\r\n:52D:")).trim().equals("") ) {
		    					if ( SwiftTag.charAt(0) == '/' ) {
		    						sGtlMsg += "Tag 52D (ISSUING BANK) contains Party Identifier. ";
		    						sGtlMsg += "\r\n";
		    					}
		    					sGtlMsg += "Tag 52D (ISSUING BANK) IS PRESENT. ";
		    					sGtlMsg += "\r\n";
		    				}
		    			}
		    			//20030813
		    			if (!(SwiftTag = GetTok(dtMsgContent, "\r\n:53A:")).trim().equals("") ) {
		    				if ( SwiftTag.charAt(0) == '/' ) {
		    					sGtlMsg += "Tag 53A (REIMBURSING BANK) contains Party Identifier. ";
		    					sGtlMsg += "\r\n";
		    				}
		    			}
		    			if (!(SwiftTag = GetTok(dtMsgContent, "\r\n:53D:")).trim().equals("") ) {
		    				if ( SwiftTag.charAt(0) == '/' ) {
		    					sGtlMsg += "Tag 53D (REIMBURSING BANK) contains Party Identifier. ";
		    					sGtlMsg += "\r\n";
		    				}
		    			}
		    			if (!(SwiftTag = GetTok(dtMsgContent, "\r\n:57A:")).trim().equals("") ) {
		    				if ( SwiftTag.charAt(0) == '/' ) {
		    					sGtlMsg += "Tag 57A (ADVISE THROUGH BANK) contains Party Identifier. ";
		    					sGtlMsg += "\r\n";
		    				}
		    				sGtlMsg += "Tag 57A (ADVISE THROUGH BANK) IS PRESENT. ";
		    				sGtlMsg += "\r\n";
		    			}
		    			if (!(SwiftTag = GetTok(dtMsgContent, "\r\n:57B:")).trim().equals("") ) {
		    				if ( SwiftTag.charAt(0) == '/' ) {
		    					sGtlMsg += "Tag 57B (ADVISE THROUGH BANK) contains Party Identifier. ";
		    					sGtlMsg += "\r\n";
		    				}
		    				sGtlMsg += "Tag 57B (ADVISE THROUGH BANK) IS PRESENT. ";
		    				sGtlMsg += "\r\n";
		    			}
		    			if (!(SwiftTag = GetTok(dtMsgContent, "\r\n:57D:")).trim().equals("") ) {
		    				if ( SwiftTag.charAt(0) == '/' ) {
		    					sGtlMsg += "Tag 57D (ADVISE THROUGH BANK) contains Party Identifier. ";
		    					sGtlMsg += "\r\n";
		    				}
		    				sGtlMsg += "Tag 57D (ADVISE THROUGH BANK) IS PRESENT. ";
		    				sGtlMsg += "\r\n";
		    			}
		    			if (!(SwiftTag = GetTok(dtMsgContent, "\r\n:59:")).trim().equals("") ) {
		    				if ( SwiftTag.charAt(0) == '/' ) {
		    					sGtlMsg += "Tag 59 (BENEFICIARY) contains Party Identifier. ";
		    					sGtlMsg += "\r\n";
		    				}
		    			}
		    			if (!(SwiftTag = GetTok(dtMsgContent, "\r\n:72:")).trim().equals("") ) {
		    				sGtlMsg += "SENDER TO RECEIVER INFORMATION: ";
		    				sGtlMsg += SwiftTag;
		    			}
		    		}
		    	}

		    logDebug("sGtlMsg = \n" + sGtlMsg);
	    	hParentResult.remove(FIELD_MSG_TEXT);
	    	hParentResult.put(FIELD_MSG_TEXT, sGtlMsg);

	        return true;
	     }catch (Exception ex) {
	            logDebug((Throwable) ex);
			    logDebug("IMParseMappingExtractor.MT710_to_Gtl: "+ex.getMessage());
				//throw new Exception(ex.getMessage());
			    logDebug("ERROR MT710_to_Gtl(). Return false");
			    return false;
	     }
	}
	
	private boolean MT740_to_Gtl(Hashtable hParentResult, DataTable dtMsgContent) throws Exception
	{
		 logDebug("Start MT740_to_Gtl()");
		 //IDataConnection  conn = null;
		 DataTable dt;
		 try{
	    	 String sProcUnit=(String)hParentResult.get(FIELD_PROC_UNIT);
	    	 String sMsgTyp=(String)hParentResult.get(FIELD_MSG_TYP);
		     String sGtlMsg="";
		     String Sql="";
		     int sQueueId=((Integer)hParentResult.get(FIELD_QUEUE_ID)).intValue();
		     String sSendRecvAddr=(String)hParentResult.get(FIELD_SEND_RECV_ADDR);
		     String sDummyId=(String)hParentResult.get(FIELD_DUMMY_ID);
		     
		         // Convert Swift to GTL and update the SI_MSG_Q
		        int len = 0;
		        String sTag40A  = "C\r\n";
		        String SwiftTag;
		        String sCustId="";
		        String SndSwfAddr;

		        String sProdCat  = "AUT";
		        String sLcTyp    = "C";
		        String sProdType = "";
		        String sExtRefNbr = "";
		        String sSenderRef = " ";
		        String sRecvRef = " ";
		        String sIssuBnkRef = " ";
		        String sTranType = " ";
		        String sOrigRefNbr = " ";
		        //20021113, Davy, Start
		        String sConfigVal = " ";
		        //20021113, Davy, End
		        
		        String sTranRefNbr="";
		        hParentResult.remove(FIELD_EXT_REF_NBR);
		        hParentResult.remove(FIELD_PROD_CAT);
		        hParentResult.remove(FIELD_PROD_TYP);
		        hParentResult.remove(FIELD_TRAN_REF_NBR);
		        hParentResult.put(FIELD_EXT_REF_NBR, sExtRefNbr);
		        hParentResult.put(FIELD_PROD_CAT, sProdCat);
		        hParentResult.put(FIELD_PROD_TYP, sProdType);
		        hParentResult.put(FIELD_TRAN_REF_NBR, sTranRefNbr);
		        
		        hParentResult.remove(FIELD_LC_TYP);
		        hParentResult.put(FIELD_LC_TYP, sLcTyp);
		        
		    //GT_DBRows *pDBRows;
			//pDBRows = new GT_DBRows();
			//GT_DBRows *pDBRows1;
		    //    pDBRows1 = new GT_DBRows();
		        

		        //GT_DBRows* pResult;
		        String  sIssuBnkId="",sDdaAcctRef="";
		        int rowcount;
		        String sSwiftId="";       
		        if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:25:")).trim().equals("")) {
		                len = SwiftTag.indexOf("\r\n");
		                if (len != -1)
		                        sDdaAcctRef = Left(SwiftTag, len);
		        else
		           	 sDdaAcctRef = "";
		        }
		        
		        //conn=getConnection();
		        	Sql  = "select a.EXT_REF ,b.EXT_MSG_REF ";
			        Sql += " from GTDPEND1..SI_MSG_Q a, GTDPEND1..SI_MSG b ";
			        Sql += " where a.INTF_PROC_UNIT = '"+sProcUnit+"' ";
			        Sql += " and a.QUEUE_TYP = 'SWF' ";
			        Sql += " and a.QUEUE_ID = "+sQueueId +" ";
				Sql += " and b.PROC_UNIT = a.INTF_PROC_UNIT ";
				Sql += " and b.QUEUE_ID = a.QUEUE_ID ";
				Sql += " and b.QUEUE_TYP = a.QUEUE_TYP ";
			
				dt= conn.executeQuery(Sql);
				//close(conn);
				
				rowcount = dt.size();
		        String sTmp;
		        if (rowcount == 1) {

		        		dt.next();
		        		sTmp=(String)dt.getField("EXT_MSG_REF");
		        		sTmp=sTmp.trim();
		        		if (! sTmp.trim().equals(""))
		                        sIssuBnkId =sTmp;
		        		
		        		sTmp=(String)dt.getField("EXT_REF");
		        		sTmp=sTmp.trim();
		                if (! sTmp.trim().equals(""))
		                        sOrigRefNbr =sTmp;
				sSenderRef = sOrigRefNbr;
		
				sIssuBnkRef = sOrigRefNbr;
		        }

	        	Sql = "exec GTDPEND1..USP_ISWF_SNDADDR_MAP_STP '"+sSendRecvAddr+"' ";
	        	logDebug("USP_ISWF_SNDADDR_MAP_STP SQL:"+Sql );
	        	//conn=getConnection();
	        	dt=conn.executeQuery(Sql);
	        	//close(conn);

			    logDebug("START SWIFT_ID="+sSwiftId);
			    if(dt.size()>0){
				    dt.next();
				    sSwiftId=(String)dt.getField("SWIFT_ID");
			    }
			    logDebug("SWIFT_ID="+sSwiftId);
			    			    
			    Sql = "GTDPEND1..USP_CGET_ISU_BNK_INFO ";
		        Sql = Sql + " '"+sProcUnit+"'";
		        Sql = Sql + ", '"+sSwiftId+"'";
		        Sql = Sql + ", '"+sDdaAcctRef+"'";
		        Sql = Sql + ", "+sQueueId;
		        Sql = Sql + ", 'SWF', '"+sIssuBnkId+"' ";
		logDebug("MapIssuingBankInfo SQL: "+Sql);
				
				//conn=getConnection();
				dt=conn.executeQuery(Sql);
				//close(conn);
				if(dt.size()>0){
					dt.next();
					sCustId=(String)dt.getField("CUST_ID");
				}
			    
			    
				/*
			    Trim(sCustId);
			    cout<<"Located Issuing Bank ID = "<< sCustId<<endl;
			    */
				sCustId=sCustId.trim();
				logDebug("Located Issuing Bank ID = "+sCustId);
			//20021113, Davy, Start
	// /*GWF: Logic of 740 generate EXT_REF_NBR is skipped - Begin
				hParentResult.put(FIELD_SENDER_REF, sSenderRef);
			    hParentResult.put(FIELD_RECV_REF, sRecvRef);
			    hParentResult.put(FIELD_ISSU_BNK_REF, sIssuBnkRef);
				
			    if (sMsgTyp.trim().equals("740")) {
		        	//GetPuConfig(sProcUnit, "INSWF_PARSE_GEN_REF_BTB", sConfigVal);
		        	sConfigVal=getPUConfig(sProcUnit, "INSWF_PARSE_GEN_REF");
				//sConfigVal = sConfigVal.SpanExcluding(" ");
				if (sConfigVal.trim().equals("Y"))	{
					logDebug("Before the process to Generate the ExtRefNbr...");
					
					//Get the CUST_ID first for get EXT_REF_NBR
				    	if ( ! sCustId.trim().equals("") ) {
						sDummyId =sCustId;
				        }else
					{
						//GetPuConfig(sProcUnit, "DUMMY_WALKIN_CUST", sDummyId);
				        sDummyId=getPUConfig(sProcUnit, "DUMMY_WALKIN_CUST");
						logDebug("Cannot find CustID for ("+SwiftTag+"), so use DUMMY_WALKIN_CUST ("+sDummyId+")");

					}
				    	hParentResult.remove(FIELD_DUMMY_ID);
				    	hParentResult.put(FIELD_DUMMY_ID, sDummyId);
				    	
				    	        if (! GetExtRefNbr (hParentResult)) {
		                                logDebug("Testing for the GetExtRefNbr ......... GetExtRefNbr failed");
		                                //GWF: Do not return false
		                                //return (QS_FAIL);
		                        }else{
		                        	logDebug("Testing for the GetExtRefNbr ......... GetExtRefNbr success");
		                        	sExtRefNbr=(String)hParentResult.get(FIELD_EXT_REF_NBR);
		                        	sProdCat=(String)hParentResult.get(FIELD_PROD_CAT);
		                        	sProdType=(String)hParentResult.get(FIELD_PROD_TYP);
		                        	sTranRefNbr=(String)hParentResult.get(FIELD_TRAN_REF_NBR);
		                        	
		                        }
		                        
		                        
					if (sExtRefNbr.trim().equals("")) {
		                                //if (selectTranType () == QS_FAIL) {
		                                if (! selectTranType (hParentResult)) {
		                                        logDebug("Testing for selectTranType.......... selectTranType failed");
		                                        //GWF: Do not return false
		                                        //return (QS_FAIL);
		                                }else{
		                                	logDebug("Testing for selectTranType.......... selectTranType success");
		                                	sProdType=(String)hParentResult.get(FIELD_PROD_TYP);
		                        			sTranType=(String)hParentResult.get(FIELD_TRAN_TYP);
		                        			sProdCat=(String)hParentResult.get(FIELD_PROD_CAT);
		                                }
		                               
		                                //if (GenNewTranRefNbr() == QS_FAIL) {
		                                if (! GenNewTranRefNbr(hParentResult)) {
		                                		logDebug("Testing for GenNewTranRefNbr.......... GenNewTranRefNbr failed");
		                                		//GWF: Do not return false
		                                        //return (QS_FAIL);
		                                }else{
		                                	logDebug("Testing for GenNewTranRefNbr.......... GenNewTranRefNbr success");
		                                	sExtRefNbr=(String)hParentResult.get(FIELD_EXT_REF_NBR);
		                                }
		                                	
		                                if (sExtRefNbr.trim().equals("")) {
		                                        logDebug("Error in getting EXT_REF_NBR for MT740");
		                                        //GWF: Do not return false
		                                        //return (QS_FAIL);
		                                }else
		                                	logDebug("The ExtRefNbr is generated");
		                                
		               }
				}
				else if (sConfigVal.trim().equals("N"))	{
					/*if (selectTranType () == QS_FAIL) {
						cout << "Testing for selectTranType.........." << endl;
						return (QS_FAIL);
					}*/
					logDebug("The process will not Generate the ExtRefNbr...");
				}

		        }
	//GWF: Logic of 740 generate EXT_REF_NBR is skipped - End */

//		20030818
		/*
		        sGtlMsg += "\r\n:00B:";
		        sGtlMsg += sTag40A;
		*/
//		20030818
//		20030818
		/*
		        if (sOrigRefNbr != "") {
					sGtlMsg += ":20:";
		            sGtlMsg += sExtRefNbr;
					sGtlMsg += "\r\n";
					sGtlMsg += ":20Z:";
					sGtlMsg += sOrigRefNbr;
					sGtlMsg += "\r\n";
					sGtlMsg += ":20Y:";
					sGtlMsg += sOrigRefNbr;
					sGtlMsg += "\r\n";
		        }

			// Value Date
			CString sValDt;
			Sql  = "select convert(char(6), getdate(), 12) as VALUE_DT";
			SetSql(Sql);
			ExecSql();
			if (!GetResult(&pDBRows))
				return (QS_FAIL) ;
		        p = pDBRows->GetAttr("VALUE_DT");
				ASSERT(p != NULL);
				if (p != NULL)
					p->GetValue(sValDt);
				sGtlMsg += ":00D:";
				sGtlMsg += CheckDt(sValDt);
				sGtlMsg += "\r\n";
			*/
//		20030818

//		****
				
		 sGtlMsg = sProdCat; sGtlMsg += sMsgTyp;
		        sGtlMsg += "\r\n";

		        if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:20:")).trim().equals("")) {
		                len = SwiftTag.indexOf("\r\n");
		                if (len != -1)
		                        sOrigRefNbr = Left(SwiftTag, len);
				else
				sOrigRefNbr = SwiftTag;
		        }

				sSenderRef  = sOrigRefNbr;
				sIssuBnkRef = sOrigRefNbr;


		        if (! sOrigRefNbr.trim().equals("")) {
				sGtlMsg += ":20:";
				sGtlMsg += sOrigRefNbr;
				sGtlMsg += "\r\n";
		        }
//		****

//		ASIA3.0
			// Value Date
				String sValDt="";
				Sql  = "select convert(char(6), getdate(), 12) as VALUE_DT";
				/*
				SetSql(Sql);
				ExecSql();
				if (!GetResult(&pDBRows))
					return (QS_FAIL) ;
		        p = pDBRows->GetAttr("VALUE_DT");
				ASSERT(p != NULL);
				if (p != NULL)
					p->GetValue(sValDt);
				*/
				//conn=getConnection();
				dt=conn.executeQuery(Sql);
				//close(conn);
				if(dt.size()>0){
					dt.next();
					sValDt=(String)dt.getField("VALUE_DT");
				}
				sGtlMsg += ":00D:";
				sGtlMsg += CheckDt(sValDt);
				sGtlMsg += "\r\n";
//		ASIA3.0		

			// Account Identification (Tag 25)
		    	if ( ! (SwiftTag = GetTok(dtMsgContent, "\r\n:25:")).trim().equals("") ) {
		                sGtlMsg += ":25:";
		                sGtlMsg += SwiftTag;
				sGtlMsg += "\r\n";
		        }
		        
			// Applicable Rule (Tag 40F)
		    	if ( ! (SwiftTag = GetTok(dtMsgContent, "\r\n:40F:")).trim().equals("") ) {
		                sGtlMsg += ":40F:";
		                sGtlMsg += SwiftTag;
				sGtlMsg += "\r\n";
		        }

		        // Date and Place of Expiry (Tag 31D)
		    	if ( ! (SwiftTag = GetTok(dtMsgContent, "\r\n:31D:")).trim().equals("") ) {
		                sGtlMsg += ":31D:";
		                sGtlMsg += SwiftTag;
				sGtlMsg += "\r\n";
		        }
		        // Negotiating Bank (Tag 58A)
		        if ( ! (SwiftTag = GetTok(dtMsgContent, "\r\n:58A:")).trim().equals("") ) {
		                sGtlMsg += ":58A:";
		                sGtlMsg += SwiftTag;
		                sGtlMsg += "\r\n";
		        }
		 
			// Negotiating Bank (Tag 58D)
		    	if ( ! (SwiftTag = GetTok(dtMsgContent, "\r\n:58D:")).trim().equals("") ) {
		                sGtlMsg += ":58D:";
		                sGtlMsg += SwiftTag;
				sGtlMsg += "\r\n";
		        }

		        // Beneficiary (Tag 59)
		    	if ( ! (SwiftTag = GetTok(dtMsgContent, "\r\n:59:")).trim().equals("") ) {
		                sGtlMsg += ":59:";
		                sGtlMsg += SwiftTag;
				sGtlMsg += "\r\n";
		        }

		        // Credit Amount (Tag 32B)
		    	if ( ! (SwiftTag = GetTok(dtMsgContent, "\r\n:32B:")).trim().equals("") ) {
		                sGtlMsg += ":32B:";
		                sGtlMsg += SwiftTag;
				sGtlMsg += "\r\n";
		        }

		        // Currency Code, Amount (Tag 39A)
		    	if ( ! (SwiftTag = GetTok(dtMsgContent, "\r\n:39A:")).trim().equals("") ) {
		                sGtlMsg += ":39A:";
		                sGtlMsg += SwiftTag;
				sGtlMsg += "\r\n";
		        }

		        // Maximum Credit Amount (Tag 39B)
		    	if ( ! (SwiftTag = GetTok(dtMsgContent, "\r\n:39B:")).trim().equals("") ) {
		                sGtlMsg += ":39B:";
		                sGtlMsg += SwiftTag;
				sGtlMsg += "\r\n";
		        }

		        // Additional Amounts Covered (Tag 39C)
		    	if ( ! (SwiftTag = GetTok(dtMsgContent, "\r\n:39C:")).trim().equals("") ) {
		                sGtlMsg += ":39C:";
		                sGtlMsg += SwiftTag;
				sGtlMsg += "\r\n";
		        }



		        // Available With... By... (Tag 41A)
		    	if ( ! (SwiftTag = GetTok(dtMsgContent, "\r\n:41A:")).trim().equals("") ) {
		                sGtlMsg += ":41A:";
		                sGtlMsg += SwiftTag;
				sGtlMsg += "\r\n";
		        }

		        // Available With... By... (Tag 41D)
		    	if ( ! (SwiftTag = GetTok(dtMsgContent, "\r\n:41D:")).trim().equals("") ) {
		                sGtlMsg += ":41D:";
		                sGtlMsg += SwiftTag;
				sGtlMsg += "\r\n";
		        }

		        // Drawee (Tag 42A)
		    	if ( ! (SwiftTag = GetTok(dtMsgContent, "\r\n:42A:")).trim().equals("") ) {
		                sGtlMsg += ":42A:";
		                sGtlMsg += SwiftTag;
				sGtlMsg += "\r\n";
		        }

		        // Drafts at... (Tag 42C)
		    	if ( ! (SwiftTag = GetTok(dtMsgContent, "\r\n:42C:")).trim().equals("") ) {
		                sGtlMsg += ":42C:";
		                sGtlMsg += SwiftTag;
				sGtlMsg += "\r\n";
		        }

		        // Drawee (Tag 42D)
		    	if ( ! (SwiftTag = GetTok(dtMsgContent, "\r\n:42D:")).trim().equals("") ) {
		                sGtlMsg += ":42D:";
		                sGtlMsg += SwiftTag;
				sGtlMsg += "\r\n";
		        }

		        // Mixed Payment Details (Tag 42M)
		    	if ( ! (SwiftTag = GetTok(dtMsgContent, "\r\n:42M:")).trim().equals("") ) {
		                sGtlMsg += ":42M:";
		                sGtlMsg += SwiftTag;
				sGtlMsg += "\r\n";
		        }

		        // Deferred Payment Details (Tag 42P)
		    	if ( ! (SwiftTag = GetTok(dtMsgContent, "\r\n:42P:")).trim().equals("") ) {
		                sGtlMsg += ":42P:";
		                sGtlMsg += SwiftTag;
				sGtlMsg += "\r\n";
		        }

		        // Partial Shipments (Tag 43P)
		    	if ( ! (SwiftTag = GetTok(dtMsgContent, "\r\n:43P:")).trim().equals("") ) {
		                sGtlMsg += ":43P:";
		                sGtlMsg += SwiftTag;
				sGtlMsg += "\r\n";
		        }

		        // Reimbursing Bank's Charges (Tag 71A)
		    	if ( ! (SwiftTag = GetTok(dtMsgContent, "\r\n:71A:")).trim().equals("") ) {
		                sGtlMsg += ":71A:";
		                sGtlMsg += SwiftTag;
				sGtlMsg += "\r\n";
		        }

		        // Other Charges (Tag 71B)
		    	if ( ! (SwiftTag = GetTok(dtMsgContent, "\r\n:71B:")).trim().equals("") ) {
		                sGtlMsg += ":71B:";
		                sGtlMsg += SwiftTag;
				sGtlMsg += "\r\n";
		        }

		        // For Transportation to... (Tag 44B)
		    	if ( ! (SwiftTag = GetTok(dtMsgContent, "\r\n:44B:")).trim().equals("") ) {
		                sGtlMsg += ":44B:";
		                sGtlMsg += SwiftTag;
				sGtlMsg += "\r\n";
		        }

		        // Sender to Receiver Information (Tag 72)
		    	if ( ! (SwiftTag = GetTok(dtMsgContent, "\r\n:72:")).trim().equals("") ) {
		                sGtlMsg += ":72:";
		                sGtlMsg += SwiftTag;
				sGtlMsg += "\r\n";
		        }

		   

		    logDebug("sGtlMsg = \n" + sGtlMsg);
	    	hParentResult.remove(FIELD_MSG_TEXT);
	    	hParentResult.put(FIELD_MSG_TEXT, sGtlMsg);

	        return true;
	     }catch (Exception ex) {
	            //throw new TriggerException(e.getMessage());
	            logDebug((Throwable) ex);
			    logDebug("IMParseMappingExtractor.MT740_to_Gtl: "+ex.getMessage());
				//throw new Exception(ex.getMessage());
			    logDebug("ERROR MT740_to_Gtl(). Return false");
			    return false;
	     }finally{
	    	 //close(conn);
	     }
	}

	private boolean MT747_to_Gtl(Hashtable hParentResult, DataTable dtMsgContent) throws Exception
	{
		 logDebug("Start MT747_to_Gtl()");
		 //IDataConnection  conn = null;
		 DataTable dt;
	     try{
	    	 String sProcUnit=(String)hParentResult.get(FIELD_PROC_UNIT);
		     String sMsgTyp=(String)hParentResult.get(FIELD_MSG_TYP);
		     String sGtlMsg="";
		     String Sql="";
		     int sQueueId=((Integer)hParentResult.get(FIELD_QUEUE_ID)).intValue();
		     
		     
		 	// Convert Swift to GTL and update the SI_MSG_a
		 	String SwiftTag;
		 	int rowcount=0 ;
		 	
		 	String sExtRefNbr = "";
		 	String sSenderRef = " ";
		 	String sRecvRef = " ";
		 	String sIssuBnkRef = "";
		 	String sProdType = " ";
		 	String sProdCat = " ";
		 	String sTranType = " ";
		 	String sOrigRefNbr = " ";
		 	String sLcTyp = " ";
		 	String sTmpStr="";

		 	int len = 0;

		 	if  ( ! (SwiftTag = GetTok(dtMsgContent, "\r\n:20:")).trim().equals("") )
		 	{
		 		len = SwiftTag.length();
		 		//if (SwiftTag.Right(2) == "\r\n")
		 		//sTmpStr=SwiftTag.substring(len-2);
		 		sTmpStr=Right(SwiftTag,2);
		 		if(sTmpStr.trim().equals("\r\n"))
		 			sOrigRefNbr = Left(SwiftTag, len-2);
		 		else
		 			sOrigRefNbr = SwiftTag;

		 		sIssuBnkRef = sOrigRefNbr;
		 	}

		 	if ( ! (SwiftTag = GetTok(dtMsgContent, "\r\n:21:")).trim().equals("") )
		 	{
		 		len = SwiftTag.length();
		 		//sTmpStr=SwiftTag.substring(len-2);
		 		sTmpStr=Right(SwiftTag,2);
		 		if (sTmpStr.trim().equals("\r\n"))
		 			sRecvRef = Left(SwiftTag, len-2);
		 		else
		 			sRecvRef = SwiftTag;
		 	}

		 	sSenderRef = sOrigRefNbr;
		 	
			Sql  = "select a.EXT_REF ,b.EXT_MSG_REF ";
			Sql += " from GTDPEND1..SI_MSG_Q a, GTDPEND1..SI_MSG b ";
			Sql += " where a.INTF_PROC_UNIT = '"+sProcUnit+"' ";
			Sql += " and a.QUEUE_TYP = 'SWF' ";
			Sql += " and a.QUEUE_ID = "+sQueueId +" ";
			Sql += " and b.PROC_UNIT = a.INTF_PROC_UNIT ";
			Sql += " and b.QUEUE_ID = a.QUEUE_ID ";
			Sql += " and b.QUEUE_TYP = a.QUEUE_TYP ";
		 						
             logDebug("Sql ="+Sql);
             //conn=getConnection();
             dt=conn.executeQuery(Sql);
             //close(conn);
             rowcount = dt.size();
             
			 String sTmp;
             if (rowcount == 1) {

            	 	 dt.next();
            	 	 sTmp=(String)dt.getField("EXT_MSG_REF");
            	 	 sTmp=sTmp.trim();
            	 	 if (! sTmp.trim().equals(""))
                             sRecvRef =sTmp;


            	 	 sTmp=(String)dt.getField("EXT_REF");
            	 	 sTmp=sTmp.trim();
                     if (! sTmp.trim().equals(""))
                             sOrigRefNbr =sTmp;
 				sSenderRef = sOrigRefNbr;

 				sIssuBnkRef = sOrigRefNbr;
             }
		 	
               
		    hParentResult.put(FIELD_SENDER_REF, sSenderRef);
		    hParentResult.put(FIELD_RECV_REF, sRecvRef);
		    hParentResult.put(FIELD_ISSU_BNK_REF, sIssuBnkRef);
		    
		    /* GWF: Do not return false if GetExtRefNbr failure
		 	if (!GetExtRefNbr (hParentResult))
		 		return false;
			*/
		    if (GetExtRefNbr(hParentResult)){
		    	logDebug("GetExtRefNbr success");
		    	sExtRefNbr=(String)hParentResult.get(FIELD_EXT_REF_NBR);
		    	sProdCat=(String)hParentResult.get(FIELD_PROD_CAT);
		    	sProdType=(String)hParentResult.get(FIELD_PROD_TYP);
		    }
		    
		 	if (sExtRefNbr.trim().equals(""))
		 	{
		 	       logDebug("MT747_to_Gtl(): Unable to get EXT_REF_NBR.");
		                //GWF: GWF: Do not return false if GetExtRefNbr failure
		 	       		//return  false ;
		 	}

		 	sGtlMsg  = sProdCat; 
		 	sGtlMsg += sMsgTyp;
		 	sGtlMsg += "\r\n";

		 	sGtlMsg += ":20:";
		 	sGtlMsg += sExtRefNbr;
		 	sGtlMsg += "\r\n";
		 	sGtlMsg += ":20Z:";
		 	sGtlMsg += sOrigRefNbr;
		 	sGtlMsg += "\r\n";

		 	// New Expiration Date
		 	if ( ! (SwiftTag = GetTok(dtMsgContent, "\r\n:31E:")).trim().equals("") ) {
		 		sGtlMsg += ":31E:";
		 		sGtlMsg += SwiftTag;
		 		sGtlMsg += "\r\n";
		 	} 

		 	// Amount
		 	String sTmpSwiftTag;
		 	if ( ! (SwiftTag = GetTok(dtMsgContent, "\r\n:32B:")).trim().equals("") )
		 	{
		 		sGtlMsg += ":32C:";
		 		/*
		  		sTmpSwiftTag= SwiftTag.Right(SwiftTag.GetLength() - 3);
		 		int nComma = SwiftTag.Find(',');
		 		if (nComma >= 0)
		 			SwiftTag.SetAt(nComma, '.');
		 		*/
		 		//sTmpSwiftTag=SwiftTag.substring(SwiftTag.length()-3);
		 		sTmpSwiftTag=Right(SwiftTag, 3);
		 		SwiftTag.replace(',', '.');
		 		sGtlMsg += sTmpSwiftTag;
		 		
		 		sGtlMsg += ":32B:";
		 				/*
		                 nComma = SwiftTag.Find(',');
		                 if (nComma >= 0)
		                         SwiftTag.SetAt(nComma, '.');
		                */
		 				 SwiftTag=SwiftTag.replace(',', '.');
		                 sGtlMsg += SwiftTag;
		 	}
		 	else
		 	{
		 		if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:33B:")).trim().equals("") ) {
		 			sGtlMsg += ":32C:";
		 			sGtlMsg += "-";
		 			
		 			/*
		 			sTmpSwiftTag = SwiftTag.Right(SwiftTag.GetLength() - 3);
		 			int nComma = SwiftTag.Find(',');
		 			if (nComma >= 0)
		 				SwiftTag.SetAt(nComma, '.');
		 			*/
		 			//sTmpSwiftTag = SwiftTag.substring(SwiftTag.length()-3);
		 			sTmpSwiftTag = Right(SwiftTag, 3);
		 			SwiftTag=SwiftTag.replace(',', '.');
		 			sGtlMsg += sTmpSwiftTag;
		 	
		 			sGtlMsg += ":33B:";
		 						 /*
		                         nComma = SwiftTag.Find(',');
		                         if (nComma >= 0)
		                                 SwiftTag.SetAt(nComma, '.');
		                         */
		 						 SwiftTag=SwiftTag.replace(',', '.');
		                         sGtlMsg += SwiftTag;
		 			
		 		}
		 	}

		 	// Currency
		 	if ( ! (SwiftTag = GetTok(dtMsgContent, "\r\n:34B:")).trim().equals("") ) {
		 		sGtlMsg += ":32Z:";
		 		/*
		 		int nComma = SwiftTag.Find(',');
		 		if (nComma >= 0)
		 			SwiftTag.SetAt(nComma, '.');
		 		*/
		 		SwiftTag=SwiftTag.replace(',', '.');
		 		sGtlMsg += SwiftTag;
		 		
		 		sGtlMsg += ":34B:";
		 				 /*
		                 nComma = SwiftTag.Find(',');
		                 if (nComma >= 0)
		                         SwiftTag.SetAt(nComma, '.');
		                 */
		 				 SwiftTag.replace(',','.');
		                 sGtlMsg += SwiftTag;
		 	
		 	} 

		 	// Variance
		 	if ( ! (SwiftTag = GetTok(dtMsgContent, "\r\n:39A:")).trim().equals("") ) {
		 		sGtlMsg += ":39A:";
		 		sGtlMsg += SwiftTag;
		 	} 

		 	// Default Tag Content 

		 	// Maximum Credit Amount
		 	if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:30:")).trim().equals("")) {
		 		sGtlMsg += ":30:";
		 		sGtlMsg += SwiftTag;
		 	}	

		 	// Maximum Credit Amount
		 	if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:39B:")).trim().equals("")) {
		 		sGtlMsg += ":39B:";
		 		sGtlMsg += SwiftTag;
		 	}
		 	
		 	// Additional Amounts Covered
		 	if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:39C")).trim().equals("")) {
		 		sGtlMsg += ":39C:";
		 		sGtlMsg += SwiftTag;
		 	}

		 	// Narrative
		 	if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:77A:")).trim().equals("")) {
		 		sGtlMsg += ":77A:";
		 		sGtlMsg += SwiftTag;
		 	}

		 	// Sender to Receiver Information
		 	if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:72:")).trim().equals("")) {
		 		sGtlMsg += ":72:";
		 		sGtlMsg += SwiftTag;
		 	}

		 	SwiftTag += "-\r\n";


		    logDebug("sGtlMsg = \n" + sGtlMsg);
	    	hParentResult.remove(FIELD_MSG_TEXT);
	    	hParentResult.put(FIELD_MSG_TEXT, sGtlMsg);

	        return true;
	     }catch (Exception ex) {
	            logDebug((Throwable) ex);
			    logDebug("IMParseMappingExtractor.MT747_to_Gtl: "+ex.getMessage());
				//throw new Exception(ex.getMessage());
			    logDebug("ERROR MT747_to_Gtl(). Return false");
			    return false;
	     }finally {
	    	 //close(conn);
	     }
	}
	
	private boolean MT742_to_Gtl(Hashtable hParentResult, DataTable dtMsgContent) throws Exception
	{
		 logDebug("Start MT742_to_Gtl()");
		 //IDataConnection  conn = null;
		 DataTable dt;
	     try{
	    	 String sProcUnit=(String)hParentResult.get(FIELD_PROC_UNIT);
		     String sMsgTyp=(String)hParentResult.get(FIELD_MSG_TYP);
		     String sGtlMsg="";
		     String Sql="";
		     int sQueueId=((Integer)hParentResult.get(FIELD_QUEUE_ID)).intValue();
		     
		 	// Convert Swift to GTL and update the SI_MSG_Q
		 	String SwiftTag;
		 	String sTag40A, sTag20 = "";
		 	String LCTyp;
		 	String sClaimBnkRef="", sSndRcvAddr;
		 	int rowcount =0;
		 	String sExtRefNbr = "";
		 	String sSenderRef = " ";
		 	String sRecvRef = " ";
		 	String sIssuBnkRef = " ";
		 	String sProdType = " ";
		 	String sProdCat = " ";
		 	String sTranType = " ";
		 	String sOrigRefNbr = " ";
		 	String sLcTyp = " ";

		 	sLcTyp = "C";
		 	sTag40A = "C\r\n"; // EB - Use MapLCTyp to locate PROD_CAT

		 	int len = 0;

		 	// Claiming Bank Reference
		 	if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:20:")).trim().equals("")) {
		 		len = SwiftTag.indexOf("\r\n");
		 		if (len != -1)
		 			sClaimBnkRef = Left(SwiftTag, len);
		 		else
		 			sClaimBnkRef = SwiftTag;
		 	}

		 	// Documentary Credit Number
		 	if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:21:")).trim().equals("")) {
		 		len = SwiftTag.indexOf("\r\n");
		 		if (len != -1)
		 			sOrigRefNbr = Left(SwiftTag, len);
		 		else
		 			sOrigRefNbr = SwiftTag;
		 		
		 		sTag20 = sOrigRefNbr;
		 	}

		 	sSenderRef = sOrigRefNbr;
		 	sIssuBnkRef = sOrigRefNbr;

		 		Sql  = "select a.EXT_REF ,b.EXT_MSG_REF ";
		                         Sql += " from GTDPEND1..SI_MSG_Q a, GTDPEND1..SI_MSG b ";
		                         Sql += " where a.INTF_PROC_UNIT = '"+sProcUnit+"' ";
		                         Sql += " and a.QUEUE_TYP = 'SWF' ";
		                         Sql += " and a.QUEUE_ID = "+sQueueId +" ";
		                         Sql += " and b.PROC_UNIT = a.INTF_PROC_UNIT ";
		                         Sql += " and b.QUEUE_ID = a.QUEUE_ID ";
		                         Sql += " and b.QUEUE_TYP = a.QUEUE_TYP ";

		                         //conn=getConnection();
		                         dt=conn.executeQuery(Sql);
		                         //close(conn);
		                         rowcount = dt.size();
		                         
		                         String sTmp;
		                         if (rowcount == 1) {

		                        	 	 dt.next();
		                        	 	 sTmp=(String)dt.getField("EXT_MSG_REF");
		                        	 	 sTmp=sTmp.trim();
		                                 if (! sTmp.trim().equals(""))
		                                         sRecvRef =sTmp;
		                                 
		                                 sTmp=(String)dt.getField("EXT_REF");
		                                 sTmp=sTmp.trim();
		                                 if (! sTmp.trim().equals(""))
		                                         sOrigRefNbr =sTmp;
		                                 sSenderRef = sOrigRefNbr;
		                                 sIssuBnkRef = sOrigRefNbr;

		                         }
		    
		                         
		    hParentResult.put(FIELD_SENDER_REF, sSenderRef);
		    hParentResult.put(FIELD_RECV_REF, sRecvRef);
		    hParentResult.put(FIELD_ISSU_BNK_REF, sIssuBnkRef);	

		 	//if (GetExtRefNbr() == QS_FAIL)
		    if(! GetExtRefNbr(hParentResult)){
		 		logDebug("GetExtRefNbr failed");
		 		//GWF: Do not return false
		    	//return (QS_FAIL);
		    }else{
		    	logDebug("GetExtRefNbr success");
		    	sExtRefNbr=(String)hParentResult.get(FIELD_EXT_REF_NBR);
		    	sProdCat=(String)hParentResult.get(FIELD_PROD_CAT);
		    	sProdType=(String)hParentResult.get(FIELD_PROD_TYP);
		    }

		 	sProdCat = "CLM";
		 	sLcTyp = "C";
		 	sTag40A = "C\r\n";
		 	
		 	hParentResult.remove(FIELD_LC_TYP);
			hParentResult.remove(FIELD_PROD_TYP);
			hParentResult.remove(FIELD_TRAN_TYP);
			hParentResult.remove(FIELD_PROD_CAT);
		 	hParentResult.put(FIELD_LC_TYP, sLcTyp);
			hParentResult.put(FIELD_PROD_TYP, sProdType);
			hParentResult.put(FIELD_TRAN_TYP, sTranType);
			hParentResult.put(FIELD_PROD_CAT, sProdCat);
			
		 	if (! sExtRefNbr.trim().equals(""))
		 	{
		 		sExtRefNbr = "";

		 		//if (selectTranType () == QS_FAIL)
		 		if (! selectTranType(hParentResult)){
		 			logDebug("selectTranType() failed");
		 			//GWF: Do not return false
		 			//return (QS_FAIL);
		 		}else{
		 			logDebug("selectTranType() success");
		 			sProdType=(String)hParentResult.get(FIELD_PROD_TYP);
		 			sTranType=(String)hParentResult.get(FIELD_TRAN_TYP);
		 			sProdCat=(String)hParentResult.get(FIELD_PROD_CAT);
		 		}
		 		//if (GenNewTranRefNbr() == QS_FAIL)
		 		if (! GenNewTranRefNbr(hParentResult)){
		 			logDebug("GenNewTranRefNbr() failed");
		 			//GWF: Do not return false
		 			//return (QS_FAIL);
		 		}else{
		 			logDebug("GenNewTranRefNbr() success");
		 			sExtRefNbr=(String)hParentResult.get(FIELD_EXT_REF_NBR);
		 		}
		 		if (sExtRefNbr.trim().equals(""))
		 		{
		 			logDebug("Error in getting EXT_REF_NBR");
		 			//GWF: Do not return false
		 			//return (QS_FAIL);
		 		}
		 	}
		 	else {
		 		logDebug("Ext Ref Nbr [" + sExtRefNbr + "] not found in Master Database.");
		 		//GWF: Do not return false
		 		//return (QS_FAIL);
		 	}

		 	sGtlMsg = sProdCat; 
		 	sGtlMsg += sMsgTyp;

		 	sGtlMsg += "\r\n:00B:";
		 	sGtlMsg += sTag40A;

		 	sGtlMsg += ":20:";
		 	sGtlMsg += sExtRefNbr;
		 	sGtlMsg += "\r\n";
		 	sGtlMsg += ":20Z:";
		 	sGtlMsg += sClaimBnkRef;
		 	sGtlMsg += "\r\n";
		 	sGtlMsg += ":20Y:";
		 	sGtlMsg += sOrigRefNbr;
		 	sGtlMsg += "\r\n";

		 	// Issuing Bank Name and Address
		 	if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:52A:")).trim().equals("")) {
		 		
	 			sGtlMsg += ":52A:";
	         	sGtlMsg += SwiftTag;
	         	sGtlMsg += "\r\n";
	         	
	         	logDebug("sGtlMsg: " + sGtlMsg);

		        Sql  = "select l.CUST_ID ";
				Sql += "from GTDMAST1..SWIFT_ADDR_LOCAL l ";
				Sql += "where l.PROC_UNIT = '";
				Sql += sProcUnit;
				Sql += "' and l.SWIFT_ADDR = '";
				Sql += Left(SwiftTag, 11);
				Sql += "' and l.STATUS = 'A'";
				
				logDebug("MapIssuingBankInfo SQL 2: "+ Sql);
		 		//conn=getConnection();
		 		dt=conn.executeQuery(Sql);
		 		rowcount = dt.size();
		 		//close(conn);
		 		
		 		String sCustId = "";

		 		if (rowcount == 1)
		 		{
		 			dt.next();
		 			sCustId=(String)dt.getField("CUST_ID");
		 			sCustId=sCustId.trim();
		 			
		 			sGtlMsg += ":52Z:" ;
		 			sGtlMsg += sCustId ;
		 			sGtlMsg += "\r\n" ;

		 			sGtlMsg += ":50Z:";
		 			sGtlMsg += sCustId;
		 			sGtlMsg += "\r\n";
		 			
		 		}
		 		else {
		 			
		 			Sql  = "select l.CUST_ID ";
					Sql += "from GTDMAST1..SWIFT_ADDR_LOCAL l ";
					Sql += "where l.PROC_UNIT = '";
					Sql += sProcUnit;
					Sql += "' and l.SWIFT_ADDR = '";
					Sql += Left(SwiftTag, 8);
					Sql += "' and l.STATUS = 'A'";
		 			
		 			//conn=getConnection();
		 			dt=conn.executeQuery(Sql);
		 			//close(conn);
		 			rowcount = dt.size();
		 			
		 			if (rowcount == 1){
		 				
		 				dt.next();
			 			sCustId=(String)dt.getField("CUST_ID");
			 			sCustId=sCustId.trim();
			 			
			 			sGtlMsg += ":52Z:" ;
			 			sGtlMsg += sCustId ;
			 			sGtlMsg += "\r\n" ;
	
			 			sGtlMsg += ":50Z:";
			 			sGtlMsg += sCustId;
			 			sGtlMsg += "\r\n";
		 			}
		 		}
		 	}
		 	
		 	if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:52D:")).trim().equals("")) {
		 		sGtlMsg += ":52D:";
		 		sGtlMsg += SwiftTag;
		 		
		 		sGtlMsg += ":50:";
		 		sGtlMsg += SwiftTag;
		 	}
		 		
		 	// Advising Mode
		 	// sGtlMsg += ":101:";
		    	// sGtlMsg += "TN\r\n";

		 	// Issue Date
		 	if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:31C:")).trim().equals("") ) {
		 		sGtlMsg += ":31C:";
		 		sGtlMsg += CheckDt(Left(SwiftTag,6));
		 		sGtlMsg += "\r\n";
		 	} 

		 	// Principal Amount Claim
		 	if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:32B:")).trim().equals("") ) {
		 		sGtlMsg += ":32B:";
		 		/*
		 		int nComma = SwiftTag.Find(',');
		 		if (nComma >= 0)
		 			SwiftTag.SetAt(nComma, '.');
		 		*/
		 		SwiftTag=SwiftTag.replace(',','.');
		 		sGtlMsg += SwiftTag;
		 	}

		 	// Additional Amount Alaimed 
		 	if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:33B:")).trim().equals("")) {
		 		sGtlMsg += ":33B:";
		 		/*
		 		int nComma = SwiftTag.Find(',');
		 		if (nComma >= 0)
		 			SwiftTag.SetAt(nComma, '.');
		 		*/
		 		SwiftTag=SwiftTag.replace(',', '.');
		 		sGtlMsg += SwiftTag;
		 	}

		 	// Charges
		 	if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:71B:")).trim().equals("") ) {
		 		sGtlMsg += ":71B:";
		 		sGtlMsg += SwiftTag;
		 		// sGtlMsg += "B";
		 		// sGtlMsg += "\r\n";
		 	} 
		 	
		 	logDebug("sGtlMsg 71B: " + sGtlMsg);

		 	// Total Amount Claimed
		 	if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:34B:")).trim().equals("") ) {
		 		sGtlMsg += ":34B:";
		 		/*
		 		int nComma = SwiftTag.Find(',');
		 		if (nComma >= 0)
		 			SwiftTag.SetAt(nComma, '.');
		 		*/
		 		SwiftTag=SwiftTag.replace(',', '.');
		 		sGtlMsg += SwiftTag;
		 	} 
		 	else
		 	if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:34A:")).trim().equals("")) {
		 		sGtlMsg += ":34A:";
		                 sGtlMsg += SwiftTag;
		                  sGtlMsg += "\r\n";

		 		//SwiftTag = SwiftTag.Mid(6);
		        //SwiftTag=SwiftTag.substring(6);
		        SwiftTag=Mid(SwiftTag, 6);
		 		/*
		        int nComma = SwiftTag.Find(',');
		 		if (nComma >= 0)
		 			SwiftTag.SetAt(nComma, '.');
		 		*/
		        SwiftTag=SwiftTag.replace(',', '.');
		 		sGtlMsg += ":34B:";
		 		sGtlMsg += SwiftTag;
		 	}
		 	
		 	// Default Tag Content

		 	// Presenting Bank
		 	if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:57A:")).trim().equals("")) {
		 		sGtlMsg += ":57A:";
		                 sGtlMsg += SwiftTag;
		                 sGtlMsg += "\r\n";
		 		
		 		Sql  = "select l.CUST_ID ";
		 		Sql += "from GTDMAST1..SWIFT_ADDR_LOCAL l ";
		 		Sql += "where l.PROC_UNIT = '";
		 		Sql += sProcUnit;
		 		Sql += "' and l.SWIFT_ADDR = '";
		 		//Sql += SwiftTag.Left(11);
		 		Sql += Left(SwiftTag, 11);
		 		Sql += "' and l.STATUS = 'A'";
		 		
		 		logDebug("Sql:"+Sql);
		 		//conn=getConnection();
		 		dt=conn.executeQuery(Sql);
		 		//close(conn);
		 		rowcount = dt.size();
		 		
		 		String sCustId;
		 		if ( rowcount == 1 ) {

		 			dt.next();
		 			sCustId=(String)dt.getField("CUST_ID");
		 			
		 			sGtlMsg += ":55Z:" ;
		 			sGtlMsg += sCustId ;
		 			sGtlMsg += "\r\n" ;

		 		} else {
		 			Sql  = "select l.CUST_ID ";
		 			Sql += "from GTDMAST1..SWIFT_ADDR_LOCAL l ";
		 			Sql += "where l.PROC_UNIT = '";
		 			Sql += sProcUnit;
		 			Sql += "' and l.SWIFT_ADDR = '";
		 			//Sql += SwiftTag.Left(8);
		 			Sql += Left(SwiftTag, 8);
		 			Sql += "' and l.STATUS = 'A'";

		 			//conn=getConnection();
		 			dt=conn.executeQuery(Sql);
		 			//close(conn);
		 			rowcount=dt.size();
		 			
		 			if (rowcount == 1) {

		 				dt.next();
		 				sCustId=(String)dt.getField("CUST_ID");
		 				
		 				sGtlMsg += ":55Z:" ;
		 				sGtlMsg += sCustId ;
		 				sGtlMsg += "\r\n" ;
		 			}
		 			else {
		 				sGtlMsg += ":55D:";
		 				sGtlMsg += SwiftTag;
		 			}

		 		}
		 	} 
		 	else if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:57B:")).trim().equals("")) {
		 		sGtlMsg += ":57B:";
		                 sGtlMsg += SwiftTag;
		                 sGtlMsg += "\r\n";

		 		sGtlMsg += ":55D:";
		 		sGtlMsg += SwiftTag;
		                 sGtlMsg += "\r\n";
		 	} 
		 	else if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:57D:")).trim().equals("")) {
		 		sGtlMsg += ":57D:";
		                 sGtlMsg += SwiftTag;
		                 sGtlMsg += "\r\n";

		 		sGtlMsg += ":55D:";
		 		sGtlMsg += SwiftTag;		
		                 sGtlMsg += "\r\n";
		 	} 
		 	else {
		 		sGtlMsg += ":55D:";
		 		sGtlMsg += ".";
		 		sGtlMsg += "\r\n";
		 	}
		 		
		 	// Beneficiary Bank
		 	if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:58A:")).trim().equals("")) {

		 		sGtlMsg += ":58A:";
		                 sGtlMsg += SwiftTag;
		                 sGtlMsg += "\r\n";

		 		Sql  = "select l.CUST_ID ";
		 		Sql += "from GTDMAST1..SWIFT_ADDR_LOCAL l ";
		 		Sql += "where l.PROC_UNIT = '";
		 		Sql += sProcUnit;
		 		Sql += "' and l.SWIFT_ADDR = '";
		 		//Sql += SwiftTag.Left(11);
		 		Sql += Left(SwiftTag, 11);
		 		Sql += "' and l.STATUS = 'A'";
		 		
		 		//conn=getConnection();
		 		dt=conn.executeQuery(Sql);
		 		//close(conn);
		 		rowcount=dt.size();
		 		
		 		String sCustId;
		 		if ( rowcount == 1 ) {

		 			dt.next();
		 			sCustId=(String)dt.getField("CUST_ID");
		 			
		 			sGtlMsg += ":59Z:" ;
		 			sGtlMsg += sCustId ;
		 			sGtlMsg += "\r\n" ;

		 		} else {
		 			Sql  = "select l.CUST_ID ";
		 			Sql += "from GTDMAST1..SWIFT_ADDR_LOCAL l ";
		 			Sql += "where l.PROC_UNIT = '";
		 			Sql += sProcUnit;
		 			Sql += "' and l.SWIFT_ADDR = '";
		 			//Sql += SwiftTag.Left(8);
		 			Sql += Left(SwiftTag, 8);
		 			Sql += "' and l.STATUS = 'A'";
		 			
		 			//conn=getConnection();
		 			dt=conn.executeQuery(Sql);
		 			//close(conn);
		 			rowcount=dt.size();
		 			
		 			if (rowcount == 1) {

		 				dt.next();
		 				sCustId=(String)dt.getField("CUST_ID");
		 				
		 				sGtlMsg += ":59Z:" ;
		 				sGtlMsg += sCustId ;
		 				sGtlMsg += "\r\n" ;
		 			}
		 			else {
		 				sGtlMsg += ":59D:";
		 				sGtlMsg += SwiftTag;
		 			}

		 		}	
		 	}
		 	else if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:58D:")).trim().equals("")) {
		 		sGtlMsg += ":58D:";
		                 sGtlMsg += SwiftTag;
		 		sGtlMsg += "\r\n";


		 		sGtlMsg += ":59D:";
		 		sGtlMsg += SwiftTag;
		 	}
		 	else {
		 		sGtlMsg += ":59D:";
		 		sGtlMsg += ".";
		 		sGtlMsg += "\r\n";
		 	}

		 	// TP Comment
		 	if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:72:")).trim().equals("")) {
		 		sGtlMsg += ":72:";
		 		sGtlMsg += SwiftTag;
		 	}

		 	sGtlMsg += "-\r\n";	// prevent endless loop with CMicroParser::Parse() 
		 	
		 	//return (QS_SUCCEED);
		     
		     
		    logDebug("sGtlMsg = \n" + sGtlMsg);
	    	hParentResult.remove(FIELD_MSG_TEXT);
	    	hParentResult.put(FIELD_MSG_TEXT, sGtlMsg);

	        return true;
	     }catch (Exception ex) {
	            logDebug((Throwable) ex);
			    logDebug("IMParseMappingExtractor.MT742_to_Gtl: "+ex.getMessage());
				//throw new Exception(ex.getMessage());
			    logDebug("ERROR MT742_to_Gtl(). Return false");
			    return false;
	     }finally{
	    	 //close(conn);
	     }
	}
	
	private boolean MT760_to_Gtl(Hashtable hParentResult, DataTable dtMsgContent) throws Exception
	{
		 logDebug("Start MT760_to_Gtl()");
		 //IDataConnection  conn = null;
		 DataTable dt;
	     try{
	    	 String sProcUnit=(String)hParentResult.get(FIELD_PROC_UNIT);
		     String sMsgTyp=(String)hParentResult.get(FIELD_MSG_TYP);
		     String sGtlMsg="";
		     String Sql="";
		     String sMsgHeader=(String)hParentResult.get(FIELD_MSG_HEADER);
		     
		        // Convert Swift to GTL and update the SI_MSG_Q
		        int len = 0;
		        String sTag40A  = "C\r\n";
		        String SwiftTag;
		        String sCustId;
		        String SndSwfAddr;
				String sTmp="";

				String sProdCat  = "XLC";
				String sLcTyp    = "C";
				String sProdType = "";
				String sExtRefNbr = "";
				String sSenderRef = " ";
				String sRecvRef = " ";
				String sIssuBnkRef = " ";
				String sTranType = " ";
				String sOrigRefNbr = " ";
				String s3rdPtyRefNbr = " ";
				//20021113, Davy, Start
				String sConfigVal = " ";
				//20021113, Davy, End
		    
				String sIsDefaultDummyCust="";
				String sDummyId="";
				
				String sTranRefNbr="";
		        hParentResult.remove(FIELD_EXT_REF_NBR);
		        hParentResult.remove(FIELD_PROD_CAT);
		        hParentResult.remove(FIELD_PROD_TYP);
		        hParentResult.remove(FIELD_TRAN_REF_NBR);
		        hParentResult.remove(FIELD_LC_TYP);
		        hParentResult.put(FIELD_EXT_REF_NBR, sExtRefNbr);
		        hParentResult.put(FIELD_PROD_CAT, sProdCat);
		        hParentResult.put(FIELD_PROD_TYP, sProdType);
		        hParentResult.put(FIELD_TRAN_REF_NBR, sTranRefNbr);
		        hParentResult.put(FIELD_LC_TYP, sLcTyp);
		        
		        hParentResult.put(FIELD_SENDER_REF, sSenderRef);
			    hParentResult.put(FIELD_RECV_REF, sRecvRef);
			    hParentResult.put(FIELD_ISSU_BNK_REF, sIssuBnkRef);
			/*
			GT_DBRows *pDBRows;
			pDBRows = new GT_DBRows();
			*/
						
				
			//if (GetPuConfig(sProcUnit, "SWF_USE_AUTO_MAP", sConfigVal))
			//if (sConfigVal.Find("760")>=0){
			sConfigVal=getPUConfig(sProcUnit, "SWF_USE_AUTO_MAP");
			if (! sConfigVal.trim().equals(""))
			if (sConfigVal.indexOf("760")>=0){
			if (sMsgTyp.trim().equals("760")) {
		        	//GetPuConfig(sProcUnit, "INSWF_PARSE_GEN_REF", sConfigVal);
				sConfigVal=getPUConfig(sProcUnit, "INSWF_PARSE_GEN_REF");
				//sConfigVal = sConfigVal.SpanExcluding(" ");
				if (sConfigVal.trim().equals("Y"))	{
					logDebug("Before the process to Generate the ExtRefNbr...");
					
					//Get the CUST_ID first for get EXT_REF_NBR
				    	
						if ( ! (SwiftTag = GetTok(dtMsgContent, "\r\n:20:")).trim().equals("") ) {
						//if (GetPuConfig(sProcUnit, "SWF_USE_AUTO_MAP", sConfigVal)) {
						//GWF: GetPuConfig in message.c return true if non-blank 
						sConfigVal=getPUConfig(sProcUnit, "SWF_USE_AUTO_MAP");
						if (! sConfigVal.trim().equals("")) {   		
						        /*if (SwiftTag[0] == '/') { // using [/34x] format. Ignore Acct Num
						                int nLineFeed = SwiftTag.Find('\n');
						                ++nLineFeed;
						                SwiftTag = SwiftTag.Mid(nLineFeed, SwiftTag.GetLength());
						        }*/
						

								// ---[EMEA]---[20060928]
								//if (GetPuConfig(sProcUnit, "DEFAULT_DUMMY_WALKIN_CUST", sIsDefaultDummyCust))
								sIsDefaultDummyCust=getPUConfig(sProcUnit, "DEFAULT_DUMMY_WALKIN_CUST");
								if (! sIsDefaultDummyCust.trim().equals(""))
								{
									if (sIsDefaultDummyCust.trim().equals("Y"))
									{
										//GetPuConfig(sProcUnit, "DUMMY_WALKIN_CUST", sDummyId);
										sDummyId=getPUConfig(sProcUnit, "DUMMY_WALKIN_CUST");
									}
									else
									{
										//if (FindCustIdFromName(SwiftTag, sDummyId) != QS_TRUE) {
										//GetPuConfig(sProcUnit, "DUMMY_WALKIN_CUST", sDummyId);
										//cout << "Cannot find CustID for (" << SwiftTag << "), so use DUMMY_WALKIN_CUST (" << sDummyId << ")" << endl;
										//}
										sDummyId=FindCustIdFromName(SwiftTag, sProcUnit);
										if(sDummyId.trim().equals("")){
											sDummyId=getPUConfig(sProcUnit, "DUMMY_WALKIN_CUST");
											logDebug("Cannot find CustID for (" + SwiftTag + "), so use DUMMY_WALKIN_CUST (" + sDummyId + ")");
										}
										
										hParentResult.remove(FIELD_DUMMY_ID);
										hParentResult.put(FIELD_DUMMY_ID, sDummyId);
									}
								}
								// ---[EMEA]---[END]
						}
				        }
						
				        		
		                        //if (GetExtRefNbr () == QS_FAIL) {
		                        if (! GetExtRefNbr (hParentResult)) {
		                        		logDebug("Testing for the GetExtRefNbr ......... GetExtRefNbr failed");
		                                //GWF: Do not return false
		                        		//return (QS_FAIL);
		                        }else{
		                        	logDebug("Testing for the GetExtRefNbr ......... GetExtRefNbr success");
		                        	sExtRefNbr=(String)hParentResult.get(FIELD_EXT_REF_NBR);
		            		    	sProdCat=(String)hParentResult.get(FIELD_PROD_CAT);
		            		    	sProdType=(String)hParentResult.get(FIELD_PROD_TYP);
		                        }
		                        	
		                        if (sExtRefNbr.trim().equals("")) {
		                                if (! selectTranType (hParentResult)) {
		                                        logDebug("Testing for selectTranType..........selectTranType failed");
		                                        //GWF: Do not return false
		                                        //return (QS_FAIL);
		                                }else{
		                                	logDebug("Testing for selectTranType.......... selectTranType success");
		                                	sProdType=(String)hParentResult.get(FIELD_PROD_TYP);
		                        			sTranType=(String)hParentResult.get(FIELD_TRAN_TYP);
		                        			sProdCat=(String)hParentResult.get(FIELD_PROD_CAT);
		                                }
		                                
		                                if (! GenNewTranRefNbr(hParentResult)) {
		                                        logDebug("Testing for GenNewTranRefNbr..........GenNewTranRefNbr failed");
		                                        //GWF: Do not return false
		                                        //return (QS_FAIL);
		                                }else{
					                    	logDebug("Testing for GenNewTranRefNbr.......... GenNewTranRefNbr success");
					                    	sExtRefNbr=(String)hParentResult.get(FIELD_EXT_REF_NBR);
					                    }
		                                
		                                if (sExtRefNbr.trim().equals("")) {
		                                        logDebug("Error in getting EXT_REF_NBR for MT760");
		                                        //GWF: Do not return false;
		                                        //return (QS_FAIL);
		                                }else
		                                	logDebug("The ExtRefNbr is generated. sExtRefNbr:"+sExtRefNbr);
					}
				}
				else if (sConfigVal.trim().equals("N"))	{
					/*if (selectTranType () == QS_FAIL) {
						cout << "Testing for selectTranType.........." << endl;
						return (QS_FAIL);
					}*/
					logDebug("The process will not Generate the ExtRefNbr...");
				}

		        }
		        
			//20021113, Davy, End
		        else if (sMsgTyp.trim().equals("765")) {
					/*if (selectTranType () == QS_FAIL)
						return (QS_FAIL);*/
					if (! GenNewTranRefNbr(hParentResult)){
						logDebug("GenNewTranRefNbr failed");
						//GWF: Do no return false
						//return (QS_FAIL);
					}else{
						logDebug("GenNewTranRefNbr success");
						sExtRefNbr=(String)hParentResult.get(FIELD_EXT_REF_NBR);
					}
						
					if (sExtRefNbr.trim().equals(""))
		            {
						logDebug("Error in getting EXT_REF_NBR for MT765");
						//GWF: Do not return false
						//return (QS_FAIL);
					}
		        }
		    }
			sGtlMsg = sProdCat; sGtlMsg += sMsgTyp;
		    sGtlMsg += "\r\n";
		        
				// Transaction Reference Number
				sGtlMsg += "\r\n";
		        if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:20:")).trim().equals("") ) {
		                len = SwiftTag.indexOf("\r\n");
		                if (len != -1)
		                        sOrigRefNbr = Left(SwiftTag, len);

		                sGtlMsg += ":20:";
		                sGtlMsg += sOrigRefNbr;
				sGtlMsg += "\r\n";
		        }
		//if (GetPuConfig(sProcUnit, "SWF_USE_AUTO_MAP", sConfigVal))
		sConfigVal=getPUConfig(sProcUnit, "SWF_USE_AUTO_MAP");
		if (! sConfigVal.trim().equals("")){
		    if (sConfigVal.indexOf("760")>=0){
		        String sValDt="";
				Sql  = "select convert(char(6), getdate(), 12) as VALUE_DT";

				logDebug("Sql:"+Sql);
				//conn=getConnection();
				dt=conn.executeQuery(Sql);
				//close(conn);
				if(dt.size()>0){
					dt.next();
					sValDt=(String)dt.getField("VALUE_DT");
				}
				
				sGtlMsg += ":00D:";
				sGtlMsg += CheckDt(sValDt);
				sGtlMsg += "\r\n";
		    }
		}
		    
			// Further Identification (Tag 23)
				sGtlMsg += "\r\n";
		    	if ( ! (SwiftTag = GetTok(dtMsgContent, "\r\n:23:")).trim().equals("") ) {
		                len = SwiftTag.indexOf("\r\n");
		                if (len != -1)
							sTmp = Left(SwiftTag, len);

		                sGtlMsg += ":23:";
		                sGtlMsg += sTmp;
				sGtlMsg += "\r\n";
		        }

		        // Sequence of Total (Tag 27)
				sGtlMsg += "\r\n";
		    	if ( ! (SwiftTag = GetTok(dtMsgContent, "\r\n:27:")).trim().equals("") ) {
		                sGtlMsg += ":27:";
		                sGtlMsg += SwiftTag;
				sGtlMsg += "\r\n";
		        }

		        // Date (Tag 30)
		    	if ( ! (SwiftTag = GetTok(dtMsgContent, "\r\n:30:")).trim().equals("") ) {
		                len = SwiftTag.indexOf("\r\n");
		                if (len != -1)
							sTmp = Left(SwiftTag, len);

		                sGtlMsg += ":30:";
		                //if (GetPuConfig(sProcUnit, "SWF_USE_AUTO_MAP", sConfigVal))
		                sConfigVal=getPUConfig(sProcUnit, "SWF_USE_AUTO_MAP");
		                if (! sConfigVal.trim().equals(""))
		                if (sConfigVal.indexOf("760")>=0){
		                sGtlMsg += CheckDt(sTmp);
		                }
		                sGtlMsg += sTmp;
				sGtlMsg += "\r\n";
		        }

		        // Applicable Rules (Tag 40C)
				sGtlMsg += "\r\n";
		    	if ( ! (SwiftTag = GetTok(dtMsgContent, "\r\n:40C:")).trim().equals("") ) {
		                len = SwiftTag.indexOf("\r\n");
		                if (len != -1)
							sTmp = Left(SwiftTag, len);

		                sGtlMsg += ":40C:";
		                sGtlMsg += sTmp;
				sGtlMsg += "\r\n";
		        }

		        
		        //if (GetPuConfig(sProcUnit, "SWF_USE_AUTO_MAP", sConfigVal)) {
		        sConfigVal=getPUConfig(sProcUnit, "SWF_USE_AUTO_MAP");
		        if (! sConfigVal.trim().equals("")) {
			        if (sConfigVal.indexOf("760") >= 0)
			        {
			        	sGtlMsg += ":32B:";
		            	sGtlMsg += "USD0.00";
		            	sGtlMsg += "\r\n";
		        	}
		        }
		        
		        
		        // Issuing Bank (from SWIFT Address) (Tag 52D/Z)
		        //if (GetPuConfig(sProcUnit, "SWF_USE_AUTO_MAP", sConfigVal)) 
		        sConfigVal=getPUConfig(sProcUnit, "SWF_USE_AUTO_MAP");
		        if (! sConfigVal.trim().equals(""))
		        if (sConfigVal.indexOf("760") >= 0)
		        {
			        //{
			        //SndSwfAddr = sMsgHeader.Mid(46, 12);
			        //SndSwfAddr = sMsgHeader.substring(46, 46+12);	
		        	SndSwfAddr = Mid(sMsgHeader, 46, 46+12);
		        	//if (FindCustIdFromSwf(SndSwfAddr, sCustId) == QS_TRUE) {
		        	sCustId=FindCustIdFromSwf(SndSwfAddr, sProcUnit);
		        	if (! sCustId.trim().equals("")) {
		        		sGtlMsg += ":52Z:";
		        	    	sGtlMsg += sCustId;
		        	    	sGtlMsg += "\r\n";
		        	}else{
		        		
			        	//else if (GetPuConfig(sProcUnit, "DUMMY_FOREIGN_BANK", sCustId)) {
		        		sCustId=getPUConfig(sProcUnit, "DUMMY_FOREIGN_BANK");
		        		if (! sCustId.trim().equals("")){
			        		sGtlMsg += ":52Z:";
							sGtlMsg += sCustId;
							sGtlMsg += "\r\n";
						}
			        	else {
							sGtlMsg += ":52D:";
							sGtlMsg += SndSwfAddr;
							sGtlMsg += "\r\n";
							sGtlMsg += "(Sender SWIFT Address)";
							sGtlMsg += "\r\n";
			        	}
		        	}
		    		//}
		    	}
		        
		        
		        // 'Advise Through' Bank (Tag 57A/B/D)
			//if (GetPuConfig(sProcUnit, "SWF_USE_AUTO_MAP", sConfigVal)) {  
			sConfigVal=getPUConfig(sProcUnit, "SWF_USE_AUTO_MAP");
			if (! sConfigVal.trim().equals("")) {
				if (sConfigVal.indexOf("760") >= 0)
		        { 		
			    if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:57A:")).trim().equals("")) {
			        String SndAddr;
			        //if (SwiftTag[0] == '/') { // using [/34x] acct num
			        if (SwiftTag.charAt(0) == '/') { // using [/34x] acct num
			        		int nLineFeed = SwiftTag.indexOf('\n');
			                ++nLineFeed;
			                //SndAddr = SwiftTag.Mid(nLineFeed, SwiftTag.GetLength() - 2 );
			                //GWF: Seems substring to skip last \r\n. Original Mid function seems incorrect. CString::Mid(index, count)
			                //SndAddr = SwiftTag.substring(nLineFeed, SwiftTag.length()-2 );
			                SndAddr = Mid(SwiftTag, nLineFeed, SwiftTag.length()-2 );
			        }
			        else
			                //SndAddr = SwiftTag.Left(SwiftTag.GetLength() - 2);
			        		SndAddr = Left(SwiftTag, SwiftTag.length() - 2);
			
			        //if (FindCustIdFromSwf(SndAddr, sCustId) == QS_TRUE) {
			        sCustId=FindCustIdFromSwf(SndAddr, sProcUnit);
			        if (! sCustId.trim().equals("")) {
			                sGtlMsg += ":57Y:";
			                sGtlMsg += sCustId;
			                sGtlMsg += "\r\n";
			        }
			        else {
			                sGtlMsg += ":52D:";
			                sGtlMsg += SndAddr;
			                sGtlMsg += "\r\n";
			        }
			    } else if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:57B:")).trim().equals("") ) { // 06/24 Need to clarify
			        sGtlMsg += ":57E:";                           // how to handle 2nd Advising
			        sGtlMsg += SwiftTag;                          // Bank info.
					sGtlMsg += "\r\n";
			    } else if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:57D:")).trim().equals("") ) {
			        sGtlMsg += ":57E:";
			        sGtlMsg += SwiftTag;
					sGtlMsg += "\r\n";
			    }      
				}
			}
				//if (GetPuConfig(sProcUnit, "SWF_USE_AUTO_MAP", sConfigVal)) {
				sConfigVal=getPUConfig(sProcUnit, "SWF_USE_AUTO_MAP");
		        if (! sConfigVal.trim().equals("")) {
			        if (sConfigVal.indexOf("760") >= 0)
		        {
			        //if (GetPuConfig(sProcUnit, "DUMMY_WALKIN_CUST", sCustId)) {
			        sCustId=getPUConfig(sProcUnit, "DUMMY_WALKIN_CUST");
		        	if (! sCustId.trim().equals("")) {
						sGtlMsg += ":59:";
						sGtlMsg += sCustId;
						sGtlMsg += "\r\n";
						sGtlMsg += ":59D:";
						sGtlMsg += sCustId;
						sGtlMsg += "\r\n";
						sGtlMsg += ":59Z:";
						sGtlMsg += sCustId;
				                			
					}		        
		    	}
		    	}
		        // Details of Guarantee (Tag 77C)
				sGtlMsg += "\r\n";
		    	if ( ! (SwiftTag = GetTok(dtMsgContent, "\r\n:77C:")).trim().equals("") ) {
		                sGtlMsg += ":77C:";
		                sGtlMsg += SwiftTag;
				sGtlMsg += "\r\n";
		        }

		        // Sender to Receiver Information (Tag 72)
		    	if ( ! (SwiftTag = GetTok(dtMsgContent, "\r\n:72:")).trim().equals("") ) {
		                sGtlMsg += ":72:";
		                sGtlMsg += SwiftTag;
				sGtlMsg += "\r\n";
		        }

		    logDebug("sGtlMsg = \n" + sGtlMsg);
	    	hParentResult.remove(FIELD_MSG_TEXT);
	    	hParentResult.put(FIELD_MSG_TEXT, sGtlMsg);

	        return true;
	     }catch (Exception ex) {
	            logDebug((Throwable) ex);
			    logDebug("IMParseMappingExtractor.MT760_to_Gtl: "+ex.getMessage());
				//throw new Exception(ex.getMessage());
			    logDebug("ERROR MT760_to_Gtl(). Return false");
			    return false;
	     }finally {
	    	 //close(conn);
	     }
	}
	
	private boolean MT767_to_Gtl(Hashtable hParentResult, DataTable dtMsgContent) throws Exception
	{
		 logDebug("Start MT767_to_Gtl()");
		 //IDataConnection  conn = null;
		 DataTable dt;
	     try{
	    	 String sProcUnit=(String)hParentResult.get(FIELD_PROC_UNIT);
		     String sMsgTyp=(String)hParentResult.get(FIELD_MSG_TYP);
		     String sGtlMsg="";
		     String Sql="";
		     String sMsgHeader=(String)hParentResult.get(FIELD_MSG_HEADER);
		     
		        // Convert Swift to GTL and update the SI_MSG_Q
		        int len = 0;
		        String sTag40A  = "C\r\n";
		        String SwiftTag;
		        String sCustId;
		        String SndSwfAddr;
				String sTmp="";

				String sProdCat  = "XLC";
				String sLcTyp    = "C";
				String sProdType = "";
				String sExtRefNbr = "";
				String sSenderRef = " ";
				String sRecvRef = " ";
				String sIssuBnkRef = " ";
				String sTranType = " ";
				String sOrigRefNbr = " ";
				String s3rdPtyRefNbr = " ";
				//20021113, Davy, Start
				String sConfigVal = " ";
				//20021113, Davy, End
		    
				String sIsDefaultDummyCust="";
				String sDummyId="";
				

			/*
			GT_DBRows *pDBRows;
			pDBRows = new GT_DBRows();
			*/
			    
			    //Convert Swift to GTL and update the SI_MSG_Q

		        sExtRefNbr = "";
		        sSenderRef = " ";
		        sRecvRef = " ";
		        sIssuBnkRef = "";
		        sProdType = " ";
		        sProdCat = "XLC";
		        sTranType = " ";
		        sOrigRefNbr = " ";
		        sLcTyp = " ";

		        sGtlMsg = sProdCat; sGtlMsg += sMsgTyp;
		        sGtlMsg += "\r\n";

		        String sTmp1;
			    
				String sTranRefNbr="";
		        hParentResult.remove(FIELD_EXT_REF_NBR);
		        hParentResult.remove(FIELD_PROD_CAT);
		        hParentResult.remove(FIELD_PROD_TYP);
		        hParentResult.remove(FIELD_TRAN_REF_NBR);
		        hParentResult.remove(FIELD_LC_TYP);
		        hParentResult.put(FIELD_EXT_REF_NBR, sExtRefNbr);
		        hParentResult.put(FIELD_PROD_CAT, sProdCat);
		        hParentResult.put(FIELD_PROD_TYP, sProdType);
		        hParentResult.put(FIELD_TRAN_REF_NBR, sTranRefNbr);
		        hParentResult.put(FIELD_LC_TYP, sLcTyp);
		        
		        // Sequence of Total (Tag 27)
				sGtlMsg += "\r\n";
		    	if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:27:")).trim().equals("") ) {
		                sGtlMsg += ":27:";
		                sGtlMsg += SwiftTag;
				sGtlMsg += "\r\n";
		        }

			// Transaction Reference Number
		        if (!(SwiftTag = GetTok(dtMsgContent, "\r\n:20:")).trim().equals("")) {
		                len = SwiftTag.indexOf("\r\n");
		                if (len != -1)
		                        sOrigRefNbr = Left(SwiftTag, len);

		                sGtlMsg += ":20:";
		                sGtlMsg += sOrigRefNbr;
				sGtlMsg += "\r\n";
				//if (GetPuConfig(sProcUnit, "SWF_USE_AUTO_MAP", sConfigVal)) {
				sConfigVal=getPUConfig(sProcUnit, "SWF_USE_AUTO_MAP");
				if (! sConfigVal.trim().equals("")) {
			        if (sConfigVal.indexOf("767") >= 0)
		        	{
						//RightTrim(SwiftTag);
			        	SwiftTag=SwiftTag.trim();
						sIssuBnkRef = SwiftTag;
						sSenderRef = SwiftTag;
						//sTmp1 = SwiftTag;
						
						//cout<<"sTmp1 = "<<sTmp1<<endl;
					}
				}
		        }

			// Related Reference
			sGtlMsg += "\r\n";
		        if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:21:")).trim().equals("")) {
		                len = SwiftTag.indexOf("\r\n");
		                if (len != -1)
		                        sTmp = Left(SwiftTag, len);

		                sGtlMsg += ":21:";
		                sGtlMsg += sTmp;
				sGtlMsg += "\r\n";
				//if (GetPuConfig(sProcUnit, "SWF_USE_AUTO_MAP", sConfigVal)) {
				sConfigVal=getPUConfig(sProcUnit, "SWF_USE_AUTO_MAP");
				if (! sConfigVal.trim().equals("")) {
			        if (sConfigVal.indexOf("767") >= 0)
		        	{
						//RightTrim(SwiftTag);
			        	SwiftTag=SwiftTag.trim();
						sRecvRef = SwiftTag;
					}
				}
		        }

			// Further Identification (Tag 23)
			sGtlMsg += "\r\n";
		    	if ( ! (SwiftTag = GetTok(dtMsgContent, "\r\n:23:")).trim().equals("") ) {
		                len = SwiftTag.indexOf("\r\n");
		                if (len != -1)
							sTmp = Left(SwiftTag, len);

		                sGtlMsg += ":23:";
		                sGtlMsg += sTmp;
				sGtlMsg += "\r\n";
				
		        }
		    	
		        hParentResult.put(FIELD_SENDER_REF, sSenderRef);
			    hParentResult.put(FIELD_RECV_REF, sRecvRef);
			    hParentResult.put(FIELD_ISSU_BNK_REF, sIssuBnkRef);
		    	
		    	//if (GetPuConfig(sProcUnit, "SWF_USE_AUTO_MAP", sConfigVal)) {
		    	sConfigVal=getPUConfig(sProcUnit, "SWF_USE_AUTO_MAP");
		        if (! sConfigVal.trim().equals("")) {
			        if (sConfigVal.indexOf("767") >= 0)
		        	{
		 		       	//if (GetExtRefNbr () == QS_FAIL)
		 		       	if (! GetExtRefNbr (hParentResult)){
		 		       	logDebug("Testing for the GetExtRefNbr ......... GetExtRefNbr failed");
		        	        //GWF: Do not return false
		 		       		//return (QS_FAIL);
		 		       	}else{
			 		       	logDebug("Testing for the GetExtRefNbr ......... GetExtRefNbr success");
	                    	sExtRefNbr=(String)hParentResult.get(FIELD_EXT_REF_NBR);
	        		    	sProdCat=(String)hParentResult.get(FIELD_PROD_CAT);
	        		    	sProdType=(String)hParentResult.get(FIELD_PROD_TYP);
		 		       	}

						logDebug("ExtRefNbr = " + sExtRefNbr);

		        		if (sExtRefNbr.trim().equals(""))
		        		{
		                	//cout << "<shrivasm> " << "EXTERNAL REFRENCE NUMBER EMPTY ........" << endl;
		                	//ThrowQSException(QS_QSERVER_ERROR);
		                	logDebug("EXT_REF_NBR is null ......");
		                	//GWF: Do not return false
		                	//return  QS_FAIL ;
		        		}
					}
		    	}
			// Date (Tag 30)
		    	if ( ! (SwiftTag = GetTok(dtMsgContent, "\r\n:30:")).trim().equals("") ) {
		                len = SwiftTag.indexOf("\r\n");
		                if (len != -1)
							sTmp = Left(SwiftTag, len);

		                sGtlMsg += ":30:";
		                sGtlMsg += sTmp;
				sGtlMsg += "\r\n";
		        }

			// Number of Amendment (Tag 26E)
		    	if ( ! (SwiftTag = GetTok(dtMsgContent, "\r\n:26E:")).trim().equals("")) {
		                len = SwiftTag.indexOf("\r\n");
		                if (len != -1)
							sTmp = Left(SwiftTag, len);

		                sGtlMsg += ":26E:";
		                sGtlMsg += sTmp;
				sGtlMsg += "\r\n";
		        }

			// Date of Issue or Request to Issue (Tag 31C)
			sGtlMsg += "\r\n";
		    	if ( !(SwiftTag = GetTok(dtMsgContent, "\r\n:31C:")).trim().equals("")) {
		                len = SwiftTag.indexOf("\r\n");
		                if (len != -1)
							sTmp = Left(SwiftTag, len);

		                sGtlMsg += ":31C:";
		                sGtlMsg += sTmp;
				sGtlMsg += "\r\n";
		        }
		        
		        // Amendment Details (Tag 77C)
				sGtlMsg += "\r\n";
		    	if ( !(SwiftTag = GetTok(dtMsgContent, "\r\n:77C:")).trim().equals("") ) {
		                sGtlMsg += ":77C:";
		                sGtlMsg += SwiftTag;
				sGtlMsg += "\r\n";
		        }

		        // Sender to Receiver Information (Tag 72)
		    	if ( !(SwiftTag = GetTok(dtMsgContent, "\r\n:72:")).trim().equals("") ) {
		                sGtlMsg += ":72:";
		                sGtlMsg += SwiftTag;
				sGtlMsg += "\r\n";
		        }

		        //return (QS_SUCCEED);
			    
			    logDebug("sGtlMsg = \n" + sGtlMsg);
		    	hParentResult.remove(FIELD_MSG_TEXT);
		    	hParentResult.put(FIELD_MSG_TEXT, sGtlMsg);

		       return true;
		}catch (Exception ex) {
		    logDebug((Throwable) ex);
			logDebug("IMParseMappingExtractor.MT760_to_Gtl: "+ex.getMessage());
			//throw new Exception(ex.getMessage());
			logDebug("ERROR MT760_to_Gtl(). Return false");
			return false;
		}finally{
			//close(conn);
		}
	}
	
	private boolean MT410_to_Gtl(Hashtable hParentResult, DataTable dtMsgContent) throws Exception
	{
		 logDebug("Start MT410_to_Gtl()");
		 //IDataConnection  conn = null;
		 DataTable dt;
	     try{
	    	 String sProcUnit=(String)hParentResult.get(FIELD_PROC_UNIT);
		     String sMsgTyp=(String)hParentResult.get(FIELD_MSG_TYP);
		     String sGtlMsg="";
		     String Sql="";
	    	 
		        // Convert Swift to GTL and update the SI_MSG_Q
		        String SwiftTag;
		        String sTmp="";
		        int len = 0, i=1;

		        String sExtRefNbr = "";
		        String sSenderRef = " ";
		        String sRecvRef = " ";
		        String sIssuBnkRef = "";
		        String sProdType = " ";
		        String sProdCat = "EC";
		        String sTranType = " ";
		        String sOrigRefNbr = " ";
		        String sLcTyp = " ";

		        sGtlMsg = sProdCat;
				sGtlMsg += sMsgTyp;
		        sGtlMsg += "\r\n";

				// check Mandatory Repetitive Seq A
				// Transaction Reference Number
		        while (! (SwiftTag = GetTok2(dtMsgContent, "\r\n:20:", i)).trim().equals("")){
		                len = SwiftTag.indexOf("\r\n");
		                if (len != -1)
		                        sOrigRefNbr = Left(SwiftTag, len);
		                sGtlMsg += ":20:";
		                sGtlMsg += sOrigRefNbr;
						sGtlMsg += "\r\n";
		        

				// Related Reference
				sGtlMsg += "\r\n";
		        if (!(SwiftTag = GetTok3(dtMsgContent, "\r\n:21:", i)).trim().equals("")) {
		                len = SwiftTag.indexOf("\r\n");
		                if (len != -1)
		                        sTmp = Left(SwiftTag, len);
		                sGtlMsg += ":21:";
		                sGtlMsg += sTmp;
						sGtlMsg += "\r\n";
		        }

				// Amount Ack option A
				sGtlMsg += "\r\n";
		        if (!(SwiftTag = GetTok3(dtMsgContent, "\r\n:32A:", i)).trim().equals("")) {
		                len = SwiftTag.indexOf("\r\n");
		                if (len != -1)
		                        sTmp = Left(SwiftTag, len);
		                sGtlMsg += ":32A:";
		                sGtlMsg += sTmp;
						sGtlMsg += "\r\n";
		        }
				// Amount Ack option B
				sGtlMsg += "\r\n";
		        if (!(SwiftTag = GetTok3(dtMsgContent, "\r\n:32B:", i)).trim().equals("")) {
		                len = SwiftTag.indexOf("\r\n");
		                if (len != -1)
		                        sTmp = Left(SwiftTag, len);
		                sGtlMsg += ":32B:";
		                sGtlMsg += sTmp;
						sGtlMsg += "\r\n";
		        }
		        i++;
		    }
				// Amount Ack option K
				sGtlMsg += "\r\n";
		        if (!(SwiftTag = GetTok3(dtMsgContent, "\r\n:32K:", i)).trim().equals("")) {
		                len = SwiftTag.indexOf("\r\n");
		                if (len != -1)
		                        sTmp = Left(SwiftTag, len);
		                sGtlMsg += ":32K:";
		                sGtlMsg += sTmp;
						sGtlMsg += "\r\n";
		        }
				// Sender to Receiver Information
				sGtlMsg += "\r\n";
		      	if ( !(SwiftTag = GetTok(dtMsgContent, "\r\n:72:")).trim().equals("") ) {
		                sGtlMsg += ":72:";
		                sGtlMsg += SwiftTag;
						sGtlMsg += "\r\n";
		        }
		        //return (QS_SUCCEED);
		     
	    	
		    logDebug("sGtlMsg = \n" + sGtlMsg);
	    	hParentResult.remove(FIELD_MSG_TEXT);
	    	hParentResult.put(FIELD_MSG_TEXT, sGtlMsg);

	        return true;
	     }catch (Exception ex) {
	            logDebug((Throwable) ex);
			    logDebug("IMParseMappingExtractor.MT410_to_Gtl: "+ex.getMessage());
				//throw new Exception(ex.getMessage());
			    logDebug("ERROR MT410_to_Gtl(). Return false");
			    return false;
	     }finally{
				//close(conn);
		}
	}
	
	private boolean MT412_to_Gtl(Hashtable hParentResult, DataTable dtMsgContent) throws Exception
	{
		 logDebug("Start MT412_to_Gtl()");
		 //IDataConnection  conn = null;
		 DataTable dt;
	     try{
	    	 String sProcUnit=(String)hParentResult.get(FIELD_PROC_UNIT);
		     String sMsgTyp=(String)hParentResult.get(FIELD_MSG_TYP);
		     String sGtlMsg="";
		     String Sql="";
		     
		        // Convert Swift to GTL and update the SI_MSG_Q
		        String SwiftTag;
		        String sTmp="";
		        int len = 0, i=1;

		        String sExtRefNbr = "";
		        String sSenderRef = " ";
		        String sRecvRef = " ";
		        String sIssuBnkRef = "";
		        String sProdType = " ";
		        String sProdCat = "EC";
		        String sTranType = " ";
		        String sOrigRefNbr = " ";
		        String sLcTyp = " ";

		        sGtlMsg = sProdCat;
		        sGtlMsg += sMsgTyp;
		        sGtlMsg += "\r\n";
				
		        // check Mandatory Repetitive Seq A
				// Transaction Reference Number
		        while (! (SwiftTag = GetTok2(dtMsgContent, "\r\n:20:", i)).trim().equals("")){
		            len = SwiftTag.indexOf("\r\n");
		            if (len != -1)
		             	sOrigRefNbr = Left(SwiftTag, len);
		            sGtlMsg += ":20:";
		            sGtlMsg += sOrigRefNbr;
					sGtlMsg += "\r\n";
					logDebug("TAG20 = ***"+sOrigRefNbr+"***");
		        	logDebug("i = "+i+"\n++++++++++++++++++++++++++");

				// Related Reference
					sGtlMsg += "\r\n";
		        	if (! (SwiftTag = GetTok3(dtMsgContent, "\r\n:21:", i)).trim().equals("")) {
		                len = SwiftTag.indexOf("\r\n");
		                if (len != -1)
		                        sTmp = Left(SwiftTag, len);
		                sGtlMsg += ":21:";
		                sGtlMsg += sTmp;
						sGtlMsg += "\r\n";
						logDebug("TAG21 = ***"+sTmp+"***");
		        	}
		        	
		logDebug("i = "+i+"\n++++++++++++++++++++++++++");
				// Amount Ack option A
					sGtlMsg += "\r\n";
		        	if (! (SwiftTag = GetTok3(dtMsgContent, "\r\n:32A:", i)).trim().equals("")) {
		                len = SwiftTag.indexOf("\r\n");
		                if (len != -1)
		                        sTmp = Left(SwiftTag, len);
		                sGtlMsg += ":32A:";
		                sGtlMsg += sTmp;
						sGtlMsg += "\r\n";
		        	}
		      logDebug("i = "+i+"\n++++++++++++++++++++++++++");  
		        // Amount Ack option B
					sGtlMsg += "\r\n";
		        	if (! (SwiftTag = GetTok3(dtMsgContent, "\r\n:32B:", i)).trim().equals("")) {
		                len = SwiftTag.indexOf("\r\n");
		                if (len != -1)
		                        sTmp = Left(SwiftTag, len);
		                sGtlMsg += ":32B:";
		                sGtlMsg += sTmp;
						sGtlMsg += "\r\n";
		        	}
		  logDebug("i = "+i+"\n++++++++++++++++++++++++++");       
		        // Amount Ack option K
					sGtlMsg += "\r\n";
		        	if (! (SwiftTag = GetTok3(dtMsgContent, "\r\n:32K:", i)).trim().equals("")) {
		                len = SwiftTag.indexOf("\r\n");
		                if (len != -1)
		                        sTmp = Left(SwiftTag, len);
		                sGtlMsg += ":32K:";
		                sGtlMsg += sTmp;
						sGtlMsg += "\r\n";
		        	}
		        	 logDebug("i = "+i+"\n++++++++++++++++++++++++++"); 
		     		i++;
		 		}
		        // Sender to Receiver Information
				sGtlMsg += "\r\n";
		      	if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:72:")).trim().equals("") ) {
		                sGtlMsg += ":72:";
		                sGtlMsg += SwiftTag;
						sGtlMsg += "\r\n";
		        }
		        //return (QS_SUCCEED);
		     
		     
		    logDebug("sGtlMsg = \n" + sGtlMsg);
		    hParentResult.remove(FIELD_MSG_TEXT);
		    hParentResult.put(FIELD_MSG_TEXT, sGtlMsg);
		    
		     return true;
	     }catch (Exception ex) {
	            logDebug((Throwable) ex);
			    logDebug("IMParseMappingExtractor.MT412_to_Gtl: "+ex.getMessage());
				//throw new Exception(ex.getMessage());
			    logDebug("ERROR MT412_to_Gtl(). Return false");
			    return false;
	     }finally{
				//close(conn);
		}
	}
	
	private boolean MT430_to_Gtl(Hashtable hParentResult, DataTable dtMsgContent) throws Exception
	{
		 logDebug("Start MT430_to_Gtl()");
		 //IDataConnection  conn = null;
		 DataTable dt;
	     try{
	    	 String sProcUnit=(String)hParentResult.get(FIELD_PROC_UNIT);
		     String sMsgTyp=(String)hParentResult.get(FIELD_MSG_TYP);
		     String sGtlMsg="";
		     String Sql="";
		     
		        // Convert Swift to GTL and update the SI_MSG_Q
		        String SwiftTag;
		        String sTmp="";
		        //CString* SwiftTag2;
		        int len = 0, i=1;
		        String mapCheck = "0";
		        int Check32=0, Check33=0, Check32a=0, Check74=0;
		        //CString TAG32content;

		        String sExtRefNbr = "";
		        String sSenderRef = " ";
		        String sRecvRef = " ";
		        String sIssuBnkRef = "";
		        String sProdType = " ";
		        String sProdCat = "IC";
		        String sTranType = " ";
		        String sOrigRefNbr = " ";
		        String sLcTyp = " ";

		        sGtlMsg = sProdCat;
				sGtlMsg += sMsgTyp;
		        sGtlMsg += "\r\n";

		         // check Mandatory Repetitive Seq A
				// Transaction Reference Number
		        while (! (SwiftTag = GetTok2(dtMsgContent, "\r\n:20:", i)).trim().equals("")){
				//if ((SwiftTag = GetTok2("\r\n:20:")) != "") {
		                len = SwiftTag.indexOf("\r\n");
		                if (len != -1)
		                        sOrigRefNbr = Left(SwiftTag, len);
		                sGtlMsg += ":20:";
		                sGtlMsg += sOrigRefNbr;
						sGtlMsg += "\r\n";
						logDebug("TAG20 = ***"+sOrigRefNbr+"***");
		        //}

				// Related Reference
				sGtlMsg += "\r\n";
		        if (! (SwiftTag = GetTok3(dtMsgContent, "\r\n:21:", i)).trim().equals("")) {
		                len = SwiftTag.indexOf("\r\n");
		                if (len != -1)
		                        sTmp = Left(SwiftTag, len);
		                sGtlMsg += ":21:";
		                sGtlMsg += sTmp;
						sGtlMsg += "\r\n";
						
		        }
		        logDebug("TAG21 = ***"+sTmp+"***");
		       
		  
		       
					// Amount Ack option A
					sGtlMsg += "\r\n";
		        	if (! (SwiftTag = GetTok3(dtMsgContent, "\r\n:32A:", i)).trim().equals("")){
		        	        len = SwiftTag.indexOf("\r\n");
		        	        if (len != -1)
		        	                sTmp = Left(SwiftTag, len);
		        	        sGtlMsg += ":32A:";
		        	        sGtlMsg += sTmp;
							sGtlMsg += "\r\n";
							if (i<2){
								Check32a=1;
								Check32=1;
							}
		        	}
		        	
		        	// Amount Ack option K
					sGtlMsg += "\r\n";
		        	if (! (SwiftTag = GetTok3(dtMsgContent, "\r\n:32K:", i)).trim().equals("")){
		        	        len = SwiftTag.indexOf("\r\n");
		        	        if (len != -1)
		        	                sTmp = Left(SwiftTag, len);
		        	        sGtlMsg += ":32K:";
		        	        sGtlMsg += sTmp;
							sGtlMsg += "\r\n";
							if (i<2){
								Check32=1;
								//TAG32content=sTmp;
							}
		        	}
		        	
		        	// Amount Amended option A
					sGtlMsg += "\r\n";
		        	if (! (SwiftTag = GetTok3(dtMsgContent, "\r\n:33A:", i)).trim().equals("")){
		        	        len = SwiftTag.indexOf("\r\n");
		        	        if (len != -1)
		        	                sTmp = Left(SwiftTag, len);
		        	        sGtlMsg += ":33A:";
		        	        sGtlMsg += sTmp;
							sGtlMsg += "\r\n";
							if (i<2)
								Check33=1;
		        	}
		        	
		        	// Amount Amended option K
					sGtlMsg += "\r\n";
		        	if (! (SwiftTag = GetTok3(dtMsgContent, "\r\n:33K:", i)).trim().equals("")){
		        	        len = SwiftTag.indexOf("\r\n");
		        	        if (len != -1)
		        	                sTmp = Left(SwiftTag, len);
		        	        sGtlMsg += ":33K:";
		        	        sGtlMsg += sTmp;
							sGtlMsg += "\r\n";
							if (i<2)
								Check33=1;
		        	}
		        	
		        	i++;
		    	}
		        	
		    
		    
		        // Drawee
				sGtlMsg += "\r\n";
		      	if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:59:")).trim().equals("") ) {
		                sGtlMsg += ":59:";
		                sGtlMsg += SwiftTag;
						sGtlMsg += "\r\n";
		        }
		     
		        // Sender to Receiver Information
				sGtlMsg += "\r\n";
		      	if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:72:")).trim().equals("") ) {
		                sGtlMsg += ":72:";
		                sGtlMsg += SwiftTag;
						sGtlMsg += "\r\n";
		        }
		        
		        // Amendments
				sGtlMsg += "\r\n";
		      	if (! (SwiftTag = GetTok(dtMsgContent, "\r\n:74:")).trim().equals("") ) {
		                sGtlMsg += ":74:";
		                sGtlMsg += SwiftTag;
						sGtlMsg += "\r\n";
						Check74=1;
		        }
		       /* cout<<"Check32="<<Check32<<"\nCheck32a="<<Check32a<<"\nCheck33="<<Check33<<"\nCheck74="<<Check74<<endl;
		        // check for validation in advance of mapping
		        if (i==2)//check for multiple collection info - [1 Mandatory seq]
		        	if (!((Check33==1) && (Check32==0))) // if TAG33 is present, TAG32 must be present
		        		if ((Check32==1) || (Check74==1)){ // at least TAG32 or TAG74 is present
		        			mapCheck="1";
		        			if (Check32a==1)
		        				mapCheck="2";
		        			else if (Check32==1)
		        				mapCheck="3";        				
		    			}
		    	
		        //GT_DATABASE* pDatabase;
		        //pDatabase = GetDatabaseObj();
				CString Sql2;
			    GT_DBRows *PollDBRows;
			    //GT_DBRETCODE retcode;
			    //GT_Value * PollVal;
			                   	                    
			    Sql2 = "update GTDPEND1..SI_MSG set EXT_MSG_REF = '";
			    //if ((Check32==1) && (mapCheck=='1'))
			    //	Sql2 += TAG32content;
			   	//else
			   	Sql2 += mapCheck;    	
		        Sql2 += "' where PROC_UNIT = '";
		        Sql2 += sProcUnit;
		        Sql2 += "' and QUEUE_ID = ";
		        Sql2 += sQueueId;
		    		
		        cout<<"QueueID = "<<sQueueId<<endl;
		        cout<< "*************\n"<<Sql2<<"\n**************"<<endl;
		        
				SetSql (Sql2);
				cout<<"SetSql(Sql2) update mapCheck"<<endl;
		        ExecSql();
		        cout<<"ExecSql() update mapCheck"<<endl; 
		       */ 
		           	
		        // 0: not valid --> no mapping later on
		        // 1: no TAG32 and TAG33
		        // 2: check TAG32A
		        // 3: check TAG32K
		        //return (QS_SUCCEED);
		     
		     logDebug("sGtlMsg = \n" + sGtlMsg);
			 hParentResult.remove(FIELD_MSG_TEXT);
			 hParentResult.put(FIELD_MSG_TEXT, sGtlMsg);
			    
			 return true;
		 }catch (Exception ex) {
		 	logDebug((Throwable) ex);
			logDebug("IMParseMappingExtractor.MT430_to_Gtl: "+ex.getMessage());
			//throw new Exception(ex.getMessage());
			logDebug("ERROR MT430_to_Gtl(). Return false");
			return false;
		 }finally{
			//close(conn);
		}
	}		     
	
	private boolean getMsgRouteResult(Hashtable hParseResult) throws Exception{
		//IDataConnection conn = null;
		String sRouteProdTyp = "";
		String sRouteLocationCd = "";
		String sRouteExtRefNbr = "";
		String sCustNm = "";
		CallableStatement pstmt = null;
		
	    try{
    	
	    	/* Remark:  
	    	 * 1. For SWIFT: KEY_1 = TAG21, KEY_2 = TAG20, KEY_3 = TAG40A/TAG40B, KEY_4 = TAG59 
	    	 * 2. For GTI: KEY_1 = Tag <Type>, KEY_2 = PTY_ID/EXT_REF_NBR, KEY_3 = BLANK, KEY_4 = BLANK 
	    	 */
	    	String sProcUnit=(String)hParseResult.get(FIELD_PROC_UNIT);
	    	String sQueueTyp=(String)hParseResult.get(FIELD_QUEUE_TYP);
	    	String sMsgTyp=(String)hParseResult.get(FIELD_MSG_TYP);
	    	String sKey1=(String)hParseResult.get(FIELD_SWIFT_TAG21);
	    	String sKey2=(String)hParseResult.get(FIELD_SWIFT_TAG20);
	    	String sKey3=(String)hParseResult.get(FIELD_SWIFT_TAG40A);
	    	if (sKey3.trim().equals("")){
	    		sKey3=(String)hParseResult.get(FIELD_SWIFT_TAG40B);
	    	}
	    	String sKey4=(String)hParseResult.get(FIELD_SWIFT_TAG59);
	    	
	    	if(sQueueTyp.trim().equals(QUEUE_TYP_SWIFT)&&(sMsgTyp.trim().equals("740")||sMsgTyp.trim().equals("742")||sMsgTyp.trim().equals("747"))){
	    		String sSendRecvAddr=(String)hParseResult.get(FIELD_SEND_RECV_ADDR);
	    		String sBICName=getBIC_Name(sSendRecvAddr);
	    		sKey4 = sBICName;
	    		
	    		//FIELD_ISU_BNK_NAME may not be using 
	    		hParseResult.remove(FIELD_ISU_BNK_NAME);
	    		hParseResult.put(FIELD_ISU_BNK_NAME, sBICName);  		
	    	}
	    	
	    	logDebug("getMsgRouteResult: Sql:"+_spMsgRouteResult+" ("+sProcUnit+"|"+sQueueTyp+"|"+sMsgTyp+"|"+sKey1+"|"+sKey2+"|"+sKey3+"|"+sKey4+"|?|?|?|?)");
	    	
	    	//conn = getConnection();
	        pstmt=conn.prepareCall(_spMsgRouteResult);
	        pstmt.setString(1, sProcUnit);
	        pstmt.setString(2, sQueueTyp);
	        pstmt.setString(3, sMsgTyp);
	        pstmt.setString(4, sKey1);
	        pstmt.setString(5, sKey2);
	        pstmt.setString(6, sKey3);
	        pstmt.setString(7, sKey4);
	        pstmt.registerOutParameter(8,Types.CHAR);
	        pstmt.registerOutParameter(9,Types.CHAR);
	        pstmt.registerOutParameter(10,Types.CHAR);
	        pstmt.registerOutParameter(11,Types.VARCHAR);
            pstmt.execute();
            sRouteProdTyp = (String)pstmt.getObject(8);
            sRouteProdTyp = sRouteProdTyp.trim();
            sRouteLocationCd = (String)pstmt.getObject(9);
            sRouteLocationCd = sRouteLocationCd.trim();
            sRouteExtRefNbr = (String)pstmt.getObject(10);
            sRouteExtRefNbr = sRouteExtRefNbr.trim();
            sCustNm = (String)pstmt.getObject(11);
            sCustNm = sCustNm.trim();
            
            logDebug("getMsgRouteResult: Result: sRouteProdTyp["+sRouteProdTyp+"], sRouteLocationCd["+sRouteLocationCd+"], sRouteExtRefNbr["+sRouteExtRefNbr+"], sCustNm["+sCustNm+"]");
	        
            hParseResult.remove(FIELD_ROUTE_PROD_TYP);
            hParseResult.remove(FIELD_ROUTE_LOCATION_CD);
            hParseResult.remove(FIELD_ROUTE_EXT_REF_NBR);
            hParseResult.remove(FIELD_CUST_NM);
            hParseResult.put(FIELD_ROUTE_PROD_TYP, sRouteProdTyp);
            hParseResult.put(FIELD_ROUTE_LOCATION_CD, sRouteLocationCd);
            hParseResult.put(FIELD_ROUTE_EXT_REF_NBR, sRouteExtRefNbr);
            hParseResult.put(FIELD_CUST_NM, sCustNm);
            
            
            return true;
	    }
	    catch(Exception e) {
	        logDebug((Throwable) e);
	        logDebug("getMsgRouteResult: Catch Exception");
	        return false;
	    }finally {
			if (pstmt != null) {
				try{
					pstmt.close();
				} catch (SQLException e) {
					com.chase.infra.util.LogWrapper.instance.logDebug("IMParseMappingExtractor.getMsgRouteResult failed to close PreparedStatement");
					e.printStackTrace();
				}
			}
		}
	}
	
	private String CheckDt(String Dt) {

        int yr = Integer.parseInt(Left(Dt,2));

        if ( yr > 50 ) {
                Dt = "19" + Dt;
        } else {
                Dt = "20" + Dt;
        }
        return Dt;
	}
	
	private long GetAudID(String sProcUnit) throws Exception{
		long sNewAudId=0;
		try{
			logDebug("Enter GetAudID()");
			DataTable dt;
			
			String Sql  = "exec GTDPEND1..USP_CGET_AUDID1 '" + sProcUnit + "'";
			logDebug("Exec Sql: [" + Sql + "]");

			dt=conn.executeQuery(Sql);
			int	rowcount = dt.size();
			if ( rowcount == 1)
			{
				dt.next();
				sNewAudId=Long.parseLong(dt.getField("AUD_ID").toString());
			}
			
			logDebug("GetAudID: sNewAudId=["+sNewAudId+"]");

		}catch(Exception e){
			logDebug((Throwable) e);
		    logDebug("IMParseMappingExtractor.GetAudID: "+e.getMessage());
			throw new Exception(e.getMessage());
		}
		return sNewAudId;
	}
	
	
	
	private boolean GetExtRefNbr (Hashtable hParentResult) throws Exception
	{
		CallableStatement getExtRefNbrStmt = null;
		//IDataConnection  conn = null;
        try {
	        String sErrMsg = "";
	        String sRetry = "";
			String sDay = "";
			String Sql="";
			DataTable dt;
			ResultSet rs;

			String sProcUnit=(String)hParentResult.get(FIELD_PROC_UNIT);
			int sQueueId=((Integer)hParentResult.get(FIELD_QUEUE_ID)).intValue();
			String sMsgTyp=(String)hParentResult.get(FIELD_MSG_TYP);
			String sSenderRef=(String)hParentResult.get(FIELD_SENDER_REF);
			String sRecvRef=(String)hParentResult.get(FIELD_RECV_REF);
			String sIssuBnkRef=(String)hParentResult.get(FIELD_ISSU_BNK_REF);
			
	        int dbRtnCode, dbRstCode;
	        int rowcount;
	        
			// Get latest QUEUE_STATUS in GTDTRAN1..SI_MSG_Q, if QUEUE_STATUS = 'X', then it is a retry by user
			//Sql  = "select THIS_PROC_DT from GTDMAST1..PROC_UNIT ";
	        Sql  = "select THIS_PROC_DT=convert(char(8), THIS_PROC_DT, 112) from GTDMAST1..PROC_UNIT ";
	        Sql += "where PROC_UNIT = '"; 
			Sql += sProcUnit;
			Sql += "'";
			
			logDebug("Get THIS_PROC_DT : "+Sql);
			
			//conn=getConnection();
			dt=conn.executeQuery(Sql);
			//close(conn);
			if (dt.size()>0){
				dt.next();
				sDay=(String)dt.getField("THIS_PROC_DT");
			}

			Sql  = "select distinct QUEUE_STATUS from GTDTRAN1..SI_MSG_Q ";
			Sql += "where INTF_PROC_UNIT = '"; 
			Sql += sProcUnit;
			Sql += "' and QUEUE_TYP = 'SWF' and QUEUE_ID = ";
			Sql += sQueueId;
			Sql += " and QUEUE_STATUS = 'X' and PROC_DT > dateadd(dd, -365, '";
			Sql += sDay;
			Sql += "')";
			
			logDebug("Get Latest QUEUE_STATUS in GTDTRAN1..SI_MSG_Q : "+Sql);
			
			//conn=getConnection();
			dt=conn.executeQuery(Sql);
			//close(conn);
			if(dt.size()>0){
				dt.next();
				sRetry=(String)dt.getField("QUEUE_STATUS");
			}
			
			String getExtRefNbrSql = "{? = call GTDPEND1..USP_IGET_EXT_REF_NBR ?, ?, ? ,? ,?, ?}";
			
			//conn=getConnection();
			getExtRefNbrStmt = conn.prepareCall(getExtRefNbrSql);
			
			getExtRefNbrStmt.registerOutParameter(1,Types.INTEGER);
			getExtRefNbrStmt.setString(2, sProcUnit);
			getExtRefNbrStmt.setString(3, sSenderRef);
			getExtRefNbrStmt.setString(4, sRecvRef);
			getExtRefNbrStmt.setString(5, sIssuBnkRef);
			getExtRefNbrStmt.setString(6, sMsgTyp);
			
			if (sRetry == "X")
			{
				getExtRefNbrStmt.setString(7, "Y");
			}else{
				getExtRefNbrStmt.setString(7, "N");
			}

	        logDebug("USP_IGET_EXT_REF_NBR : " + getExtRefNbrSql);
	        logDebug("USP_IGET_EXT_REF_NBR sProcUnit: " + sProcUnit);
	        logDebug("USP_IGET_EXT_REF_NBR sSenderRef: " + sSenderRef);
	        logDebug("USP_IGET_EXT_REF_NBR sRecvRef: " + sRecvRef);
	        logDebug("USP_IGET_EXT_REF_NBR sIssuBnkRef: " + sIssuBnkRef);
	        logDebug("USP_IGET_EXT_REF_NBR sMsgTyp: " + sMsgTyp);
	        logDebug("USP_IGET_EXT_REF_NBR sRetry: " + sRetry);

	        getExtRefNbrStmt.execute();
	        
	        logDebug("USP_IGET_EXT_REF_NBR Success");
	        
	        dbRtnCode   = getExtRefNbrStmt.getInt(1);
	        
	        if ( dbRtnCode == 0) {
	        	logDebug("Ext_Ref_Nbr................");
	        	
	        	rs = getExtRefNbrStmt.executeQuery();
	        	
	        	while (rs.next())
	            {
		        	String sRecExistInd=rs.getString(FIELD_REC_EXIST_IND);
		        	if (sRecExistInd.trim().equals("Y")){
		        		logDebug("GetExtRefNbr: sRecExistInd=Y");
		        		
			        	String sExtRefNbr=rs.getString(FIELD_EXT_REF_NBR);
			        	String sProdCat=rs.getString(FIELD_PROD_CAT);
			        	String sProdType=rs.getString(FIELD_PROD_TYP);
			        	String sTranRefNbr=rs.getString(FIELD_TRAN_REF_NBR);
			        	
			        	hParentResult.remove(FIELD_EXT_REF_NBR);
			        	hParentResult.remove(FIELD_PROD_CAT);
			        	hParentResult.remove(FIELD_PROD_TYP);
			        	hParentResult.remove(FIELD_TRAN_REF_NBR);
			        	hParentResult.put(FIELD_EXT_REF_NBR, sExtRefNbr);
			        	hParentResult.put(FIELD_PROD_CAT, sProdCat);
			        	hParentResult.put(FIELD_PROD_TYP, sProdType);
			        	hParentResult.put(FIELD_TRAN_REF_NBR, sTranRefNbr);
		        	}else{
		        		logDebug("GetExtRefNbr: sRecExistInd <> Y. Return false");
		        		//close(conn);
		        		return false;
		        	}
	            }
	        	
	        }
	        else{
	        	logDebug("GetExtRefNbr(): return code : " + dbRtnCode);
	        	//close(conn);
	        	return false;
	        }

	        return true;
        }catch (Exception ex) {
	            logDebug((Throwable) ex);
			    logDebug("IMParseMappingExtractor.GetExtRefNbr(): "+ex.getMessage());
				//throw new Exception(ex.getMessage());
			    logDebug("GetExtRefNbr(): return false");
			    //close(conn);
			    //QC# 27997: GWF - WHEM AUT (UG25) - getting error "Attempt to insert NULL value into column 'KEY2', table 'GTDPEND1.dbo.OFAC_Q'; column does not allow nulls. Update fails."
			    //SQL exception that rollback updates should not proceed
			    //return false;
			    throw ex;
	    }finally {
			if (getExtRefNbrStmt != null) {
				try{
					getExtRefNbrStmt.close();
				} catch (SQLException e) {
					com.chase.infra.util.LogWrapper.instance.logDebug("IMParseMappingExtractor.GetExtRefNbr failed to close PreparedStatement");
					e.printStackTrace();
				}
			}
		}
	}
	
	private boolean GenNewTranRefNbr (Hashtable hParentResult)
	{
		//IDataConnection  conn = null;
		DataTable dt;
        try {
        	String sProcUnit=(String)hParentResult.get(FIELD_PROC_UNIT);
        	String sProdCat=(String)hParentResult.get(FIELD_PROD_CAT);
        	String sProdType=(String)hParentResult.get(FIELD_PROD_TYP);
        	String sOpTeamCd=(String)hParentResult.get(FIELD_OP_TEAM_CD);
        	String sTranRefNbr=(String)hParentResult.get(FIELD_TRAN_REF_NBR);
        	String sDummyId=(String)hParentResult.get(FIELD_DUMMY_ID);
        	
        	String Sql;
        	String sExtRefNbr;
        	String clmTranRefNbr = "";
	        String szSchm;
			szSchm=getPUConfig(sProcUnit, "SPEC_REF_SCHM");
			
			logDebug("GenNewTranRefNbr ,sProdCat , sTranRefNbr = "+sProdCat+","+sTranRefNbr);

			if (szSchm.trim().equals("")) {
	                Sql = "exec GTDPEND1..USP_CGET_NEWTRN '";
	                Sql += sProcUnit;
	                Sql += "', '";
	                Sql += sOpTeamCd;
	                Sql += "', '";
	                Sql += sProdType;
			Sql += "', '";
			Sql += sDummyId;
			Sql += "', 'E'";
			//if (sProdCat =="CLM")
			if (sProdCat.trim().equals("CLM"))
				Sql += ", '"+sTranRefNbr + "'";
	                //Sql += "', '', 'E'";
	        }
	        else {
	                Sql = "exec GTDPEND1..USP_CGEN_SPEC_REF '";
	                Sql += sProcUnit;
	                Sql += "', '";
	                Sql += sOpTeamCd;
	                Sql += "', '";
	                Sql += sProdType;
	                Sql += "', '', '', 'E'";
	        }

	        logDebug("GenNewTranRefNbr(): Exec Sql: [" + Sql + "]");
	        
	        //conn=getConnection();
	        dt=conn.executeQuery(Sql);
	        //close(conn);
	        if (dt.size()>0){
	        	dt.next();
	        	sExtRefNbr=(String)dt.getField("EXT_REF_NBR");
	        	hParentResult.remove(FIELD_EXT_REF_NBR);
	        	hParentResult.put(FIELD_EXT_REF_NBR, sExtRefNbr);
	        }
	        
			Sql = "exec GTDPEND1..USP_CUNLCK_TRANITEM '" +sProcUnit +"','"+sProdCat+"','"+sTranRefNbr+"',''";

			logDebug("GetNewTranRefNbr(): sql:"+Sql);
			//conn=getConnection();
			conn.executeUpdate(Sql);
			//close(conn);

	        return true;
        }catch (Exception ex) {
	            logDebug((Throwable) ex);
			    logDebug("IMParseMappingExtractor.GetNewTranRefNbr(): "+ex.getMessage());
				//throw new Exception(ex.getMessage());
			    logDebug("GetNewTranRefNbr(): return false");
			    return false;
	    }
	    finally {
	        //close(conn);
	    }
	}
	
	private String getPUConfig(String procUnit, String puName){
		//IDataConnection conn = null;
		String puValue = "";
		CallableStatement pstmt = null;

	    try{
	        //conn = getConnection();
	        pstmt=conn.prepareCall(_spGetPuConfig);
	        pstmt.setString(1, procUnit);
            pstmt.setString(2, puName);
            pstmt.registerOutParameter(3,Types.CHAR);
            pstmt.execute();
            puValue = (String)pstmt.getObject(3);
            puValue = puValue.trim();
            logDebug("PU Config of ["+puName+"] is : ["+puValue+"]");
	        return puValue;
	    }
	    catch(Exception e) {
	        logDebug((Throwable) e);
	        return puValue;
	    }finally{
	    	if (pstmt != null) {
				try{
					pstmt.close();
				} catch (SQLException e) {
					com.chase.infra.util.LogWrapper.instance.logDebug("IMParseMappingExtractor.getPUConfig failed to close PreparedStatement");
					e.printStackTrace();
				}
			}
	    }
	}	
	
	private boolean selectTranType (Hashtable hParentResult)
	{
		//IDataConnection  conn = null;
		DataTable dt;
		try{
			String sProcUnit=(String)hParentResult.get(FIELD_PROC_UNIT);
			String sMsgTyp=(String)hParentResult.get(FIELD_MSG_TYP);
			String sLcTyp=(String)hParentResult.get(FIELD_LC_TYP);
			String sProdType=(String)hParentResult.get(FIELD_PROD_TYP);
			String sTranType=(String)hParentResult.get(FIELD_TRAN_TYP);
			String sProdCat=(String)hParentResult.get(FIELD_PROD_CAT);
			String Sql;
			
	        Sql  = "select m.PROD_TYP, m.TRAN_TYP, p.PROD_CAT ";
	        Sql += "from GTDMAST1..SI_PROD_TYP_MAP m, GTDMAST1..PROD_TYP p ";
	        Sql += "where m.INTF_PROC_UNIT = '";
	        Sql += sProcUnit;
	        Sql += "' and m.MSG_TYP = '";
	        Sql += sMsgTyp;
	        Sql += "' and m.INTF_PROC_UNIT = p.PROC_UNIT ";
	        Sql += "and m.PROD_TYP = p.PROD_TYP ";
	        Sql += "and m.QUEUE_TYP = 'SWF' ";
	        Sql += "and m.LC_TYP = '";
	        Sql += sLcTyp;
	        Sql += "'";
	        
	        logDebug("Get the PROD_CAT, PROD_TYP, TRAN_TYP SQL: " + Sql );

			//conn=getConnection();
			dt=conn.executeQuery(Sql);
			//close(conn);
	        
			int rowcount = dt.size();
						
	        if ( rowcount > 0 ) {
	        		dt.next();
	        		sProdType=(String)dt.getField("PROD_TYP");
	        		sTranType=(String)dt.getField("TRAN_TYP");
	        		sProdCat=(String)dt.getField("PROD_CAT");
	        		
	        } else {
	                sProdType = "";
	                sTranType = "";
	                sProdCat = "";
	        }
	        
	        hParentResult.remove(FIELD_PROD_TYP);
			hParentResult.remove(FIELD_TRAN_TYP);
			hParentResult.remove(FIELD_PROD_CAT);
	        hParentResult.put(FIELD_PROD_TYP, sProdType);
			hParentResult.put(FIELD_TRAN_TYP, sTranType);
			hParentResult.put(FIELD_PROD_CAT, sProdCat);
			
			/*
	        if (pDBRows != NULL) {
	                delete pDBRows; 
	                pDBRows = NULL;
	        }
	        */

	        //return (QS_SUCCEED);
	        return true;
		}
        catch (Exception ex) {
            logDebug("selectTranType():"+(Throwable) ex);
		    logDebug("selectTranType() failed. return false");
			//throw new Exception(ex.getMessage());
		    return false;
        }
        finally {
            //close(conn);
        }
	}
	
	//private void Update_SI_MSGQ(Hashtable hParentResult) throws Exception
	private void commitParentResult(Hashtable hParentResult) throws Exception
	{
		//IDataConnection  conn = null;
		CallableStatement stmt = null;
		try{
						
			String sProcUnit=(String)hParentResult.get(FIELD_PROC_UNIT);
			String sQueueTyp=(String)hParentResult.get(FIELD_QUEUE_TYP);
			Integer iQueueID=(Integer)hParentResult.get(FIELD_QUEUE_ID);
			String sMsgTyp=(String)hParentResult.get(FIELD_MSG_TYP);
			String sApplMsgRef=(String)hParentResult.get(FIELD_APPL_MSG_REF);
			String sGtlMsg=(String)hParentResult.get(FIELD_MSG_TEXT);
			//String sNeedTransformSysFmt=(String)hParentResult.get(FIELD_NEED_TRANSFORM_SYSFMT);
			//String sTransformSysFmtSuccess=(String)hParentResult.get(FIELD_TRANSFORM_SYSFMT_SUCCESS);
			String sOFACInd=(String)hParentResult.get(FIELD_OFAC_IND);
			String sActionTyp=(String)hParentResult.get(FIELD_ACTION_TYP);
			Long iAudID=(Long)hParentResult.get(FIELD_AUD_ID);
			String sProcessorID=(String)hParentResult.get(FIELD_PROCESSOR_ID);
			Timestamp tBatchID=(Timestamp)hParentResult.get(FIELD_BATCH_ID);
			
			sGtlMsg=DuplicateQuote1(sGtlMsg);
			String lsSql;
			
			if(sQueueTyp.trim().equals(QUEUE_TYP_SWIFT)){
				logDebug("commitParentResult: QUEUE_TYP is SWIFT. Update SI_MSG.MSG_SYS_CONTENT with System Format");
				//int status;
				lsSql="update GTDPEND1..SI_MSG ";
				lsSql += "set MSG_SYS_CONTENT = '";
		        lsSql += sGtlMsg;
		        /* GWF: Skip update SI_MSG_Q.MSG_CONTENT
		        if (sQueueTyp == "SWF")
				{
					Sql += "\", MSG_CONTENT = \"";
					Sql += sMsgContent;
				}
				*/
		        lsSql += "' where PROC_UNIT = '";
		        lsSql += sProcUnit;
		        lsSql += "' and QUEUE_TYP = '";
		        lsSql += sQueueTyp;
		        lsSql += "' and QUEUE_ID = ";
		        lsSql += iQueueID;
		        
		        logDebug("commitParentResult(): Update GTDPEND1..SI_MSG.MSG_SYS_CONTENT with System Format");
		        //conn=getConnection();
		        stmt = conn.prepareCall(lsSql);
		        int lirow=stmt.executeUpdate();
		        //close(conn);
		        logDebug("rowcount="+lirow);
		        if (lirow!=1){
		        	String lsExcept="commitParentResult(): Update GTDPEND1..SI_MSG.MSG_SYS_CONTENT failed. Sql:"+lsSql;
		        	logDebug(lsExcept);
		        	throw new Exception(lsExcept);
		        }
			}else{
				logDebug("commitParentResult: QUEUE_TYP is Not SWIFT. Do Not Update SI_MSG.MSG_SYS_CONTENT");
			}
	        
			/*
			lsSql="select EXT_REF from GTDPEND1..SI_MSG_Q where INTF_PROC_UNIT='CNY' and QUEUE_TYP='"+sQueueTyp+"' and QUEUE_ID="+iQueueID+" ";
			logDebug("Hunter0111: Sql:"+lsSql);
			DataTable dt1=conn.executeQuery(lsSql);
			dt1.next();
			String s1=(String)dt1.getField("EXT_REF");
			s1=s1.trim();
			logDebug("Hunter0111: s1["+s1+"]");
			*/
			
			
	        Hashtable params = new Hashtable();
            params.put(FIELD_PROC_UNIT, sProcUnit);
            params.put(FIELD_QUEUE_TYP, sQueueTyp);
            params.put(FIELD_QUEUE_ID, iQueueID);
            params.put(FIELD_MSG_TYP, sMsgTyp);
            params.put(FIELD_APPL_MSG_REF, sApplMsgRef);
            //params.put(FIELD_NEED_TRANSFORM_SYSFMT, sNeedTransformSysFmt);
            //params.put(FIELD_TRANSFORM_SYSFMT_SUCCESS, sTransformSysFmtSuccess);
            params.put(FIELD_ACTION_TYP, sActionTyp);
            params.put(FIELD_OFAC_IND, sOFACInd);
            params.put(FIELD_INPUT_AUD_ID, iAudID);
            params.put(FIELD_PROCESSOR_ID, sProcessorID);
            params.put(FIELD_BATCH_ID, tBatchID);
            
            logDebug("commitParentResult() sql : "+_sCommitParent+" ("+sProcUnit+"|"+sQueueTyp+"|"+ iQueueID+"|"+sMsgTyp+"|"+sApplMsgRef+"|"+sActionTyp+"|"+sOFACInd+"|"+iAudID+"|"+sProcessorID+"|"+tBatchID+")");
            
            //conn=getConnection();
            conn.executeUpdate(_sCommitParent,params );
	        //close(conn);
            
            logDebug("End of commitParentResult");
	        
		}catch (Exception ex) {
            //throw new TriggerException(e.getMessage());
            logDebug((Throwable) ex);
		    logDebug("IMParseMappingExtractor.commitParentResult(): "+ex.getMessage());
			throw new Exception(ex.getMessage());
        }finally{
	    	if (stmt != null) {
				try{
					stmt.close();
				} catch (SQLException e) {
					com.chase.infra.util.LogWrapper.instance.logDebug("IMParseMappingExtractor.commitParentResult failed to close PreparedStatement");
					e.printStackTrace();
				}
			}
	    }

/*GWF: Skip update QUEUE_STATUS - Begin
        WriteErrLog("Update SI_MSG_Q MSG_TEXT ["+sProcUnit+"] ["+sExtRefNbr+"] ["+sQueueId+"]");
		TRY
		{
			SetSql(Sql);
			ExecSql();
		}
	        CATCH_ALL(e)
			WriteErrLog("Error Updating SI_MSG_Q");
			Sql  =  "USP_CUPD_SIMSGQ_STAT '";
			Sql +=  sProcUnit;
			Sql +=  "', ";
			Sql +=  "'SWF', ";
			Sql +=  sQueueId;
			Sql +=  ", 'FAIL', '01/01/1900', 'SWFPARSER'";
			WriteErrLog("ExecSql:[" + Sql + "]");

			SetSql(Sql);
			ExecSql();

			 return (QS_FAIL);
	        END_CATCH_ALL

	        Sql  =  "USP_CUPD_SIMSGQ_STAT '";
	        Sql +=  sProcUnit;
			// Gary Start 20030626
	        Sql +=  "', '";
	        Sql +=  sQueueTyp;
			Sql += "', ";
			// Gary End
	        Sql +=  sQueueId;
	        Sql +=  ", 'RTRY', '01/01/1900', 'SWFPARSER'";

	        SetSql(Sql);
	        ExecSql();
	                
	        GetRetStatus(status);
	        TRACE_INT(status, status);

	        if (status)
	        {
	                WriteErrLog("Error Execute Sql:  " + Sql);
	                return (QS_FAIL);
	        }

	        return (QS_SUCCEED);

* GWF: Skip update QUEUE_STATUS - End */
	}
	
	private void commitParseResult(Hashtable hParseResult) throws Exception {
		
		//IDataConnection  conn = null;
		CallableStatement stmt = null;
        try {
        	
			String lsProcUnit="";
			String lsQueueTyp="";
			int	liQueueID=0;
			long liAudID=0;
			String lsMsgText="";
			int lirow=0;
			String lsSql="";
			String lsExcept="";
			
			lsProcUnit=(String)hParseResult.get(FIELD_PROC_UNIT);
			lsQueueTyp=(String)hParseResult.get(FIELD_QUEUE_TYP);
			liQueueID=((Integer)hParseResult.get(FIELD_QUEUE_ID)).intValue();
			liAudID=((Long)hParseResult.get(FIELD_AUD_ID)).longValue();
        	
        	if (lsQueueTyp.equals(QUEUE_TYP_SWIFT)){
	        	logDebug("commitParseResult(): Queue Type SWIFT, Update SI_MSG.MSG_TEXT/MSG_DISPLAY_CONTENT with Translated format");
	        	
        		lsMsgText=(String)hParseResult.get(FIELD_MSG_TEXT);
        		lsMsgText=DuplicateQuote1(lsMsgText);
        		
        		//logDebug("Hunter0604 commitParseResult: lsMsgText["+lsMsgText+"]");
	        	
	        	lsSql="update GTDPEND1..SI_MSG set MSG_TEXT='" +lsMsgText+"', MSG_DISPLAY_CONTENT='" +lsMsgText+ "' "
	        			+ "where PROC_UNIT='"+lsProcUnit+"' "
	        			+ "and QUEUE_TYP='"+lsQueueTyp+"' "
	        			+ "and QUEUE_ID="+liQueueID+" ";
	        	
	        	logDebug("commitParseResult(): SWIFT update GTDPEND1..SI_MSG.MSG_TEXT/MSG_DISPLAY_CONTENT with Translated format");
	        	//conn=getConnection();
	        	stmt = conn.prepareCall(lsSql);
		        lirow=stmt.executeUpdate();
		        //close(conn);
		        logDebug("For lsSql1, rowcount="+lirow);
		        if (lirow!=1){
		        	logDebug("commitParseResult(): Update GTDPEND1..SI_MSG failed. Sql:"+lsSql);
		        	lsExcept="commitParseResult(): Update GTDPEND1..SI_MSG failed";
		        	throw new Exception(lsExcept);
		        }
		        
		        //lsSql="update GTDPEND1..SI_MSG_Q set MSG_CONTENT='" +lsMsgText+"' "
    			//+ "where INTF_PROC_UNIT='"+lsProcUnit+"' "
    			//+ "and QUEUE_TYP='"+lsQueueTyp+"' "
    			//+ "and QUEUE_ID="+liQueueID+" ";
		        //    			
		        //logDebug("commitParseResult(): update GTDPEND1..SI_MSG_Q.MSG_CONTENT with Translated format");
				//conn=getConnection();
		        //stmt = conn.prepareCall(lsSql);
		        //lirow=stmt.executeUpdate();
		        //close(conn);
		        //logDebug("For lsSql2, rowcount="+lirow);
		        //if (lirow!=1){
		        //	logDebug("commitParseResult(): Update GTDPEND1..SI_MSG_Q failed. sql:"+lsSql);
		        //	lsExcept="commitParseResult(): Update GTDPEND1..SI_MSG_Q failed";
		        //	throw new Exception(lsExcept);
		        //}
        	}else if (lsQueueTyp.equals(QUEUE_TYP_GTI)){
	        	logDebug("commitParseResult(): Queue Type GTI, Update SI_MSG.MSG_TEXT/MSG_DISPLAY_CONTENT with Application Print");
	        	
        		lsMsgText=(String)hParseResult.get(FIELD_MSG_TEXT);
        		lsMsgText=DuplicateQuote1(lsMsgText);
        		
        		//logDebug("Hunter0604 commitParseResult: lsMsgText["+lsMsgText+"]");
	        	
	        	lsSql="update GTDPEND1..SI_MSG set MSG_TEXT='" +lsMsgText+"', MSG_DISPLAY_CONTENT='" +lsMsgText+ "' "
	        			+ "where PROC_UNIT='"+lsProcUnit+"' "
	        			+ "and QUEUE_TYP='"+lsQueueTyp+"' "
	        			+ "and QUEUE_ID="+liQueueID+" ";
	        	
	        	logDebug("commitParseResult(): GTI update GTDPEND1..SI_MSG.MSG_TEXT/MSG_DISPLAY_CONTENT with Application Print");
	        	//conn=getConnection();
	        	stmt = conn.prepareCall(lsSql);
		        lirow=stmt.executeUpdate();
		        //close(conn);
		        logDebug("For lsSql1, rowcount="+lirow);
		        if (lirow!=1){
		        	logDebug("commitParseResult(): Update GTDPEND1..SI_MSG failed. Sql:"+lsSql);
		        	lsExcept="commitParseResult(): Update GTDPEND1..SI_MSG failed";
		        	throw new Exception(lsExcept);
		        }
		        
		        logDebug("Hunter0621: get APPL_PRNT_PDF");
		        ByteArrayOutputStream applPrntPdfOut = (ByteArrayOutputStream)hParseResult.get(FIELD_APPL_PRNT_PDF);
		        
		        //conn=getConnection();
		        lsSql = "DELETE GTDPEND1..APPL_PRNT "+
					"where PROC_UNIT=? and QUEUE_TYP=? and QUEUE_ID=?";
					
				stmt = conn.prepareCall(lsSql);
					
				stmt.setString(1, lsProcUnit);
			    stmt.setString(2, lsQueueTyp);
				stmt.setInt(3, liQueueID);
					
				logDebug("#####DELETE from GTDPEND1..APPL_PRNT");
				stmt.execute();
				logDebug("#####After DELETE from GTDPEND1..APPL_PRNT");
					
			    lsSql = "INSERT INTO GTDPEND1..APPL_PRNT SELECT "+
			    	" PROC_UNIT		=?,"+	// 1
			    	" QUEUE_TYP		=?,"+	// 2
			    	" QUEUE_ID		=?,"+	// 3
			    	" IMG_TYP		=?,"+	// 4
			    	" MESSAGE_IMG	=?,"+	// 5
			    	" MESSAGE_TEXT	=?,"+	// 6
			    	" ACTION_CD		=?,"+	// 7
			    	" PROC_DT		=?,"+	// 8
			    	" GMT_DT		=getdate(),"+
			    	" AUD_ID		=?";	// 9
					
			    stmt = conn.prepareCall(lsSql);
			    	
			    stmt.setString(1, lsProcUnit);
			    stmt.setString(2, lsQueueTyp);
				stmt.setInt(3, liQueueID);
			    stmt.setString(4, "PDF");
				stmt.setBytes(5, applPrntPdfOut.toByteArray());
				stmt.setString(6, lsMsgText);
			    stmt.setString(7, "I");
			    stmt.setString(8, "19000101");
			    stmt.setLong(9, liAudID);
			    	
				logDebug("#####INSERT Data into GTDPEND1..APPL_PRNT");
				stmt.execute();
				logDebug("#####After INSERT Data into GTDPEND1..APPL_PRNT");
					
				//close(conn);
		        
        	}else{
        		logDebug("commitParseResult(): Queue Type Not SWIFT/GTI, Do Not Update SI_MSG.MSG_TEXT");
        	}
        	
	        String p1=(String)hParseResult.get(FIELD_PROC_UNIT);
	        String p2=(String)hParseResult.get(FIELD_QUEUE_TYP);
	        Integer p3=(Integer)hParseResult.get(FIELD_QUEUE_ID);
	        String p4=(String)hParseResult.get(FIELD_MSG_TYP);
	        String p5=(String)hParseResult.get(FIELD_APPL_MSG_REF);
	        String p6=(String)hParseResult.get(FIELD_LNK_REF);
	        Integer p7=(Integer)hParseResult.get(FIELD_LNK_MSG_SEQ);
	        Integer p8=(Integer)hParseResult.get(FIELD_LNK_MSG_TOTAL);
	        String p9=(String)hParseResult.get(FIELD_EXT_MSG_REF);
	        String p10=(String)hParseResult.get(FIELD_REPAIR_IND);
	        String p11=(String)hParseResult.get(FIELD_DUPLICATE_IND);
	        String p12=(String)hParseResult.get(FIELD_NEED_GROUPING);
	        String p13=(String)hParseResult.get(FIELD_GROUP_COMPLETE);
	        Integer p14=(Integer)hParseResult.get(FIELD_PARENT_QUEUE_ID);
	        String p15=(String)hParseResult.get(FIELD_ROUTE_PROD_TYP);
            String p16=(String)hParseResult.get(FIELD_ROUTE_LOCATION_CD);
            String p17=(String)hParseResult.get(FIELD_ROUTE_EXT_REF_NBR);
            String p18=(String)hParseResult.get(FIELD_CUST_NM);
            String p19=(String)hParseResult.get(FIELD_MSG_CCY_CD);
            String p20=(String)hParseResult.get(FIELD_MSG_AMT);
            Long p21=(Long)hParseResult.get(FIELD_AUD_ID);
            
	        Hashtable params = new Hashtable();
	        params.put(FIELD_PROC_UNIT, p1);
	        params.put(FIELD_QUEUE_TYP, p2);
	        params.put(FIELD_QUEUE_ID, p3);
	        params.put(FIELD_MSG_TYP, p4);
	        params.put(FIELD_APPL_MSG_REF, p5);
	        params.put(FIELD_LNK_REF, p6);
	        params.put(FIELD_LNK_MSG_SEQ, p7);
	        params.put(FIELD_LNK_MSG_TOTAL, p8);
	        params.put(FIELD_EXT_MSG_REF, p9);
	        params.put(FIELD_REPAIR_IND, p10);
	        params.put(FIELD_DUPLICATE_IND, p11);
	        params.put(FIELD_NEED_GROUPING, p12);
	        params.put(FIELD_GROUP_COMPLETE, p13);
	        params.put(FIELD_PARENT_QUEUE_ID, p14);
	        params.put(FIELD_ROUTE_PROD_TYP, p15);
	        params.put(FIELD_ROUTE_LOCATION_CD, p16);
	        params.put(FIELD_ROUTE_EXT_REF_NBR, p17);
	        params.put(FIELD_CUST_NM, p18);
	        params.put(FIELD_MSG_CCY_CD, p19);
	        params.put(FIELD_MSG_AMT, p20);
	        params.put(FIELD_INPUT_AUD_ID, p21);
	             
	        //logDebug("commitParseResult() sql : "+_sCommitParseSWF+" ("+p1+"|"+p2+"|"+ p3+"|"+p4+"|"+ p5+"|"+p6+"|"+p7+"|"+p8+"|"+p9+"|"+p10+"|"+p11+"|"+p12+"|"+p13+")");
	        logDebug("commitParseResult() sql : "+_sCommitParse+" ("+p1+"|"+p2+"|"+ p3+"|"+p4+"|"+ p5+"|"+p6+"|"+p7+"|"+p8+"|"+p9+"|"+p10+"|"+p11+"|"+p12+"|"+p13+"|"+p14+"|"+p15+"|"+p16+"|"+p17+"|"+p18+"|"+p19+"|"+p20+"|"+p21+")");
	        
	        
	        //conn=getConnection();
	        conn.executeUpdate(_sCommitParse, params);
	        //close(conn);
	        
	        logDebug("End of commitParseResult()");

        }
        catch (Exception ex) {
            logDebug((Throwable) ex);
		    logDebug("IMParseMappingExtractor.commitParseResult: "+ex.getMessage());
			throw new Exception(ex.getMessage());
        }finally{
	    	if (stmt != null) {
				try{
					stmt.close();
				} catch (SQLException e) {
					com.chase.infra.util.LogWrapper.instance.logDebug("IMParseMappingExtractor.commitParentResult failed to close PreparedStatement");
					e.printStackTrace();
				}
			}
	    }

	}

	private void commitResult(Hashtable hParseResult, Hashtable hParentResult) throws Exception {
		
		//IDataConnection  conn = null;
		CallableStatement stmt = null;
		CallableStatement lStmtCommitResult = null;
		
        try {
        	logDebug("commitResult(): Begin Commit Parse Result");
        	
        	String lsParseProcUnit="";
			String lsParseQueueTyp="";
			int	liParseQueueID=0;
			long liParseAudID=0;
			String lsParseMsgText="";
			String lsParseMsgContent="";
			int lirow=0;
			String lsSql="";
			String lsExcept="";
			String lsRepairInd="";
			
			lsParseProcUnit=(String)hParseResult.get(FIELD_PROC_UNIT);
			lsParseQueueTyp=(String)hParseResult.get(FIELD_QUEUE_TYP);
			liParseQueueID=((Integer)hParseResult.get(FIELD_QUEUE_ID)).intValue();
			liParseAudID=((Long)hParseResult.get(FIELD_AUD_ID)).longValue();
			lsRepairInd=(String)hParseResult.get(FIELD_REPAIR_IND);
			
        	if (lsParseQueueTyp.trim().equals(QUEUE_TYP_SWIFT)){
	        	logDebug("commitParseResult(): Queue Type SWIFT, Update SI_MSG.MSG_TEXT/MSG_DISPLAY_CONTENT with Translated format");
	        	
        		lsParseMsgText=(String)hParseResult.get(FIELD_MSG_TEXT);
        		lsParseMsgText=DuplicateQuote1(lsParseMsgText);
        		lsParseMsgContent=(String)hParseResult.get(FIELD_MSG_CONTENT);
        		lsParseMsgContent=DuplicateQuote1(lsParseMsgContent);
        		
        		//logDebug("Hunter0604 commitParseResult: lsMsgText["+lsMsgText+"]");
	        	
	        	lsSql="update GTDPEND1..SI_MSG set MSG_CONTENT='" + lsParseMsgContent +"', MSG_TEXT='" +lsParseMsgText+"', MSG_DISPLAY_CONTENT='" +lsParseMsgText+ "' "
	        			+ "where PROC_UNIT='"+lsParseProcUnit+"' "
	        			+ "and QUEUE_TYP='"+lsParseQueueTyp+"' "
	        			+ "and QUEUE_ID="+liParseQueueID+" ";
	        	
	        	logDebug("commitParseResult(): SWIFT update GTDPEND1..SI_MSG.MSG_TEXT/MSG_DISPLAY_CONTENT with Translated format");
	        	//conn=getConnection();
	        	stmt = conn.prepareCall(lsSql);
		        lirow=stmt.executeUpdate();
		        //close(conn);
		        logDebug("For lsSql1, rowcount="+lirow);
		        if (lirow!=1){
		        	logDebug("commitParseResult(): Update GTDPEND1..SI_MSG failed. Sql:"+lsSql);
		        	lsExcept="commitParseResult(): Update GTDPEND1..SI_MSG failed";
		        	throw new Exception(lsExcept);
		        }
		        
		        //lsSql="update GTDPEND1..SI_MSG_Q set MSG_CONTENT='" +lsMsgText+"' "
    			//+ "where INTF_PROC_UNIT='"+lsProcUnit+"' "
    			//+ "and QUEUE_TYP='"+lsQueueTyp+"' "
    			//+ "and QUEUE_ID="+liQueueID+" ";
		        //    			
		        //logDebug("commitParseResult(): update GTDPEND1..SI_MSG_Q.MSG_CONTENT with Translated format");
				//conn=getConnection();
		        //stmt = conn.prepareCall(lsSql);
		        //lirow=stmt.executeUpdate();
		        //close(conn);
		        //logDebug("For lsSql2, rowcount="+lirow);
		        //if (lirow!=1){
		        //	logDebug("commitParseResult(): Update GTDPEND1..SI_MSG_Q failed. sql:"+lsSql);
		        //	lsExcept="commitParseResult(): Update GTDPEND1..SI_MSG_Q failed";
		        //	throw new Exception(lsExcept);
		        //}
        	}else if (lsParseQueueTyp.trim().equals(QUEUE_TYP_GTI)){
	        	
        		if (! lsRepairInd.trim().equals("Y")){
	        		logDebug("commitParseResult(): Queue Type GTI, Update SI_MSG.MSG_TEXT/MSG_DISPLAY_CONTENT with Application Print");
		        	
	        		lsParseMsgText=(String)hParseResult.get(FIELD_MSG_TEXT);
	        		lsParseMsgText=DuplicateQuote1(lsParseMsgText);
	        		
	        		//logDebug("Hunter0604 commitParseResult: lsMsgText["+lsMsgText+"]");
		        	
		        	lsSql="update GTDPEND1..SI_MSG set MSG_TEXT='" +lsParseMsgText+"', MSG_DISPLAY_CONTENT='" +lsParseMsgText+ "' "
		        			+ "where PROC_UNIT='"+lsParseProcUnit+"' "
		        			+ "and QUEUE_TYP='"+lsParseQueueTyp+"' "
		        			+ "and QUEUE_ID="+liParseQueueID+" ";
		        	
		        	logDebug("ccommitParseResult(): GTI update GTDPEND1..SI_MSG.MSG_TEXT/MSG_DISPLAY_CONTENT with Application Print");
		        	//conn=getConnection();
		        	stmt = conn.prepareCall(lsSql);
			        lirow=stmt.executeUpdate();
			        //close(conn);
			        logDebug("For lsSql1, rowcount="+lirow);
			        if (lirow!=1){
			        	lsExcept="commitParseResult(): Update GTDPEND1..SI_MSG failed. Sql:"+lsSql;
			        	logDebug(lsExcept);
			        	throw new Exception(lsExcept);
			        }
			        
			        //Move RestoreNonASCII logic from Webservice GTSXmlMsgProcessor.java to IMParseMappingExtractor.java - Start
			        String lsRestoredMsgContent=(String)hParseResult.get(FIELD_MSG_CONTENT);
			        lsRestoredMsgContent=DuplicateQuote1(lsRestoredMsgContent);
	        		
	        		lsSql="update GTDPEND1..SI_MSG set MSG_CONTENT='" +lsRestoredMsgContent+"', MSG_SYS_CONTENT='" +lsRestoredMsgContent+ "' "
		        			+ "where PROC_UNIT='"+lsParseProcUnit+"' "
		        			+ "and QUEUE_TYP='"+lsParseQueueTyp+"' "
		        			+ "and QUEUE_ID="+liParseQueueID+" ";
		        	
		        	logDebug("ccommitParseResult(): GTI update GTDPEND1..SI_MSG.MSG_CONTENT/MSG_SYS_CONTENT with Restored Message Content");
		        	stmt = conn.prepareCall(lsSql);
			        lirow=stmt.executeUpdate();
			        logDebug("For lsSql1, rowcount="+lirow);
			        if (lirow!=1){
			        	lsExcept="commitParseResult(): Update GTDPEND1..SI_MSG failed. Sql:"+lsSql;
			        	logDebug(lsExcept);
			        	throw new Exception(lsExcept);
			        }
			        //Move RestoreNonASCII logic from Webservice GTSXmlMsgProcessor.java to IMParseMappingExtractor.java - End
			        
			        logDebug("commitParseResult(): get APPL_PRNT_PDF");
			        ByteArrayOutputStream applPrntPdfOut = (ByteArrayOutputStream)hParseResult.get(FIELD_APPL_PRNT_PDF);
			        
			        //conn=getConnection();
			        lsSql = "DELETE GTDPEND1..APPL_PRNT "+
						"where PROC_UNIT=? and QUEUE_TYP=? and QUEUE_ID=?";
						
					stmt = conn.prepareCall(lsSql);
						
					stmt.setString(1, lsParseProcUnit);
				    stmt.setString(2, lsParseQueueTyp);
					stmt.setInt(3, liParseQueueID);
						
					logDebug("#####DELETE from GTDPEND1..APPL_PRNT");
					stmt.execute();
					logDebug("#####After DELETE from GTDPEND1..APPL_PRNT");
						
				    lsSql = "INSERT INTO GTDPEND1..APPL_PRNT SELECT "+
				    	" PROC_UNIT		=PROC_UNIT,"+	
				    	" QUEUE_TYP		=?,"+	// 1
				    	" QUEUE_ID		=?,"+	// 2
				    	" IMG_TYP		=?,"+	// 3
				    	" MESSAGE_IMG	=?,"+	// 4
				    	" MESSAGE_TEXT	=?,"+	// 5
				    	" ACTION_CD		=?,"+	// 6
				    	" PROC_DT		=THIS_PROC_DT,"+
				    	" GMT_DT		=getdate(),"+
				    	" AUD_ID		=?"	    // 7
				    + " from GTDMAST1..PROC_UNIT where PROC_UNIT=?"; //8
						
				    stmt = conn.prepareCall(lsSql);
				    	
				    stmt.setString(1, lsParseQueueTyp);
					stmt.setInt(2, liParseQueueID);
				    stmt.setString(3, "PDF");
					stmt.setBytes(4, applPrntPdfOut.toByteArray());
					stmt.setString(5, lsParseMsgText);
				    stmt.setString(6, "I");
				    stmt.setLong(7, liParseAudID);
				    stmt.setString(8, lsParseProcUnit);
				    	
					logDebug("#####INSERT Data into GTDPEND1..APPL_PRNT");
					logDebug("Hunter0628: stmt.toString():"+stmt.toString());
					stmt.execute();
					logDebug("#####After INSERT Data into GTDPEND1..APPL_PRNT");
						
					//close(conn);
        		}else
        			logDebug("commitParseResult(): Queue Type GTI with REPAIR_IND=Y, Skip update APPL_PRNT ");
        		
        	}else{
        		logDebug("commitParseResult(): Queue Type Not SWIFT/GTI, Do Not Update SI_MSG.MSG_TEXT");
        	}
        	
        	
        	String sCompleteParentProcess=(String)hParentResult.get(FIELD_COMPLETE_PARENT_PROCESS);
        	logDebug("commitParentResult: sCompleteParentProcess["+sCompleteParentProcess+"]");
        	
        	if(sCompleteParentProcess.trim().equals("Y")){
        		logDebug("commitResult(): Begin Commit Parent Result");
        		
	        	String lsParentProcUnit=(String)hParentResult.get(FIELD_PROC_UNIT);
				String lsParentQueueTyp=(String)hParentResult.get(FIELD_QUEUE_TYP);
				Integer liParentQueueID=(Integer)hParentResult.get(FIELD_QUEUE_ID);
				String lsParentMsgTyp=(String)hParentResult.get(FIELD_MSG_TYP);
				String lsParentApplMsgRef=(String)hParentResult.get(FIELD_APPL_MSG_REF);
				
				//String sNeedTransformSysFmt=(String)hParentResult.get(FIELD_NEED_TRANSFORM_SYSFMT);
				//String sTransformSysFmtSuccess=(String)hParentResult.get(FIELD_TRANSFORM_SYSFMT_SUCCESS);
				String lsParentOFACInd=(String)hParentResult.get(FIELD_OFAC_IND);
				String lsParentActionTyp=(String)hParentResult.get(FIELD_ACTION_TYP);
				Long liParentAudID=(Long)hParentResult.get(FIELD_AUD_ID);
				String lsParentProcessorID=(String)hParentResult.get(FIELD_PROCESSOR_ID);
				Timestamp ltParentBatchID=(Timestamp)hParentResult.get(FIELD_BATCH_ID);
				
				if(lsParentQueueTyp.trim().equals(QUEUE_TYP_SWIFT)){
					logDebug("commitParentResult: QUEUE_TYP is SWIFT. Update SI_MSG.MSG_SYS_CONTENT with System Format");
					
					String lsParentGtlMsg=(String)hParentResult.get(FIELD_MSG_TEXT);
					lsParentGtlMsg=DuplicateQuote1(lsParentGtlMsg);
					
					//int status;
					lsSql="update GTDPEND1..SI_MSG ";
					lsSql += "set MSG_SYS_CONTENT = '";
			        lsSql += lsParentGtlMsg;
			        /* GWF: Skip update SI_MSG_Q.MSG_CONTENT
			        if (sQueueTyp == "SWF")
					{
						Sql += "\", MSG_CONTENT = \"";
						Sql += sMsgContent;
					}
					*/
			        lsSql += "', GMT_DT=getdate(), AUD_ID="+liParentAudID+" where PROC_UNIT = '";
			        lsSql += lsParentProcUnit;
			        lsSql += "' and QUEUE_TYP = '";
			        lsSql += lsParentQueueTyp;
			        lsSql += "' and QUEUE_ID = ";
			        lsSql += liParentQueueID;
			        
			        logDebug("commitParentResult(): Update GTDPEND1..SI_MSG.MSG_SYS_CONTENT with System Format");
			        //conn=getConnection();
			        stmt = conn.prepareCall(lsSql);
			        lirow=stmt.executeUpdate();
			        //close(conn);
			        logDebug("rowcount="+lirow);
			        if (lirow!=1){
			        	lsExcept="commitParentResult(): Update GTDPEND1..SI_MSG.MSG_SYS_CONTENT failed. Sql:"+lsSql;
			        	logDebug(lsExcept);
			        	throw new Exception(lsExcept);
			        }

			        logDebug("commitParentResult(): P2T of SI_MSG");
			        lsSql="insert GTDTRAN1..SI_MSG select * from GTDPEND1..SI_MSG";
					lsSql += " where PROC_UNIT = '";
			        lsSql += lsParentProcUnit;
			        lsSql += "' and QUEUE_TYP = '";
			        lsSql += lsParentQueueTyp;
			        lsSql += "' and QUEUE_ID = ";
			        lsSql += liParentQueueID;
			        
			        stmt = conn.prepareCall(lsSql);
			        lirow=stmt.executeUpdate();
			        logDebug("rowcount="+lirow);
			        
				}else{
					logDebug("commitParentResult: QUEUE_TYP is Not SWIFT. Do Not Update SI_MSG.MSG_SYS_CONTENT");
				}

        	}else
        		logDebug("commitResult(): Do not Commit Parent Result");
        	
        	
        	String p1=(String)hParseResult.get(FIELD_PROC_UNIT);
	        String p2=(String)hParseResult.get(FIELD_QUEUE_TYP);
	        Integer p3=(Integer)hParseResult.get(FIELD_QUEUE_ID);
	        String p4=(String)hParseResult.get(FIELD_MSG_TYP);
	        String p5=(String)hParseResult.get(FIELD_APPL_MSG_REF);
	        String p6=(String)hParseResult.get(FIELD_LNK_REF);
	        Integer p7=(Integer)hParseResult.get(FIELD_LNK_MSG_SEQ);
	        Integer p8=(Integer)hParseResult.get(FIELD_LNK_MSG_TOTAL);
	        String p9=(String)hParseResult.get(FIELD_EXT_MSG_REF);
	        String p10=(String)hParseResult.get(FIELD_REPAIR_IND);
	        String p11=(String)hParseResult.get(FIELD_DUPLICATE_IND);
	        String p12=(String)hParseResult.get(FIELD_NEED_GROUPING);
	        String p13=(String)hParseResult.get(FIELD_GROUP_COMPLETE);
	        Integer p14=(Integer)hParseResult.get(FIELD_PARENT_QUEUE_ID);
	        String p15=(String)hParseResult.get(FIELD_ROUTE_PROD_TYP);
            String p16=(String)hParseResult.get(FIELD_ROUTE_LOCATION_CD);
            String p17=(String)hParseResult.get(FIELD_ROUTE_EXT_REF_NBR);
            String p18=(String)hParseResult.get(FIELD_CUST_NM);
            String p19=(String)hParseResult.get(FIELD_MSG_CCY_CD);
            String p20=(String)hParseResult.get(FIELD_MSG_AMT);
            Long p21=(Long)hParseResult.get(FIELD_AUD_ID);
            
            String p22=(String)hParentResult.get(FIELD_COMPLETE_PARENT_PROCESS);
            String p23=(String)hParentResult.get(FIELD_MSG_TYP);
            String p24=(String)hParentResult.get(FIELD_APPL_MSG_REF);
            String p25=(String)hParentResult.get(FIELD_ACTION_TYP);
            String p26=(String)hParentResult.get(FIELD_OFAC_IND);
            String p27=(String)hParentResult.get(FIELD_PROCESSOR_ID);
            Timestamp p28=(Timestamp)hParentResult.get(FIELD_BATCH_ID);
            
            logDebug("USP_IMPARSE_COMMIT_RESULT: @PROC_UNIT                  ["+ p1   + "]");
            logDebug("USP_IMPARSE_COMMIT_RESULT: @QUEUE_TYP                  ["+ p2   + "]");
            logDebug("USP_IMPARSE_COMMIT_RESULT: @QUEUE_ID                   ["+ p3   + "]");
            logDebug("USP_IMPARSE_COMMIT_RESULT: @MSG_TYP                    ["+ p4   + "]");
            logDebug("USP_IMPARSE_COMMIT_RESULT: @APPL_MSG_REF               ["+ p5   + "]");
            logDebug("USP_IMPARSE_COMMIT_RESULT: @LNK_REF                    ["+ p6   + "]");
            logDebug("USP_IMPARSE_COMMIT_RESULT: @LNK_MSG_SEQ                ["+ p7   + "]");
            logDebug("USP_IMPARSE_COMMIT_RESULT: @LNK_MSG_TOTAL              ["+ p8   + "]");
            logDebug("USP_IMPARSE_COMMIT_RESULT: @EXT_MSG_REF                ["+ p9   + "]");
            logDebug("USP_IMPARSE_COMMIT_RESULT: @REPAIR_IND                 ["+ p10  + "]");
            logDebug("USP_IMPARSE_COMMIT_RESULT: @DUPLICATE_IND              ["+ p11  + "]");
            logDebug("USP_IMPARSE_COMMIT_RESULT: @NEED_GROUPING              ["+ p12  + "]");
            logDebug("USP_IMPARSE_COMMIT_RESULT: @GROUP_COMPLETE             ["+ p13  + "]");
            logDebug("USP_IMPARSE_COMMIT_RESULT: @PARENT_QUEUE_ID            ["+ p14  + "]");
            logDebug("USP_IMPARSE_COMMIT_RESULT: @ROUTE_PROD_TYP             ["+ p15  + "]");
            logDebug("USP_IMPARSE_COMMIT_RESULT: @ROUTE_LOCATION_CD          ["+ p16  + "]");
            logDebug("USP_IMPARSE_COMMIT_RESULT: @ROUTE_EXT_REF_NBR          ["+ p17  + "]");
            logDebug("USP_IMPARSE_COMMIT_RESULT: @CUST_NM                    ["+ p18  + "]");
            logDebug("USP_IMPARSE_COMMIT_RESULT: @MSG_CCY_CD                 ["+ p19  + "]");
            logDebug("USP_IMPARSE_COMMIT_RESULT: @MSG_AMT                    ["+ p20  + "]");
            logDebug("USP_IMPARSE_COMMIT_RESULT: @AUD_ID                     ["+ p21  + "]");
            logDebug("USP_IMPARSE_COMMIT_RESULT: @COMPLETE_PARENT_PROCESS    ["+ p22  + "]");
            logDebug("USP_IMPARSE_COMMIT_RESULT: @PARENT_MSG_TYP             ["+ p23  + "]");
            logDebug("USP_IMPARSE_COMMIT_RESULT: @PARENT_APPL_MSG_REF        ["+ p24  + "]");
            logDebug("USP_IMPARSE_COMMIT_RESULT: @ACTION_TYP                 ["+ p25  + "]");
            logDebug("USP_IMPARSE_COMMIT_RESULT: @OFAC_IND                   ["+ p26  + "]");
            logDebug("USP_IMPARSE_COMMIT_RESULT: @PROCESSOR_ID               ["+ p27  + "]");
            logDebug("USP_IMPARSE_COMMIT_RESULT: @BATCH_ID                   ["+ p28  + "]");
            
			//conn=getConnection();
			lStmtCommitResult = conn.prepareCall(_sCommitResult);
			
			lStmtCommitResult.registerOutParameter(1,Types.INTEGER);
			lStmtCommitResult.setString(2, p1);
			lStmtCommitResult.setString(3, p2);
			lStmtCommitResult.setInt(4, p3.intValue());
			lStmtCommitResult.setString(5, p4);
			lStmtCommitResult.setString(6, p5);
			lStmtCommitResult.setString(7, p6);
			lStmtCommitResult.setInt(8, p7.intValue());
			lStmtCommitResult.setInt(9, p8.intValue());
			lStmtCommitResult.setString(10, p9);
			lStmtCommitResult.setString(11, p10);
			lStmtCommitResult.setString(12, p11);
			lStmtCommitResult.setString(13, p12);
			lStmtCommitResult.setString(14, p13);
			lStmtCommitResult.setInt(15, p14.intValue());
			lStmtCommitResult.setString(16, p15);
			lStmtCommitResult.setString(17, p16);
			lStmtCommitResult.setString(18, p17);
			lStmtCommitResult.setString(19, p18);
			lStmtCommitResult.setString(20, p19);
			lStmtCommitResult.setString(21, p20);
			lStmtCommitResult.setLong(22, p21.longValue());
			lStmtCommitResult.setString(23, p22);
			lStmtCommitResult.setString(24, p23);
			lStmtCommitResult.setString(25, p24);
			lStmtCommitResult.setString(26, p25);
			lStmtCommitResult.setString(27, p26);
			lStmtCommitResult.setString(28, p27);
			lStmtCommitResult.setTimestamp(29, p28);

			lStmtCommitResult.execute();
	        
	        logDebug("commitResult(): USP_IMPARSE_COMMIT_RESULT Success");
	        
	        int dbRtnCode   = lStmtCommitResult.getInt(1);
	        
            logDebug("commitResult(): dbRtnCode["+dbRtnCode+"]");
            
            if(dbRtnCode!=0){
            	lsExcept="commitResult(): Update GTDPEND1..USP_IMPARSE_COMMIT_RESULT failed";
	        	logDebug(lsExcept);
	        	throw new Exception(lsExcept);
            }
        }
        catch (Exception ex) {
            logDebug((Throwable) ex);
		    logDebug("IMParseMappingExtractor.commitResult: "+ex.getMessage());
			throw new Exception(ex.getMessage());
        }finally{
	    	if (stmt != null) {
				try{
					stmt.close();
				} catch (SQLException e) {
					com.chase.infra.util.LogWrapper.instance.logDebug("IMParseMappingExtractor.commitResult failed to close PreparedStatement");
					e.printStackTrace();
				}
			}
	    	if (lStmtCommitResult != null){
	    		try{
	    			lStmtCommitResult.close();
				} catch (SQLException e) {
					com.chase.infra.util.LogWrapper.instance.logDebug("IMParseMappingExtractor.commitResult failed to close PreparedStatement");
					e.printStackTrace();
				}
	    	}
	    }

	}
	
	private void commitSiMsgQ_P2T(String sProcUnit, String sQueueTyp, int iParentQueueID, long iAudID) throws Exception {
		
		//IDataConnection  conn = null;
        try {
        	Hashtable params = new Hashtable();
	        params.put(FIELD_PROC_UNIT, sProcUnit);
	        params.put(FIELD_QUEUE_TYP, sQueueTyp);
	        params.put(FIELD_PARENT_QUEUE_ID, new Integer(iParentQueueID));
	        params.put(FIELD_AUD_ID, new Long(iAudID));
	             
	        //logDebug("commitParseResult() sql : "+_sCommitParseSWF+" ("+p1+"|"+p2+"|"+ p3+"|"+p4+"|"+ p5+"|"+p6+"|"+p7+"|"+p8+"|"+p9+"|"+p10+"|"+p11+"|"+p12+"|"+p13+")");
	        logDebug("commitSiMsgQ_P2T() sql : "+_sCommitSiMsgQ_P2T+" ("+sProcUnit+"|"+sQueueTyp+"|"+ iParentQueueID+"|"+iAudID+")");
	        
	        //conn=getConnection();
	        conn.executeUpdate(_sCommitSiMsgQ_P2T, params);
	        //close(conn);
        	
        }
        catch (Exception ex) {
            logDebug((Throwable) ex);
		    logDebug("IMParseMappingExtractor.commitSiMsgQ_P2T: "+ex.getMessage());
			throw new Exception(ex.getMessage());
        }
        finally {
            //close(conn);
        }

	}
	
	//	(for MT940 and MT950): Allow continual parsing of the remaining message
	private String GetRepeatTok(DataTable dtMsgContent, String sTok, int counter)
	{
	        //CString sTok = CString(Tok);
	        String sNxtTok = "";
	        return GetRepeatTok(dtMsgContent, sTok, counter, sNxtTok);
	}

	private String GetRepeatTok(DataTable dtMsgContent, String Tok, int counter, String NxtTok)
	{
	        String sMsg = "";
	        String sRetMsg = "";
	        String sTempMsg = "";
	        
			logDebug("START OF GetRepeatTok LOOP!!! counter = " + counter);

			/*
	        int ArraySz = MsgArray.GetSize();

	        for (int incr = 0; incr < ArraySz; incr++)
			{
	                sTempMsg = *((CString *) MsgArray[incr]);
	                sMsg = sMsg + sTempMsg;
			}        
			*/
			dtMsgContent.BOF();
			while(dtMsgContent.next()){
				sMsg=sMsg+(String)dtMsgContent.getField(FIELD_MSG_CONTENT);
			}
			
			sRetMsg = GetRepeatTok(Tok, counter, sMsg, NxtTok);

			logDebug("END OF GetRepeatTok LOOP!!! return sRetMsg = " + sRetMsg);
	        return sRetMsg;
	}



	private String GetRepeatTok(String sTok, int counter, String sMsg, String sNxtTok) 
	{
	        int posBegin=0, posEnd=0, tempcounter=0;
	        //CString sTok = CString(Tok);
	        //CString sNxtTok = CString(NxtTok);
	        String sRetMsg = "";
	        String sTempMsg = "";
	        String sTmpTag = "";

	    for (tempcounter = 1; tempcounter<=counter; tempcounter++)
		{
			logDebug("Counter = " +counter + ", tempcounter = " + tempcounter);
			logDebug("sMsg length = " + sMsg.length());
			posBegin = sMsg.indexOf(sTok);

			if (tempcounter == counter) {
				if (posBegin >= 0) {
					logDebug(" posBegin = " + posBegin );
					/*
					for (posEnd = posBegin+sTok.length(); posEnd <= sMsg.length(); posEnd++) {
			            if (( sMsg[posEnd] == ':' ) & ( sMsg[posEnd - 1] == '\n' )) {
							if (sNxtTok.GetLength() != 0) {
				                        	if (sMsg.Mid(posEnd-2, sNxtTok.GetLength()).Compare(sNxtTok) == 0) {
				                        		sTempMsg = "";
									cout << "NextTokMsg = " << sMsg.Mid(posEnd-2, sMsg.GetLength()) << endl;
									sRetMsg = GetRepeatTok(sNxtTok, 1, sMsg.Mid(posEnd-2, sMsg.GetLength()), sTempMsg);
								} else {
									sRetMsg = "";
								}
							} else {	
								cout << ":\n posEnd = " << posEnd << endl;
								sRetMsg = sMsg.Mid(posBegin+sTok.GetLength(), posEnd - (posBegin+sTok.GetLength()+1));
							}
			                                break;
						} else if   ((sMsg[posEnd] == '-' ) & ( sMsg[posEnd + 1] == '}' )) {
							if (sNxtTok.GetLength() != 0) {
								cout << "~} Empty Value " << posEnd << endl;
								sRetMsg = "";
							} else {
								cout << "~} posEnd = " << posEnd << endl;
								sRetMsg = sMsg.Mid(posBegin+sTok.GetLength(), posEnd - (posBegin+sTok.GetLength()+1));
							}
						}
			        }
			        */
					//sMsg=sMsg.substring(sTok.length());
					sMsg=Mid(sMsg, posBegin+sTok.length());
					
					posEnd=sMsg.indexOf(TAGDELI);	//find next \n:
					if(posEnd >= 0){
						posEnd=posEnd+1;			//posEnd is index of ":"
						if(sNxtTok.length()!=0){
							//sTmpTag=sMsg.substring(posEnd-2, posEnd-2+sNxtTok.length());
							sTmpTag=Mid(sMsg, posEnd-2, posEnd-2+sNxtTok.length());
							logDebug("sTmpTag:"+sTmpTag);
							if(sTmpTag.equals(sNxtTok)){
								sTempMsg="";
								//logDebug("NextTokMsg = " + sMsg.substring(posEnd-2));
								logDebug("NextTokMsg = " + Mid(sMsg,posEnd-2));
								//sRetMsg = GetRepeatTok(sNxtTok, 1, sMsg.substring(posEnd-2), sTempMsg);
								sRetMsg = GetRepeatTok(sNxtTok, 1, Mid(sMsg,posEnd-2), sTempMsg);
							}else{
								logDebug("Next tag after "+sTok+" is not "+sNxtTok);
								sRetMsg = "";
							}
						}else{
							logDebug(":\n posEnd = " + posEnd);
							sRetMsg = Left(sMsg, posEnd);	//substring before next :Tag:
						}
					}else{
						posEnd=sMsg.indexOf(SWIFTEND);
						if(posEnd >= 0){
							if (sNxtTok.length() != 0) {
								logDebug("~} Empty Value "+ posEnd);	//search to -} but cannot get sNxtTok
								sRetMsg = "";
							} else {
								logDebug("~} posEnd = " + posEnd);
								sRetMsg = Left(sMsg, posEnd);
							}
						}else{
							logDebug("Cannot search for \\n: and -}");
						}
					}
				} else {	//tempcounter == counter but cannot search sTok
					logDebug(" final do nothing " + posBegin );
				}
			} else {	//tempcounter != counter
				if (posBegin >= 0) {
					logDebug(" tempcounter != counter, posBegin = " + posBegin);
//					sTempMsg = sMsg.Mid(posBegin+sTok.GetLength(), sMsg.GetLength()-(posBegin+sTok.GetLength()+1));
					//sTempMsg = sMsg.Mid(posBegin+sTok.GetLength(), sMsg.GetLength());
					//sTempMsg = sMsg.substring(posBegin+sTok.length());
					sTempMsg = Mid(sMsg,posBegin+sTok.length());
					logDebug("sTempMsg = " + sTempMsg.length());
					sMsg = sTempMsg;
				} else {
					logDebug(" tempcounter != counter, break! ");
					break;	
				}
			}		
					
	    }
	    //logDebug("End of GetRepeatTok. sRetMsg:"+sRetMsg);
	    return sRetMsg;
	}

//	MT940/950: for the matched transaction, create a new entry with NewQueueId and NewAudId
	private boolean Insert_SI_MSG(Hashtable hEntryResult)	{	
//	RM
		logDebug("Entering Insert_SI_MSG()...");
	    int     status;
	    //IDataConnection  conn = null;
		CallableStatement stmt = null;
		DataTable dt;
		int lirow;
	    try{
			String sProcUnit=(String)hEntryResult.get(FIELD_PROC_UNIT);
			String sQueueTyp=(String)hEntryResult.get(FIELD_QUEUE_TYP);
			String sMsgTyp=(String)hEntryResult.get(FIELD_MSG_TYP);
			int sNewQueueId=Integer.parseInt(hEntryResult.get(FIELD_NEW_QUEUE_ID).toString());
			String sOrigRefNbr=(String)hEntryResult.get(FIELD_ORIG_REF_NBR);
			String sProdCat=(String)hEntryResult.get(FIELD_PROD_CAT);
			String sProdType=(String)hEntryResult.get(FIELD_PROD_TYP);
			String sTranType=(String)hEntryResult.get(FIELD_TRAN_TYP);
			String sGtlMsg1=(String)hEntryResult.get(FIELD_GTL_MSG_1);
			String sGtlMsg2=(String)hEntryResult.get(FIELD_GTL_MSG_2);
			String sOpTeamCd=(String)hEntryResult.get(FIELD_OP_TEAM_CD);
			String sProcDt=(String)hEntryResult.get(FIELD_PROC_DT);
			long sNewAudId=Long.parseLong(hEntryResult.get(FIELD_AUD_ID).toString());
			Timestamp sRecvDt=(Timestamp)hEntryResult.get(FIELD_RECV_DT);
			String sExtRefNbr=(String)hEntryResult.get(FIELD_EXT_REF_NBR);
			String sSendRecvAddr=(String)hEntryResult.get(FIELD_SEND_RECV_ADDR);
			String sApplMsgRef=(String)hEntryResult.get(FIELD_APPL_MSG_REF);

			int sQueueId=Integer.parseInt(hEntryResult.get(FIELD_QUEUE_ID).toString());
			String sMsgHeader=(String)hEntryResult.get(FIELD_MSG_HEADER);
			String sCurCd=(String)hEntryResult.get(FIELD_CUR_CD);
			String sMsgAmt=(String)hEntryResult.get(FIELD_MSG_AMT);
			String sExtMsgRef=(String)hEntryResult.get(FIELD_EXT_MSG_REF);
			
			String sHead = "{4:\r\n";
			String sTail = "-}\n";
			String sTempMsgContent = sHead + sGtlMsg2 + sTail;
	
			String sDummy = "\r\n\n";
			String sTempMsgText = "PARENT QUEUE ID:: ";
			sTempMsgText = sTempMsgText + sQueueId;
			sTempMsgText += sDummy;
			sTempMsgText = sTempMsgText + sGtlMsg1 + sGtlMsg2;
			String sTempGtlMsg = sGtlMsg1 + sGtlMsg2;
	
			//Insert into GTDPEND1..SI_MSG
			String Sql  = "insert GTDPEND1..SI_MSG (PROC_UNIT, QUEUE_TYP, QUEUE_ID, LNK_REF, LNK_MSG_SEQ, LNK_MSG_TOTAL, ";
			Sql += "MSG_CCY_CD, MSG_AMT, SEND_RECV_ADDR, EXT_MSG_REF, APPL_MSG_REF, CMNT, MSG_TYP, PTM_IND, ";
			Sql += "MSG_HEADER, MSG_TRAILER, MSG_CONTENT, MSG_TEXT,	MSG_DISPLAY_CONTENT, MSG_SYS_CONTENT,PROC_DT, GMT_DT, AUD_ID) values ('";
			Sql += sProcUnit;
			Sql += "', 'SWF', ";
			Sql += sNewQueueId;
			Sql += ", '";
			Sql += sOrigRefNbr;
			Sql += "', 1, 1, '";
			Sql += sCurCd;
			Sql += "', ";
			Sql += sMsgAmt;
			Sql += ", '";
			Sql += sSendRecvAddr;	
			Sql += "', '";
			Sql += sExtMsgRef;
			Sql += "', '";
			Sql += sApplMsgRef;
			Sql += "', ' ', '', ' ', '";
			Sql += sMsgHeader;
			Sql += "', ' ', '";
			Sql += sTempMsgContent;
			Sql += "', '";
			Sql += sTempMsgText;
			Sql += "', '";
//			Sql += sTempMsgContent;
			Sql += "', '";
			Sql += sTempGtlMsg;
			Sql += "', '";
			Sql += sProcDt;
			Sql += "', ";
			Sql += "getdate(), ";
			Sql += sNewAudId;
			Sql += ")";
				
				//WriteErrLog("Insert_SI_MSG(): Insert new entry into GTDPEND1..SI_MSG [" + sProcUnit + "] [" + sExtRefNbr + "] [" + sNewQueueId + "]");
				logDebug("Insert_SI_MSG(): Insert new entry into GTDPEND1..SI_MSG. Sql:"+Sql);
		        /*
				SetSql(Sql);
		        ExecSql();
	
		        GetRetStatus(status);
		        TRACE_INT(status, status);
	
		        if (status)
		        {
		                WriteErrLog("Error Inserting GTDPEND1..SI_MSG");
		                return (QS_FAIL);
		        }
		        */
				//conn=getConnection();
		        stmt = conn.prepareCall(Sql);
		        lirow=stmt.executeUpdate();
		        //close(conn);
		        logDebug("rowcount="+lirow);
			
		        if(lirow<=0){
		        	logDebug("Insert GTDPEND1..SI_MSG_Q with zero entry. Return false");
			    	return false;
		        }
		        	
		        
			logDebug("Insert_SI_MSG(): Matched transaction info inserted into P1..SI_MSG.");
	
			//Copy from PEND1 to TRAN1
			Sql  = "insert GTDTRAN1..SI_MSG ";
			//Sql += "select * from GTDPEND1..SI_MSG where PROC_UNIT = '";
			Sql +="select PROC_UNIT ";
			Sql +=",QUEUE_TYP      ";
			Sql +=",QUEUE_ID       ";
			Sql +=",LNK_REF        ";
			Sql +=",LNK_MSG_SEQ    ";
			Sql +=",LNK_MSG_TOTAL  ";
			Sql +=",MSG_CCY_CD     ";
			Sql +=",MSG_AMT        ";
			Sql +=",SEND_RECV_ADDR ";
			Sql +=",EXT_MSG_REF    ";
			Sql +=",APPL_MSG_REF   ";
			Sql +=",CMNT           ";
			Sql +=",MSG_TYP        ";
			Sql +=",PTM_IND        ";
			Sql +=",MSG_HEADER     ";
			Sql +=",MSG_TRAILER    ";
			Sql +=",MSG_CONTENT    ";
			Sql +=",MSG_TEXT       ";
			Sql +=",MSG_DISPLAY_CONTENT    ";
			Sql +=",MSG_SYS_CONTENT       ";
			Sql +=",PROC_DT        ";
			Sql +=",GMT_DT         ";
			Sql +=",AUD_ID         ";
			Sql +="from GTDPEND1..SI_MSG where PROC_UNIT = '";
			Sql += sProcUnit;
			Sql += "' and QUEUE_TYP = '"+sQueueTyp+"' and QUEUE_ID = ";
			Sql += sNewQueueId;
			Sql += " and LNK_MSG_SEQ = 1";
			
			//WriteErrLog("Insert_SI_MSG(): Insert new entry into GTDTRAN1..SI_MSG [" + sProcUnit + "] [" + sExtRefNbr + "] [" + sNewQueueId + "]");
			logDebug("Insert_SI_MSG(): Insert new entry into GTDTRAN1..SI_MSG. Sql:"+Sql);
				/*
				SetSql(Sql);
		        ExecSql();
	
			GetRetStatus(status);
		        TRACE_INT(status, status);
	
		        if (status)
		        {
		                WriteErrLog("Error Inserting GTDTRAN1..SI_MSG");
		                return (QS_FAIL);
		        }
		        */
			//conn=getConnection();
	        stmt = conn.prepareCall(Sql);
	        lirow=stmt.executeUpdate();
	        //close(conn);
	        logDebug("rowcount="+lirow);
	        if(lirow<=0){
	        	logDebug("Insert GTDTRAN1..SI_MSG_Q with zero entry. Return false");
		    	return false;
	        }
		logDebug("Insert_SI_MSG(): Matched transaction info inserted into T1..SI_MSG.");
	
	//	RM 
		logDebug("Leaving Insert_SI_MSG...");
		        //return (QS_SUCCEED);
			return true;
	        
	     }catch (Exception ex) {
	            logDebug((Throwable) ex);
			    logDebug("IMParseMappingExtractor.Insert_SI_MSG: "+ex.getMessage()+". Return false");
				//throw new Exception(ex.getMessage());
			    return false;
	     }finally{
				if (stmt != null) {
					try{
						stmt.close();
					} catch (SQLException e) {
						com.chase.infra.util.LogWrapper.instance.logDebug("IMParseMappingExtractor.Insert_SI_MSG failed to close PreparedStatement");
						e.printStackTrace();
					}
				}
		 }
	}
	
//	MT940/950: for the matched transaction, create a new entry with NewQueueId and NewAudId
	private boolean Insert_SI_MSG_Q(Hashtable hEntryResult)
	{
		logDebug("Entering Insert_SI_MSG_Q()");
		//IDataConnection  conn = null;
		CallableStatement stmt = null;
		DataTable dt;
		try{
			String sProcUnit=(String)hEntryResult.get(FIELD_PROC_UNIT);
			String sQueueTyp=(String)hEntryResult.get(FIELD_QUEUE_TYP);
			String sMsgTyp=(String)hEntryResult.get(FIELD_MSG_TYP);
			int sNewQueueId=Integer.parseInt(hEntryResult.get(FIELD_NEW_QUEUE_ID).toString());
			String sOrigRefNbr=(String)hEntryResult.get(FIELD_ORIG_REF_NBR);
			String sProdCat=(String)hEntryResult.get(FIELD_PROD_CAT);
			String sProdType=(String)hEntryResult.get(FIELD_PROD_TYP);
			String sTranType=(String)hEntryResult.get(FIELD_TRAN_TYP);
			String sGtlMsg1=(String)hEntryResult.get(FIELD_GTL_MSG_1);
			String sGtlMsg2=(String)hEntryResult.get(FIELD_GTL_MSG_2);
			String sOpTeamCd=(String)hEntryResult.get(FIELD_OP_TEAM_CD);
			String sProcDt=(String)hEntryResult.get(FIELD_PROC_DT);
			long sNewAudId=Long.parseLong(hEntryResult.get(FIELD_AUD_ID).toString());
			Timestamp sRecvDt=(Timestamp)hEntryResult.get(FIELD_RECV_DT);
			String sExtRefNbr=(String)hEntryResult.get(FIELD_EXT_REF_NBR);
			String sSendRecvAddr=(String)hEntryResult.get(FIELD_SEND_RECV_ADDR);
			String sApplMsgRef=(String)hEntryResult.get(FIELD_APPL_MSG_REF);
			
			//	RM
		    int status;
		    int lirow;
		    
			String sTempGtlMsg = sGtlMsg1 + sGtlMsg2;
	
			// [GWF]---[20071219]
			//Insert into GTDPEND1..SI_MSG_Q
			String Sql  = "insert GTDPEND1..SI_MSG_Q (INTF_PROC_UNIT, QUEUE_ID, PARENT_QUEUE_ID, QUEUE_STATUS, PREV_QUEUE_STATUS, QUEUE_TYP, ";
			Sql += "TRAN_REF_NBR, TRAN_SEQ_NBR, PT_REF_NBR, EXT_REF, PROD_CAT, PROD_TYP, TRAN_TYP, ";
			Sql += "USER_ID, USER_PROC_UNIT, OP_TEAM_CD, MSG_TYP, ERRMSG_ID, ERR_MSG, TRAIL_CNT, PRINT_CNT, ";
			Sql += "ACTION_CD, PROC_DT, GMT_DT, AUD_ID, RECV_DT, EXT_REF_NBR, SEND_RECV_ADDR, APPL_MSG_REF, COMPLETED_IND, REPAIR_IND, CLONE_QUEUE_ID, DISPLAY_SEQ, ROUTE_PROD_TYP, ROUTE_LOCATION_CD, CUST_NM) values ('";
			Sql += sProcUnit;
			Sql += "', ";
			Sql += sNewQueueId;
			Sql += ", ";
			Sql += sNewQueueId;
			Sql += ", 'A', ' ', 'SWF', ' ', 0, 0, '";
			Sql += sOrigRefNbr;
			Sql += "', '";
			Sql += sProdCat;
			Sql += "', '";
			Sql += sProdType;
			Sql += "', '";
			Sql += sTranType;
			Sql += "', 'gtsopr', '";
			Sql += sProcUnit;
			Sql += "', '";
			Sql += sOpTeamCd;
			Sql += "', '";
			//Sql += sTempGtlMsg;
			//Sql += "', '";
			Sql += sMsgTyp;
			Sql += "', 0, ' ', 0, 0, 'I', '";
			Sql += sProcDt;
			Sql += "', getdate(), ";
			Sql += sNewAudId;
			Sql += ", '";
			Sql += sRecvDt;
			Sql += "', '";
			//Sql += sRecvDt;
			//Sql += "', '";
			Sql += sExtRefNbr;
			Sql += "', '";
			Sql += sSendRecvAddr;
			Sql += "', '";
			Sql += sApplMsgRef;
			//Sql += "', '";
	//		Sql += sTempMsgContent;
			Sql += "', 'Y', 'N', 0, 1, '', '', '')"; //To put parent ROUTE_PROD_TYP, ROUTE_LOCATION_CD
			// [GWF]---[END]
	
		        //WriteErrLog("Insert_SI_MSG_Q(): Insert new entry into GTDPEND1..SI_MSG_Q [" + sProcUnit + "] [" + sExtRefNbr + "] [" + sNewQueueId + "]");
		        logDebug("Insert_SI_MSG_Q(): Insert new entry into GTDPEND1..SI_MSG_Q. Sql:"+Sql);
				/*
		        SetSql(Sql);
		        ExecSql();
				
		        GetRetStatus(status);
		        TRACE_INT(status, status);
	
		        if (status)
		        {
		                WriteErrLog("Error Inserting GTDPEND1..SI_MSG_Q");
		                return (QS_FAIL);
		        }
		        */
		        //conn=getConnection();
		        stmt = conn.prepareCall(Sql);
		        lirow=stmt.executeUpdate();
		        //close(conn);
		        logDebug("rowcount="+lirow);
		    
		    if (lirow<=0){
		    	logDebug("Insert GTDPEND1..SI_MSG_Q with zero entry. Return false");
		    	return false;
		    }
		    	
			logDebug("Insert_SI_MSG_Q(): Matched transaction info inserted into P1..SI_MSG_Q.");
	
		        //Copy from PEND1 to TRAN1
			Sql  = "exec USP_CCPY_SIMSGQP2M '";
			Sql += sProcUnit;
			Sql += "' , "+sNewQueueId + ", '" + sQueueTyp+"'";
			
			
			//WriteErrLog("Insert_SI_MSG_Q(): Insert new entry into GTDTRAN1..SI_MSG_Q [" + sProcUnit + "] [" + sExtRefNbr + "] [" + sNewQueueId + "]");
			logDebug("Insert_SI_MSG_Q(): Insert new entry into GTDTRAN1..SI_MSG_Q. Sql:"+Sql);
		    /*
		        SetSql(Sql);
		        ExecSql();
	
			GetRetStatus(status);
		        TRACE_INT(status, status);
	
		        if (status)
		        {
		                WriteErrLog("Error Inserting GTDTRAN1..SI_MSG_Q");
		                return (QS_FAIL);
		        }
		    */
			//conn=getConnection();
	        /*
			stmt = conn.prepareCall(Sql);
	        lirow=stmt.executeUpdate();
	        //close(conn);
	        logDebug("rowcount="+lirow);
			if (lirow<=0){
				logDebug("Insert GTDTRAN1..SI_MSG_Q with zero entry. Return false");
		    	return false;
			}
			*/
			Sql="{? = call GTDPEND1..USP_CCPY_SIMSGQP2M ?, ?, ?}";
			stmt = conn.prepareCall(Sql);
			stmt.registerOutParameter(1,Types.INTEGER);
			stmt.setString(2, sProcUnit);
			stmt.setInt(3, sNewQueueId);
			stmt.setString(4, sQueueTyp);
			
			stmt.execute();
	        
	        logDebug("Insert_SI_MSG_Q(): USP_CCPY_SIMSGQP2M Success");
	        
	        int dbRtnCode   = stmt.getInt(1);
	        
            logDebug("Insert_SI_MSG_Q(): dbRtnCode["+dbRtnCode+"]");
            
            if(dbRtnCode!=0){
            	logDebug("Insert_SI_MSG_Q(): USP_CCPY_SIMSGQP2M return code["+dbRtnCode+"]");
	        	return false;
            }
			logDebug("Insert_SI_MSG_Q(): Matched transaction info inserted into T1..SI_MSG_Q.");
	
			//	RM
			logDebug("Leaving Insert_SI_MSG_Q()");
		        //return (QS_SUCCEED);
			return true;
	     }catch (Exception ex) {
	            logDebug((Throwable) ex);
			    logDebug("IMParseMappingExtractor.Insert_SI_MSG_Q: "+ex.getMessage()+". Return false");
				//throw new Exception(ex.getMessage());
			    return false;
	     }finally{
				if (stmt != null) {
					try{
						stmt.close();
					} catch (SQLException e) {
						com.chase.infra.util.LogWrapper.instance.logDebug("IMParseMappingExtractor.Insert_SI_MSG_Q failed to close PreparedStatement");
						e.printStackTrace();
					}
				}
		 }
	     
	}
	
	private boolean Insert_AUD_TRAIL(Hashtable hEntryResult)
	{
		//	RM
		logDebug("Entering Insert_AUD_TRAIL()...");
		int	status;
		int lirow;
		//IDataConnection  conn = null;
		CallableStatement stmt = null;
		DataTable dt;
		try{
			String sProcUnit=(String)hEntryResult.get(FIELD_PROC_UNIT);
			long sNewAudId=Long.parseLong(hEntryResult.get(FIELD_AUD_ID).toString());
			int sNewQueueId=Integer.parseInt(hEntryResult.get(FIELD_NEW_QUEUE_ID).toString());
			String sProcDt=(String)hEntryResult.get(FIELD_PROC_DT);
			
			String Sql  = "insert GTDTRAN1..AUD_TRAIL (PROC_UNIT, AUD_ID, TRAN_REF_NBR, TRAN_SEQ_NBR, PT_REF_NBR, ";
			Sql += "QUEUE_TYP, QUEUE_ID, TBL_PROD_TYP, SUPPORT_TBL_KEY, BATCH_REF_NBR, LOG_TYP, LOG_SOURCE, ";
			Sql += "LOG_CD, LOG_STATUS, USER_PROC_UNIT, USER_ID, PROC_DT, GMT_DT) values ('";
			Sql += sProcUnit;
			Sql += "', ";
			Sql += sNewAudId;
			Sql += ", '";
	//		Sql += sTranRefNbr;
			Sql += " ', 0, 0, 'SWF', ";
			Sql += sNewQueueId;
			Sql += ", ' ', ' ', ' ', 'S', 'Q', 'SWFA', 'P', '";
			Sql += sProcUnit;
			Sql += "', 'gtsopr', '";
			Sql += sProcDt;
			Sql += "', getdate())";
	
			logDebug("Insert_AUD_TRAIL(): Insert new entry into GTDTRAN1..AUD_TRAIL. Sql:"+Sql);
		        /*
				SetSql(Sql);
		        ExecSql();
	
		        GetRetStatus(status);
		        TRACE_INT(status, status);
	
		        if (status)
		        {
		                WriteErrLog("Error Inserting GTDTRAN1..AUD_TRAIL");
		                return (QS_FAIL);
		        }
		        */
			//conn=getConnection();
			stmt = conn.prepareCall(Sql);
	        lirow=stmt.executeUpdate();
	        //close(conn);
	        logDebug("rowcount="+lirow);
	    
		    if (lirow<=0){
		    	logDebug("Insert GTDTRAN1..AUD_TRAIL with zero entry. Return false");
		    	return false;
		    }
			
			logDebug("Insert_AUD_TRAIL(): Matched transaction info inserted into AUD_TRAIL.");
	
			//	RM
			logDebug("Leaving Insert_AUD_TRAIL()");
			//return (QS_SUCCEED);
			return true;
		
	     }catch (Exception ex) {
	            logDebug((Throwable) ex);
			    logDebug("IMParseMappingExtractor.Insert_AUD_TRAIL: "+ex.getMessage()+". Return false");
				//throw new Exception(ex.getMessage());
			    return false;
	     }finally{
				if (stmt != null) {
					try{
						stmt.close();
					} catch (SQLException e) {
						com.chase.infra.util.LogWrapper.instance.logDebug("IMParseMappingExtractor.Insert_AUD_TRAIL failed to close PreparedStatement");
						e.printStackTrace();
					}
				}
		 }
	}
	
	
//	MT940/950: for the matched transaction, create a new entry with NewQueueId and NewAudId
	private boolean Insert_WK_AUTO_EC_CANC(Hashtable hEntryResult)
	{
		//	RM
		logDebug("Entering Insert_WK_AUTO_EC_CANC()");
		int	status;
		int lirow;
		//IDataConnection  conn = null;
		CallableStatement stmt = null;
		DataTable dt;
		String Sql;
		
		String sProcUnit=(String)hEntryResult.get(FIELD_PROC_UNIT);
		String sQueueTyp=(String)hEntryResult.get(FIELD_QUEUE_TYP);
		String sMsgTyp=(String)hEntryResult.get(FIELD_MSG_TYP);
		int sNewQueueId=Integer.parseInt(hEntryResult.get(FIELD_NEW_QUEUE_ID).toString());
		String sOrigRefNbr=(String)hEntryResult.get(FIELD_ORIG_REF_NBR);
		String sProdCat=(String)hEntryResult.get(FIELD_PROD_CAT);
		String sProdType=(String)hEntryResult.get(FIELD_PROD_TYP);
		String sTranType=(String)hEntryResult.get(FIELD_TRAN_TYP);
		String sGtlMsg1=(String)hEntryResult.get(FIELD_GTL_MSG_1);
		String sGtlMsg2=(String)hEntryResult.get(FIELD_GTL_MSG_2);
		String sOpTeamCd=(String)hEntryResult.get(FIELD_OP_TEAM_CD);
		String sProcDt=(String)hEntryResult.get(FIELD_PROC_DT);
		long sNewAudId=Long.parseLong(hEntryResult.get(FIELD_AUD_ID).toString());
		String sRecvDt=(String)hEntryResult.get(FIELD_RECV_DT);
		String sExtRefNbr=(String)hEntryResult.get(FIELD_EXT_REF_NBR);
		String sSendRecvAddr=(String)hEntryResult.get(FIELD_SEND_RECV_ADDR);
		String sApplMsgRef=(String)hEntryResult.get(FIELD_APPL_MSG_REF);

		int sQueueId=Integer.parseInt(hEntryResult.get(FIELD_QUEUE_ID).toString());
		String sMsgHeader=(String)hEntryResult.get(FIELD_MSG_HEADER);
		String sCurCd=(String)hEntryResult.get(FIELD_CUR_CD);
		String sMsgAmt=(String)hEntryResult.get(FIELD_MSG_AMT);
		String sExtMsgRef=(String)hEntryResult.get(FIELD_EXT_MSG_REF);
		
		String sTranRefNbr=(String)hEntryResult.get(FIELD_TRAN_REF_NBR);
		int sTranSeqNbr=Integer.parseInt(hEntryResult.get(FIELD_TRAN_SEQ_NBR).toString());
		String sDDANbr=(String)hEntryResult.get(FIELD_DDA_NBR);
		String sNYCrRef=(String)hEntryResult.get(FIELD_NY_CR_REF);
		String sValDt=(String)hEntryResult.get(FIELD_VAL_DT);
		String sItemOs=(String)hEntryResult.get(FIELD_ITEM_OS);
		int sMsgId=Integer.parseInt(hEntryResult.get(FIELD_MSG_ID).toString());
		String sDrCrInd=(String)hEntryResult.get(FIELD_DR_CR_IND);
		String sStmtSeqNbr=(String)hEntryResult.get(FIELD_STMT_SEQ_NBR);
		String sStmtLine=(String)hEntryResult.get(FIELD_STMT_LINE);
		String sInfo2AcctOnr=(String)hEntryResult.get(FIELD_INFO2_ACCT_ONR);
			
		String sTempGtlMsg = sGtlMsg1 + ", " + sGtlMsg2;
		
		try{

			Sql =  "insert GTDPEND1..WK_AUTO_EC_CANC (PROC_UNIT, MSG_TYP, EXT_REF_NBR, TRAN_REF_NBR, TRAN_SEQ_NBR, ";
			Sql += "QUEUE_ID, QUEUE_ID_LAST, STATUS, PROD_CAT, PROD_TYP, TRAN_TYP, MSG_CCY_CD, MSG_AMT, TRAN_AMT, ";
			Sql += "CORR_BK_CHRG, CORR_BK_CHRG_RT, DDA_REF, NY_CR_REF, VAL_DT, LNK_REF, MSG_TEXT, ";
			Sql += "DRAWER_PTY_ID, DRAWER_PTY_NM, PARENT_QUEUE_ID, RECV_DT, PROC_DT, GMT_DT, AUD_ID, NEW_TRAN_SEQ_NBR, ITEM_OS, MESSAGE_ID, DR_CR_IND, ";
			Sql += "STATEMENT_NBR, TAG61, TAG86 ";
			Sql += ") values ('";
			Sql += sProcUnit;
			Sql += "', '";
			Sql += sMsgTyp;
			Sql += "', '";
			Sql += sExtRefNbr;
			Sql += "', '";
			Sql += sTranRefNbr;
			Sql += "', ";
			Sql += sTranSeqNbr;
			Sql += ", ";
			Sql += sNewQueueId;
			Sql += ", ";
			Sql += sNewQueueId;
			Sql += ", 'N', '";
			Sql += sProdCat;
			Sql += "', '";
			Sql += sProdType;
			Sql += "', '";
			Sql += sTranType;
			Sql += "', '";
			Sql += sCurCd;
			Sql += "', ";
			Sql += sMsgAmt;
			Sql += ", 0, 0, 0, '";
			Sql += sDDANbr;
			Sql += "', '";
			Sql += FixQuote1(sNYCrRef);
			Sql += "', '";
			Sql += sValDt;
			Sql += "', '";
			Sql += sOrigRefNbr;
			Sql += "', '";
			Sql += FixQuote1(sTempGtlMsg);
			Sql += "', '', '', ";
			Sql += sQueueId;
			Sql += ", '";
			Sql += sRecvDt;
			Sql += "', '";
			Sql += sProcDt;
			Sql += "', getdate()";
			Sql += ", ";
			Sql += sNewAudId;
			Sql += ",0, '";
			Sql += sItemOs;
			Sql += "', ";
			Sql += sMsgId;
			Sql += ", '";
			Sql += sDrCrInd;
			Sql += "','";
			Sql += FixQuote1(sStmtSeqNbr);
			Sql += "','";
			Sql += FixQuote1(sStmtLine);
			Sql += "','";
			Sql += FixQuote1(sInfo2AcctOnr);
			Sql += "'";
			Sql += ")";
			//WriteErrLog("Insert_WK_AUTO_EC_CANC(): Insert new entry into GTDPEND1..WK_AUTO_EC_CANC [" + sProcUnit + "] [" + sExtRefNbr + "] [" + sNewQueueId + "]");
			logDebug("Insert_WK_AUTO_EC_CANC(): Insert new entry into GTDPEND1..WK_AUTO_EC_CANC. Sql:"+Sql);
			
			/*
			TRY
			{
				SetSql(Sql);
				ExecSql();
			}
			CATCH_ALL(e) 
			*/
			//conn=getConnection();
			stmt = conn.prepareCall(Sql);
	        lirow=stmt.executeUpdate();
	        //close(conn);
	        logDebug("rowcount="+lirow);
	    
		    if (lirow<=0){
		    	logDebug("Insert_WK_AUTO_EC_CANC(): Insert result zero entry");
		    	throw new Exception("Insert_WK_AUTO_EC_CANC(): Insert result zero entry");
		    }
			    
			/*
			GetRetStatus(status);
		        TRACE_INT(status, status);
	
		        if (status)
		        {
		                WriteErrLog("Error Inserting GTDPEND1..WK_AUTO_EC_CANC");
		                return (QS_FAIL);
		        }
		    */
			logDebug("Insert_WK_AUTO_EC_CANC(): Matched transaction info inserted into WK_AUTO_EC_CANC.");
	
			//	RM
			logDebug("Leaving Insert_WK_AUTO_EC_CANC()...");
			//return (QS_SUCCEED);
			return true;
	     }catch (Exception ex) {
	            logDebug((Throwable) ex);
			    logDebug("IMParseMappingExtractor.Insert_WK_AUTO_EC_CANC: "+ex.getMessage()+". Return false");
				
			    try{
				    Sql =  "delete GTDTRAN1..WK_AUTO_EC_CANC ";
					Sql += "from GTDPEND1..WK_AUTO_EC_CANC a join GTDTRAN1..WK_AUTO_EC_CANC b ";
					Sql += "on ";
					Sql += "	a.PROC_UNIT = b.PROC_UNIT ";
					Sql += "	and a.QUEUE_ID = b.QUEUE_ID ";
					Sql += "	and a.PROC_DT = b.PROC_DT ";
					Sql += "where a.PROC_UNIT = '";
					Sql += sProcUnit;
					Sql += "' and a.MSG_TYP = '";
					Sql += sMsgTyp;
					Sql += "' and a.PARENT_QUEUE_ID = ";
					Sql += sQueueId;
					Sql += " and a.DDA_REF = '";
					Sql += sDDANbr;
					Sql += "' ";
					/*
					SetSql(Sql);
					ExecSql();
					*/
					logDebug("Sql:"+Sql);
					//conn=getConnection();
					conn.executeUpdate(Sql);
					//close(conn);
					
					Sql =  "delete GTDPEND1..WK_AUTO_EC_CANC where PROC_UNIT = '";
					Sql += sProcUnit;
					Sql += "' and MSG_TYP = '";
					Sql += sMsgTyp;
					Sql += "' and PARENT_QUEUE_ID = ";
					Sql += sQueueId;
					Sql += " and DDA_REF = '";
					Sql += sDDANbr;
					Sql += "' ";
					/*
					SetSql(Sql);
					ExecSql();
					*/
					logDebug("Sql:"+Sql);
					//conn=getConnection();
					conn.executeUpdate(Sql);
					//close(conn);
			    
			    }catch (Exception ex1) {
			    	logDebug((Throwable) ex);
			    }finally{
			    	//close(conn);
			    }
			    
			    //throw new Exception(ex.getMessage());
			    return false;
	     }finally{
				if (stmt != null) {
					try{
						stmt.close();
					} catch (SQLException e) {
						com.chase.infra.util.LogWrapper.instance.logDebug("IMParseMappingExtractor.commitResult failed to close PreparedStatement");
						e.printStackTrace();
					}
				}
		 }
	}
	
//	MT940/950: for the matched transaction, create a new entry with NewQueueId and NewAudId
	private boolean WK_AUTO_EC_CANC_P2T(Hashtable hEntryResult)
	{
		logDebug("Entering WK_AUTO_EC_CANC_P2T");
		int	status;
		//IDataConnection  conn = null;
		try{
			String sProcUnit=(String)hEntryResult.get(FIELD_PROC_UNIT);
			int sNewQueueId=Integer.parseInt(hEntryResult.get(FIELD_NEW_QUEUE_ID).toString());
			
			String Sql =  "exec GTDPEND1..USP_BAUTOCLOS_MAIN3 '";
			Sql += sProcUnit;
			Sql += "', ";
			Sql += sNewQueueId;
			//WriteErrLog("WK_AUTO_EC_CANC_P2T(): USP_BAUTOCLOS_MAIN3 [" + sProcUnit + "] [" + sNewQueueId + "]");
			logDebug("WK_AUTO_EC_CANC_P2T(): Sql:"+Sql);
		        /*
				SetSql(Sql);
		        ExecSql();
				
			GetRetStatus(status);
		        TRACE_INT(status, status);
	
		        if (status)
		        {
		                WriteErrLog("Error Inserting GTDPEND1..WK_AUTO_EC_CANC_P2T");
		                return (QS_FAIL);
		        }
		        */
			//conn=getConnection();
			//conn.executeUpdate(Sql);
			Sql = "{? = call GTDPEND1..USP_BAUTOCLOS_MAIN3 ?, ?}";
			CallableStatement stmt = conn.prepareCall(Sql);
			stmt.registerOutParameter(1,Types.INTEGER);
			stmt.setString(2, sProcUnit);
			stmt.setInt(3, sNewQueueId);
			
			stmt.execute();
			int dbRtnCode   = stmt.getInt(1);
	        logDebug("WK_AUTO_EC_CANC_P2T(): dbRtnCode["+dbRtnCode+"]");
            
            if(dbRtnCode!=0){
            	logDebug("WK_AUTO_EC_CANC_P2T(): GTDPEND1..USP_BAUTOCLOS_MAIN3 with return code["+dbRtnCode+"]");
	        	return false;
            }
			
			//close(conn);
			
			logDebug("Leaving WK_AUTO_EC_CANC_P2T...");
			//return (QS_SUCCEED);
			return true;
			
	     }catch (Exception ex) {
	            logDebug((Throwable) ex);
			    logDebug("IMParseMappingExtractor.Insert_SI_MSG_Q: "+ex.getMessage()+". Return false");
				//throw new Exception(ex.getMessage());
			    logDebug("Error Inserting GTDPEND1..WK_AUTO_EC_CANC_P2T. Return false");
			    return false;
	     }finally{
	    	 //close(conn);
	     }
	}
	
//	MT940/950: for updating original message status to 'R' with a new ThisAudId (for this action)
//    and put SI_MSG..MSG_CONTENT to SI_MSG_Q..MSG_TEXT (so that it can be viewable in IM button)
	private boolean Update_SI_MSGQ_P2R(Hashtable hParentResult)
	{
/* GWF: Skip generate insert AUD_TRAIL and P2T of SI_MSG_Q (will update in commitParentResult())
		//Get AUD_ID
	Sql  = "USP_CGET_AUDID1 '";
	Sql += sProcUnit;
	Sql += "'";
	WriteErrLog("Exec Sql: [" + Sql + "]");
	SetSql(Sql);
	ExecSql();
	
	if (!GetResult(&pDBRows))
	{
	           WriteErrLog("Update_SI_MSGQ_P2R: Error return from stored proc [" + Sql + "]");
		cout << "Update_SI_MSGQ_P2R: Error return from stored proc USP_CGET_AUDID1" << endl;
		return (QS_FAIL) ;
	}
	
	int rowcount = (pDBRows->GetRowCount());
	if ( rowcount > 0)
	{
		p = pDBRows->GetAttr("AUD_ID");
	   	ASSERT(p != NULL);
	   	if (p != NULL)
	   		p->GetValue(sThisAudId);
	  	}
	
	//Update GTDPEND1..SI_MSG_Q, status change from 'P' to 'R'
	   QS_SMALLINT     status;
	
	   Sql  = "update GTDPEND1..SI_MSG_Q ";
	   Sql += "set QUEUE_STATUS = '";
	Sql += "R";
	Sql += "', EXT_REF = '";
	Sql += sOrigRefNbr;
	Sql += "', USER_ID = '";
	Sql += "gtsopr";
	Sql += "', OP_TEAM_CD = '";
	Sql += sOpTeamCd;
	Sql += "', MSG_TEXT = '";
		Sql += FixQuote(sMsgTxt);
	Sql += "', ACTION_CD = '";
	Sql += "U";
	Sql += "', GMT_DT = getdate()";
	Sql += ", AUD_ID = ";
	Sql += sThisAudId;
	Sql += ", EXT_REF_NBR = '";
	Sql += sDDANbr;
	Sql += "' where INTF_PROC_UNIT = '";
	Sql += sProcUnit;
	Sql += "' and QUEUE_ID = ";
	Sql += sQueueId;
	
	   WriteErrLog("Update_SI_MSGQ_P2R(): Update GTDPEND1..SI_MSG_Q  [" + sProcUnit + "] [" + sQueueId + "] [" + sThisAudId + "]");
	   SetSql(Sql);
	   ExecSql();
	
	   GetRetStatus(status);
	   TRACE_INT(status, status);
	
	   if (status)
	   {
	           WriteErrLog("Update_SI_MSGQ_P2R(): Error Updating GTDPEND1..SI_MSG_Q");
	           return (QS_FAIL);
	   }
	cout << "Update_SI_MSGQ_P2R(): Parent transaction info updated in P1..SI_MSG_Q." << endl;
	
	//Copy from PEND1 to TRAN1
	Sql  = "insert GTDTRAN1..SI_MSG_Q ";
	Sql += "select * from GTDPEND1..SI_MSG_Q where INTF_PROC_UNIT = '";
	Sql += sProcUnit;
	Sql += "' and QUEUE_TYP = 'SWF' and QUEUE_STATUS = 'R' and QUEUE_ID = ";
	Sql += sQueueId;
	
	WriteErrLog("Update_SI_MSGQ_P2R(): Insert new entry into GTDTRAN1..SI_MSG_Q [" + sProcUnit + "] [" + sQueueId + "] [" + sThisAudId + "]");
	   SetSql(Sql);
	   ExecSql();
	
	GetRetStatus(status);
	   TRACE_INT(status, status);
	
	   if (status)
	   {
	           WriteErrLog("Update_SI_MSGQ_P2R(): Error Inserting GTDTRAN1..SI_MSG_Q");
	           return (QS_FAIL);
	   }
	cout << "Update_SI_MSGQ_P2R(): Parent transaction info inserted into T1..SI_MSG_Q." << endl;
	
	//Insert into GTDTRAN1..AUD_TRAIL
	Sql  = "insert GTDTRAN1..AUD_TRAIL (PROC_UNIT ,AUD_ID, TRAN_REF_NBR, TRAN_SEQ_NBR, PT_REF_NBR, ";
	Sql += "QUEUE_TYP, QUEUE_ID, TBL_PROD_TYP, SUPPORT_TBL_KEY, BATCH_REF_NBR, LOG_TYP, LOG_SOURCE, ";
	Sql += "LOG_CD, LOG_STATUS, USER_PROC_UNIT, USER_ID, PROC_DT, GMT_DT) values ('";
	Sql += sProcUnit;
	Sql += "', ";
	Sql += sThisAudId;
	Sql += ", ' ', 0, 0, 'SWF', ";
	Sql += sQueueId;
	Sql += ", ' ', ' ', ' ', 'S', 'Q', 'SWFR', 'P', '";
	Sql += sProcUnit;
	Sql += "', 'gtsopr', '";
	Sql += sProcDt;
	Sql += "', getdate())";
	
	WriteErrLog("Update_SI_MSGQ_P2R(): Insert new entry into GTDTRAN1..AUD_TRAIL [" + sProcUnit + "] [" + sQueueId + "] [" + sThisAudId + "]");
	   SetSql(Sql);
	   ExecSql();
	
	GetRetStatus(status);
	   TRACE_INT(status, status);
	
	   if (status)
	   {
	           WriteErrLog("Update_SI_MSGQ_P2R(): Error Inserting GTDTRAN1..AUD_TRAIL");
	           return (QS_FAIL);
	   }
	cout << "Update_SI_MSGQ_P2R(): Parent status change updated in T1..AUD_TRAIL." << endl;
	
	   return (QS_SUCCEED);
*/
		
		
		//Update GTDPEND1..SI_MSG_Q, status change from 'P' to 'R'
		int	status;
		//IDataConnection  conn = null;
		try{
		   String sProcUnit=(String)hParentResult.get(FIELD_PROC_UNIT);
		   String sQueueTyp=(String)hParentResult.get(FIELD_QUEUE_TYP);
		   int sQueueId=((Integer)hParentResult.get(FIELD_QUEUE_ID)).intValue();
		   
		   String sOpTeamCd=(String)hParentResult.get(FIELD_OP_TEAM_CD);
		   String sOrigRefNbr=(String)hParentResult.get(FIELD_ORIG_REF_NBR);
		   String sDDANbr=(String)hParentResult.get(FIELD_DDA_NBR);
		   
		   String Sql  = "update GTDPEND1..SI_MSG_Q ";
		   Sql += "set QUEUE_STATUS = '";
		Sql += "R";
		Sql += "', PREV_QUEUE_STATUS = case when QUEUE_STATUS = 'R' then PREV_QUEUE_STATUS else QUEUE_STATUS end ";
		Sql += ", EXT_REF = '";
		Sql += sOrigRefNbr;
		Sql += "', USER_ID = '";
		Sql += "gtsopr";
		Sql += "', OP_TEAM_CD = '";
		Sql += sOpTeamCd;
		//GWF: Skip update MSG_TEXT (in commitParentResult())
		//Sql += "', MSG_TEXT = '";
		//	Sql += FixQuote(sMsgTxt);
		Sql += "', ACTION_CD = '";
		Sql += "U";
		Sql += "', GMT_DT = getdate()";
		//GWF: Skip update AUD_ID
		//Sql += ", AUD_ID = ";
		//Sql += sThisAudId;
		Sql += ", EXT_REF_NBR = '";
		Sql += sDDANbr;
		Sql += "' where INTF_PROC_UNIT = '";
		Sql += sProcUnit;
		Sql += "' and QUEUE_TYP = '";
		Sql += sQueueTyp;
		Sql += "' and QUEUE_ID = ";
		Sql += sQueueId;
		
		   //WriteErrLog("Update_SI_MSGQ_P2R(): Update GTDPEND1..SI_MSG_Q  [" + sProcUnit + "] [" + sQueueId + "] [" + sThisAudId + "]");
		   logDebug("Update_SI_MSGQ_P2R(): Update GTDPEND1..SI_MSG_Q. Sql:"+Sql);
		   /*
		   SetSql(Sql);
		   ExecSql();
		   
		   GetRetStatus(status);
		   TRACE_INT(status, status);
		
		   if (status)
		   {
		           WriteErrLog("Update_SI_MSGQ_P2R(): Error Updating GTDPEND1..SI_MSG_Q");
		           return (QS_FAIL);
		   }
		   */
		   //conn=getConnection();
		   //conn.executeUpdate(Sql);
		   CallableStatement stmt = conn.prepareCall(Sql);
		   int lirow=stmt.executeUpdate();
	       logDebug("rowcount="+lirow);
	       if(lirow<=0){
	    	   logDebug("Update GTDPEND1..SI_MSG_Q with zero entry. Return false");
	    	   return false;
	       }		   
		   //close(conn);
		   
		   logDebug("Update_SI_MSGQ_P2R(): Parent transaction info updated in P1..SI_MSG_Q.");
	       
		   return true;
		}catch (Exception ex) {
	            logDebug((Throwable) ex);
			    logDebug("IMParseMappingExtractor.Update_SI_MSGQ_P2R: "+ex.getMessage()+". Return false");
				//throw new Exception(ex.getMessage());
			    logDebug("Error Update_SI_MSGQ_P2R. Return false");
			    return false;
	     }finally{
	    	 //close(conn);
	     }
		
	}
	
//	 -----------------------------------------------------------------------
//	 Func  : FindCustIDFromSwf
//	 Input : Swift Address
//	 Output: CUST_ID if SWIFT address found
//	         Empty String if SWIFT address not found
//	 -----------------------------------------------------------------------
	private String FindCustIdFromSwf(String szSwfAddr, String sProcUnit)	//, CString& szCustID)
	{
		//IDataConnection  conn = null;
		DataTable dt;
		String szCustID="";
	    try{
	    	logDebug("Testing FindCustIdFormSwf ........");
	        /*
			GT_DBRows* pDBRows;
			pDBRows = new GT_DBRows();
			*/
		// GT_Value *pVal;
	        String Sql, tmpAddr, sLobCd;
	        int rowcount;

	        //GetPuConfig(sProcUnit,"SWFMAP_LOB_CD",sLobCd);
	        sLobCd=getPUConfig(sProcUnit,"SWFMAP_LOB_CD");
	        
	        if (szSwfAddr.length() > 8)
	        {
	                //tmpAddr = szSwfAddr.Left(8);
	                //tmpAddr += szSwfAddr.Right(3);
	        	tmpAddr = Left(szSwfAddr, 8);
                //tmpAddr += szSwfAddr.substring(szSwfAddr.length()-3);
	        	tmpAddr += Right(szSwfAddr, 3);
	        }
	        else {
	                tmpAddr = szSwfAddr;
	        }

			logDebug("tmpAddr(1) = " + tmpAddr );
	        // search for CUST_ID with LOB_CD = '06'
		Sql =	"select B.CUST_ID ";
		Sql +=	"from GTDMAST1..SWIFT_ADDR_LOCAL A, GTDMAST1..CUST_LCL B ";
		Sql +=	"where A.PROC_UNIT = '";
		Sql += sProcUnit + "' and A.SWIFT_ADDR = '";
		Sql += tmpAddr + "' and A.STATUS = 'A' ";
		Sql +=	"and A.CUST_ID = B.CUST_ID ";
		Sql +=	"and A.PROC_UNIT = B.PROC_UNIT ";
		Sql +=	"and B.PROC_UNIT = '";
		Sql +=  sProcUnit + "' ";
		
		if ( sLobCd.length() > 0 )
			Sql += " and B.LOB_CD = '06'";
		
		logDebug("Sql(1) = " + Sql);
	    /*
		SetSql(Sql);
		ExecSql();

		if (!GetResult(&pDBRows))
		{
			RELEASE_DBROWS(pDBRows);
			//ThrowQSException(QS_QSERVER_ERROR);
			return (QS_FAIL) ;
		}
		*/
		//conn=getConnection();
		dt=conn.executeQuery(Sql);
		//close(conn);
				
		//rowcount = (pDBRows->GetRowCount());
		rowcount = dt.size();
		if ( rowcount == 1 ) {
			/*
			GetColStr(pDBRows, "CUST_ID", szCustID);
			RELEASE_DBROWS(pDBRows);
	                return QS_TRUE;
	    	*/
			dt.next();
			szCustID=(String)dt.getField("CUST_ID");
			return szCustID;
	    }

	        // remove branch code (last three character) and search again
	        if (tmpAddr.length() > 8) {
			tmpAddr = Left(tmpAddr, 8);
			logDebug("tmpAddr(2) = " + tmpAddr );
			// search for CUST_ID with LOB_CD = '06'
		        Sql =	"select B.CUST_ID ";
		        Sql +="from GTDMAST1..SWIFT_ADDR_LOCAL A, GTDMAST1..CUST_LCL B ";
		        Sql +="where A.PROC_UNIT = '";
		        Sql += sProcUnit + "' and A.SWIFT_ADDR = '";
		        Sql +=tmpAddr + "' and A.STATUS = 'A' ";
		        Sql +="and A.CUST_ID = B.CUST_ID "  ;                  
		        Sql +="and B.PROC_UNIT = '";
		        Sql += sProcUnit + "' ";
		        
			if ( sLobCd.length() > 0 )
				Sql += " and B.LOB_CD = '06'";
			logDebug("Sql(2) = " + Sql);
			/*
			SetSql(Sql);
	       	ExecSql();

			if (!GetResult(&pDBRows))
			{
				//ThrowQSException(QS_QSERVER_ERROR);
				RELEASE_DBROWS(pDBRows);
	                	return (QS_FAIL) ;
			}
			*/
			//conn=getConnection();
			dt=conn.executeQuery(Sql);
			//close(conn);
			
			//rowcount = (pDBRows->GetRowCount());
			rowcount = dt.size();
			if ( rowcount == 1 ) {
				/*
				GetColStr(pDBRows, "CUST_ID", szCustID);
				RELEASE_DBROWS(pDBRows);
				return QS_TRUE;
				*/
				dt.next();
				szCustID=(String)dt.getField("CUST_ID");
				return szCustID;
			}
		}

	        szCustID = "";
			//delete pDBRows;
	        //return QS_FALSE;
	        
	        return szCustID;
	    }catch (Exception ex) {
	            logDebug((Throwable) ex);
			    logDebug("IMParseMappingExtractor.FindCustIdFromSwf: "+ex.getMessage());
				//throw new Exception(ex.getMessage());
			    return szCustID;
	     }finally{
	    	 //close(conn);
	     }
	 }
	
//	 -----------------------------------------------------------------------
//	 Func  : FindCustIDFromName
//	 Input : Customer Name
//	 Output: CUST_ID if Customer Name found in GTDMAST1..CUST_LCL
//	         Empty String if Customer Name not found in database
//	 -----------------------------------------------------------------------
	private String FindCustIdFromName(String szName, String sProcUnit)
	{
		//IDataConnection  conn = null;
		DataTable dt;
		String szCustID="";
	    try{
			/*
			GT_DBRows* pDBRows;
			pDBRows = new GT_DBRows();
			*/
	        // GT_Value *pVal;
	        String Sql, tmpAddr;
	        int rowcount;
	        
	        //String szFixName = szName.Left(szName.Find("\r\n")); // any better way to do the search?
	        //szFixName.MakeUpper();
	        String szFixName=Left(szName, szName.indexOf("\r\n"));
	        szFixName=szFixName.toUpperCase();
	        
	        Sql = "select A.CUST_ID from GTDMAST1..CUST_LCL A ";
	        Sql +="where A.PROC_UNIT = '";
	        Sql +=sProcUnit + "' and upper(A.CUST_NM) = '";
	        Sql +=FixQuote1(szFixName) + "' and A.STATUS = 'A'";
	        
	        logDebug("FindCustIdFromName(): Sql:"+Sql);
	        /*
	        SetSql(Sql);
	        ExecSql();
			
	        if (!GetResult(&pDBRows))
	        {
					RELEASE_DBROWS(pDBRows);
	                WriteErrLog("Sql Error: [" + Sql + "]");
	                return (QS_FAIL) ;
	        }
	        */
	        //conn=getConnection();
	        dt=conn.executeQuery(Sql);
	        //close(conn);
	        
	        //rowcount = (pDBRows->GetRowCount());
	        rowcount = dt.size();
	        if ( rowcount > 0 ) {
	        		/*
	                GetColStr(pDBRows, "CUST_ID", szCustID);
	                delete (pDBRows);
	                return QS_TRUE;
	                */
	        		dt.next();
	        		szCustID=(String)dt.getField("CUST_ID");
	        }
	        
	        /*
	        szCustID = "";
			delete pDBRows;
	        return (QS_FALSE);
	        */
	        return szCustID;
	        
	     }catch (Exception ex) {
	            logDebug((Throwable) ex);
			    logDebug("IMParseMappingExtractor.FindCustIdFromName: "+ex.getMessage());
				//throw new Exception(ex.getMessage());
			    return szCustID;
	     }finally{
	    	 //close(conn);
	     }
	}
	
    protected void updSi_Msg_Q(String sProcUnit, String sQueueTyp, int iQueueID, int iErrMsg_ID, String sErr_Msg, long iAudID) throws ExtractorException {
        logDebug("start updSi_Msg_Q: " +  sProcUnit + ", " + iQueueID );
        
        //IDataConnection conn=null;
        
        try{
            
            //conn=getConnection();
            Hashtable params=new Hashtable();
            params.put(FIELD_PROC_UNIT, sProcUnit);
            params.put(FIELD_QUEUE_TYP, sQueueTyp);
            params.put(FIELD_QUEUE_ID, new Integer(iQueueID));
            params.put("ERRMSG_ID", new Integer(iErrMsg_ID));
            params.put("ERR_MSG", sErr_Msg);
            params.put(FIELD_INPUT_AUD_ID, new Long(iAudID));
            //params.put("TRAIL_MINUS_IND", sTrailMinusIND);
            //params.put("DIRECT_NOT_LINK_IND",sDirectNotLinkInd);
            
            conn.executeUpdate(_sSi_Msg_Q_Upd, params);
            
        }catch(Exception e) {
            
            logDebug((Throwable)e);
            throw new ExtractorException("update si_msg_q error");
            
        }
        finally {
            try{
                //if(conn!=null)
                //    conn.close();
            }
            catch(Exception e) {
                logDebug((Throwable)e);
            }
            
        }
        
    }
    
    //Substring x char from left
    protected String Left(String strInput, int index) {
     
        String strOutput="";
        int	strLength;
        //logDebug("start Left: " +  strInput + ", " + index);
        if(index<=0)
        	return strOutput;
        
        strLength = strInput.length();
        
        if (strLength >= index){
        	strOutput = strInput.substring(0, index);
        }else{
        	strOutput = strInput.substring(0, strLength);
        }
        
        return strOutput;
        
    }
    
    //Substring x char from right
    //eg. Right(ABCDE,2)=DE
    protected String Right(String strInput, int x) {
     
        String strOutput="";
        int	strLength;
        //logDebug("start Right: " +  strInput + ", " + index);
        if(x<=0)
        	return strOutput;			//return ""
        
        strLength = strInput.length();
        
        if (strLength >= x){
        	strOutput = strInput.substring(strLength-x);
        }else{
        	strOutput = strInput;		//return strInput if shorter than input
        }
        
        return strOutput;
        
    }
    
    //Substring mid from offset pos
    //eg. Mid(ABCDE,1)=BCDE
    protected String Mid(String strInput, int pos) {
     
        String strOutput="";
        int	strLength;
        //logDebug("start Left: " +  strInput + ", " + index);
        if(pos<=0){
        	strOutput=strInput;			//return strInput if pos<=0
        	return strOutput;
        }
        
        strLength = strInput.length();
        
        if (strLength >= pos){
        	strOutput = strInput.substring(pos);
        }else{
        	strOutput = "";				//return "" if pos>=strLength
        }
        
        return strOutput;
        
    }

    /*
    //Substring mid x char from offset pos 
    protected String Mid(String strInput, int pos, int x) {
     
        String strOutput="";
        int	strLength;
        //logDebug("start Left: " +  strInput + ", " + index);
        if(x<=0)
        	return strOutput;			//return ""
        
        if(pos<0){
        	pos=0;						//set offset=0 if <0
        }
        
        strLength = strInput.length();
        
        if(pos >=strLength){
        	strOutput = "";				//return "" if pos >= length
        }else if (strLength >= pos+x){
        	strOutput = strInput.substring(pos, pos+x);
        }else{
        	strOutput = strInput.substring(pos);	//return substring from pos, if strLength>pos, and pos+x longer than strInput
        }
        
        return strOutput;
        
    }
    */
    
    //Substring mid from offset startpos to offset endpos(exclusive)
    //eg. Mid(ABCDE,1,3)=BC
    protected String Mid(String strInput, int startpos, int endpos) {
     
        String strOutput="";
        int	strLength;
        //logDebug("start Left: " +  strInput + ", " + index);
        if(endpos<=0)
        	return "";
        
        if(startpos>=endpos)
        	return "";
        
        if(startpos<0){
        	startpos=0;						//set offset=0 if <0
        }
        
        strLength = strInput.length();
        
        if(startpos >=strLength){
        	strOutput = "";				//return "" if startpos >= length
        }else if (strLength >= endpos){
        	strOutput = strInput.substring(startpos, endpos);
        }else{
        	strOutput = strInput.substring(startpos);	//return substring from startpos, if strLength>startpos, and endpos longer than strInput
        }
        
        return strOutput;
        
    }
}
