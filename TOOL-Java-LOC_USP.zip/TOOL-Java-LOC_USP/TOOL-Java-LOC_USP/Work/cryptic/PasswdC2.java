package com.chase.infra.util.cryptic;

import java.security.*;
//import javax.crypto.*;
import java.io.*;
import com.chase.infra.util.*;

/**
*  PasswdC2 is same as PasswdC except that the encryption and decryption does not involve Bse64 encoding/decoding, which changes all characters to printable characters and the encoded String is read from a file of some specified format.

* Format of the file being read is: XXXYYYYYYZZZZZZZZ
* where XXX is three digits giving the length of YYYYYY
* and YYYYYY is any length from the encoded username + 2 (being first one original plain text length, and second first random number)
* and ZZZZZZ is same as YYYYYY but is for encoded password
*/

final public class PasswdC2 implements TextDecryptor {
        
        //String masterKey = "38965937604323463";
	String masterKey = "174304839203740120";
        int keyLen = masterKey.length();

        public PasswdC2(){
        }
        public PasswdC2(String _mkey){
                this.masterKey = _mkey;
        }
        
        public int get_slot (int _keyLen, int _slot){
                return (_slot + 1) % _keyLen;
        }

	public void setMasterKey(String _mk){
		this.masterKey = _mk;
	}

        final public String encrypt(String input) throws Exception {
                StringBuffer sb = new StringBuffer();
                char[] chars = input.toCharArray();
                char[] charsM = masterKey.toCharArray();
                double d = Math.random()*100000;
                int slot = (int)d;
                slot = get_slot(this.keyLen, slot);
                sb.append((char)input.length());
                sb.append((char)slot);
                for (int i=0; i<input.length(); i++){
                        int c = (int)chars[i] ^ (int)charsM[slot];
                        slot = get_slot(keyLen, slot);
                        sb.append((char)c);
                }
		try {
			writeOutEnc(new File(""));
		}catch (Exception e){
			throw new Exception ("Cannot Write Out Encoded String to a file");
		}
                return sb.toString();
        }

        final public String decrypt(String filename) throws Exception {

		String encString = getPart(filename, "password");
		return decryptDo(encString); 
        }
	final public String decryptUserName(String filename) throws Exception {
		String encString = getPart(filename, "user");
		return decryptDo(encString);
	}

	private String getPart(String filename, String str) throws Exception {
		String content = new String(readInEnc(new File(filename)));
		int userlen = Integer.parseInt(content.substring(0,3));
		if (str.equals("user")){
			return content.substring(3, userlen+3);
		}
		return content.substring(3+userlen);
	}

	private String decryptDo(String encStr) throws Exception {
                
		char[] chars = encStr.toCharArray();
                char[] charsM = masterKey.toCharArray();
                
		int len = (int)chars[0];
                int slot = (int)chars[1];
		//slot = get_slot(keyLen, slot);
		//System.out.println(len+"\n"+slot+"\n"+encStr+" "+encStr.length());

                StringBuffer sb = new StringBuffer();

		//slot--;
                for (int i=0; i<len; i++){
                        int c = (int)chars[i+2] ^ (int)charsM[slot];
                        slot = get_slot(keyLen, slot);
                        sb.append((char)c);
                }

                return sb.toString();
	}

	public static synchronized byte[] readInEnc(File f) throws Exception {
		FileInputStream fis = new FileInputStream(f);	
		//byte[] b = new byte[21];
		byte[] b = new byte[(int)f.length()];
		fis.read(b);
		return b;
	}

	public static synchronized void writeOutEnc(File f) throws Exception {
		System.out.println("PasswdC2.writeOutEnc(File) not implemented");
	}

        public static void main(String[] args) throws Exception {
                String plain = null;
                String encStr = "";
                String decStr = "";
		String mkey = null;
                String fileName = null;
                for (int i=args.length-1; i>0; i--){
                        String tmp = args[i-1];
                        if (tmp.equalsIgnoreCase("-f")){
                                        fileName = args[i];
                        }else if (tmp.equalsIgnoreCase("-p")){
                                        plain = args[i];
                        }else if (tmp.equalsIgnoreCase("-decode")){
					encStr = args[i];
                        }else if (tmp.equalsIgnoreCase("m")){
					mkey = args[i];
			}
                }
                PasswdC2 pc = new PasswdC2();
		if (mkey != null){
			pc.setMasterKey(mkey);
		}
		if (encStr.length()!=0){
			System.out.println("DECRYPT "+encStr);
			decStr = pc.decrypt(encStr);
			System.out.println("DECRYPTED "+decStr);
			System.exit(1);
		}
                if (plain==null){
                        System.out.println("USAGE: java classname -p plaintext [-f filename]");
                        System.exit(1);
                }
		encStr = pc.encrypt(plain);
		System.out.println("Encryption of "+plain+" gives <"+encStr+"> (length "+encStr.length()+")");
		//decStr = new PasswdC().decrypt(encStr);
		//System.out.println("Decryption of "+encStr+" gives <"+decStr+"> (length "+decStr.length()+")");
                decStr = pc.decrypt("/apps/uk/gts/javad3/src/java/com/chase/infra/util/cryptic/abcde");
                System.out.println("Decrypted : "+decStr);
        }
}
